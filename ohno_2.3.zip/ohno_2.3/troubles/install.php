<?php
/*****************************************************************************
 Ohno: The Trouble Checking Script
 Copyright (c) by Angela Sabas
 http://scripts.indisguise.org

 This script is made available for free download, use, and modification as
 long as this note remains intact and a link back to
 http://scripts.indisguise.org is given. It is hoped that the script will be
 useful, but does not guarantee that it will solve any problem or is free from
 errors of any kind. Users of this script are forbidden to sell or distribute
 the script in whole or in part without written and explicit permission from
 me, and users agree to hold me blameless from any liability directly or
 indirectly arising from the use of this script.

 For more information please view the readme.txt file.
******************************************************************************/
require_once( 'header.inc.php' );
require_once( 'config.inc.php' );
?>

<?php

if( isset( $_GET["done"] ) ) {
	$query = 'CREATE TABLE `' . $troubles_table . '` (' .
		'`siteurl` varchar(250) NOT NULL default \'\', ' .
		'`subject` varchar(250) NOT NULL default \'\', ' .
		'`status` int(3) NOT NULL default \'0\', ' .
		'`comments` text, ' .
		'`added` timestamp(14) NOT NULL, ' .
		'PRIMARY KEY  (`siteurl`,`subject`)' .
		') TYPE=MyISAM;';
	$query .= 'CREATE TABLE `' . $status_table . '` (' .
		'`troublesid` tinyint(3) NOT NULL auto_increment, ' .
		'`desc` varchar(255) NOT NULL default \'\', ' .
		'PRIMARY KEY  (`troublesid`) ' .
		') TYPE=MyISAM AUTO_INCREMENT=24; ';
	$query .= 'INSERT INTO `' . $status_table . '` VALUES (1, \'Dead link: 404 error\'); INSERT INTO `' . $status_table . '` VALUES (2, \'Dead link: 403 error\'); INSERT INTO `' . $status_table . '` VALUES (3, \'Dead link: site is not the fanlisting\'); INSERT INTO `' . $status_table . '` VALUES (4, \'Dead link: other\'); INSERT INTO `' . $status_table . '` VALUES (5, \'Navigation problem: Broken links to essential pages\'); INSERT INTO `' . $status_table . '` VALUES (6, \'Navigation problem: broken image map\'); INSERT INTO `' . $status_table . '` VALUES (7, \'Navigation problem: difficult/confusing\'); INSERT INTO `' . $status_table . '` VALUES (8, \'Navigation problem: other\'); INSERT INTO `' . $status_table . '` VALUES (9, \'Updating: no update for two months\'); INSERT INTO `' . $status_table . '` VALUES (10, \'Updating: No "last updated" date\'); INSERT INTO `' . $status_table . '` VALUES (11, \'Updating: Auto-add with neglect\'); INSERT INTO `' . $status_table . '` VALUES (12, \'Updating: JavaScript update date\'); INSERT INTO `' . $status_table . '` VALUES (13, \'Updating: other\'); INSERT INTO `' . $status_table . '` VALUES (14, \'TFL Link: no link\'); INSERT INTO `' . $status_table . '` VALUES (15, \'TFL Link: barely visible/hidden\'); INSERT INTO `' . $status_table . '` VALUES (16, \'TFL Link: outdated\'); INSERT INTO `' . $status_table . '` VALUES (17, \'TFL Link: opens within a frame\'); INSERT INTO `' . $status_table . '` VALUES (18, \'TFL Link: other\'); INSERT INTO `' . $status_table . '` VALUES (19, \'Rule-breaking: not asking for countries\'); INSERT INTO `' . $status_table . '` VALUES (20, \'Rule-breaking: not listing countries\'); INSERT INTO `' . $status_table . '` VALUES (21, \'Rule-breaking: requiring other information\'); INSERT INTO `' . $status_table . '` VALUES (22, \'Rule-breaking: rules that prohibit certain people from joining\'); INSERT INTO `' . $status_table . '` VALUES (23, \'Rule-breaking: badly-worded rules\'); INSERT INTO `' . $status_table . '` VALUES (24, \'Rule-breaking: other\'); INSERT INTO `' . $status_table . '` VALUES (25, \'Hiatus: date of return has passed significantly\'); INSERT INTO `' . $status_table . '` VALUES (26, \'Hiatus: no set date of return\'); INSERT INTO `' . $status_table . '` VALUES (27, \'Hiatus: other\'); INSERT INTO `' . $status_table . '` VALUES (28, \'Other\');';

	$queries = explode( ';', $query );

	$db_link = mysql_connect( $db_server, $db_user, $db_password )
		or die( 'Cannot connect to the MySQL server: ' .
			mysql_error() );
	mysql_select_db( $db_database )
		or die( 'Cannot select database: ' . mysql_error() );
	foreach( $queries as $q )
		if( $q )
			mysql_query( $q )
				or die( 'Cannot execute query: ' .
				mysql_error() );

	echo '<p><b>Database tables created successfully.</b></p>';

	}
else {
?>

	<p>
	You can automatically create your database table via this page.<br />
	<b>Please make sure that you have edited your config.inc.php file
	before doing this.</b>
	<br />
	<b>If you're done editing your config.inc.php file, click the
	button below.</b></p>

	<form action="<?= $_SERVER["PHP_SELF"] ?>" method="get">
	<input type="hidden" name="done" />
	<input type="submit" value="Create my Tables" />
	</form>

<?php
	}
require_once( 'footer.inc.php' );
?>