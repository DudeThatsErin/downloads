<?php
/*****************************************************************************
 Ohno: The Trouble Checking Script
 Copyright (c) by Angela Sabas
 http://scripts.indisguise.org

 This script is made available for free download, use, and modification as
 long as this note remains intact and a link back to
 http://scripts.indisguise.org is given. It is hoped that the script will be
 useful, but does not guarantee that it will solve any problem or is free from
 errors of any kind. Users of this script are forbidden to sell or distribute
 the script in whole or in part without written and explicit permission from
 me, and users agree to hold me blameless from any liability directly or
 indirectly arising from the use of this script.

 For more information please view the readme.txt file.
******************************************************************************/
session_start();
require_once( 'config.inc.php' );
if( !isset( $_SESSION["message"] ) )
   $_SESSION["message"] = '';
if( isset( $_COOKIE["ohno_login_" . $_SERVER['SERVER_NAME']] ) &&
   $_COOKIE["ohno_login_" . $_SERVER['SERVER_NAME']] == md5( $set_password . 'OHNO' ) ) {
   header( 'Location: admin_home.php' );
   die( 'Redirecting you...' );
   }

require_once( 'header.inc.php' );
?>

<p><span class="important"><?= htmlentities( $_SESSION["message"] ) ?></span></p>

<form action="admin_login.php" method="post">

<p>Please log in:</p>

<fieldset>
   <legend>Login</legend>
   
   <label for="login_password" id="labelPassword">Password</label>
   <input type="password" id="login_password" name="login_password" />
   <input type="checkbox" id="rememberme" name="rememberme" value="yes" />
   <label for="rememberme" id="labelRememberMe">Remember me?</label>
   
   <input type="submit" id="submit" value="Log in" />
   
</fieldset>

</form>

<?php
require_once( 'footer.inc.php' );
?>