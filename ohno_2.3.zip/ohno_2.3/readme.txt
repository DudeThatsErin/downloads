
Ohno 2.3
-----------------------------
Copyright (c) Angela Sabas
http://scripts.indisguise.org
=============================

Ohno is a tool primarily for fanlisting permanent trouble checkers to
easily create lists for the fanlistings they make trouble checks for, although
it can track lists of any kind that you need to keep tabs on. Checking for
broken links in a clique you own? Verifying submission entries? OhNo can do
what you need it to do.

This script is made available for free download, use, and modification as long
as this readme and other notes found throughout the script remains intact and
a link back to http://scripts.indisguise.org/ is given. It is hoped that
the script will be useful, but does not guarantee that it will solve any
problem or is free from errors of any kind. Users of this script are forbidden
to sell or distribute the script in whole or in part or offer paid
installation of this script without written and explicit permission from me,
and users agree to hold me blameless from any liability directly or indirectly
arising from the use of this script.

These terms may be subject to change at any time without prior notice and will
still hold true for any earlier versions of the script and for any user of
any version of the script.


Features:
---------
. Automatically create a list of entries possibly in trouble using the database
  information
. List is sorted by trouble type, then alphabetically, or use a template
  for delimited lists (easy insertion into Microsoft Excel)
. Trouble types are stored in the database and only need to be selected from
  a list
. Easily reset and/or delete all entries stored
. Search feature searches entries stored in the database by looking at URLs
  and/or subjects
. Easily delete or edit a single entry
. Easily find out which entry you last added or edited
. View all entries entered in database in an organized table format
. Add comments/extra information if needed (i.e., for "Other" trouble
  information)
. Login/logout system for security
. "Remember me" feature, direct redirect from index page to the main page if
  user is still logged in via the "remember me" feature
. Email the generated troubles list directly from the script
. Ability to set how the entries' links inside the script is opened (same
  or new window)
. Ability to customize the troubles list into any sort of status or
  category list


What's new:
-----------
See changelog.txt


Requirements:
-------------
PHP 4.3.0
MySQL 4.1.x


Installation/configuration:
---------------------------
See install.txt


Upgrading:
----------
See upgrade.txt


Contact information:
--------------------
You may email me at scripts@indisguise.org or use the form at
http://scripts.indisguise.org/contact/