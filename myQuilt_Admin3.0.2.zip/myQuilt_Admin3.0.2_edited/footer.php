<!-- 
footer.php
This file should contain whatever you want to be displayed at the bottom of EVERY page.
You can configure this file however you want!
-->
	</div>
	<div id="footer">
		Images &copy; <a href="http://theqbee.net/" target="_blank" title="The Quilting Bee">The Quilting Bee</a>
	</div>
</div>
</body>
</html>
