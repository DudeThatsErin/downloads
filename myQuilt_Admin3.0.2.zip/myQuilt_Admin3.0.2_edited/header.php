<!--
header.php
This file should contain whatever you want to be displayed at the top of EVERY page.
You can configure this file however you want!
-->

<!DOCTYPE html
PUBLIC "-//W3C//DTD XHTML 1.1//EN"
"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>Welcome to my Quilt</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
<div id="wrap">
	<div id="header"><a href="index.php" title="Welcome to my Quilt"><img src="images/header.gif" alt="Welcome to my Quilt" width="601" height="80" /></a></div>
	<div id="content">

