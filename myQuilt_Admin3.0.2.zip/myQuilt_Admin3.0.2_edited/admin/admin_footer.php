	</div>
</div>

<hr />

<p class="bottom"<?= (strstr($_SERVER['PHP_SELF'], "/admin/index.php") || strstr($_SERVER['PHP_SELF'], "/admin/sendpass.php") ? " id=\"short\"" : "") ?>>Script by <a href="http://www.bubblessoc.net" title="Bubs @ BubblesSOC.Net">Bubs</a> for the <a href="http://www.theqbee.net/" title="The Quilting Bee">Quilting Bee</a></p>
</body>
</html>