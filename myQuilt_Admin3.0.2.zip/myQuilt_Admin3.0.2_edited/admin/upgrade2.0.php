<?php

/*******************************************************************************
*
*	UPGRADE MYQUILT ADMIN FROM 2.0
*
*******************************************************************************/

include("config.php");

$page_title = " &rsaquo; Upgrade MyQuilt Admin";

$path = $_SERVER['DOCUMENT_ROOT']."/";

if ($_GET['action'] == "step1") {
	// STEP 1
	
	$page_title .= " &rsaquo; Step 1";
	include("admin_header.php");
?>

<h1>Step 1: Root Patch Folder</h1>
<form action="?action=step2" method="post">
<fieldset class="directory">
	<legend>Root Patch Folder</legend>
	<ol>
		<li>
			<label for="root_f"><code><?= $path ?></code></label>
			<input name="root" id="root_f" />
		</li>
	</ol>
</fieldset>
<p><input type="submit" value="Step 2 &raquo;" /></p>
</form>

<?php
	include("admin_footer.php");
	exit;
}

if ($_GET['action'] == "step2") {
	// STEP 2
	
	$root = trim(cleanUp($_POST['root']), "/");
	
	if (!is_dir($path.$root)) {
		$page_title .= " &rsaquo; Step 1 &rsaquo; Error";
		include("admin_header.php");
		echo "<h1>Error</h1>\n";
		echo "<p>The directory <code>$path$root</code> does not exist.  Please <a href=\"javascript:history.back()\" title=\"Go Back\">go back</a> and try again.</p>\n";
	}
	elseif (!is_writable($path.$root)) {
		$page_title .= " &rsaquo; Step 1 &rsaquo; Error";
		include("admin_header.php");
		echo "<h1>Error</h1>\n";
		echo "<p>The directory <code>$path$root</code> is not writable.  Please <a href=\"javascript:history.back()\" title=\"Go Back\">go back</a> and try again.</p>\n";
	}
	else {
		$page_title .= " &rsaquo; Step 2";
		include("admin_header.php");
?>

<h1>Step 2: Secondary Patch Folders</h1>
<p>These values can be changed later.  It is highly recommended to store each patch type in its own folder.</p>

<form action="?action=step3" method="post">
<input type="hidden" name="root" value="<?= $root ?>" />
<fieldset class="directory">
	<legend>Required Patch Folder</legend>
	<ol>
		<li>
			<label for="required_f"><code><?= $path.$root."/" ?></code></label>
			<input name="required" id="required_f" />
		</li>
	</ol>
</fieldset>

<fieldset class="directory">
	<legend>Member Patch Folder</legend>
	<ol>
		<li>
			<label for="member_f"><code><?= $path.$root."/" ?></code></label>
			<input name="member" id="member_f" />
		</li>
	</ol>
</fieldset>

<fieldset class="directory">
	<legend>Miscellaneous Patch Folder</legend>
	<ol>
		<li>
			<label for="misc_f"><code><?= $path.$root."/" ?></code></label>
			<input name="misc" id="misc_f" />
		</li>
	</ol>
</fieldset>

<p><input type="submit" value="Step 3 &raquo;" /></p>
</form>

<?php
	}

	include("admin_footer.php");
	exit;
}

if ($_GET['action'] == "step3") {
	// STEP 3
	
	$root = trim(cleanUp($_POST['root']), "/");
	$required = trim(cleanUp($_POST['required']), "/");
	$member = trim(cleanUp($_POST['member']), "/");
	$misc = trim(cleanUp($_POST['misc']), "/");
	
	if ($required == "" || $member == "" || $misc == "") {
		$page_title .= " &rsaquo; Step 2 &rsaquo; Error";
		include("admin_header.php");
		echo "<h1>Error</h1>\n";
		echo "<p>You forgot to complete the required form fields.  Please <a href=\"javascript:history.back()\" title=\"Go Back\">go back</a> and try again.</p>\n";
	}
	elseif (!is_dir($path.$root) || !is_dir($path.$root."/".$required) || !is_dir($path.$root."/".$member) || !is_dir($path.$root."/".$misc)) {
		$page_title .= " &rsaquo; Step 2 &rsaquo; Error";
		include("admin_header.php");
		echo "<h1>Error</h1>\n";
		echo "<p>The directory <code>".$path;
		
		if (!is_dir($path.$root))
			echo $root;
			
		elseif (!is_dir($path.$root."/".$required))
			echo $root."/".$required;
			
		elseif (!is_dir($path.$root."/".$member))
			echo $root."/".$member;
			
		elseif (!is_dir($path.$root."/".$misc))
			echo $root."/".$misc;
		
		echo "</code> does not exist.  Please <a href=\"javascript:history.back()\" title=\"Go Back\">go back</a> and try again.</p>\n";
	}
	elseif (!is_writable($path.$root) || !is_writable($path.$root."/".$required) || !is_writable($path.$root."/".$member) || !is_writable($path.$root."/".$misc)) {
		$page_title .= " &rsaquo; Step 2 &rsaquo; Error";
		include("admin_header.php");
		echo "<h1>Error</h1>\n";
		echo "<p>The directory <code>".$path;
		
		if (!is_writable($path.$root))
			echo $root;
			
		elseif (!is_writable($path.$root."/".$required))
			echo $root."/".$required;
			
		elseif (!is_writable($path.$root."/".$member))
			echo $root."/".$member;
			
		elseif (!is_writable($path.$root."/".$misc))
			echo $root."/".$misc;
		
		echo "</code> is not writable.  Please <a href=\"javascript:history.back()\" title=\"Go Back\">go back</a> and try again.</p>\n";
	}
	else {
		// Create Tables
		$page_title .= " &rsaquo; Steps 3 &amp; 4";
		include("admin_header.php");
		echo "<h1>Step 3: Creating New Tables</h1>\n";
		echo "<p>If you receive an error, <a href='javascript:history.back()'>go back</a> and try again.</p>\n";
		
		echo "<ol>\n";
		
		// Admin
		if (!tableExists("admin")) {
			echo "\t<li>Creating <code>".TABLE_PREFIX."admin</code> table...";
			
			// Create Admin Table
			$query = "CREATE TABLE ".TABLE_PREFIX."admin (
					id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
					version text NOT NULL,
					username text NOT NULL,
					password text NOT NULL,
					member_num int(11) NOT NULL,
					name text NOT NULL,
					email text NOT NULL,
					html_email tinyint(1) DEFAULT '1' NOT NULL,
					patch_naming enum('name#', '#name', '#') DEFAULT 'name#' NOT NULL,
					date_format text NOT NULL,
					time_format text NOT NULL,
					time_offset float DEFAULT '0' NOT NULL,
					patch_dir text NOT NULL
				);";
			
			mysql_query($query) or die("<strong>Error:</strong> Couldn't create table <code>".TABLE_PREFIX."admin</code>: <br />".mysql_error());
			echo " <strong>Success!</strong></li>\n";
		}
		else
			echo "\t<li><code>".TABLE_PREFIX."admin</code> table already created successfully.</li>";
		
		// Blog
		if (!tableExists("blog")) {
			echo "\t<li>Creating <code>".TABLE_PREFIX."blog</code> table...";
			
			// Create Blog Table
			$query = "CREATE TABLE ".TABLE_PREFIX."blog (
				id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				title text NOT NULL,
				content text NOT NULL,
				post_date datetime NOT NULL,
				edit_date datetime NOT NULL
			);";
			
			mysql_query($query) or die("<strong>Error:</strong> Couldn't create table <code>".TABLE_PREFIX."blog</code>: <br />".mysql_error());
			echo " <strong>Success!</strong></li>\n";
		}
		else
			echo "\t<li><code>".TABLE_PREFIX."blog</code> table already created successfully.</li>";
			
		// Categories
		if (!tableExists("categories")) {
			echo "\t<li>Creating <code>".TABLE_PREFIX."categories</code> table...";
			
			// Create Categories Table
			$query = "CREATE TABLE ".TABLE_PREFIX."categories (
				catId int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				cat_name text NOT NULL,
				cat_desc text NOT NULL,
				folder_name text NOT NULL,
				use_fillers tinyint(1) DEFAULT '0' NOT NULL,
				filler_url text NOT NULL,
				filler_alt text NOT NULL,
				use_alt tinyint(1) DEFAULT '0' NOT NULL,
				alt_url text NOT NULL,
				alt_alt text NOT NULL,
				sort_by enum('displayId', 'member_name', 'member_num', 'date_received') DEFAULT 'date_received' NOT NULL,
				sort_how enum('asc', 'desc') DEFAULT 'desc' NOT NULL,
				perline int(11) DEFAULT '5' NOT NULL,
				perpage int(11) DEFAULT '-1' NOT NULL
			);";
			
			mysql_query($query) or die("<strong>Error:</strong> Couldn't create table <code>".TABLE_PREFIX."categories</code>: <br />".mysql_error());
			echo " <strong>Success!</strong></li>\n";
		}
		else
			echo "\t<li><code>".TABLE_PREFIX."categories</code> table already created successfully.</li>";
			
		// Patches
		if (!tableExists("patches")) {
			echo "\t<li>Creating <code>".TABLE_PREFIX."patches</code> table...";
			
			// Create Patches Table
			$query = "CREATE TABLE ".TABLE_PREFIX."patches (
					patchId int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
					catId int(11) NOT NULL,
					displayId int(11) NOT NULL,
					member_name text NOT NULL,
					member_num int(11) DEFAULT '-1' NOT NULL,
					member_email text NOT NULL,
					patch_url text NOT NULL,
					patch_img_url text NOT NULL,
					patch_stored text NOT NULL,
					patch_desc text NOT NULL,
					date_received datetime NOT NULL,
					isApproved tinyint(1) DEFAULT '0' NOT NULL
			);";
			
			mysql_query($query) or die("<strong>Error:</strong> Couldn't create table <code>".TABLE_PREFIX."patches</code>: <br />".mysql_error());
			echo " <strong>Success!</strong></li>\n";
		}
		else
			echo "\t<li><code>".TABLE_PREFIX."patches</code> table already created successfully.</li>";
			
		echo "</ol>\n\n";
		
		echo "<h1>Step 4: Importing Old Information</h1>\n";
		echo "<ol>\n";
		
		// Import Admin Info
		$query = "SELECT * FROM admin WHERE id = '1' LIMIT 1";
		$result = mysql_query($query) or die("<strong>Error:</strong> Couldn't retrieve data from <code>admin</code> table:<br />".mysql_error());
		
		$row = mysql_fetch_array($result);
		
		if (mysql_num_rows(mysql_query("SELECT * FROM ".TABLE_PREFIX."admin")) < 1) {
			echo "\t<li>Importing Admin information...";
			
			$query = "INSERT INTO ".TABLE_PREFIX."admin 
				(version, username, password, member_num, name, email, html_email, patch_naming, date_format, time_format, patch_dir) VALUES (
					'".MQA_VERSION."',
					'".escape($row['username'])."',
					'".escape($row['password'])."',
					'".escape($row['member_num'])."',
					'".escape($row['name'])."',
					'".escape($row['email'])."',
					'".($row['html_email'] == "y" ? 1 : 0)."',
					'".escape($row['patch_naming'])."',
					'".escape($row['date_format'])."',
					'g:i a',
					'".escape($root)."'
			)";
				
			mysql_query($query) or die("<strong>Error:</strong> Couldn't insert data into <code>".TABLE_PREFIX."admin</code> table:<br />".mysql_error());
			
			echo " <strong>Success!</strong></li>\n";
		}
		else
			echo "\t<li>Admin information already imported successfully.</li>\n";
		
		$sort_members_by = $row['sort_by'];	// id DESC, id ASC, member_num DESC, member_num ASC
		$use_fillers = $row['use_fillers'];	// y,n
		$filler_url = $row['filler_url'];
		$filler_alt = $row['filler_alt'];
		$misc_filler_url = $row['misc_filler_url'];
		$misc_filler_alt = $row['misc_filler_alt'];
		$use_alt = $row['use_alt'];		// y,n
		$alt_url = $row['alt_url'];
		$alt_alt = $row['alt_alt'];
		$perpage = $row['perpage'];
		$perline = $row['perline'];
		
		// Create Required Cat
		if (mysql_num_rows(mysql_query("SELECT * FROM ".TABLE_PREFIX."categories WHERE catId = '1'")) < 1) {
			echo "\t<li>Creating <em>Required</em> category...";
			
			$query = "INSERT INTO ".TABLE_PREFIX."categories (catId, cat_name, cat_desc, folder_name, sort_by, sort_how, perline, perpage) VALUES (
					1,
					'Required',
					'The first three patches on your quilt.',
					'".escape($required)."',
					'displayId',
					'asc',
					'".escape($perline)."',
					'".escape($perpage)."'
			);";
			
			mysql_query($query) or die("<strong>Error:</strong> Couldn't insert data into <code>".TABLE_PREFIX."categories</code> table:<br />".mysql_error());
			
			echo " <strong>Success!</strong></li>\n";
		}
		else
			echo "\t<li><em>Required</em> category already created successfully.</li>\n";
		
		// Create Member Cat
		if (mysql_num_rows(mysql_query("SELECT * FROM ".TABLE_PREFIX."categories WHERE catId = '2'")) < 1) {
			echo "\t<li>Creating <em>Member</em> category...";
			
			$query = "INSERT INTO ".TABLE_PREFIX."categories (catId, cat_name, cat_desc, folder_name, use_fillers, filler_url, filler_alt, use_alt, alt_url, alt_alt, sort_by, sort_how, perline, perpage) VALUES (
					2,
					'Member',
					'Qbee member patches.',
					'".escape($member)."',
					'".($use_fillers == "y" ? 1 : 0)."',
					'".escape($filler_url)."',
					'".escape($filler_alt)."',
					'".($use_alt == "y" ? 1 : 0)."',
					'".escape($alt_url)."',
					'".escape($alt_alt)."',";
					
			switch ($sort_members_by)
			{
				case "id DESC":
					$query .= "'displayId', 'desc'";
					break;
				case "member_num DESC":
					$query .= "'member_num', 'desc'";
					break;
				case "member_num ASC":
					$query .= "'member_num', 'asc'";
					break;
				default:
					$query .= "'displayId', 'asc'";
					break;
			}
			
			$query .= ", '".escape($perline)."'";
			$query .= ", '".escape($perpage)."'";
			$query .= ");";
			
			mysql_query($query) or die("<strong>Error:</strong> Couldn't insert data into <code>".TABLE_PREFIX."categories</code> table:<br />".mysql_error());
			
			echo " <strong>Success!</strong></li>\n";
		}
		else
			echo "\t<li><em>Member</em> category already created successfully.</li>\n";
			
		// Create Misc Cat
		echo "\t<li>Creating <em>Misc</em> category...";
			
		$query = "INSERT INTO ".TABLE_PREFIX."categories (cat_name, cat_desc, folder_name, use_fillers, filler_url, filler_alt, use_alt, alt_url, alt_alt, sort_by, sort_how, perline, perpage) VALUES (
				'Miscellaneous',
				'Miscellaneous patches.',
				'".escape($misc)."',
				'".($use_fillers == "y" ? 1 : 0)."',
				'".escape($misc_filler_url)."',
				'".escape($misc_filler_alt)."',
				'".($use_alt == "y" ? 1 : 0)."',
				'".escape($alt_url)."',
				'".escape($alt_alt)."',
				'displayId',
				'asc',
				'".escape($perline)."',
				'".escape($perpage)."'
		);";
		
		mysql_query($query) or die("<strong>Error:</strong> Couldn't insert data into <code>".TABLE_PREFIX."categories</code> table:<br />".mysql_error());
		$misc_cat_id = mysql_insert_id();
		
		echo " <strong>Success!</strong></li>\n";
		
		// Import Required Patches
		$query = "SELECT * FROM required ORDER BY id ASC";
		$result = mysql_query($query) or die("<strong>Error:</strong> Couldn't retrieve data from <code>required</code> table:<br />".mysql_error());
		
		// Delete old required table data
		mysql_query("DELETE FROM ".TABLE_PREFIX."patches WHERE catId = '1'") or die("<strong>Error:</strong> Couldn't delete old data in <code>".TABLE_PREFIX."patches</code> table:<br />".mysql_error());
		
		echo "\t<li>Importing <em>Required</em> patches...";
		
		$i = 1;
		while ($row = mysql_fetch_array($result)) {
			// id, patch_stored, url, alt_tag
			$query = "INSERT INTO ".TABLE_PREFIX."patches (catId, patch_url, patch_img_url, patch_stored, patch_desc, date_received, isApproved) VALUES (
				'1',
				'".escape($row['url'])."',
				'".escape($row['patch_stored'])."',
				'".escape(basename($row['patch_stored']))."',
				'".escape($row['alt_tag'])."',
				'".TODAY."',
				'1'
			);";
			
			mysql_query($query) or die("<strong>Error:</strong> Couldn't insert data into <code>".TABLE_PREFIX."patches</code> table:<br />".mysql_error());
			
			// Update displayId
			$query = "UPDATE ".TABLE_PREFIX."patches SET displayId = '$i' WHERE patchId = '".mysql_insert_id()."'";
			mysql_query($query) or die("<strong>Error:</strong> Couldn't update data in <code>".TABLE_PREFIX."patches</code> table:<br />".mysql_error());
			$i++;
		}
		
		echo " <strong>Success!</strong></li>\n";
			
		// Import Member Patches
		$query = "SELECT * FROM members ORDER BY id ASC";
		$result = mysql_query($query) or die("<strong>Error:</strong> Couldn't retrieve data from <code>members</code> table:<br />".mysql_error());
		
		// Delete old member table data
		mysql_query("DELETE FROM ".TABLE_PREFIX."patches WHERE catId = '2'") or die("<strong>Error:</strong> Couldn't delete old data in <code>".TABLE_PREFIX."patches</code> table:<br />".mysql_error());
		
		echo "\t<li>Importing <em>Member</em> patches...";
		
		$i = 1;
		while ($row = mysql_fetch_array($result)) {
			// id, name, email, member_num, url, patch_stored, alt_tag, appr, trade_date
			$query = "INSERT INTO ".TABLE_PREFIX."patches (catId, member_name, member_email, member_num, patch_url, patch_stored, patch_desc, date_received, isApproved) VALUES (
				'2',
				'".escape($row['name'])."',
				'".escape($row['email'])."',
				'".escape($row['member_num'])."',
				'".escape($row['url'])."',
				'".escape($row['patch_stored'])."',
				'".escape($row['alt_tag'])."',
				'".escape($row['trade_date'])."',
				'".($row['appr'] == "y" ? 1 : 0)."'
			);";
			
			mysql_query($query) or die("<strong>Error:</strong> Couldn't insert data into <code>".TABLE_PREFIX."patches</code> table:<br />".mysql_error());
			
			// Update displayId
			$query = "UPDATE ".TABLE_PREFIX."patches SET displayId = '$i' WHERE patchId = '".mysql_insert_id()."'";
			mysql_query($query) or die("<strong>Error:</strong> Couldn't update data in <code>".TABLE_PREFIX."patches</code> table:<br />".mysql_error());
			$i++;
		}
		
		echo " <strong>Success!</strong></li>\n";
		
		// Import Misc Patches
		$query = "SELECT * FROM misc ORDER BY id ASC";
		$result = mysql_query($query) or die("<strong>Error:</strong> Couldn't retrieve data from <code>misc</code> table:<br />".mysql_error());
		
		echo "\t<li>Importing <em>Misc</em> patches...";
		
		$i = 1;
		while ($row = mysql_fetch_array($result)) {
			// id, url, patch_stored, alt_tag, date_received
			$query = "INSERT INTO ".TABLE_PREFIX."patches (catId, patch_url, patch_stored, patch_desc, date_received, isApproved) VALUES (
				'$misc_cat_id',
				'".escape($row['url'])."',
				'".escape($row['patch_stored'])."',
				'".escape($row['alt_tag'])."',
				'".escape($row['date_received'])."',
				'1'
			);";
			
			mysql_query($query) or die("<strong>Error:</strong> Couldn't insert data into <code>".TABLE_PREFIX."patches</code> table:<br />".mysql_error());
			
			// Update displayId
			$query = "UPDATE ".TABLE_PREFIX."patches SET displayId = '$i' WHERE patchId = '".mysql_insert_id()."'";
			mysql_query($query) or die("<strong>Error:</strong> Couldn't update data in <code>".TABLE_PREFIX."patches</code> table:<br />".mysql_error());
			$i++;
		}
		
		echo " <strong>Success!</strong></li>\n";
		
		echo "</ol>\n";
		
		echo "<h1>Upgrade Complete</h1>\n";
		echo "<p>You can now <a href='index.php' title='Login'>login</a>.  <strong>Don't forget</strong> to delete this file from your server!</p>\n";
	}
	
	include("admin_footer.php");
	exit;
}

// START

include("admin_header.php");
?>

<h1>Upgrade MyQuilt Admin from 2.1/2.2/2.3</h1>

<h2>IMPORTANT!</h2>
<p>This version of MyQuilt Admin relies on categories to sort your patches.  
These categories are equivalent to folders/directories on your server.  
When you upgrade to MyQuilt Admin 3.0, two default categories are automatically created &mdash; <em>Required</em> and <em>Member</em>.
These categories can be edited but not deleted.
All other categories are created by you.</p>
<p>I recommend creating a root patch folder to contain the category folders.</p>

<h2>Example</h2>
<pre>
/qbee directory
	/patches (root patch folder)
		/required
		/member
		/misc
		/activity_1
		/activity_2
</pre>

<p>In the previous example, the <em>patches</em> subfolders (category folders) will be automatically created by the script.
The root patch folder must be writable for this script to run correctly.</p>

<h2><a href="?action=step1" title="Begin Upgrade">Begin Upgrade &raquo;</a></h2>

<?php
include("admin_footer.php");
?>
