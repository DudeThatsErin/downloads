<?php
/*******************************************************************************
*
*	UPGRADE MYQUILT ADMIN FROM 3.0.*
*
*******************************************************************************/

include("config.php");

$page_title = " &rsaquo; Upgrade MyQuilt Admin";

/* Checks */
if (!isInstalled()) {
	include("admin_header.php");
	echo "<h1>Error</h1>\n";
	echo "<p>You're in the wrong place!  You either need to <a href=\"install.php\" title=\"Install MyQuilt Admin\">install</a> or <a href=\"upgrade2.0.php\" title=\"Upgrade MyQuilt Admin\">upgrade from 2.1/2.2/2.3</a>.  This script is for users running 3.0.* only.</p>\n";
	include("admin_footer.php");
	exit;
}

if (isDbCurrent()) {
	include("admin_header.php");
	echo "<h1>Error</h1>\n";
	echo "<p>You are currently running the latest version of MyQuilt Admin (".MQA_VERSION.")!</p>\n";
	include("admin_footer.php");
	exit;
}

if ($_GET['action'] == "step1") {
	// STEP 1
	
	$page_title .= " &rsaquo; Step 1";
	include("admin_header.php");
	
	echo "<ol>\n";
	
	// Add `version` to admin
	echo "\t<li>Adding <code>`version`</code> field to <code>".TABLE_PREFIX."admin</code> table...";
	
	mysql_query("ALTER TABLE `".TABLE_PREFIX."admin` ADD `version` text NOT NULL;") or die("<strong>Error:</strong> Couldn't add <code>`version`</code> field to <code>".TABLE_PREFIX."admin</code> table:<br />".mysql_error());
	
	echo " <strong>Success!</strong></li>\n";
	
	// Insert version #
	echo "\t<li>Inserting version number into <code>".TABLE_PREFIX."admin</code> table...";
	
	if (!mysql_query("UPDATE ".TABLE_PREFIX."admin SET version = '".MQA_VERSION."' WHERE id = '1'")) {
		mysql_query("ALTER TABLE `".TABLE_PREFIX."admin` DROP `version`"); 
		echo "<strong>Error:</strong> Couldn't insert version number into <code>".TABLE_PREFIX."admin</code> table:<br />".mysql_error();
		exit;
	}
	
	echo " <strong>Success!</strong></li>\n";
	
	// Add `perline` and `perpage` to categories
	echo "\t<li>Adding <code>`perline`</code> and <code>`perpage`</code> fields to <code>".TABLE_PREFIX."categories</code> table...";
	
	if (!mysql_query("ALTER TABLE `".TABLE_PREFIX."categories` ADD `perline` INT NOT NULL DEFAULT '5', ADD `perpage` INT NOT NULL DEFAULT '-1';")) {
		mysql_query("ALTER TABLE `".TABLE_PREFIX."admin` DROP `version`");
		echo "<strong>Error:</strong> Couldn't add <code>`perpage`</code> and <code>`perline`</code> fields to <code>".TABLE_PREFIX."categories</code> table:<br />".mysql_error();
		exit;
	}
	
	echo " <strong>Success!</strong></li>\n";
	
	echo "</ol>\n";
	
	echo "<h1>Upgrade Complete</h1>\n";
	echo "<p>You can now <a href='index.php' title='Login'>login</a>.  <strong>Don't forget</strong> to delete this file from your server!</p>\n";
	
	include("admin_footer.php");
	exit;
}

// START

include("admin_header.php");
?>

<h1>Upgrade MyQuilt Admin from 3.0.0/3.0.1</h1>
<p>This script will upgrade your database for version 3.0.2.</p>

<h2><a href="?action=step1" title="Begin Upgrade">Begin Upgrade &raquo;</a></h2>

<?php
include("admin_footer.php");
?>
