<?php

/*******************************************************************************
*
*	INSTALL MYQUILT ADMIN
*
*******************************************************************************/

include("config.php");

$page_title = " &rsaquo; Install MyQuilt Admin";

$path = $_SERVER['DOCUMENT_ROOT']."/";

if ($_GET['action'] == "step1") {
	// STEP 1
	
	$page_title .= " &rsaquo; Step 1";
	include("admin_header.php");
?>

<h1>Step 1: Admin Information</h1>
<form action="?action=step2" method="post">
<fieldset>
	<legend>Login Information</legend>
	<ol>
		<li>
			<label for="username">Username</label>
			<input type="text" name="username" id="username" />
		</li>
		<li>
			<label for="password">Password</label>
			<input type="password" name="password" id="password" />
		</li>
		<li>
			<label for="pass_check">Re-Type Password</label>
			<input type="password" name="pass_check" id="pass_check" />
		</li>
	</ol>
</fieldset>

<fieldset>
	<legend>Your Information</legend>
	<ol>
		<li>
			<label for="name">Name</label>
			<input name="name" id="name" />
		</li>
		<li>
			<label for="email">Email</label>
			<input name="email" id="email" />
		</li>
		<li>
			<label for="member_num">Member #</label>
			<input name="member_num" id="member_num" size="3" class="auto" />
		</li>
		<li class="radio">
			<p class="question">What type of email do you want to receive when someone requests to trade?</p>
			<input type="radio" name="html_email" id="html_email_y" value="1" />
			<label for="html_email_y">HTML</label>
			<input type="radio" name="html_email" id="html_email_n" value="0" />
			<label for="html_email_n">Plain Text</label>
		</li>
	</ol>
</fieldset>

<fieldset>
	<legend style="margin-bottom: 0;">Quilt Preferences</legend>
	<ol>
		<li class="radio">
			<p class="question">How do you want your member patches to be named?</p>
			<input type="radio" name="patch_naming" id="name_num" value="name#" class="radio" />
			<label for="name_num">bubs77.gif</label><br />
			<input type="radio" name="patch_naming" id="num_name" value="#name" class="radio" />
			<label for="num_name">77bubs.gif</label><br />
			<input type="radio" name="patch_naming" id="num" value="#" class="radio" />
			<label for="num">77.gif</label>
		</li>
		<li>
			<p class="time"><span><abbr title="Greenwich Mean Time">GMT</abbr></span> <code><?= gmdate("Y-m-d h:i:s a") ?></code></p>
			<label for="time_offset">Time Offset</label>
			<input name="time_offset" id="time_offset" class="auto" size="3" />
		</li>
		<li>
			<label for="date_format">Date Format</label>
			<input name="date_format" id="date_format" />
			<p class="note">Example: n/j/y (<a href="http://php.net/date/" title="Date format information">Date format info</a>)</p>
		</li>
		<li>
			<label for="time_format">Time Format</label>
			<input name="time_format" id="time_format" />
			<p class="note">Example: g:i a (<a href="http://php.net/date/" title="Time format information">Time format info</a>)</p>
		</li>
	</ol>
</fieldset>

<fieldset class="directory">
	<legend>Root Patch Directory</legend>
	<ol>
		<li>
			<label for="patch_dir"><code><?= $path ?></code></label>
			<input name="patch_dir" id="patch_dir" />
		</li>
	</ol>
</fieldset>

<p><input type="submit" value="Step 2 &raquo;" /></p>
</form>

<?php
	include("admin_footer.php");
	exit;
}

if ($_GET['action'] == "step2") {
	// STEP 2
	
	$username = cleanUp($_POST['username']);
	$password = md5($_POST['password']);
	
	$name = cleanUp($_POST['name']);
	$email = cleanUp($_POST['email']);
	$member_num = cleanUp($_POST['member_num']);
	
	$html_email = $_POST['html_email'];
	
	if ($html_email != 0)
		$html_email = 1;
	
	$patch_naming = $_POST['patch_naming'];
	
	if ($patch_naming != "#name" && $patch_naming != "#")
		$patch_naming = "name#";
	
	$time_offset = cleanUp($_POST['time_offset']);
	
	if (!is_numeric($time_offset))
		$time_offset = 0;
	
	$date_format = cleanUp($_POST['date_format']);
	$time_format = cleanUp($_POST['time_format']);
	$patch_dir = trim(cleanUp($_POST['patch_dir']), "/");
	
	if ($username == "" || $_POST['password'] == "" || $name == "" || $email == "" || $member_num == "" || $time_offset == "" || $date_format == "" || $time_format == "") {
		$page_title .= " &rsaquo; Step 1 &rsaquo; Error";
		include("admin_header.php");
		echo "<h1>Error</h1>\n";
		echo "<p>You forgot to complete the required form fields.  Please <a href=\"javascript:history.back()\" title=\"Go Back\">go back</a> and try again.</p>\n";
	}
	
	elseif (!isProperUsername($username)) {
		$page_title .= " &rsaquo; Step 1 &rsaquo; Error";
		include("admin_header.php");
		echo "<h1>Error</h1>\n";
		echo "<p>Your username must contain only letters, digits, hyphens, or underscores.  Please <a href=\"javascript:history.back()\" title=\"Go Back\">go back</a> and try again.</p>\n";
	}
		
	elseif (strcmp($_POST['password'], $_POST['pass_check']) != 0) {
		$page_title .= " &rsaquo; Step 1 &rsaquo; Error";
		include("admin_header.php");
		echo "<h1>Error</h1>\n";
		echo "<p>Your confirmed password did not match your chosen password.  Please <a href=\"javascript:history.back()\" title=\"Go Back\">go back</a> and try again.</p>\n";
	}
		
	elseif (!validEmail($email)) {
		$page_title .= " &rsaquo; Step 1 &rsaquo; Error";
		include("admin_header.php");
		echo "<h1>Error</h1>\n";
		echo "<p>Your email address is invalid.  Please <a href=\"javascript:history.back()\" title=\"Go Back\">go back</a> and try again.</p>\n";
	}
	
	elseif (!is_numeric($member_num) || $member_num < 1 || $member_num > 350) {
		$page_title .= " &rsaquo; Step 1 &rsaquo; Error";
		include("admin_header.php");
		echo "<h1>Error</h1>\n";
		echo "<p>Your member number is invalid.  Please <a href=\"javascript:history.back()\" title=\"Go Back\">go back</a> and try again.</p>\n";
	}
	
	elseif (!is_dir($_SERVER['DOCUMENT_ROOT']."/".$patch_dir)) {
		$page_title .= " &rsaquo; Step 1 &rsaquo; Error";
		include("admin_header.php");
		echo "<h1>Error</h1>\n";
		echo "<p>The directory <code>$path$patch_dir</code> does not exist.  Please <a href=\"javascript:history.back()\" title=\"Go Back\">go back</a> and try again.</p>\n";
	}
	
	elseif (!is_writable($_SERVER['DOCUMENT_ROOT']."/".$patch_dir)) {
		$page_title .= " &rsaquo; Step 1 &rsaquo; Error";
		include("admin_header.php");
		echo "<h1>Error</h1>\n";
		echo "<p>The directory <code>$path$patch_dir</code> is not writable.  Please <a href=\"javascript:history.back()\" title=\"Go Back\">go back</a> and try again.</p>\n";
	}
	
	else {
		$page_title .= " &rsaquo; Step 2";
		include("admin_header.php");
		
		echo "<ul>\n";
		
		// Admin
		if (!tableExists("admin")) {
			echo "\t<li>Creating <code>".TABLE_PREFIX."admin</code> table...";
			
			// Create Admin Table
			$query = "CREATE TABLE ".TABLE_PREFIX."admin (
					id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
					version text NOT NULL,
					username text NOT NULL,
					password text NOT NULL,
					member_num int(11) NOT NULL,
					name text NOT NULL,
					email text NOT NULL,
					html_email tinyint(1) DEFAULT '1' NOT NULL,
					patch_naming enum('name#', '#name', '#') DEFAULT 'name#' NOT NULL,
					date_format text NOT NULL,
					time_format text NOT NULL,
					time_offset float DEFAULT '0' NOT NULL,
					patch_dir text NOT NULL
				);";
			
			mysql_query($query) or die("<strong>Error:</strong> Couldn't create table <code>".TABLE_PREFIX."admin</code>: <br />".mysql_error());
			echo " <strong>Success!</strong></li>\n";
		}
		else
			echo "\t<li><code>".TABLE_PREFIX."admin</code> table already created successfully.</li>";
			
		// Blog
		if (!tableExists("blog")) {
			echo "\t<li>Creating <code>".TABLE_PREFIX."blog</code> table...";
			
			// Create Blog Table
			$query = "CREATE TABLE ".TABLE_PREFIX."blog (
				id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				title text NOT NULL,
				content text NOT NULL,
				post_date datetime NOT NULL,
				edit_date datetime NOT NULL
			);";
			
			mysql_query($query) or die("<strong>Error:</strong> Couldn't create table <code>".TABLE_PREFIX."blog</code>: <br />".mysql_error());
			echo " <strong>Success!</strong></li>\n";
		}
		else
			echo "\t<li><code>".TABLE_PREFIX."blog</code> table already created successfully.</li>";
			
		// Categories
		if (!tableExists("categories")) {
			echo "\t<li>Creating <code>".TABLE_PREFIX."categories</code> table...";
			
			// Create Categories Table
			$query = "CREATE TABLE ".TABLE_PREFIX."categories (
				catId int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
				cat_name text NOT NULL,
				cat_desc text NOT NULL,
				folder_name text NOT NULL,
				use_fillers tinyint(1) DEFAULT '0' NOT NULL,
				filler_url text NOT NULL,
				filler_alt text NOT NULL,
				use_alt tinyint(1) DEFAULT '0' NOT NULL,
				alt_url text NOT NULL,
				alt_alt text NOT NULL,
				sort_by enum('displayId', 'member_name', 'member_num', 'date_received') DEFAULT 'date_received' NOT NULL,
				sort_how enum('asc', 'desc') DEFAULT 'desc' NOT NULL,
				perline int(11) DEFAULT '5' NOT NULL,
				perpage int(11) DEFAULT '-1' NOT NULL
			);";
			
			mysql_query($query) or die("<strong>Error:</strong> Couldn't create table <code>".TABLE_PREFIX."categories</code>: <br />".mysql_error());
			echo " <strong>Success!</strong></li>\n";
		}
		else
			echo "\t<li><code>".TABLE_PREFIX."categories</code> table already created successfully.</li>";
			
		// Patches
		if (!tableExists("patches")) {
			echo "\t<li>Creating <code>".TABLE_PREFIX."patches</code> table...";
			
			// Create Patches Table
			$query = "CREATE TABLE ".TABLE_PREFIX."patches (
					patchId int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
					catId int(11) NOT NULL,
					displayId int(11) NOT NULL,
					member_name text NOT NULL,
					member_num int(11) DEFAULT '-1' NOT NULL,
					member_email text NOT NULL,
					patch_url text NOT NULL,
					patch_img_url text NOT NULL,
					patch_stored text NOT NULL,
					patch_desc text NOT NULL,
					date_received datetime NOT NULL,
					isApproved tinyint(1) DEFAULT '0' NOT NULL
			);";
			
			mysql_query($query) or die("<strong>Error:</strong> Couldn't create table <code>".TABLE_PREFIX."patches</code>: <br />".mysql_error());
			echo " <strong>Success!</strong></li>\n";
		}
		else
			echo "\t<li><code>".TABLE_PREFIX."patches</code> table already created successfully.</li>";
			
		// Add Admin Info
		if (mysql_num_rows(mysql_query("SELECT * FROM ".TABLE_PREFIX."admin WHERE id = '1'")) < 1) {
			echo "\t<li>Adding <em>admin</em> information...";
			
			$query = "INSERT INTO ".TABLE_PREFIX."admin (
					version, username, password, member_num, name, email, html_email, patch_naming, date_format, time_format, time_offset, patch_dir
					) VALUES (
					'".MQA_VERSION."',
					'".escape($username)."',
					'".escape($password)."',
					'".escape($member_num)."',
					'".escape($name)."',
					'".escape($email)."',
					'".escape($html_email)."',
					'".escape($patch_naming)."',
					'".escape($date_format)."',
					'".escape($time_format)."',
					'".escape($time_offset)."',
					'".escape($patch_dir)."'
			);";
			
			mysql_query($query) or die("<strong>Error:</strong> Couldn't insert date into <code>".TABLE_PREFIX."admin</code>: <br />".mysql_error());
			echo " <strong>Success!</strong></li>\n";
		}
		else
			echo "\t<li><em>Admin</em> information already added successfully.</li>";
			
		echo "</ul>\n";
?>

<h1>Step 2: Secondary Patch Folders</h1>
<p>It is highly recommended to store each patch type in its own folder. Don't forget that these directories must be writable in order for the script to work.</p>

<form action="?action=step3" method="post">
<input type="hidden" name="patch_dir" value="<?= $patch_dir ?>" />
<fieldset class="directory">
	<legend>Required Patch Folder</legend>
	<ol>
		<li>
			<label for="required_f"><code><?= $path.$patch_dir."/" ?></code></label>
			<input name="required" id="required_f" />
		</li>
		<li class="radio">
			<input type="checkbox" name="create_required" id="create_required" value="1" />
			<label for="create_required">Create Required Folder on Server?</label>
		</li>
	</ol>
</fieldset>

<fieldset class="directory">
	<legend>Member Patch Folder</legend>
	<ol>
		<li>
			<label for="member_f"><code><?= $path.$patch_dir."/" ?></code></label>
			<input name="member" id="member_f" />
		</li>
		<li class="radio">
			<input type="checkbox" name="create_member" id="create_member" value="1" />
			<label for="create_member">Create Member Folder on Server?</label>
		</li>
	</ol>
</fieldset>

<p><input type="submit" value="Step 3 &raquo;" /></p>
</form>

<?php
	}

	include("admin_footer.php");
	exit;
}

if ($_GET['action'] == "step3") {
	// STEP 3
	
	$root = trim(cleanUp($_POST['patch_dir']), "/");
	$required = trim(cleanUp($_POST['required']), "/");
	$member = trim(cleanUp($_POST['member']), "/");
	
	$create_required = $_POST['create_required'];	
	$create_member = $_POST['create_member'];
	
	if ($required == "" || $member == "" ) {
		$page_title .= " &rsaquo; Step 2 &rsaquo; Error";
		include("admin_header.php");
		echo "<h1>Error</h1>\n";
		echo "<p>You forgot to complete the required form fields.  Please <a href=\"javascript:history.back()\" title=\"Go Back\">go back</a> and try again.</p>\n";
	}
	elseif (!is_dir($path.$root) || (!is_dir($path.$root."/".$required) && $create_required != 1) || (!is_dir($path.$root."/".$member) && $create_member != 1)) {
		$page_title .= " &rsaquo; Step 2 &rsaquo; Error";
		include("admin_header.php");
		echo "<h1>Error</h1>\n";
		echo "<p>The directory <code>".$path;
		
		if (!is_dir($path.$root))
			echo $root;
			
		elseif (!is_dir($path.$root."/".$required))
			echo $root."/".$required;
			
		elseif (!is_dir($path.$root."/".$member))
			echo $root."/".$member;
		
		echo "</code> does not exist.  Please <a href=\"javascript:history.back()\" title=\"Go Back\">go back</a> and try again.</p>\n";
	}
	elseif (!is_writable($path.$root) || (!is_writable($path.$root."/".$required) && $create_required != 1) || (!is_writable($path.$root."/".$member) && $create_member != 1)) {
		$page_title .= " &rsaquo; Step 2 &rsaquo; Error";
		include("admin_header.php");
		echo "<h1>Error</h1>\n";
		echo "<p>The directory <code>".$path;
		
		if (!is_writable($path.$root))
			echo $root;
			
		elseif (!is_writable($path.$root."/".$required))
			echo $root."/".$required;
			
		elseif (!is_writable($path.$root."/".$member))
			echo $root."/".$member;
		
		echo "</code> is not writable.  Please <a href=\"javascript:history.back()\" title=\"Go Back\">go back</a> and try again.</p>\n";
	}
	elseif ($create_required == 1 && (is_dir($path.$root."/".$required) || !mkdir($path.$root."/".$required) || !chmod($path.$root."/".$required, 0777))) {
		$page_title .= " &rsaquo; Step 2 &rsaquo; Error";
		include("admin_header.php");
		echo "<h1>Error</h1>\n";
		echo "<p>The directory <code>".$path.$root."/".$required."</code> could not be created.  Make sure that the folder does not already exist on your server.  Please <a href=\"javascript:history.back()\" title=\"Go Back\">go back</a> and try again.</p>\n";
	}
	elseif ($create_member == 1 && (is_dir($path.$root."/".$member) || !mkdir($path.$root."/".$member) || !chmod($path.$root."/".$member, 0777))) {
		$page_title .= " &rsaquo; Step 2 &rsaquo; Error";
		include("admin_header.php");
		echo "<h1>Error</h1>\n";
		echo "<p>The directory <code>".$path.$root."/".$member."</code> could not be created.  Make sure that the folder does not already exist on your server.  Please <a href=\"javascript:history.back()\" title=\"Go Back\">go back</a> and try again.</p>\n";
	}
	else {
		$page_title .= " &rsaquo; Step 3";
		include("admin_header.php");
		
		echo "<ul>\n";
		
		// Create Required Cat
		if (mysql_num_rows(mysql_query("SELECT * FROM ".TABLE_PREFIX."categories WHERE catId = '1'")) < 1) {
			echo "\t<li>Creating <em>Required</em> category...";
			
			$query = "INSERT INTO ".TABLE_PREFIX."categories (catId, cat_name, cat_desc, folder_name, sort_by, sort_how) VALUES (
					1,
					'Required',
					'The first three patches on your quilt.',
					'".escape($required)."',
					'displayId',
					'asc'
			);";
			
			mysql_query($query) or die("<strong>Error:</strong> Couldn't insert data into <code>".TABLE_PREFIX."categories</code> table:<br />".mysql_error());
			
			echo " <strong>Success!</strong></li>\n";
		}
		else
			echo "\t<li><em>Required</em> category already created successfully.</li>\n";
		
		// Create Member Cat
		if (mysql_num_rows(mysql_query("SELECT * FROM ".TABLE_PREFIX."categories WHERE catId = '2'")) < 1) {
			echo "\t<li>Creating <em>Member</em> category...";
			
			$query = "INSERT INTO ".TABLE_PREFIX."categories (catId, cat_name, cat_desc, folder_name) VALUES (
					2,
					'Member',
					'Qbee member patches.',
					'".escape($member)."'
			);";
			
			mysql_query($query) or die("<strong>Error:</strong> Couldn't insert data into <code>".TABLE_PREFIX."categories</code> table:<br />".mysql_error());
			
			echo " <strong>Success!</strong></li>\n";
		}
		else
			echo "\t<li><em>Member</em> category already created successfully.</li>\n";
		
		echo "</ul>\n";
?>

<h1>Step 3: All Done!</h1>
<p>Now you can <a href="index.php" title="Login">login</a>, but <strong>don't forget</strong> to delete this file from you server!  Happy Trading :)</p>

<?php
	}

	include("admin_footer.php");
	exit;	
}

// START

include("admin_header.php");
?>

<h1>Install MyQuilt Admin</h1>

<h2>IMPORTANT!</h2>
<p>This version of MyQuilt Admin relies on categories to sort your patches.  
These categories are equivalent to folders/directories on your server.  
When you install MyQuilt Admin 3.0, two default categories are automatically created &mdash; <em>Required</em> and <em>Member</em>.
These categories can be edited but not deleted.
All other categories are created by you.</p>
<p>I recommend creating a root patch folder to contain the category folders.</p>

<h2>Example</h2>
<pre>
/qbee directory
	/patches (root patch folder)
		/required
		/member
		/misc
		/activity_1
		/activity_2
</pre>

<p>In the previous example, the <em>patches</em> subfolders (category folders) will be automatically created by the script.
The root patch folder must be writable for this script to run correctly.</p>

<h2><a href="?action=step1" title="Begin Installation">Begin Installation &raquo;</a></h2>

<?php
include("admin_footer.php");
?>
