<!--

index.php

PHP Function Usage:
===================

print_cat_patches($catId) - Print the patches in the specified category
print_pending_count() - Print the number of pending trades
print_cat_patch_count($catId) - Print the number of patches in the specified category
print_month_trade_count() - Print the number of trades from the current month
print_last_added_member() - Prints the link to the latest member
print_last_added_date() - Prints the date of the most recent trade
print_last_added_time() - Prints the time of the most recent trade

-->

<?php
include("admin/config.php");
include("header.php");
?>

<?php print_cat_patches(1); ?>
<p class="center">(<a href="member.php" title="Member Quilt">View my Member Quilt?</a>)</p>

<p class="center">
	Pending Count: <?php print_pending_count(); ?><br />
	Total Trades: <?php print_cat_patch_count(2); ?><br />
	Trades This Month: <?php print_month_trade_count(); ?><br />
	Last Added: <?php print_last_added_member(); ?> on <?php print_last_added_date(); ?> at <?php print_last_added_time(); ?><br />
	View my <a href="log.php" title="Full Trade Log">Full Trade Log</a>
</p>

<p>I'm an official <a href="http://www.theqbee.net" title="The Quilting Bee" target="_blank">Quilting Bee</a> member! If you are also a member, and would like to trade patches, please fill out the form below. I will send you my information asap. If you're not already a member, click the button following the form for more info!</p>
<div class="center">
<?php include("form.php"); ?>
</div>

<p class="center"><a style="position: static; border-bottom-width: 0;" href="http://theqbee.net" title="The Quilting Bee" target="_blank"><img src="images/button.gif" alt="The Quilting Bee" width="88" height="24" /></a></p>

<?php
include("footer.php");
?>
