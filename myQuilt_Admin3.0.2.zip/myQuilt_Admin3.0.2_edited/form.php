<!-- 
form.php
The form for requesting a trade.
You can configure this however you want, just don't change the 'action' of the form or the 'name' of the form fields.
-->
<form method="post" action="trade.php">
<fieldset>
	<ol>
		<li>
			<label for="name">Name</label>
			<input type="text" name="name" id="name" />

		</li>
		<li>
			<label for="email">Email</label>
			<input type="text" name="email" id="email" />
		</li>
		<li>
			<label for="url"><acronym title="Uniform Resource Locator">URL</acronym></label>
			<input type="text" name="url" id="url" value="http://" />

		</li>
		<li>
			<label for="patch">Patch <acronym title="Uniform Resource Locator">URL</acronym></label>
			<input type="text" name="patch" id="patch" value="http://" />
		</li>
		<li>
			<label for="member_num">Member #</label>
			<input type="text" name="member_num" id="member_num" class="auto" size="3" maxlength="3" />
		</li>
		<li>
			<label for="comments">About You</label>
			<textarea name="comments" id="comments" rows="5" cols="20"></textarea>
		</li>
		<li class="button">
			<input type="submit" value="Trade With Me!" class="button" />
		</li>
	</ol>
</fieldset>
</form>
