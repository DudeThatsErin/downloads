  ######                ########   ##########  ##########
 ########               #########  ##########  ##########
##      ##              ##     ##  ##          ##
##      ##              ##     ##  ##          ##
##      ##              ##     ##  ##          ##
##      ##   ########   ########   ########    ########
##      ##   ########   ########   ########    ########
##      ##              ##     ##  ##          ##
##      ##              ##     ##  ##          ##
##      ##              ##     ##  ##          ##
 #########              ########   ##########  ##########
  #########             ########   ##########  ##########
         ###
          ###

*************************************************
*						*
*	MyQuilt Admin Panel			*	
*	Version 3.0.2				*
*						*
*	Copyright 2005-2007 Bubs #77		*
*	http://www.bubblessoc.net		*
*						*
*	Made for the Q*Bee			*
*	http://www.theqbee.net			*
*						*
*************************************************

## NOTICE: I am not responsible for anything that may happen as a result of you installing/running this script.  Use at your own risk.

## IN MEMORY OF: The two computer projects I skipped in order to write this script.  May they rest in peace.
## DEDICATED TO: All my beloved bee*buddies :)

## CREDITS: Alex King (http://alexking.org/) for the Javascript Quicktags
	    Jem (http://jemjabella.co.uk) for some code I stole :3

=============
## IMPORTANT!
=============

This version of MyQuilt Admin relies on categories to sort your patches.  
These categories are equivalent to folders/directories on your server.  
When you install/upgrade MyQuilt Admin 3.0, two default categories are automatically created -- Required and Member.
These categories can be edited but not deleted.
All other categories are created by you.
I recommend creating a root patch folder which will contain the category folders.

Example:
========

/qbee directory
	/patches (root patch folder)
		/required
		/member
		/misc
		/activity_1
		/activity_2
		...
		
Of course the patches subfolders (category folders) will be automatically created by the script.
The root patch folder must be writable for this script to run correctly.

================
## INSTALLATION:
================

MyQuilt Admin requires PHP/MySQL.  Please check with your host if you are unsure about this.
If you are new to PHP/MySQL, I recommend Jem's tutorials: http://www.tutorialtastic.co.uk/category/3

1. Log in to your site's Control Panel and create a database for your MyQuilt Admin panel.  I named my database 'qbeedb', but you can name yours whatever you want.  Create a new user or give an existing user access to your database.

2. Unzip the contents of myQuilt_Admin3.0.2 onto your computer.

3. Open admin/config.php in a text editor and modify the variables.

4. Upload all the files contained in the .zip to your qbee directory.

5. Point your browser to http://yoursite.com/qbee_directory/admin/install.php.  This will give you further instructions for installation.

6. Once the installation is complete, BE SURE TO DELETE admin/install.php AND admin/upgrade2.0.php AND admin/upgrade3.0.php from your server.

==============================
## UPGRADING FROM 2.1/2.2/2.3:
==============================

- BEFORE YOU BEGIN, BACK UP ALL QBEE-RELATED FILES, INCLUDING YOUR OLD DATABASE!
- Run admin/upgrade2.0.php ONLY if you are upgrading from version 2.1, 2.2, or 2.3.

1. Delete all of the old MyQuilt Admin files 
	(admin folder, footer.php, form.php, header.php, index.php, log.php, thanks.php, trade.php, quilt templates).
	
2. Open admin/config.php in a text editor and modify the variables.

3. Upload all the new files to your qbee directory.

4. Point your browser to http://yoursite.com/qbee_directory/admin/upgrade2.0.php.  This will give you further instructions for upgrading.

5. Once the upgrade is complete, BE SURE TO DELETE admin/upgrade2.0.php AND admin/upgrade3.0.php AND admin/install.php from your server.

6. Visit your Admin Profile (admin/profile.php) and edit the 'Time Offset' field as needed.


What admin/upgrade2.0.php does:
===============================

- Creates new database tables using specified prefix.
	admin, blog, categories, patches
	
- Creates default categories
	required, member, misc

- Imports old db info
	admin, members, misc, required
	
==============================
## UPGRADING FROM 3.0.0/3.0.1:
==============================

- BEFORE YOU BEGIN, BACK UP ALL QBEE-RELATED FILES, INCLUDING YOUR OLD DATABASE!
- Run admin/upgrade3.0.php ONLY if you are upgrading from version 3.0.0 or 3.0.1

1. Delete your existing admin folder and contents.

2. Open admin/config.php in a text editor and modify the variables.

3. Upload the new admin folder to your qbee directory.

4. Point your browser to http://yoursite.com/qbee_directory/admin/upgrade3.0.php.  This will give you further instructions for upgrading.

5. Once the upgrade is complete, BE SURE TO DELETE admin/upgrade3.0.php AND admin/upgrade2.0.php AND admin/install.php from your server.

6. Some of the template functions have changed, so you'll need to refer to usage.txt and make the appropriate changes in your existing Qbee files.

What admin/upgrade3.0.php does:
===============================

- Adds `version` field to admin table
- Adds `perline` and `perpage` fields to the patches table

=========
## USAGE:
=========

For information on how to use this script, please refer to usage.txt

================
## NEW FEATURES:
================

- Categories
- Full Trade Log (Thanks Gaby #212 - http://nuvempimenta.org/)
- Mini-Blog
- Better date management
- Patch validation on the trade request form now uses cURL rather than fopen()
- Built in No-Upload Plugin
- Comments field on trade request form

=============
## CHANGELOG:
=============

# 3.0.2

- I included a NEW default template that you are free to use.
- Fixed 'Email All Using Form' so that it doesn't CC you on every email (admin/email.php)
- 'Category Description' is now optional
- Added 'patches per row' and 'patches per page' to 'Manage Categories' in the admin panel (admin/categories.php)
- Fixed problem with .info emails
- Added an explanation for 'Display Id' in the admin panel
- Tweaked the quilt printing functions (see usage.txt for more info)

# 3.0.1

- Removed the link to your Admin Panel from index.php and member.php
- trade.php checks to see if member number is < 350
- Reminder in Admin to delete install.php and upgrade.php
- Added 'Add Patch' and 'Quilt' to the Admin menu
- Separated the 'Add Member Patch' and 'Add Other Patch' forms in admin/add-patch.gif
- Changed the label 'Patch URL' to 'Website' in admin/add-patch.php
- "Salted" the Admin cookie for more security
- Grouped patches by category id in the function <?php print_all_patches(); ?>

===========
## SUPPORT:
===========

You can post in the following thread at the Qbee BBS:
http://www.theqbee.net/thebbs/viewtopic.php?t=1121

Or email me: qbee@bubblessoc.net

I'd love to hear your feedback! ^__^
