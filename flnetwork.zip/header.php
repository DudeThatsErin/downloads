<!DOCTYPE html>

<html lang="en">

<head>
<?php 
 $getTitle = ucwords(str_replace("_", " ", str_replace('.php', '', basename($_SERVER['PHP_SELF']))));
 $index    = preg_replace("/([A-Za-z0-9_-]+)/", '', basename($_SERVER['PHP_SELF']));
 require("admin/inc/fun-admin.inc.php");
?>
 <meta charset="utf-8">
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 <title> flnetwork &#8212; <?php echo $fnadmin->isTitle($getTitle); ?> </title>
 <link href="admin/style.css" rel="stylesheet" type="text/css">
</head>

<body>

<div id="container">

<div id="wrapper">

<nav>
<menu>
 <li<?php echo $fnadmin->isCurrent('approved', 1); ?>><a href="approved.php">Approved</a></li>
 <li<?php echo $fnadmin->isCurrent('apply'); ?>><a href="apply.php">Apply</a></li>
 <li<?php echo $fnadmin->isCurrent('forms'); ?>><a href="forms.php">Forms</a></li>
</menu>

<menu>
 <li<?php echo $fnadmin->isCurrent('index', 1); ?>><a href="<?php echo $index; ?>">Home</a></li>
 <li><a href="/admin/">Admin</a></li>
</menu>
</nav>

<section id="content">
