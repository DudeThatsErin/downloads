<?php 
require("header.php");
?>
<h2>Applications Form</h2>
<?php 
# -----------------------------------------------------------
require("fig.inc.php");
# -----------------------------------------------------------
require(FNPATH . "inc/show-application.php");
# -----------------------------------------------------------
?>
<?php
require("footer.php");
?>
