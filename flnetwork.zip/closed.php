<?php 
require("header.php");
?>
<h2>Closed Form</h2>
<?php 
# -----------------------------------------------------------
require("fig.inc.php");
# -----------------------------------------------------------
require(FNPATH . "inc/show-closed.php");
# -----------------------------------------------------------
?>
<?php 
require("footer.php");
?>
