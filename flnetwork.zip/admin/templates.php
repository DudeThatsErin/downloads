<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       E-mail Templates <templates.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
$getTitle = "Templates";
require("pro.inc.php");
require("header.php");

/** 
 * Grab our header :D 
 */ 
$sp = !isset($_GET['g']) ? " <span><a href=\"templates.php?g=new\">Add Template</a></span>" : '';
echo "<h2>{$getTitle}$sp</h2>\n";

if($fnusers->userStatus() == 1) {
 if(isset($_GET['g']) && $_GET['g'] == 'new') {
?>
<p>Each template will be named <samp>email_NAMEHERE</samp>. 
<samp>NAMEHERE</samp> needs to be letters <em>only</em> and be unique. Neither 
<abbr title="Hypertext Markup Language">HTML</abbr>, nor bbCode, is allowed; if 
you are providing a link, be sure to inclose them with arrows 
(e.g. <samp>&lt;http://thetaboolistings.net&gt;</samp>).</p>
<p>Below is a sample from one of the default e-mails you installed with the 
script, following variables from the script that you can apply:</p>
<code style="height: 150px; overflow: auto;">
Hello +name+,<br><br>
Congratulations! Your application to build and run the +subject+ fanlisting has been approved at The Taboolistings 
Network! We recommend you save this e-mail for future reference.<br><br>
While we truly cannot wait to see your fanlisting up and running, there are few basic rules for building 
the fanlisting:<br><br>
1.) Have your fanlisting up within 4 weeks (1 month) of receiving this e-mail.<br>
2.) A link back to the The Taboolistings Network must be up at ALL times.<br>
3.) Link back buttons are highly recommended, especially for those interested in linking back to the fanlisting by image.<br>
4.) Everyone must be allowed to join the fanlisting.<br><br>
We sincerely hope you have fun building your fanlisting! Once done, remember to send in a Finished form. If 
you have any questions, feel more than free to ask. Congratulations again and good luck! :D<br><br>
--<br>
+staffer+<br>
+category+ Category<br>
&lt;http://thetaboolistings.net&gt;
</code>
<table class="stats" width="100%"><tbody>
 <tr>
  <td class="right">+category+</td>
  <td class="left">Category the listing belongs under</td>
 </tr>
 <tr>
  <td class="right">+name+</td>
  <td class="left">Name of the subject approve</td>
 </tr>
 <tr>
  <td class="right">+staffer+</td>
	<td class="left">Application staffer in the category</td>
 </tr>
 <tr>
  <td class="right">+subject+</td>
  <td class="left">Subject of the listing</td>
 </tr>
</tbody></table>
<p><strong>NOTE:</strong> The e-mail of the approve will be used from the database, and is not needed in a template.</p>

<form action="templates.php" method="post">
<fieldset>
 <legend>Add Template</legend>
 <p><label><strong>Template Name:</strong></label> 
  <span style="padding: 0 1%; width: 48%"><samp>email_</samp> 
  <input name="name" type="text" style="width: auto;"></span>
 </p>
 <p class="clear"></p>
 <p><label><strong>Template Title</strong><br>
 This is the title of the template, e.g. "Update Form":</label> 
 <input name="title" class="input1" type="text"></p>
 <p class="clear"></p>
 <p><strong>Template</strong><br>
 <textarea name="template" cols="50" rows="16" style="height: 150px; width: 100%;"></textarea></p>
 <p class="tc">
  <input name="action" class="input2" type="submit" value="Add Template"> 
  <input class="input2" type="reset" value="Reset">
 </p>
</fieldset>
</form>
<?php 
 }

 elseif (isset($_POST['action']) && $_POST['action'] == 'Add Template') {
  $name = $flnetwork->cleanMys($_POST['name']);
  if(empty($name) || !preg_match("/([a-z]+)/", $name)) {
   $flnetwork->displayError('Form Error', 'The <samp>template name</samp> must' . 
	 ' contain only lowercase letters.', false);
  }
  $title = $flnetwork->cleanMys($_POST['title']);
  if(empty($title) || !preg_match("/([A-Za-z-\s]+)/i", $title)) {
   $flnetwork->displayError('Form Error', 'The <samp>template title</samp> field' . 
	 ' must contain only letters (lower and uppercase), spaces and dashes.', false);
  }
  $template = $flnetwork->cleanMys($_POST['template'], 'n', 'y', 'n');
  if(empty($template)) {
   $flnetwork->displayError('Form Error', 'The <samp>template</samp> field is' . 
	 ' empty.', false);
  }

  $insert = "INSERT INTO `$_FN[templates]` (`tempName`, `tempTitle`," . 
	" `tempTemplate`) VALUES ('email_$name', '$title', '$template')";
  $fndatabase->query("SET NAMES 'utf8';");
  $true = $fndatabase->query($insert);

  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to add the' . 
	 ' template to the database.', true, $insert);
  } elseif ($true == true) {
   echo '<p class="successButton"><span class="success">SUCCESS!</span> Your' . 
	 ' <samp>email_' . $name . "</samp> template was added to the database!</p>\n";
   echo $flnetwork->backLink('temp');
  }
 }

 /** 
  * Edit! 
  */ 
 elseif (isset($_GET['g']) && $_GET['g'] == 'old') {
  $name   = $flnetwork->cleanMys($_GET['name']);
  $select = "SELECT * FROM `$_FN[templates]` WHERE `tempName` = '$name' LIMIT 1";
  $true   = $fndatabase->query($select);
  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to select' . 
	 ' template from the database.', false, $select);
  }
  $getItem = $fndatabase->obj($true);
?>
<form action="templates.php" method="post">
<input name="name" type="hidden" value="<?php echo $getItem->tempName; ?>">

<fieldset>
<legend>Edit Template</legend>
 <p><label><strong>Template Name:<strong></label> 
 <span style="padding: 0 1%; width: 48%"><samp><?php echo $getItem->tempName; ?></samp></span></p>
 <p><label><strong>Template Title:</strong></label> 
 <input name="title" class="input1" type="text" value="<?php echo $getItem->tempTitle; ?>"></p>
 <p><strong>Template</strong><br>
  <textarea name="template" cols="50" rows="16" style="height: 150px;width: 100%;">
<?php echo $getItem->tempTemplate; ?>
  </textarea>
 </p>
 <p class="tc"><input name="action" class="input2" type="submit" value="Edit Template"></p>
</fieldset>
</form>
<?php 
 }

 elseif (isset($_POST['action']) && $_POST['action'] == 'Edit Template') {
  $name = $flnetwork->cleanMys($_POST['name']);
  if(empty($name)) {
   $flnetwork->displayError('Form Error', 'Your template name is empty. This means' . 
	 ' you selected an incorrect template or you\'re trying to access something' . 
	 ' that doesn\'t exist. Go back and try again.', false);
  } 
  $title = $flnetwork->cleanMys($_POST['title']);
  if(empty($title) || !preg_match("/([A-Za-z-\s]+)/i", $title)) {
   $flnetwork->displayError('Form Error', 'The <samp>template title</samp> field' . 
	 ' must contain only letters (lower and uppercase), spaces and dashes.', false);
  }
  $template = $flnetwork->cleanMys($_POST['template'], 'n', 'y', 'n');
  if(empty($template)) {
   $flnetwork->displayError('Form Error', 'The <samp>template</samp> field is' . 
	 ' empty.', false);
  }

  $update = "UPDATE `$_FN[templates]` SET `tempTitle` = '$title', `tempTemplate`" . 
	" = '$template' WHERE `tempName` = '$name' LIMIT 1";
  $fndatabase->query("SET NAMES 'utf8';");
  $true = $fndatabase->query($update);

  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to edit' . 
	 ' the template.', true, $update);
  } elseif ($true == true) {
   echo '<p class="successButton"><span class="success">SUCCESS!</span> Your' . 
	 " template was edited!</p>\n";
   echo $flnetwork->backLink('temp');
  }
 }

 /** 
  * Delete 
  */ 
 elseif (isset($_GET['g']) && $_GET['g'] == 'erase') {
  $name   = $flnetwork->cleanMys($_GET['name']);
  $select = "SELECT * FROM `$_FN[templates]` WHERE `tempName` = '$name' LIMIT 1";
  $true   = $fndatabase->query($select);
  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to select' . 
	 ' template from the database.', false, $select);
  }
  $getItem = $fndatabase->obj($true);
?>
<form action="templates.php" method="post">
<input name="name" type="hidden" value="<?php echo $getItem->tempName; ?>">

<fieldset>
 <p>You are about to delete the <strong><?php echo $getItem->tempName; ?></strong> 
 template. Please be aware that once you delete a template, it is gone forever. 
 This cannot be undone! To continue, click the "Delete Template" button.</p>
 <legend>Delete Template</legend>
 <p><label><strong>Template Name:</strong></label> 
  <span style="padding: 0 1%; width: 48%"><samp><?php echo $getItem->tempName; ?></samp>
	</span>
 </p>
 <p class="tc"><input name="action" class="input2" type="submit" value="Delete Template"></p>
</fieldset>
</form>
<?php 
 }

 elseif (isset($_POST['action']) && $_POST['action'] == 'Delete Template') {
  $name = $flnetwork->cleanMys($_POST['name']);
  if(empty($name)) {
   $flnetwork->displayError('Form Error', 'Your template name is empty. This means' . 
	 ' you selected an incorrect template or you\'re trying to access something' . 
	 ' that doesn\'t exist. Go back and try again.', false);
  } 

  $update = "DELETE FROM `$_FN[templates]` WHERE `tempName` = '$name' LIMIT 1";
  $fndatabase->query("SET NAMES 'utf8';");
  $true = $fndatabase->query($update);

  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to delete' . 
	 ' the template.', true, $update);
  } elseif ($true == true) {
   echo '<p class="successButton"><span class="success">SUCCESS!</span> Your' . 
	 " template was deleted!</p>\n";
   echo $flnetwork->backLink('temp');
  }
 }

 /** 
  * Index 
  */ 
 else {
?>
<p>Welcome to <samp>templates.php</samp>, the page designed for creating, 
editing and delete e-mail templates. :D On installation, the script installed 
three default e-mail templates: <samp>email_approval</samp>, 
<samp>email_finished</samp> and <samp>email_troubleremoval</samp>. They can be 
edited and deleted.</p>

<h3>Templates</h3>
<table class="index">
<thead><tr>
 <th>Name</th>
 <th>Title</th>
 <th>Action</th>
</tr></thead>
<?php 
  $select = "SELECT * FROM `$_FN[templates]` ORDER BY `tempName` ASC";
  $true   = $fndatabase->query($select);
  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to select' . 
	 ' the templates from the database.', true, $select);
  }

  while($getItem = $fndatabase->obj($true)) {
?>
<tbody><tr>
 <td class="tc"><?php echo $getItem->tempName; ?></td>
 <td class="tc"><?php echo $getItem->tempTitle; ?></td>
 <td class="floatIcons tc">
  <a href="templates.php?g=old&#38;name=<?php echo $getItem->tempName; ?>">
	 <img src="img/icons/edit.png" alt="">
	</a> 
  <a href="templates.php?g=erase&#38;name=<?php echo $getItem->tempName; ?>">
	 <img src="img/icons/delete.png" alt="">
	</a>
 </td>
</tr></tbody>
<?php 
  }
  echo "</table>\n";
 }
} else {
?>
<p class="errorButton"><span class="error">ERROR!</span> Only the admin and 
senior staff are allowed to access this area.</p>
<?php 
}

require("footer.php");
?>
