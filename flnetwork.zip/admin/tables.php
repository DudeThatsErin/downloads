<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Listings <tables.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
$getTitle = "Category Tables";
require("pro.inc.php");
require("vars.inc.php");
require("header.php");

/** 
 * Grab our header and pagination variables :D 
 */ 
$sp = isset($_GET['table']) && !isset($_GET['g']) ? 
" <span><a href=\"tables.php?table=" . $flnetwork->cleanMys($_GET['table']). 
"&#38;g=new\">Add FL</a></span>" : '';
echo "<h2>{$getTitle}$sp</h2>\n";

if(!isset($_GET['p']) || empty($_GET['p']) || !is_numeric($_GET['p'])) { 
 $page = 1;
} else {
 $page = $flnetwork->cleanMys((int)$_GET['p']);
}
$start = $fndatabase->escape((($page * $per_page) - $per_page));

if(isset($_GET['table']) && in_array($_GET['table'], $fncategories->categoryList('id', 'table'))) {
 $table_name = $flnetwork->cleanMys($_GET['table']);
 $tableobj   = $fncategories->getCategory($table_name, 'table');

 if(isset($_GET['g'])) {
  if($_GET['g'] == 'new') {
?>
<p>You are about to add a fanlisting to the 
<strong><?php echo $tableobj->catName; ?></strong> category. This function of 
the script should only be used as a case-by-case basis (e.g. re-adding to the 
network, et al.), and should not be used to replace the application form.</p>

<form action="tables.php?table=<?php echo $table_name; ?>" method="post">
<input name="table" type="hidden" value="<?php echo $table_name; ?>">

<fieldset>
 <legend>Owner Details</legend>
 <p><label><strong>Name:</strong></label> 
 <input name="name" class="input1" type="text"></p>
 <p><label><strong>E-mail:</strong></label> 
 <input name="email" class="input1" type="text"></p>
 <p><label><strong>Website:</strong></label> 
 <input name="website" class="input1" type="text"></p>
</fieldset>

<fieldset>
 <legend>Fanlisting Details</legend>
 <p><label><strong>Subject:</strong></label> 
 <input name="subject" class="input1" type="text"></p>
 <p><label><strong>URL:</strong></label> 
 <input name="url" class="input1" type="text"></p>
<?php  
 if($tableobj->catSubcats == 1) {
  $catID  = $fncategories->getCatID($table_name_edit, 'table');
  $select = $fndatabase->query("SELECT * FROM `$_FN[categories]` WHERE `catParent`" . 
	" = '$catID' ORDER BY `catName` ASC");
  if($fndatabase->total($select) > 0) {
?>
 <p><label><strong>Subcategory:</strong></label> 
 <select name="subcategory" class="input1">
<?php  
   while($getCat = $fndatabase->obj($select)) {
    echo "<option value=\"" . $getCat->catID . "\">" . $getCat->catName . "</option>\n";
   }
?>
 </select></p>
<?php 
  }
 } 
?>
 <p><label><strong>Status:</strong></label> 
  <input name="status" class="input3" type="radio" value="0"> Current
  <input name="status" checked="checked" class="input3" type="radio" value="1"> Upcoming
  <input name="status" class="input3" type="radio" value="2"> Pending
 </p>
</fieldset>

<fieldset>
 <legend>E-mail Options</legend>
 <p><label><strong>Send E-mail?</strong></label> <select name="email_option" class="input1">
  <option selected="selected" value="none">No E-mail</option>
	<option value="approval">Approval E-mail</option>
  <option value="finished">Finished E-mail</option>
 </select></p>
</fieldset>

<fieldset>
 <legend>Submit</legend>
 <p class="tc"><input name="action" class="input2" type="submit" value="Add Listing"></p>
</fieldset>
</form>
<?php 
	}

  elseif ($_GET['g'] == 'old') {
   $table_name_edit = $flnetwork->cleanMys($_GET['table']);
   $old_id          = $flnetwork->cleanMys($_GET['d']);

   $select = "SELECT * FROM `$table_name_edit` WHERE `fID` = '$old_id' LIMIT 1";
   $true   = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to select' . 
		' the specified fanlisting.', true, $select);
   }
   $getItem = $fndatabase->obj($true);
	 $catnow  = $fncategories->getCategory($table_name_edit, 'table');
?>
<p>You are about to edit the <strong><?php echo $getItem->fSubject; ?></strong> 
fanlisting. Any changes you may make cannot be undone. To proceed, click the 
"Edit Member" button.</p>

<form action="tables.php?table=<?php echo $table_name; ?>" method="post">
<input name="id" type="hidden" value="<?php echo $getItem->fID; ?>">
<input name="table" type="hidden" value="<?php echo $table_name_edit; ?>">
<input name="subcategory" type="hidden" value="<?php echo $getItem->fSubCat; ?>">

<fieldset>
 <legend>Owner Details</legend>
 <p><label><strong>Name:</strong></label> 
 <input name="name" class="input1" type="text" value="<?php echo $getItem->ownerName; ?>"></p>
 <p><label><strong>E-mail:</strong></label> 
 <input name="email" class="input1" type="text" value="<?php echo $getItem->ownerEmail; ?>"></p>
 <p><label><strong>Website:</strong></label> 
 <input name="website" class="input1" type="text" value="<?php echo $getItem->ownerURL; ?>"></p>
</fieldset>

<fieldset>
 <legend>Fanlisting Details</legend>
 <p><label><strong>Subject:</strong></label> 
 <input name="subject" class="input1" type="text" value="<?php echo $getItem->fSubject; ?>"></p>
 <p><label><strong>URL:</strong></label> 
 <input name="url" class="input1" type="text" value="<?php echo $getItem->fURL; ?>"></p>
<?php  
 if($catnow->catSubcats == 1) {
  $catID  = $fncategories->getCatID($table_name_edit, 'table');
  $select = $fndatabase->query("SELECT * FROM `$_FN[categories]` WHERE `catParent`" . 
	" = '$catID' ORDER BY `catName` ASC");
  if($fndatabase->total($select) > 0) {
?>
 <p><label><strong>Subcategory:</strong></label> 
 <select name="subcategory" class="input1">
<?php  
   while($getCat = $fndatabase->obj($select)) {
    echo "<option value=\"" . $getCat->catID . "\"";
		if($getCat->catID == $getItem->fSubCat) {
		 echo " selected=\"selected\"";
		}
		echo ">" . $getCat->catName . "</option>\n";
   }
?>
 </select></p>
<?php 
  }
 } 
?>
 <p><label><strong>Status:</strong></label> 
<?php 
 if($getItem->fStatus == 0) {
?>
 <input name="status" checked="checked" class="input3" type="radio" value="0"> Current
 <input name="status" class="input3" type="radio" value="1"> Upcoming
 <input name="status" class="input3" type="radio" value="2"> Pending
<?php 
 } elseif ($getItem->fStatus == 1) {
?>
 <input name="status" class="input3" type="radio" value="0"> Current
 <input name="status" checked="checked" class="input3" type="radio" value="1"> Upcoming
 <input name="status" class="input3" type="radio" value="2"> Pending
<?php 
 } elseif ($getItem->fStatus == 2) {
?>
 <input name="status" class="input3" type="radio" value="0"> Current
 <input name="status" class="input3" type="radio" value="1"> Upcoming
 <input name="status" checked="checked" class="input3" type="radio" value="2"> Pending
<?php 
 }
?>
 </p>
</fieldset>

<fieldset>
 <legend>E-mail Options</legend>
 <p><label><strong>Send E-mail?</strong></label> <select name="email_option" class="input1">
  <option selected="selected" value="none">No E-mail</option>
  <option value="finished">Finished E-mail</option>
  <option value="update">Update E-mail</option>
  <option value="closed">Closed E-mail</option>
 </select></p>
 <p><label><strong>Is there a new owner?</strong></label> 
  <input name="new_owner" class="input3" type="radio" value="y"> Yes
  <input name="new_owner" checked="checked" class="input3" type="radio" value="n"> No
 </p>
</fieldset>

<fieldset>
 <legend>Submit</legend>
 <p class="tc"><input name="action" class="input2" type="submit" value="Edit Listing"></p>
</fieldset>
</form>
<?php 
  }
 }
 
 elseif (isset($_POST['action']) && $_POST['action'] == 'Add Listing') {
  $table_post_edit = $flnetwork->cleanMys($_POST['table']);
  if(!in_array($table_post_edit, $fncategories->categoryList('id', 'table'))) {
   $flnetwork->displayError('Form Error', 'It appears the table you are trying to' . 
	 ' view does not exist. Go back and try again.', false);
  }
  $name = $flnetwork->cleanMys($_POST['name']);
  if(empty($name)) {
   $flnetwork->displayError('Form Error', 'The <samp>name</samp> field is empty.', false);
  }
  $email = $flnetwork->cleanMys($_POST['email']);
  if(
	 empty($email) ||
	 !preg_match("/([A-Za-z0-9-_\.]+)@(([A-Za-z0-9-_]+\.)+)([a-zA-Z]{2,4})$/i", $email)
	) {
   $flnetwork->displayError('Form Error', 'The characters specified in the' . 
	 ' <samp>email</samp> field are not allowed.', false); 
  }
  $website = $flnetwork->cleanMys($_POST['website']);
  if(empty($website) || !strstr($website, 'http://')) {
   $flnetwork->displayError('Form Error', 'The <samp>website</samp> field does' . 
	 ' not start with http:// and therefore is not valid. Go back and apply' . 
	 ' \'http://\' to your website\'s address.', false);
  } 
  $subject = $flnetwork->cleanMys($_POST['subject']);
  if(empty($subject)) {
   $flnetwork->displayError('Form Error', 'The <samp>subject</samp> is empty.', false);
  } 
  $url = $flnetwork->cleanMys($_POST['url']);
	if(isset($_POST['subcategory']) && $tableobj->catSubcats == 1) {
	 $subcategory = $flnetwork->cleanMys($_POST['subcategory']);	 
	 if(empty($subcategory)) {
    $flnetwork->displayError('Form Error', 'The <samp>subcategory</samp> is empty;' . 
		' please make sure to fill out the field by entering the field.', false); 
	 }
  } else {
   $subcategory = '';
  }
  $status = $flnetwork->cleanMys($_POST['status']);
  if(!is_numeric($status) || $status > 2) {
   $flnetwork->displayError('Form Error', 'The <samp>fanlistings\'s status' . 
	 '</samp> is invalid.', false);
  }
  $email_option       = $flnetwork->cleanMys($_POST['email_option']);
  $email_option_array = array('approval', 'finished', 'none');
  if(empty($email_option) || !in_array($email_option, $email_option_array)) {
   $flnetwork->displayError('Form Error', 'The <samp>send e-mail option</samp>' . 
	 ' is invalid.', false);
  }
  
  /** 
	 * Send e-mail if specified: 
	 */ 
  if($email_option != 'none') {
   $mail = $fnemails->mailbyTemplate(
	  $table_post_edit, $subcategory, $subject, $email, $email_option, $new
	 );
	 if($mail) {
    echo '<p class="successButton"><span class="success">SUCCESS!</span> The ' . 
		$email_option . ' e-mail has been sent to <samp>' . $email. "</samp>!</p>\n";
   }
  }

  /** 
	 * Edit listing! 
	 */ 
	$appr    = date("Y-m-d H:i:s");
	$updated = '';
	if($status == '0' || $status == 0) {
	 $approved = $appr;
	} else {
	 $approved = '0000-00-00 00:00:00';
	}
	
  $insert = "INSERT INTO `$table_post_edit` (`ownerName`, `ownerEmail`," . 
	" `ownerURL`, `fSubcat`, `fSubject`, `fURL`, `fStatus`, `fAdded`, `fAppr`," . 
	" `fUpdated`) VALUES ('$name', '$email', '$website', '$subcategory'," . 
	" '$subject', '', $status, NOW(), '$approved', '')";
  $true = $fndatabase->query($insert);
  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to add the' . 
	 ' fanlisting.', true, $insert);
  } else {
   echo '<p class="successButton"><span class="success">SUCCESS!</span> The' . 
	 ' <samp>' . $subject . "</samp> fanlisting was edited!</p>\n";
  }
  
  echo $flnetwork->backLink('tables', $table_post_edit);
 }

 elseif (isset($_POST['action']) && $_POST['action'] == 'Edit Listing') {
  $id = $flnetwork->cleanMys((int)$_POST['id']);
  if(empty($id) || !is_numeric($id)) {
   $flnetwork->displayError('Form Error', 'Your ID is empty or invalid. This means' . 
	 ' you selected an incorrect listing or you\'re trying to access something' . 
	 ' that doesn\'t exist. Go back and try again.', false);
  }
  $table_post_edit = $flnetwork->cleanMys($_POST['table']);
  $all_table_post_edit = $fncategories->categoryList('id', 'table');
  if(!in_array($table_post_edit, $all_table_post_edit)) {
   $flnetwork->displayError('Form Error', 'It appears the table you are trying to' . 
	 ' view does not exist. Go back and try again.', false);
  }
	$getcatnow = $fncategories->getCategory($table_post_edit, 'table');
  $name = $flnetwork->cleanMys($_POST['name']);
  if(empty($name)) {
   $flnetwork->displayError('Form Error', 'The <samp>name</samp> field is empty.', false);
  }
  $email = $flnetwork->cleanMys($_POST['email']);
  if(
	 empty($email) ||
	 !preg_match("/([A-Za-z0-9-_\.]+)@(([A-Za-z0-9-_]+\.)+)([a-zA-Z]{2,4})$/i", $email)
	) {
   $flnetwork->displayError('Form Error', 'The characters specified in the' . 
	 ' <samp>email</samp> field are not allowed.', false); 
  }
  $website = $flnetwork->cleanMys($_POST['website']);
  if(empty($website) || !strstr($website, 'http://')) {
   $flnetwork->displayError('Form Error', 'The <samp>website</samp> field does' . 
	 ' not start with http:// and therefore is not valid. Go back and apply' . 
	 ' \'http://\' to your website\'s address.', false);
  } 
  $subject = $flnetwork->cleanMys($_POST['subject']);
  if(empty($subject)) {
   $flnetwork->displayError('Form Error', 'The <samp>subject</samp> is empty.', false);
  } 
  $url = $flnetwork->cleanMys($_POST['url']);
	if(isset($_POST['subcategory']) && $getcatnow->catSubcats == 1) {
	 $subcategory = $flnetwork->cleanMys($_POST['subcategory']);	 
	 if(empty($subcategory)) {
    $flnetwork->displayError('Form Error', 'The <samp>subcategory</samp> is empty;' . 
		' please make sure to fill out the field by entering the field.', false); 
	 }
  } else {
   $subcategory = '';
  }
  $status = $flnetwork->cleanMys($_POST['status']);
  if(!is_numeric($status) || $status > 2) {
   $flnetwork->displayError('Form Error', 'The <samp>fanlistings\'s status' . 
	 '</samp> is invalid.', false);
  }
  $email_option       = $flnetwork->cleanMys($_POST['email_option']);
  $email_option_array = array('closed', 'finished', 'none', 'update');
  if(empty($email_option) || !in_array($email_option, $email_option_array)) {
   $flnetwork->displayError('Form Error', 'The <samp>send e-mail option</samp>' . 
	 ' is invalid.', false);
  }
  $new_owner = $flnetwork->cleanMys($_POST['new_owner']);
  
  /** 
	 * Send e-mail if specified: 
	 */ 
  if($email_option != 'none') {
   $new  = $new_owner == 'y' ? 'y' : '';
   $mail = $fnemails->mailbyTemplate(
	  $table_post_edit, $subcategory, $subject, $email, $email_option, $new
	 );
	 if($mail) {
    echo '<p class="successButton"><span class="success">SUCCESS!</span> The ' . 
		$email_option . ' e-mail has been sent to <samp>' . $email. "</samp>!</p>\n";
   }
  }

  /** 
	 * Edit listing! 
	 */ 
	$appr    = $flnetwork->cleanMys($_POST['appr']);
	$updated = $flnetwork->cleanMys($_POST['updated']);
	if(($status == 1) && ($appr == "0000-00-00 00:00:00")) {
	 $appr2 = date("Y-m-d H:i:s");
	} elseif (($status == 1) && ($appr !== "0000-00-00 00:00:00")) {
	 $appr2 = $appr;
	} else { 
	 $appr2 == "0000-00-00 00:00:00";
	}
	
  $update = "UPDATE `$table_post_edit` SET `ownerName` = '$name', `ownerEmail`" . 
	" = '$email', `ownerURL` = '$website', `fSubCat` = '$subcategory', `fSubject`" . 
	" = '$subject', `fURL` = '$url', `fStatus` = '$status', `fAppr` = '$appr2'," . 
	" `fUpdated` = NOW() WHERE `fID` = '$id' LIMIT 1";
	
  $true = $fndatabase->query($update);
  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to edit the' . 
	 ' fanlisting.', true, $update);
  } else {
   echo '<p class="successButton"><span class="success">SUCCESS!</span> The' . 
	 ' <samp>' . $subject . "</samp> fanlisting was edited!</p>\n";
  }
  
  echo $flnetwork->backLink('tables', $table_post_edit);
 }

 /** 
  * Mass-approve fanlistings! 
  */ 
 elseif (isset($_POST['action']) && $_POST['action'] == 'Approve') {
  $table_now = $flnetwork->cleanMys($_POST['table']);
  if(empty($_POST['fl'])) {
   $flnetwork->displayError('Form Error', 'You need to select a listing (or' . 
	 ' two) in order to approve them.', false);
  }
  foreach($_POST['fl'] as $fl) {
   $flid   = $flnetwork->cleanMys($fl);
	 $item   = $fnlistings->getListing($table_now, $flid);
   $appr   = date("Y-m-d H:i:s");
	 $update = "UPDATE `$table_now` SET `fStatus` = '1', `fAppr` = '$appr'," . 
	 " `fUpdated` = NOW() WHERE `fID` = '$flid' LIMIT 1";
	 $true = $fndatabase->query($update);
	 if($true == true) {
	  echo '<p class="successButton"><span class="success">SUCCESS!</span> The' . 
		" owner was approved for the <samp>" . $item->fSubject . "</samp> listing!</p>\n";
	 }
	
	 $sub  = empty($item->fSubcat) ? '' : $item->fSubcat;
	 $mail = $fnemails->mailOwner($table_now, $item->fSubject, $sub);
	 if($mail) {
    echo '<p class="successButton"><span class="success">SUCCESS!</span> The' . 
		" approval e-mail has been sent to the new owner of <samp>" . $item->fSubject . 
		"</samp>!</p>\n";
   } elseif (!$mail) { 
	  print_r(error_get_last()); 
	 }
	}
  echo $flnetwork->backLink('tables', $table_now);
 }

 /** 
  * Now, mass-trouble fanlistings! 
  */ 
 elseif (isset($_POST['action']) && $_POST['action'] == 'Trouble') {
  $table_now = $flnetwork->cleanMys($_POST['table']);
  if(empty($_POST['fl'])) {
   $flnetwork->displayError('Form Error', 'You need to select a member (or two)' . 
	 ' in order to trouble them.', false);
  }
  $catid = $fncategories->getCatID($table_now);
  foreach($_POST['fl'] as $fl) {
   $flid   = $flnetwork->cleanMys($fl);
	 $item   = $fnlistings->getListing($table_now, $flid);
   $insert = "INSERT INTO `$_FN[troubles]` (`tProblem`, `tListing`, `tCategory`," . 
	 " `tAdded`) VALUES ('', '$flid', '$table_now', NOW())";
	 $true = $fndatabase->query($insert);
	 if($true == true) {
	  echo '<p class="successButton"><span class="success">SUCCESS!</span>' . 
		' <samp>' . $item->fSubject . "</samp> has been added to troubles!</p>\n";
	 }
  }
  echo '<p class="successButton"><span class="success">SUCCESS!</span> The' . 
	' fanlistings have been added to troubles! Before sending e-mails, please be' . 
	' aware you have to apply the particular trouble the fanlisting is in. You' . 
	' can so on the <a href="troubles.php?table=' . $table_now . '">&#187;' . 
	" Troubles</a> page.</p>\n";
  echo $flnetwork->backLink('tables', $table_now);
 }
 
 /** 
  * Aaaaa-aaa-and mass-delete fanlistings! 
  */ 
 elseif (isset($_POST['action']) && $_POST['action'] == 'Delete') {
  $table_now = $flnetwork->cleanMys($_POST['table']);
  if(empty($_POST['fl'])) {
   $flnetwork->displayError('Form Error', 'You need to select a member (or two)' . 
	 ' in order to trouble them.', false);
  }
  foreach($_POST['fl'] as $fl) {
   $flid   = $flnetwork->cleanMys($fl);
	 $item   = $fnlistings->getListing($table_now, $flid);
   $delete = "DELETE FROM `$table_now` WHERE `fID` = '$flid' LIMIT 1";
	 $true   = $fndatabase->query($delete);
	 if($true == true) {
	  echo "<p class=\"successButton\"><span class=\"success\">SUCCESS!</span>" . 
		" The listing was deleted! </p>\n";
	 }
  }
  echo $flnetwork->backLink('tables', $table_now);
 }
 
 else {
  $select = "SELECT * FROM `$table_name`";
  if(isset($_GET['s']) && ($_GET['s'] == 'searchStatus')) {
   $status = $flnetwork->cleanMys($_GET['status']);
   $select .= " WHERE `fStatus` = '$status'";
  } else {
   $select .= " ORDER BY `fStatus` DESC";
  }
  $true  = $fndatabase->query($select);
  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to select' . 
	 ' listings from the specific category table.', true, $select);
  }
  $count = $fndatabase->total($true);
?>
<p>Below are the listings from the 
<strong><?php echo $fncategories->getCatName($table_name, 'table'); ?></strong> 
category.</p>
<?php 
  if($count > 0) {
?>

<form action="tables.php?table=<?php echo $table_name; ?>" method="get">
<p class="noMargin"><input name="s" type="hidden" value="searchStatus"></p>
<input name="table" type="hidden" value="<?php echo $table_name; ?>">
<fieldset class="lap-two">
 <legend>Search Status</legend>
 <p class="tc"><select name="status" class="input1">
  <option value="0">Current</option>
  <option value="1">Upcoming</option>
  <option value="2">Pending</option>
 </select></p>
 <p class="tc"><input class="input2" type="submit" value="Search Status"></p>
</fieldset>
</form>

<form action="tables.php?table=<?php echo $table_name; ?>" method="post">
<input name="table" type="hidden" value="<?php echo $table_name; ?>">

<table class="index">
<thead><tr>
 <th>&#160;</th>
 <th>Subject</th>
 <th>Status</th>
 <th>Subcategory</th>
 <th>Owner</th>
 <th>Action</th>
</tr></thead>
<?php 
   while($getItem = $fndatabase->obj($true)) {
	  $displaycat = $fncategories->getCategory($table_name, 'table');
    if($getItem->fStatus == 0) {
		 $st = "Current";
     $sj = "<a href=\"" . $getItem->fURL . "\">" . $getItem->fSubject . "</a>";
    } elseif ($getItem->fStatus == 1) {
     if($getItem->fAppr <= date("Y-m-d", strtotime("-1 months"))) {
		  $st = "<ins>Overdue</ins>";
      $sj = $getItem->fSubject;
     } else {
		  $st = "<strong>Upcoming</strong>";
      $sj = $getItem->fSubject;
     }
    } elseif ($getItem->fStatus == 2) {
		 $st = "<em>Pending</em>";
     $sj = $getItem->fSubject;
    }
		
		$sb = '';
		if($displaycat->catSubcats == 1) {
		 $sb .= $fncategories->getCatName($getItem->fSubCat);
		} else {
		 $sb .= '&#8211;';
		}
?>
<tbody><tr>
 <td class="tc">
  <input name="fl[]" type="checkbox" value="<?php echo $getItem->fID; ?>">
 </td>
 <td class="tc"><?php echo $sj; ?></td>
 <td class="tc"><?php echo $st; ?></td>
 <td class="tc"><?php echo $sb; ?></td>
 <td class="tc"><?php echo $getItem->ownerName; ?> (<?php echo $getItem->ownerEmail; ?>)</td>
 <td class="floatIcons tc">
  <a href="tables.php?table=<?php echo $table_name; ?>&#38;g=old&#38;d=<?php echo $getItem->fID; ?>">
   <img src="img/icons/edit.png" alt="">
  </a></td>
</tr></tbody>
<?php 
   }
?>
<tfoot><tr>
 <td class="tc" colspan="6">With Checked: 
  <input name="action" class="input2" type="submit" value="Approve">
  <input name="action" class="input2" type="submit" value="Trouble">
  <input name="action" class="input2" type="submit" value="Delete">
 </td>
</tr></tfoot>
</table>
</form>
<?php 
  }

  else {
?>
<p class="tc">Currently no listings!</p>
<?php
  }
 }
}
 
/** 
 * Index 
 */ 
else {
?>
<p>Below are the category tables that hold your listings. Each category table 
was created when a <a href="categories.php">category</a> was created.</p>

<table class="index">
<thead><tr>
 <th>Category</th>
 <th>Category Table Name</th>
 <th>Action</th>
</tr></thead>
<?php
 $select = "SELECT * FROM `$_FN[categories]` WHERE `catParent` = '0' ORDER BY" . 
 "`catName` ASC LIMIT $start, $per_page";
 $true = $fndatabase->query($select);
 if($true == false) {
  $flnetwork->displayError('Database Error', 'Could not select the categories from' . 
	' the database.', true, $select);
 }
 $count = $fndatabase->total($true);

 if($count > 0) {
  while($getItem = $fndatabase->obj($true)) {
?>
<tbody><tr>
 <td class="tc"><?php echo $getItem->catName; ?></td>
 <td class="tc"><samp><?php echo $getItem->tableName; ?></samp></td>
 <td class="tc"><a href="tables.php?table=<?php echo $getItem->tableName; ?>">View Listings</a></td>
</tr></tbody>
<?php 
  }
  echo "</table>\n";

  echo "\n<p id='pagination'>Pages: ";
  $total = count($fncategories->categoryList());
  $pages = ceil($total / $per_page);

  for($i = 1; $i <= $pages; $i++) {
   if($page == $i) {
    echo $i . " ";
   } else {
    echo '<a href="tables.php?p=' . $i . '">' . $i . '</a> ';
   }
  }

  echo "</p>\n"; 
 } else {
?>
<p class="tc">Current no category tables!</p>
<?php 
 }
}

require("footer.php");
?>
