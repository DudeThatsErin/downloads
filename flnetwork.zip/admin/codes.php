<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Display Codes <codes.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
$getTitle = "Display Codes";
require("pro.inc.php");
require("header.php");

echo "<h2>{$getTitle}</h2>\n";

if($fnusers->userStatus() == 1) {
?>
<h3>Application Form</h3>
<code>
&lt;?php<br>
# -----------------------------------------------------------<br>
require("fig.inc.php");<br>
# -----------------------------------------------------------<br>
require(FNPATH . &#039;show-application.php&#039;);<br>
# -----------------------------------------------------------<br>
?&gt;
</code>

<h3>Approved (and Finished) Listings</h3>
<code>
&lt;?php<br>
# -----------------------------------------------------------<br>
require("fig.inc.php");<br>
# -----------------------------------------------------------<br>
require(FNPATH . &#039;show-approved.php&#039;);<br>
# -----------------------------------------------------------<br>
?&gt;
</code>

<h3>Closed Form</h3>
<code>
&lt;?php<br>
# -----------------------------------------------------------<br>
require("fig.inc.php");<br>
# -----------------------------------------------------------<br>
require(FNPATH . &#039;show-closed.php&#039;);<br>
# -----------------------------------------------------------<br>
?&gt;
</code>

<h3>Finished Form</h3>
<code>
&lt;?php<br>
# -----------------------------------------------------------<br>
require("fig.inc.php");<br>
# -----------------------------------------------------------<br>
require(FNPATH . &#039;show-finished.php&#039;);<br>
# -----------------------------------------------------------<br>
?&gt;
</code>

<h3>Update Form</h3>
<code>
&lt;?php<br>
# -----------------------------------------------------------<br>
require("fig.inc.php");<br>
# -----------------------------------------------------------<br>
require(FNPATH . &#039;show-update.php&#039;);<br>
# -----------------------------------------------------------<br>
?&gt;
</code>

<h3>Volunteer: Staffer Form</h3>
<code>
&lt;?php<br>
# -----------------------------------------------------------<br>
require("fig.inc.php");<br>
# -----------------------------------------------------------<br>
$cat = 'staffer';<br>
# -----------------------------------------------------------<br>
require(FNPATH . &#039;show-volunteer.php&#039;);<br>
# -----------------------------------------------------------<br>
?&gt;
</code>

<h3>Volunteer: Trouble Checker Form</h3>
<code>
&lt;?php<br>
# -----------------------------------------------------------<br>
require("fig.inc.php");<br>
# -----------------------------------------------------------<br>
$cat = 'troublechecker';<br>
# -----------------------------------------------------------<br>
require(FNPATH . &#039;show-volunteer.php&#039;);<br>
# -----------------------------------------------------------<br>
?&gt;
</code>
<?php 
} else {
 echo "<p class=\"errorButton\"><span class=\"error\">ERROR!</span> Only the admin" . 
 " and senior staff are allowed to access this area.</p>\n";
}

require("footer.php");
?>
