<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Trouble Checkers <checkers.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
$getTitle = "Staffers";
require("pro.inc.php");
require("vars.inc.php");
require("header.php");

/** 
 * Grab our header and pagination variables :D 
 */ 
$sp = !isset($_GET['g']) ? " <span><a href=\"staffers.php?g=new\">Add Staffer</a></span>" : '';
echo "<h2>{$getTitle}$sp</h2>\n";

if(!isset($_GET['p']) || empty($_GET['p']) || !is_numeric($_GET['p'])) { 
 $page = 1;
} else {
 $page = $flnetwork->cleanMys((int)$_GET['p']);
}
$start = $fndatabase->escape((($page * $per_page) - $per_page));

if($fnusers->userStatus() == 1) {
 if(isset($_GET['g']) && $_GET['g'] == 'new') {
?>
<p>Upon creation, a staffer will be given the <strong>current</strong> status 
(making them a full staffer) and will be given their own 
<a href="profile.php">&#187; Profile</a>. You can change the status by editing 
the staffer post creation.</p>

<form action="staffers.php" enctype="multipart/form-data" method="post">
<fieldset>
 <legend>Staffer Details</legend>
 <p class="noteButton"> <samp>Username</samp> will be the username of the user, 
 therefore, it is unique.</p>
 <p><label><strong>Name:</strong></label> <input name="name" class="input1" type="text"></p>
 <p><label><strong>Username:</strong></label> <input name="username" class="input1" type="text"></p>
 <p><label style="height: 90px;"><strong>Password</strong><br>
 Type the password twice; if left blank, a password will be generated:</label> 
 <input name="password" class="input1" type="password"><br>
 <input name="passwordv" class="input1" type="password"></p>
</fieldset>

<fieldset>
 <legend>Web Details</legend>
 <p><label><strong>E-mail Address:</strong></label> <input name="email" class="input1" type="text"></p>
 <p><label><strong>Show e-mail address?</strong></label> 
  <input name="show_email" checked="checked" class="input3" type="radio" value="1"> No
  <input name="show_email" class="input3" type="radio" value="0"> Yes
 </p>
 <p><label><strong>URL:</strong></label> <input name="url" class="input1" type="text"></p>
</fieldset>

<fieldset>
 <legend>Categories</legend>
 <p class="noteButton">You can choose multiple categories for the staffer.</p>
 <p><label><strong>Categories:</strong></label> 
 <select name="category[]" class="input1" multiple="multiple" size="10">
<?php 
 $select = "SELECT * FROM `$_FN[categories]` WHERE `catParent` = '0' ORDER BY" . 
 " `catName` ASC";
 $true = $fndatabase->query($select);
 if($true == false) { 
  echo "  <option>No Categories Available</option>\n";
 }

 else {
  while($getItem = $fndatabase->obj($true)) {
   echo '  <option value="' . $getItem->catID . '">' . $getItem->catName . 
	 "</option>\n";
  }
 }
?>
 </select></p>
</fieldset>

<fieldset>
 <legend>Admin Controls</legend>
 <p><label><strong>User Status:</atrong></label> 
 <select name="user_status[]" class="input1" multiple="multiple" size="4">
  <option value="1">Administrator</option>
	<option value="2">Senior Staffer</option>
  <option selected="selected" value="3">Category Staffer</option>
	<option value="4">Technical Staffer</option>
 </select></p>
 <p><label><strong>Other Duties:</strong></label> <input name="duties" class="input1" type="text"></p>
</fieldset>

<fieldset>
 <legend>Submit</legend>
 <p class="tc">
  <input name="action" type="submit" value="Add Staffer"> 
	<input type="reset" value="Reset">
 </p>
</fieldset>
</form>
<?php 
 }

 elseif (isset($_POST['action']) && $_POST['action'] == 'Add Staffer') {
  $name = $flnetwork->cleanMys($_POST['name']);
  if(empty($name) || !preg_match("/([A-Za-z\s])/i", $name)) {
   $flnetwork->displayError('Form Error', 'The <samp>name</samp> field is' . 
	 ' invalid; make sure the field is not empty, and contains only letters and' . 
	 ' spaces.', false);
  } 
  $username = $flnetwork->cleanMys($_POST['username']);
  if(empty($username) || !preg_match("/([A-Za-z0-9])/i", $name)) { 
   $flnetwork->displayError('Form Error', 'The <samp>username</samp> field is' . 
	 ' invalid; make sure the field is not empty, and contains only letters and' . 
	 ' numbers.', false);
  } elseif ($fnchecker->checkUserName($username) == true) {
   $flnetwork->displayError('Form Error', 'The <samp>username</samp> you chose' . 
	 ' is taken. Please go back and choose another.', false);
  }
  $password  = $flnetwork->cleanMys($_POST['password']);
  $passwordv = $flnetwork->cleanMys($_POST['passwordv']);
  if(!empty($password)) {
   if(empty($passwordv)) {
    $flnetwork->displayError('Form Error', 'In order to create your password, you' .  
		' need to fill out both new password fields.', false);
   } elseif ($password !== $passwordv) {
    $flnetwork->displayError('Form Error', 'In order to create your password, both' . 
		' passwords need to match.', false);
   }
  } 
  if(empty($password) && empty($passwordv)) {
   $pass = substr(sha1(mt_rand(99999, 999999)), 0, 12);
  } else {
   $pass = $password;
  }
  $email = $flnetwork->cleanMys($_POST['email']);
  if(
	 empty($email) ||
	 !preg_match("/([A-Za-z0-9-_\.]+)@(([A-Za-z0-9-_]+\.)+)([a-zA-Z]{2,4})$/i", $email)
	) {
   $flnetwork->displayError('Form Error', 'The characters specified in the <samp>' . 
	 'email</samp> field are not allowed.', false); 
  } elseif ($fnchecker->checkEmail($email) == true) {
   $flnetwork->displayError('Form Error', 'The <samp>e-mail address</samp> you' . 
	 ' chose is already taken.', false);
  } 
  $showemail  = $flnetwork->cleanMys($_POST['show_email']);
  $show_email = !is_numeric($showemail) || $showemail > 1 ? 0 : $showemail;
  $url        = $flnetwork->cleanMys($_POST['url']);
  if(!empty($url)) {
   if(!strstr($url, 'http://')) {
    $flnetwork->displayError('Form Error', 'The <samp>site URL</samp> field does' . 
		' not start with http:// and therefore is not valid. Try again.', false);
   } 
  }
	if(!isset($_POST['category']) || empty($_POST['category'])) {
	 $cat = '!0!';
	} else {
   $category = array();
   $category = $_POST['category'];
   $category = array_map(array($flnetwork, 'cleanMys'), $category);
	 $cat      = implode('!', $category);
   $cat      = '!' . trim($cat, '!') . '!';
	}
  $status   = array();
  $status   = $_POST['user_status'];
	$status   = array_map(array($flnetwork, 'cleanMys'), $status);
	$duties   = $flnetwork->cleanMys($_POST['duties']);
  $sta      = implode('!', $status);
  $sta      = '!' . trim($sta, '!') . '!';

  $insert = "INSERT INTO `$_FN[staffers]` (`sCategory`, `sStatus`, `sOtherDuties`," . 
	" `sRealName`, `sBio`, `sName`, `sPassword`, `sEmail`, `sEmailShow`, `sURL`," . 
	" `sUpdated`, `sAdded`, `sPending`) VALUES ('$cat', '$sta', '$duties'," . 
	" '$name', '', '$username', SHA1('$pass'), '$email', '$show_email', '$url'," . 
	" '0000-00-00 00:00:00', NOW(), '0')";
  $fndatabase->query("SET NAMES 'utf8';");
  $true = $fndatabase->query($insert);

  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to add the' . 
	 ' category to the database.', true, $insert);
  } elseif ($true == true) {
   echo "<p class=\"successButton\"><span class=\"success\">SUCCESS!</span> Your" . 
	 " staffer was added to the database! You may want to give the following" . 
	 " information to the staffer:</p>\n<code style=\"text-align: center;\">" . 
	 "\n<samp>Username:</samp> {$username}\n<br><samp>Password:</samp> {$pass}" . 
	 "\n</code>\n";
   echo $flnetwork->backLink('staffers');
  }
 }

 /** 
  * Edit Staffer 
  */ 
 elseif (isset($_GET['g']) && $_GET['g'] == 'old') {
  if(empty($_GET['d']) || !isset($_GET['d'])) {
?>
<form action="staffers.php" method="get">
<input name="g" type="hidden" value="old">

<fieldset> 
 <legend>Choose Staffer</legend>
 <p><label><strong>Staffer:</strong></label> <select name="d" class="input1">
<?php 
 $select = "SELECT * FROM `$_FN[staffers]` ORDER BY `sName` ASC";
 $true = $fndatabase->query($select);
 if($true == false) { 
  echo "  <option>No Staffers Available</option>\n";
 }

 else {
  while($getItem = $fndatabase->obj($true)) {
   echo '  <option value="' . $getItem->sID . '">' . $getItem->sName . "</option>\n";
  }
 }
?>
 </select></p>
 <p class="tc"><input class="input2" type="submit" value="Edit Staffer"></p>
</fieldset>
</form>
<?php
  }

  if(!empty($_GET['d'])) {
   $id = $flnetwork->cleanMys($_GET['d']);
   if(!is_numeric($id)) {
    $flnetwork->displayError('Script Error', 'Your ID is not a number. Go back' . 
		' and try again.', false);
   }

   $select = "SELECT * FROM `$_FN[staffers]` WHERE `sID` = '$id' LIMIT 1";
   $true = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to select' . 
		' that specific user.', true, $select);
   }
   $getItem = $fndatabase->obj($true);
?>
<form action="staffers.php" enctype="multipart/form-data" method="post">
<input name="id" type="hidden" value="<?php echo $getItem->sID; ?>">

<fieldset>
 <legend>Staffer Details</legend>
 <p><label><strong>Name:</strong></label> 
 <input name="name" class="input1" type="text" value="<?php echo $getItem->sRealName; ?>"></p>
 <p><label><strong>Username:</strong></label> 
 <input name="username" class="input1" type="text" value="<?php echo $getItem->sName; ?>"></p>
</fieldset>

<fieldset>
 <legend>Password</legend>
 <p><label style="height: 80px;"><strong>Password</strong><br>
 Type the password twice; if left blank (and "Change Password" is ticked yes), 
 a password will be generated):</label> 
 <input name="password" class="input1" type="password"><br>
 <input name="passwordv" class="input1" type="password"></p>
 <p class="clear"></p>
 <p><label><strong>Change password?</strong></label>
 <input name="change_password" class="input3" type="radio" value="y"> Yes 
 <input name="change_password" checked="checked" class="input3" type="radio" value="n"> No</p>
</fieldset>

<fieldset>
 <legend>Web Details</legend>
 <p><label><strong>E-Mail Address:</strong></label> 
 <input name="email" class="input1" type="text" value="<?php echo $getItem->sEmail; ?>"></p>
 <p><label><strong>Show E-Mail Address:</strong></label> 
<?php 
if($getItem->sEmailShow == 1) {
?>
  <input name="show_email" checked="checked" class="input3" type="radio" value="1"> No (Leave)
  <input name="show_email" class="input3" type="radio" value="0"> Yes
<?php 
} elseif ($getItem->sEmailShow == 0) {
?>
  <input name="show_email" checked="checked" class="input3" type="radio" value="0"> Yes (Leave)
  <input name="show_email" class="input3" type="radio" value="1"> No
<?php 
}
?>
 </p>
 <p><label><strong>URL:</strong></label> 
 <input name="url" class="input1" type="text" value="<?php echo $getItem->sURL; ?>"></p>
</fieldset>

<fieldset>
 <legend>Categories</legend>
 <p class="noteButton">You can choose multiple categories for the staffer.</p>
 <p><label><strong>Categories:</strong></label> 
 <select name="category[]" class="input1" multiple="multiple" size="10">
<?php 
 $select = "SELECT * FROM `$_FN[categories]` WHERE `catParent` = '0' ORDER BY" . 
 " `catName` ASC";
 $true = $fndatabase->query($select);
 if($true == false) { 
  echo "  <option>No Categories Available</option>\n";
 }

 else {
  while($getCat = $fndatabase->obj($true)) {
   $cats = $flnetwork->emptyarray(explode('!', $getItem->sCategory));
   echo '  <option';
	 if(in_array($getCat->catID, $cats)) { 
	  echo ' selected="selected"'; 
	 }
	 echo ' value="' . $getCat->catID . '">' . $getCat->catName . "</option>\n";
  }
 }
?>
 </select></p>
</fieldset>

<fieldset>
 <legend>Admin Controls</legend>
 <p><label><strong>Staffer Status:</strong></label> 
 <select name="user_status[]" class="input1" multiple="multiple" size="4">
<?php 
 $statusArray = $flnetwork->emptyarray(explode('!', $getItem->sStatus));
 foreach($fnusers->stafferarray as $key => $value) {
  echo '  <option';
  if(in_array($key, $statusArray)) { 
   echo ' selected="selected"';
  }
  echo ' value="' . $key . '">' . $value . "</option>\n";
 }
?>
 </select></p>
 <p><label><strong>Other Duties:</strong></label> 
 <input name="duties" class="input1" type="text" value="<?php echo $getItem->sOtherDuties; ?>"></p>
 <p><label><strong>Is the staffer pending?</strong></label> 
<?php 
if($getItem->sPending == 0) {
?>
 <input name="pending" checked="checked" class="input3" type="radio" value="0"> No
 <input name="pending" class="input3" type="radio" value="1"> Yes
<?php 
} elseif ($getItem->sPending == 1) {
?>
 <input name="pending" checked="checked" class="input3" type="radio" value="1"> Yes
 <input name="pending" class="input3" type="radio" value="0"> No
<?php 
}
?>
 </p>
</fieldset>

<fieldset>
 <legend>Submit</legend>
 <p class="tc">
  <input name="action" type="submit" value="Edit Staffer"> 
  <input name="action" type="submit" value="Delete Staffer"> 
  <input type="reset" value="Reset">
 </p>
</fieldset>
</form>
<?php 
  }
 }

 elseif (
  (isset($_POST['action'])) && 
  ($_POST['action'] == 'Edit Staffer' || $_POST['action'] == 'Delete Staffer')
 ) {
  $id = $flnetwork->cleanMys($_POST['id']);
  if(!in_array($id, $fnusers->stafferList())) {
   $flnetwork->displayError('Form Error', 'Your ID is empty. This means you selected' . 
	 ' an incorrect staffer or you\'re trying to access something that doesn\'t' . 
	 ' exist. Go back and try again.', false);
  }
	$staffer = $fnusers->getStaffer($id);
  $name    = $flnetwork->cleanMys($_POST['name']);
  if(empty($name) || !preg_match("/([A-Za-z\s])/i", $name)) {
   $flnetwork->displayError('Form Error', 'The <samp>name</samp> field is' . 
	 ' invalid; make sure the field is not empty, and contains only letters and' . 
	 ' spaces.', false);
  } 
  $username = $flnetwork->cleanMys($_POST['username']);
  if(empty($username) || !preg_match("/([A-Za-z0-9])/i", $name)) { 
   $flnetwork->displayError('Form Error', 'The <samp>username</samp> field is' . 
	 ' invalid; make sure the field is not empty, and contains only letters and' . 
	 ' numbers.', false);
  }
  $password  = $flnetwork->cleanMys($_POST['password']);
  $passwordv = $flnetwork->cleanMys($_POST['passwordv']);
  if(!empty($password)) {
   if(empty($passwordv)) {
    $flnetwork->displayError('Form Error', 'In order to create your password, you' .  
		' need to fill out both new password fields.', false);
   } elseif ($password !== $passwordv) {
    $flnetwork->displayError('Form Error', 'In order to create your password, both' . 
		' passwords need to match.', false);
   }
  } 
  if(empty($password) && empty($passwordv)) {
   $pass = substr(sha1(mt_rand(99999, 999999)), 0, 12);
  } else {
   $pass = $password;
  }
  $email = $flnetwork->cleanMys($_POST['email']);
  if(
	 empty($email) ||
	 !preg_match("/([A-Za-z0-9-_\.]+)@(([A-Za-z0-9-_]+\.)+)([a-zA-Z]{2,4})$/i", $email)
	) {
   $flnetwork->displayError('Form Error', 'The characters specified in the <samp>' . 
	 'email</samp> field are not allowed.', false); 
  } elseif ($email != $staffer->sEmail && $fnchecker->checkEmail($email) == true) {
   $flnetwork->displayError('Form Error', 'The <samp>e-mail address</samp> you' . 
	 ' chose is already taken.', false);
  } 
  $showemail  = $flnetwork->cleanMys($_POST['show_email']);
  $show_email = !is_numeric($showemail) || $showemail > 1 ? 0 : $showemail;
  $url        = $flnetwork->cleanMys($_POST['url']);
  if(!empty($url)) {
   if(!strstr($url, 'http://')) {
    $flnetwork->displayError('Form Error', 'The <samp>site URL</samp> field does' . 
		' not start with http:// and therefore is not valid. Try again.', false);
   } 
  }
  if(!isset($_POST['category']) || empty($_POST['category'])) {
	 $cat = '!0!';
	} else {
   $category = array();
   $category = $_POST['category'];
   $category = array_map(array($flnetwork, 'cleanMys'), $category);
	 $cat      = implode('!', $category);
   $cat      = '!' . trim($cat, '!') . '!';
	}
	$status   = array();
  $status   = $_POST['user_status'];
	$status   = array_map(array($flnetwork, 'cleanMys'), $status);
  $pending  = $flnetwork->cleanMys($_POST['pending']);
  if(!is_numeric($pending) || $pending > 1) {
   $flnetwork->displayError('Form Error', 'Your <samp>pending staffer</samp> field is invalid.', false);
  }
	$duties = $flnetwork->cleanMys($_POST['duties']);
	$sta    = implode('!', $status);
  $sta    = '!' . trim($sta, '!') . '!';

  $update = "UPDATE `$_FN[staffers]` SET `sCategory` = '$cat', `sStatus` = '$sta'," . 
	" `sOtherDuties` = '$duties', `sRealName` = '$name', `sName` = '$username',";
  if(isset($_POST['change_password']) && $_POST['change_password'] == 'y') { 
	 $update .= " `sPassword` = SHA1('$pass'),";
	}
  $update .= " `sEmail` = '$email', `sEmailShow` = '$show_email', `sURL` =" . 
	" '$url', `sPending` = '$pending', `sUpdated` = NOW()";
	if(
	 $staffer->sPending == 1 &&
	 ($pending == '0' || $pending == 0)
	) {
	 $update .= ", `sAdded` = NOW()";
	}
	$update .= " WHERE `sID` = '$id' LIMIT 1";
	$delete = "DELETE FROM `$_FN[staffers]` WHERE `sID` = '$id' LIMIT 1";
  
	if($_POST['action'] == 'Delete Staffer') {
   $true = $fndatabase->query($delete);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to delete the' . 
		' staffer.', true, $delete);
   } elseif ($true == true) {
    echo "<p class=\"successButton\"><span class=\"success\">SUCCESS!</span> The" . 
		" staffer was deleted!</p>\n";
   }
	} else {
	 $fndatabase->query("SET NAMES 'utf8';");
   $true = $fndatabase->query($update);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to edit the' . 
		' staffer.|Make sure your staffer table exists.', true, $update);
   } elseif ($true == true) {
    echo '<p class="successButton"><span class="success">SUCCESS!</span> The' . 
		' <samp>' . $name . "</samp> staffer was edited!</p>\n";
	  if(isset($_POST['change_password']) && $_POST['change_password'] == 'yes') { 
	   echo "<p class=\"noteButton\"><span class=\"note\">Note:</span> As the staffer" . 
		 "'s password was changed, you might want to note their new password:</p>" . 
		 "<code style=\"text-align: center;\"><samp>Password:</samp> {$pass}</code>\n";
	  }
   }
	 echo $flnetwork->backLink('staffers', $id);
  }
	echo $flnetwork->backLink('staffers');
 }

 /** 
  * Index 
  */ 
 else {
?>
<p>Welcome to <samp>staffers.php</samp>, the page to add users (who haven't 
registered themselves) and edit or delete your current ones! Below is the list 
of users. To edit or delete a current one, click "Edit" or "Delete" by the 
appropriate user.</p>
<?php
  $select = "SELECT * FROM `$_FN[staffers]` ORDER BY `sName`, `sPending` ASC" . 
	" LIMIT $start, $per_page";
  $true  = $fndatabase->query($select);
  $count = $fndatabase->total($true);

  if($count > 0) {
?>
<table class="index">
<thead><tr>
 <th>Staffer ID</th>
 <th>Name</th>
 <th>Status</th>
 <th>Categor(y/ies)</th>
 <th>Action</th>
</tr></thead>
<?php 
   while($getItem = $fndatabase->obj($true)) {
    $status = $flnetwork->emptyarray(explode('!', $getItem->sStatus));
    $s = '';
    foreach($status as $st) {
     $s .= $fnusers->getStatusName($st) . ', ';
    }
    $s = trim($s, ', ');

		if($getItem->sCategory == '!0!') {
		 $c = '&#8212;';
		} else {
     $cats = $flnetwork->emptyarray(explode('!', $getItem->sCategory));
     $c    = '';
     foreach($cats as $cat) {
      $c .= $fncategories->getCatName($cat) . ', ';
     }
     $c = trim($c, ', ');
    }
		
    if(
		 $fnusers->staffer($getItem->sStatus) == 'admin' ||
		 $fnusers->staffer($getItem->sStatus) == 'senior'
		) {
     $n = '<samp>' . $getItem->sName . '</samp>';
    } elseif (
		 (
		  $fnusers->staffer($getItem->sStatus) == 'category' || 
		  $fnusers->staffer($getItem->sStatus) == 'technical'
		 ) && 
		 $fnusers->staffer($getItem->sStatus) != 'senior' && 
		 $getItem->sPending == 0
		) {
     $n = '<strong>' . $getItem->sName . '</strong>';
    } elseif (
		 (
		  $fnusers->staffer($getItem->sStatus) == 'category' ||
		  $fnusers->staffer($getItem->sStatus) == 'technical'
		 ) && 
		 $getItem->sPending == 1
		) {
     $n = '<em>' . $getItem->sName . '</em>';
    }
?>
<tbody><tr>
 <td class="tc"><?php echo $getItem->sID; ?></td>
 <td class="tc"><?php echo $n; ?></td>
 <td class="tc"><?php echo $s; ?></td>
 <td class="tc"><?php echo $c; ?></td>
 <td class="floatIcons tc">
  <a href="staffers.php?g=old&#38;d=<?php echo $getItem->sID; ?>">
   <img src="img/icons/edit.png" alt=""> 
  </a>
 </td>
</tr></tbody>
<?php
    } 
    echo "</table>\n";

    echo '<p id="pagination">Pages: ';
    $total = count($fnusers->stafferList());
    $pages = ceil($total / $per_page);

    for($i = 1; $i <= $pages; $i++) {
     if($page == $i) {
      echo $i . " ";
     } else {
      echo '<a href="staffers.php?p=' . $i . '">' . $i . '</a> ';
     }
    }

    echo "</p>\n";
   } else {
   echo '<p class="tc">Currently no staffers!</p>' . "\n";
  }
 }
}

else {
?>
<p class="errorButton"><span class="error">ERROR!</span> Only the admin and senior 
staffers are allowed to access this area.</p>
<?php 
}

require("footer.php");
?>
