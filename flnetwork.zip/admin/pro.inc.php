<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Protection File <pro.inc.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
session_cache_limiter('private_no_expire, must-revalidate');
session_start();

require("rats.inc.php");
require("inc/fun.inc.php");
require("inc/fun-admin.inc.php");
require("inc/fun-categories.inc.php");
require("inc/fun-check.inc.php");
require("inc/fun-listings.inc.php");
require("inc/fun-misc.inc.php");
require("inc/fun-users.inc.php");

if(isset($_GET['g']) && $_GET['g'] == 'logout') {
 setcookie('fnlog', '', time() - 3600, '/');
 setcookie('fnusr', '', time() - 3600, '/');
 header("Location: " . basename($_SERVER['PHP_SELF']));
}

$loginForm = true;
$errors    = array();

if(isset($_POST['action']) && $_POST['action'] == 'Login') {
 $bots = "/(Indy|Blaiz|Java|libwww-perl|Python|OutfoxBot|User-Agent|PycURL|" . 
 "AlphaServer|T8Abot|Syntryx|WinHttp|WebBandit|nicebot|Jakarta|curl|Snoopy|" . 
 "PHPcrawl|id-search)/i";

 if(preg_match($bots, $_SERVER['HTTP_USER_AGENT']) || empty($_SERVER['HTTP_USER_AGENT'])) {
  $errors['form'] = '<p class="error tc">Known SPAM bots aren\'t allowed.</p>';
 }
 
 $check = $fnusers->check(
  $flnetwork->cleanMys($_POST['username'], 'y', 'y', 'n'),
	sha1($_POST['password'])
 );
 
 if($check == 0) {
  $errors['form'] = '<p class="error tc">ERROR: The username/password' . 
	' combination you entered does not match the one on file. Try again.</p>';
 } 

 elseif ($check == 1) {
  $showForm = false;
	$c        = $flnetwork->cleanMys($_POST['username'], 'y', 'y', 'n') . 
	"|" . sha1($_POST['password']);
	
	$getItem = $fnusers->getStaffer($c, 'userpass');
	$hash    = sha1(
	 substr(sha1($floptions->passHash), 0, 6) .
	 substr(sha1($getItem->sName), 0, 6) .
	 substr(sha1($getItem->sPassword), 0, 6) .
	 substr(sha1($floptions->saltPass), 0, 6)
	);
	
  if(isset($_POST['r']) && $_POST['r'] == 'y') {
   setcookie('fnusr', $getItem->sID, time()+60*60*24*7);
   setcookie('fnlog', $hash, time()+60*60*24*7);
  } else {
   setcookie('fnusr', $getItem->sID);
   setcookie('fnlog', $hash);
  }
  header("Location: " . $fnoptions->getOption('adminHttp'));
	exit();
 }
} 

else {
 $loginForm = false;
 if(isset($_COOKIE['fnlog']) && isset($_COOKIE['fnusr'])) {
  if(
   empty($_COOKIE['fnlog']) || empty($_COOKIE['fnusr']) || 
   $fnusers->checkUser() != $_COOKIE['fnlog']
  ) {
   $loginForm = true;
  }
 } else {
  $loginForm = true;
 }
}

if($loginForm) {
?>
<!DOCTYPE html>

<html lang="en">

<head>
 <meta charset="utf-8">
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 <title> <?php echo $fnoptions->getOption('siteName'); ?> &#8212; Log In </title>
 <link href="style.css" rel="stylesheet" type="text/css">
</head>

<body id="loginpage">

<div id="login">

<section id="logo">
<h2>Enter Your Password</h2>
<p>Fill in the username and password to login to the network.</p>
<?php 
if(isset($errors['form'])) {
 echo "\n<h3>Errors</h3>\n";
 echo "{$errors['form']}\n";
}
?>
</section>

<section id="form">
<form action="<?php echo basename($_SERVER['PHP_SELF']); ?>" method="post">
<fieldset>
 <legend>Login</legend>
 <p class="tc tb" id="loginform">
  <input name="username" class="input4" id="username" type="text"> 
  <input name="password" class="input4" id="password" type="password">
 </p>
 <p class="tc">
  <input name="r" class="input3" type="checkbox" value="y"> Remember me! 
	<input name="action" class="input2" type="submit" value="Login">
 </p>
</fieldset>
</form>
</section>

<section id="clear"></section>
</div>

<script src="js-tess.js" type="text/javascript"></script>
<script src="jquery.js" type="text/javascript"></script>
<script src="jquery-custom.js" type="text/javascript"></script>

</body>
</html>
<?php 
 exit();
}
?>