<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Main Functions <fun.inc.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 

if(class_exists('flnetwork') == false) {
 class flnetwork {
 
  /** 
	 * Cleans and escapes the text passed through the $post param 
	 * 
   * @function  $flnetwork->cleanMys() 
   * 
   * @param     $post, text; text to be cleaned~ 
   * @param     $p, string; decides if we're stripping HTML tags~
   * @param     $s, string; encoding by way of htmlentites() or 
   * htmlspecialchars() -- can also be turned off 
   * @param     $e, string; stripping function for SQL shit :D 
   */  
  public function cleanMys($post, $p = 'y', $s = 'y', $e = 'y') {
	 global $fndatabase;
	 
   if($p == 'y') {
    $post = strip_tags($post);
   }
	 
	 /** 
    * If any characters not supported by htmlentities() exist, convert 
    * them to their HTML-compliant entities :D 
    */ 
   $post = iconv('UTF-8', 'ASCII//TRANSLIT', $post);
 
   if($s == 'y') {
    $post = trim(htmlentities($post, ENT_QUOTES, 'UTF-8'));
   } elseif ($s == 'n') {
    $post = trim($post);
   } else {
    $post = trim(htmlentities($post, ENT_NOQUOTES, 'UTF-8'));
   }

   if($e == 'y') {
    if(get_magic_quotes_gpc()) {
     $post = stripslashes($post);
	  }
    $post = $fndatabase->escape($post);
   }
 
   return $post;
  }
	
	/** 
   * My faaaaaavourite function *_* Takes the array given and takes 
   * out elements that are empty (or considered empty, e.g. '', "", 
   * 0, and '0') 
   * 
	 * @function  $flnetwork->emptyarray() 
 	 * @param     $a, array; array to be emptied 
	 */ 
  function emptyarray($a) {
   $n = array();
   $e = array();

   foreach($a as $k) {
    $k = trim($k);
    $e[] = '0';

    if(!in_array($k, $e) && $k != "") {
     $n[] = $k;
    }
   }
	 
   return $n;
  }
	
	/** 
   * @function  $flnetwork->replaceSpec() 
   * @param     $p, text; string to clean 
   */ 
  public function replaceSpec($p) {
   $e = trim($p);
   $e = html_entity_decode($e, ENT_QUOTES, 'ISO-8859-15');
   return $e;
  }
	
	/** 
	 * Strips bad symbols - and replaces others - for a entry, page, script, 
	 * or script version slug 
	 * 
   * @function  $flnetwork->slug() 
   * @param     $r, string; returns given string with characters stripped 
   */ 
  public function slug($r, $v = 0) {
   $s = html_entity_decode($r);
   $p = str_replace(array('"', "'"), '', $s);
   $p = preg_replace("/([!:;,+&#$()\.<>])/", '', $p);
   $p = preg_replace("/([\s])/", '', $p);
   return strtolower($p);
  }

  /** 
   * Error display function; formats and displays regular ole errors, or 
   * MySQL errors 
   * 
	 * @function  $flnetwork->displayError() 
	 * 
	 * @param     $e, string; error title (often "Form Error", "Database
	 * Error", "Script Error", et al.) 
	 * @param     $b, text; error description; can be separated by "|" for 
	 * multiple paragraphs :D) 
	 * @param     $a, boolean; debug mode (set to true if so); true by default 
	 * @param     $q, text; MySQL query; optional 
	 * @param     $o, character; another link identifer; false by default 
	 */ 
  public function displayError($e, $b, $a = true, $q = '') {
   global $fndatabase;

   echo "<h3>" . $e . "</h3>\n";

   $class = '';
   if($e == 'Database Error') {
    $class = "mysql";
   } elseif ($e == 'Script Error') {
    $class = "php";
   } else {
    $class = "error";
   }
   
	 $p = '';
	 if($e == 'Connection/Database Error') {
	  $p = "dbButton";
	 } elseif ($e == 'Database Error') {
    $p = "mysqlButton";
   } elseif ($e == 'Script Error') {
    $p = "scriptButton";
   } elseif ($e == 'Form Error') {
    $p = "formButton";
   } else {
	  $p = "errorButton";
	 }

   $o = explode('|', $b);
   foreach($o as $i) {
    echo "<p class=\"{$p} tb\">" . $i . "</p>\n";
   }

   if(isset($_COOKIE['fnlog']) && $a) {
    echo "<h3>Debug Mode</h3>\n<p>There seems to be a few (hopefully minor)" . 
		" issues with the script:</p>\n<p class=\"$p\"><span class=\"$class\">" . 
		"MySQL Errors:</span> ";
    if($q != '') {
     echo $fndatabase->error();
     echo "\n<br><em>" . $q . "</em></p>\n";
    } else {
     echo "</p>\n";
    }
   }
 
   exit();
  }

  /** 
   * Formats a back link, e.g. "Back to Affiliate" 
   * 
	 * @function  $flnetwork->backLink() 
	 * 
	 * @param     $p, string; page we're formatting (e.g. "pages", "cat") 
	 * @param     $i, int; usually the page ID for editing; optional 
	 */ 
  public function backLink($p, $a = '') {

   if($p == 'cat') {
    $link = "\n" . '<p class="backLink"><a href="categories.php">Back' . 
		" to Categories</a></p>\n";
   } elseif ($p == 'cat_options') {
    $link = "\n" . '<p class="backLink">&#171;  <a href="cat_options.php?table=' . $a . 
		'">Back to Category Options</a>' . "</p>\n";
   } elseif ($p == 'options') {
    $link = "\n" . '<p class="backLink">&#171;  <a href="options.php">Back to' . 
		" Options</a></p>\n";
   } elseif ($p == 'profile') {
    $link = "\n" . '<p class="backLink">&#171;  <a href="profile.php">Back to' . 
		" Your Profile</a></p>\n";
   } elseif ($p == 'staffers') {
	  if($a != '' && is_numeric($a)) {
		 $link = "\n" . '<p class="backLink">&#171;  <a href="staffers.php?g=old' . 
		 '&#38;d=' . $a . "\">Back to Staffer</a></p>\n";
		} else {
     $link = "\n" . '<p class="backLink">&#171;  <a href="staffers.php">Back to' . 
		 " Staffers</a></p>\n";
		}
   } elseif ($p == 'tables') {
    $link = "\n" . '<p class="backLink">&#171;  <a href="tables.php?table=' . $a . 
		"\">Back to Listings</a></p>\n";
   } elseif ($p == 'temp') {
    $link = "\n" . '<p class="backLink">&#171;  <a href="templates.php">Back to' . 
		" Templates</a></p>\n";
   } elseif ($p == 'temp_trob') {
    $link = "\n" . '<p class="backLink">&#171;  <a href="templates_troubles.php' . 
		"\">Back to Troubles Templates</a></p>\n";
   } elseif ($p == 'troubles') {
    $link = "\n" . '<p class="backLink">&#171;  <a href="troubles.php?table=' . $a . 
		"\">Back to Troubles</a></p>\n";
   }
   return $link;
  }
	
 }
}

$flnetwork = new flnetwork();
?>
