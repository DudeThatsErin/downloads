<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Contact Form <show-contact.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
require("b.inc.php");
require(MAINDIR. "rats.inc.php");
require_once("fun.inc.php");
require_once("fun-admin.inc.php");
require_once("fun-categories.inc.php");
require_once("fun-check.inc.php");
require_once("fun-listings.inc.php");
require_once("fun-misc.inc.php");
require_once("fun-users.inc.php");
require(MAINDIR . "vars.inc.php");

/** 
 * Get options! 
 */ 
$options = (object) array();
if(isset($cat) && in_array($cat, array('category', 'senior'))) {
 if($cat == 'senior') {
  $options->type = 0;
 } elseif ($cat == 'category') {
  $options->type = 1;
 }
} else {
 $flnetwork->displayError(
  'Form Error', 'The form type has not be set, m\'dear!', false
 );
}

/** 
 * If the form has been set :D 
 */ 
if(isset($_POST['action']) && $_POST['action'] == 'Send Form') {
 $name = $flnetwork->cleanMys($_POST['name']);
 if(empty($name) || !preg_match("/([A-Za-z-\s]+)/i", $name)) { 
  $flnetwork->displayError('Form Error', 'There are invalid characters in' . 
	' the <samp>name</samp> field. Go back and try again.', false);
 } 
 $name  = ucwords($name);
 $email = $flnetwork->cleanMys($_POST['email']);
 if(
  empty($email) || 
  !preg_match("/([A-Za-z0-9-_\.]+)@(([A-Za-z0-9-_]+\.)+)([a-zA-Z]{2,4})$/i", $email)
 ) {
  $flnetwork->displayError('Form Error', 'The characters specified in the' . 
	' <samp>email</samp> field are not allowed.', false); 
 }
 $website = $flnetwork->cleanMys($_POST['website']);
 if(!empty($website)) { 
  if(
	 $website == 'http://' || 
	 preg_match("@(http://)([A-Za-z0-9-_\./?]+)([A-Za-z\.]{2,4})/?$@i", $website) === false
  ) {
   $flnetwork->displayError('Form Error', 'The <samp>website</samp> field is' . 
	 ' not valid. Please supply a valid site URL or empty the field.', false);
  } 
 }
 if($options->type == 0) {
  $staffer = $flnetwork->cleanMys($_POST['staffer']);
	$reason  = $flnetwork->cleanMys($_POST['reason']);
  if($staffer != 'none' && !in_array($staffer, $fnusers->stafferList())) {
   $flnetwork->displayError('Form Error', 'It appears the staffer you chose' . 
	 ' does not exist.', false);
  }
	if($contact != 'none' && !in_array($reason, array_keys($fnadmin->sscontact))) {
   $flnetwork->displayError('Form Error', 'It appears the reason you chose' . 
	 ' is invalid; try submitting the form again.', false);
  }
	if($staffer == 'none' && $reason == 'none') {
	 $flnetwork->displayError('Form Error', 'You must choose a senior staffer' . 
	 ' <ins>or</ins> a reason in order to send a contact form.', false);
	}
	if($staffer == 'none') {
	 $sendtoemail = 'seniorstaff@alterlistings.org';
	} else {
   $staffernow  = $fnusers->getStaffer($staffer);
   $sendtoemail = $staffernow->sEmail;
	}
 } elseif ($options->type == 1) {
  $category = $flnetwork->cleanMys($_POST['category']);
  if(!in_array($category, $fncategories->categoryList())) {
   $flnetwork->displayError('Form Error', 'It appears the category you chose' . 
	 ' does not exist.', false);
  }
  $table_name_pk = $fncategories->tableName($category);
	$categoryname  = $fncategories->getCatName($category);
  $sendtoemail   = $fnoptions->getCatOption($table_name_pk, 'stafferFormsEmail');
	$reason        = $flnetwork->cleanMys($_POST['reason']);
  if(!in_array($reason, array_keys($fnadmin->cscontact))) {
   $flnetwork->displayError('Form Error', 'It appears the reason you chose' . 
	 ' is invalid; try submitting the form again.', false);
  }
 }
 $comments = $flnetwork->cleanMys($_POST['comments']);
 if(empty($comments)) {
  $flnetwork->displayError('Form Error', 'In order to submit a form, you need' . 
	' to fill out the comments field.', false);
 }

 /** 
  * Check for SPAM words and bots! 
  */ 
 foreach($fnlistings->badwords as $b) {
  if(strpos($_POST['extrainfo'], $b) !== false || strpos($_POST['comments'], $b) !== false) {
	 $flnetwork->displayError('SPAM Error', 'SPAM language is not allowed.', false);
  }
 }

 if(preg_match($bots, $_SERVER['HTTP_USER_AGENT']) || empty($_SERVER['HTTP_USER_AGENT'])) {
  $flnetwork->displayError('SPAM Error', 'SPAM bots are not allowed.', false);
 }
 
 /**
  * Send the e-mail! :D 
  */ 
 $getreason  = $options->type == 0 ? $fnadmin->sscontact : $fnadmin->cscontact; 
 if($options->type == 0) {
  $realreason = $reason == 'none' ? $staffernow->sRealName : $getreason[$reason];
 } else {
  $realreason = $categoryname . " (" . $getreason[$reason] . ")";
 }
 
 $subjectf  = "Contact Form: " . $realreason;
 $message  .= "You have a received a contact form";
 if($options->type == 1) {
  $message .= " for the $categoryname category";
 }
 $message .= ":\n\nName: {$name}\nE-mail: {$email}\n";
 if(!empty($website)) {
  $message .= "URL: {$website}\n\n";
 } else {
  $message .= "\n";
 }
 $message .= "Reason: " . $getreason[$reason] . "\nComments:" . 
 " {$_POST[comments]}\n\nIP Address: {$_SERVER['REMOTE_ADDR']}\nBrowser:" . 
 " {$_SERVER['HTTP_USER_AGENT']}\n\n";

 $headers = "From: {$name} <$email>\nReply-To: <{$email}>";
 $mail    = mail($sendtoemail, $subjectf, $message, $headers);
 if($mail) {
  echo '<p><span class="success">Success!</span> Your contact form was' . 
	' processed and was sent to appropriate party, ready for review by a staff' . 
	' member. Please give the staffer time to respond to your form; all forms' . 
	" are reviewed and -- if not a report form -- replied to.</p>\n";
 } else {
	echo "<p><span class=\"error\">Error:</span> The form was unable to be sent" . 
	" to the appropriate staffer. If the problem persists, feel free to contact" . 
	" the staffer " . 
	($options->type == 1 ? $fnlistings->javascriptEmail($table_name_pk, 'stafferFormsEmail', 'directly here') : 
  $fnoptions->javascriptEmail($sendtoemail, 'directly here')) . "</p>\n";
 }
}

/** 
 * Get the form! 
 */ 
else {
 $w       = $options->type == 0 ? 'senior' : 'category';
 $formuri = $options->type == 0 ? $fnoptions->getOption('formsContact') : $fnoptions->getOption('formsContactStaff');
?>
<p>You can use the form below to contact a <?php echo $w; ?> staffer. If you're 
using the form in regards to multiple fanlistings, please submit one form per 
fanlisting. Thank you!</p>

<h3>Form</h3>
<form action="<?php echo $formuri; ?>" method="post">
<input name="type" type="hidden" value="<?php echo $options->type; ?>">

<table class="contact_form" width="100%">
<tbody><tr>
 <td style="text-align: right;"><strong>Name:</strong></td>
 <td style="text-align: left;"><input name="name" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right;"><strong>E-mail Address:</strong></td>
 <td style="text-align: left;"><input name="email" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right;"><strong>URL:</strong></td>
 <td style="text-align: left;"><input name="website" type="text" style="width: 100%;"></td>
</tr></tbody>
<?php 
if($options->type == 0) {
?>
<tbody><tr>
 <td style="text-align: right;"><strong>Senior Staffer:</strong></td>
 <td style="text-align: left;">
  <select name="staffer" style="width: 100%;">
	 <option selected="selected" value="none">None</option>
<?php 
 $seniorstaff = $fnusers->stafferList(2);
 if(count($seniorstaff) > 0) {
  foreach($seniorstaff as $ss) {
	 $senior = $fnusers->getStaffer($ss);
   echo "   <option value=\"" . $senior->sID . "\">" . $senior->sRealName . 
	 "</option>\n";
  }
 }
?>
  </select>
 </td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right;"><strong>Reason:</strong></td>
 <td style="text-align: left;"><select name="reason" style="width: 100%;">
  <option selected="selected" value="none">None</option>
<?php 
 $ssarray = $fnadmin->sscontact;
 foreach($ssarray as $k => $v) {
  echo "   <option value=\"$k\">$v</option>\n";
 }
?>
 </select></td>
</tr></tbody>
<?php 
} elseif ($options->type == 1) {
?>
<tbody><tr>
 <td style="text-align: right;"><strong>Category:</strong></td>
 <td style="text-align: left;">
  <select name="category" style="width: 100%;">
	 <option selected="selected" value="select">Select</option>
<?php 
 $select = "SELECT * FROM `$_FN[categories]` WHERE	`catParent` = '0' ORDER BY" . 
 " `catName` ASC";
 $true = $fndatabase->query($select);
 if($true == false) {
  echo "   <option>No Category Available</option>\n";
 }

 else {
  while($getItem = $fndatabase->obj($true)) {
   echo "   <option value=\"" . $getItem->catID . "\">" . $getItem->catName . 
	 "</option>\n";
  }
 }
?>
  </select>
 </td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right;"><strong>Reason:</strong></td>
 <td style="text-align: left;"><select name="reason" style="width: 100%;">
<?php 
 $csarray = $fnadmin->cscontact;
 foreach($csarray as $e => $a) {
  echo "   <option";
	if($e == 'general') {
	 echo " selected=\"selected\"";
	}
	echo " value=\"$e\">$a</option>\n";
 }
?>
 </select></td>
</tr></tbody>
<?php 
}
?>
<tbody><tr>
 <td style="text-align: right;"><strong>Comments:</strong></td>
 <td style="text-align: left;"><textarea name="comments" cols="40" rows="10" style="height: 100px; width: 100%;"></textarea></td>
</tr></tbody>
<tbody><tr>
 <td class="tc" colspan="2">
  <input name="action" type="submit" value="Send Form"> 
  <input type="reset" value="Reset">
 </td>
</tr></tbody>
</table>
</form>
<?php 
}
?>
