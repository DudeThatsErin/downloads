<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Options Functions <fun-misc.inc.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 

if(class_exists('fnoptions') == false) {
 class fnoptions {

  /** 
	 * @function  $fnoptions->editOption() 
	 * 
	 * @param     $o, string; option value we're updating 
	 * @param     $v, text; value we're updating to 
	 * @param     $e, character; decides if we're escaping the value 
	 */ 
  public function editOption($o, $v, $e = 0) {
   global $_FN, $fndatabase, $flnetwork;

	 if($e == 1) {
    if(get_magic_quotes_gpc()) {
     $v = stripslashes($v);
	  }
    $v = $fndatabase->real_escape_string($v);
	 }

   $update = "UPDATE `$_FN[options]` SET `text` = '$v' WHERE `name` = '$o' LIMIT 1";
   $fndatabase->query("SET NAMES 'utf8';");
   $true = $fndatabase->query($update);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to update' . 
		' the specified option.', true, $update);
   } 
 
   else {
    echo '<p class="successButton"><span class="success">SUCCESS!</span> Your <samp>' . 
	  $o . "</samp> option has been edited! :D</p>";
   }
  }  

  /** 
	 * @function  $fnoptions->getOption() 
	 * @param     $o, string; option we use to return it's value 
	 */ 
  public function getOption($o) {
   global $_FN, $fndatabase, $flnetwork;

   $select = "SELECT `text` FROM `$_FN[options]` WHERE `name` = '$o' LIMIT 1";
   $true   = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to select' . 
		' the option from the database.', false);
   }
   $getItem = $fndatabase->obj($true);

   return $getItem->text;
  } 

  /** 
	 * @function  $fnoptions->troublesList() 
	 */ 
  public function troublesList() {
   global $_FN, $fndatabase, $flnetwork;
 
   $select = "SELECT * FROM `$_FN[troubles_templates]` ORDER BY `troubName` ASC";
   $true   = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script could not select the' . 
		' categories from the database.', true, $select);
   }

   $all = array();
   while($getItem = $fndatabase->obj($true)) {
    $all[] = $getItem->troubName;
   }

   return $all;
  }
	
	/** 
	 * @function  $fnoptions->templatesList() 
	 */ 
  public function templatesList() {
   global $_FN, $fndatabase, $flnetwork;

   $select = "SELECT * FROM `$_FN[templates]` ORDER BY `tempName` ASC";
   $true   = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script could not select the' . 
		' categories from the database.', true, $select);
   }

   $all = array();
   while($getItem = $fndatabase->obj($true)) {
    $all[] = $getItem->tempName;
   }

   return $all;
  }

  /** 
	 * @function  $fnoptions->templateTitle() 
	 * @param     $n, string; template slug 
	 */ 
  public function templateTitle($n) {
   global $_FN, $fndatabase, $flnetwork;

   $select = "SELECT `tempTitle` FROM `$_FN[templates]` WHERE `tempName` =" . 
	 " '$n' LIMIT 1";
   $true = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script could not select the' . 
		' category name from the database.', false);
   }
   $getItem = $fndatabase->obj($true);

   return $getItem->tempTitle; 
  }
	
	/** 
	 * @function  $fnoptions->getTemplate() 
	 * @param     $m, string; template slug 
	 */ 
  public function getTemplate($m) {
   global $_FN, $fndatabase, $flnetwork;

   $select = "SELECT `tempTemplate` FROM `$_FN[templates]` WHERE `tempName` = '$m'";
   $true   = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script could not select the' . 
		' specified template from the database.', false);
   }  
   $getItem = $fndatabase->obj($true);

   return $getItem->tempTemplate;
  }

  /** 
	 * @function  $fnoptions->editCatOption() 
	 * 
	 * @param     $o, string; option slug 
	 * @param     $v, text 
	 * @param     $a, string; category slug 
	 * @param     $e, boolean; escapes MySQL 
	 */ 
  public function editCatOption($o, $v, $a, $e = 0) {
   global $flnetwork, $fndatabase;
	 
	 if($e == 1) {
    if(get_magic_quotes_gpc()) {
     $v = stripslashes($v);
	  }
    $v = $fndatabase->escape($v);
	 }

   $update = "UPDATE `{$a}_options` SET `optText` = '$v' WHERE `optName` = '$o' LIMIT 1";
   $fndatabase->query("SET NAMES 'utf8';");
   $true = $fndatabase->query($update);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to update' . 
		' the specified category option.', true, $update);
   } else {
    echo '<p class="successButton"><span class="success">SUCCESS!</span> Your <samp>' . 
	  $o . "</samp> option has been edited! :D</p>";
   }
  }

  /** 
	 * @function  $fnoptions->getCatOption() 
	 * @param     $a, string; category slug 
	 * @param     $o, string; option slug 
	 */ 
  public function getCatOption($a, $o) {
   global $fndatabase, $flnetwork;
	 
   $select = "SELECT `optText` FROM `{$a}_options` WHERE `optName` = '$o' LIMIT 1";
   $true   = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script cannot select the' . 
		' category option from the database.', false);
   }
   $getItem = $fndatabase->obj($true);

   return $getItem->optText;
  } 

  /** 
	 * @function  $fnoptions->getCount() 
	 * @param     $c, string 
	 */ 
  public function getCount($c) {
   global $_FN, $fndatabase, $flnetwork;

   $select = "SELECT * FROM";
   if($c == 'cat') {
    $select .= " `$_FN[categories]`";
   } elseif ($c == 'comments') {
    $select .= " `$_FN[comments]`";
   } elseif ($c == 'entries') {
    $select .= " `$_FN[main]`";
   } elseif ($c == 'templates') {
    $select .= " `$_FN[templates]`";
   }
	 $true = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to select' . 
		' the specified table.', false);
   }
   $count = $fndatabase->total($true);

   return $count;
  }
	
	/** 
   * @function  $fnoptions->javascriptEmail() 
   * @param     $e, string; e-mail address 
	 * @param     $p, text; link title; optional 
   */ 
  public function javascriptEmail($e, $p = 'e-mail me') {
	 global $fnoptions;
   $s = "<script type=\"text/javascript\">\n<!--\n" . 
	 " var jsEmail = '$e';\n" .
   " document.write('<a h' + 'ref=\"mailto:' + jsEmail + '\">$e</' + 'a>');\n" . 
   "//-->\n</script>\n";
   return $s;
  }
	
 }
}

$fnoptions = new fnoptions();
?>
