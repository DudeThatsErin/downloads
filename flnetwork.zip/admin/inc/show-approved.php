<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Approved Listings <show-approved.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
require("b.inc.php");
require(MAINDIR . "rats.inc.php");
require_once("fun.inc.php");
require_once("fun-categories.inc.php");
require_once("fun-listings.inc.php");
require_once("fun-misc.inc.php");
require(MAINDIR . "vars.inc.php");

if(!isset($_GET['p']) || empty($_GET['p']) || !ctype_digit($_GET['p'])) {
 $page = 1;
} else {
 $page = $flnetwork->cleanMys((int)$_GET['p']);
}
$start = $fndatabase->escape((($page * $per_approved) - $per_approved));

if(isset($_SERVER['QUERY_STRING'])) {
 if(isset($_GET['page'])) {
 	$_URL = '?';
	$query = str_replace($_GET['page'], '', $query);
	$query = str_replace(array('&amp;page=', '&#38;page='), '', $query);
	$query = str_replace('&page=', '', $query);
	$query = str_replace('page=', '', $query);
	$query = str_replace('&', '&amp;', $query);
	$_URL .= $query;
 } else {
  $_URL = '?' . str_replace('&', '&amp;', $_SERVER['QUERY_STRING']);
 }
} else {
 $_URL = '';
}

/** 
 * Get category \o/ 
 */ 
if(isset($_GET['cat']) && !empty($_GET['cat'])) {
 $cat     = $flnetwork->cleanMys($_GET['cat']);
 $catid   = $fncategories->getCatID($cat);
 $catname = $fncategories->getCatName($cat, 'table');

 if(!isset($_GET['subcat'])) {
  if(!in_array($cat, $fncategories->categoryList('id', 'table'))) {
   $flnetwork->displayError('Script Error', 'It appears the category you are trying' . 
	 ' to view does not exist. Go back and try again.', false);
  }

  echo "<h3>{$catname}</h3>\n";
  $sub_level_one_split = $fncategories->catSubcats($catid);
	if(count($sub_level_one_split) > 0) {
	 echo "<p class=\"tc\" style=\"text-align: center;\">\n";
   $s = '';
   foreach($sub_level_one_split as $sub) {
    $b .= ' <a href="' . $_URL . '&amp;subcat=' . $sub  . 
	  '">' . $fncategories->getCatName($sub) . '</a> |';
	  $s = empty($b) ? '' : $b;
   }
	 $s = trim($s, '|');
   echo $s;
   echo "</p>\n";
  }

	$catnow = $fncategories->getCategory($cat, 'table');
	$select = "SELECT * FROM `$cat` WHERE `fSubcat` = '' ORDER BY `fSubject`" . 
	" ASC LIMIT $start, $per_approved";
	$true = $fndatabase->query($select);
	
	if($fndatabase->total($true) > 0) {
	 echo "<ol>\n";
   while($getItem = $fndatabase->obj($true)) { 
	  if($getItem->fStatus == 0) {
	   echo ' <li><a href="' . $getItem->fURL . '">' . $getItem->fSubject . "</a></li>\n";
	  } elseif ($getItem->fStatus == 1) {
	   echo ' <li>' . $getItem->fSubject . "</li>\n";
	  }
	 }
	 echo "</ol>\n";
  } else {
   if($catnow->catSubcats != 1) {
    echo "<p style=\"text-align: center;\">Currently no listings listed under the" . 
	  " <strong>{$catname}</strong> category.</p>\n";
	 }
  }
	
	if($fndatabase->total($true) > 0 && $catnow->catSubcats != 1) {
   echo "\n<p id=\"pagination\" style=\"text-align: center;\">Pages: ";
   $selectPag = "SELECT * FROM `$cat` WHERE `fSubcat` = ''";
   $truePag   = $fndatabase->query($selectPag);
   $total     = $fndatabase->total($truePag);
   $pages     = ceil($total / $per_approved);
 
   for($i = 1; $i <= $pages; $i++) {
    if($page == $i) {
     echo $i . " ";
    } else { 
     echo '<a href="' . $_URL . '&amp;p=' . $i . '">' . $i . '</a> ';
    }
   }
   echo "</p>\n"; 
  }
 }

 /** 
  * If subcategory is set! 
  */ 
 elseif (isset($_GET['subcat']) && !empty($_GET['subcat'])) {
  $all_subcats_split = $fncategories->catSubcats($catid);
  $subcat            = $flnetwork->cleanMys($_GET['subcat']);
  if(!in_array($subcat, $all_subcats_split)) {
   $flnetwork->displayError('Script Error', 'It appears the subcategory you are' . 
	 ' trying to view does not exist. Go back and try again.', false);
  }

  echo "<h3>" . $fncategories->getCatName($subcat) . "</h3>\n";
  $query = "SELECT * FROM `$cat` WHERE `fSubcat` = '$subcat' ORDER BY `fSubject`" . 
	" ASC LIMIT $start, $per_approved";
  $result = $fndatabase->query($query);
  if($result == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to select' . 
	 ' the fanlistings under the specified subcategory.', false);
  }
  $numbers = $fndatabase->total($result);
 
  if($numbers > 0) {
   echo "<ol>\n";
   while($item = $fndatabase->obj($result)) { 
	  if($item->fStatus == 0) {
	   echo ' <li><a href="' . $item->fURL . '">' . $item->fSubject . "</a></li>\n";
	  } elseif ($item->fStatus == 1) {
	   echo ' <li>' . $item->fSubject . "</li>\n";
	  }
	 }
   echo "</ol>\n";
  } else {
   echo "<p style=\"text-align: center;\">Currently no listings listed under" . 
	 " the <strong>" . $fncategories->getCatName($subcat) . "</strong> subcategory.</p>\n";
  }

  echo "\n<p id=\"pagination\" style=\"text-align: center;\">Pages: ";
  $selectPag = "SELECT * FROM `$cat` WHERE `fSubCat` = '$subcat'";
  $truePag   = $fndatabase->query($selectPag);
  $total     = $truePag->num_rows;
  $pages     = ceil($total / $per_approved);

  for($i = 1; $i <= $pages; $i++) {
   if($page == $i) {
    echo $i . " ";
   } else { 
    echo '<a href="' . $_URL . '&amp;p=' . $i . '">' . $i . '</a> ';
   }
  }
  echo "</p>\n";
 }
	
 echo "<p id='back'><a href=\"javascript:history.go(-1)\">&laquo; Go Back</a></p>\n";
}

else {
?>
<p>Below you can choose the category approved fanlistngs are listed under.</p>

<table class="index" style="width: 100%;">
<?php 
 $select = "SELECT * FROM `$_FN[categories]` WHERE `catParent` = '0' ORDER BY" . 
 " `catName` ASC";
 $true  = $fndatabase->query($select);
 $count = $fndatabase->total($true);

 for($i = 0; $i < $count; $i++) {
  $getItem = $fndatabase->obj($true);
  if($i % 2 == 0) {
   echo "<tr>\n";
  }
  echo ' <td class="tc"><a href="?cat=' . $getItem->tableName . 
	'">' . $getItem->catName . "</a></td>\n";
  if(($i % 2) == (2 - 1) || ($i + 1) == $count) {
   echo "</tr>\n";
  }
 }
?>
</table>
<?php 
}
?>
