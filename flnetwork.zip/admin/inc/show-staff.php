<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Staffers Lists <show-staff.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
require("b.inc.php");
require(MAINDIR. "rats.inc.php");
require_once("fun.inc.php");
require_once("fun-categories.inc.php");
require_once("fun-check.inc.php");
require_once("fun-listings.inc.php");
require_once("fun-misc.inc.php");
require_once("fun-users.inc.php");
require(MAINDIR . "vars.inc.php");

/** 
 * Options! 
 */ 
$options = (object) array(
 'markup' => $fnoptions->getOption('markup')
);

if($options->markup == 'xhtml') {
 $options->break = '<br />';
} else {
 $options->break = '<br>';
}

/** 
 * If a staffer has been selected! 
 */ 
if(isset($_GET['staff']) && in_array($_GET['staff'], $fnusers->stafferList())) {
 $staff   = $flnetwork->cleanMys($_GET['staff']);
 $staffer = $fnusers->getStaffer($staff);
 
 echo "<h3>Statistics</h3>\n<p><strong>Name:</strong> " . $staffer->sRealName;
 if($staffer->sEmailShow == '0' || $staffer->sEmailShow == 0) {
  echo $options->break . "\n<strong>E-mail:</strong> " . $staffer->sEmail;
 }
 if(!empty($staffer->sURL)) {
  echo $options->break . "\n<strong>URL:</strong> <a href=\"" . $staffer->sURL . "\">Website</a>";
 }
 $cats = $staffer->sCategory == '!0!' ? '&#8212;' : $fncategories->pullCatNames($staffer->sCategory, '!');
 echo $options->break . "\n<strong>Joined:</strong> " . date('F jS, Y', strtotime($staffer->sAdded)) . 
 $options->break . 
 "\n<strong>Categories:</strong> " . $cats . 
 $options->break . "\n<strong>Other Duties:</strong> " . $staffer->sOtherDuties . 
 "</p>";
 
 echo "<h3>Bio</h3>\n<p>" . html_entity_decode($staffer->sBio, ENT_QUOTES, 'ISO-8859-15') . 
 "</p>\n";
}

/** 
 * Index 
 */ 
else {
 /** 
  * Get list of senior staffers first :D 
  */ 
 echo "<h3>Senior Staffers</h3>\n<p>Senior staffers help maintain and run the" . 
 " network.</p>\n<ul>\n";
 foreach($fnusers->stafferList(2) as $ss) {
  $senior = $fnusers->getStaffer($ss);
  echo " <li><a href=\"?staff=$ss\">" . $senior->sRealName . 
	"</a></li>\n";
 }
 echo "</ul>\n";
 
 /** 
  * Get list of category staffers first :D 
  */ 
 echo "<h3>Category Staffers</h3>\n<p>The category staffers of the network help" . 
 " run and maintain the categories they're assigned.</p>\n<ul>\n";
 foreach($fnusers->stafferList(3) as $cs) {
  $staff = $fnusers->getStaffer($cs);
	$cats  = $flnetwork->emptyarray(explode('!', $staff->sStatus));
	if(!in_array(1, $cats) && !in_array(2, $cats)) {
   echo " <li><a href=\"?staff=$cs\">" . $staff->sRealName . 
	 "</a></li>\n";
	}
 }
 echo "</ul>\n";
 
 /** 
  * Grab the technical staffer, w00t!  
  */ 
 echo "<h3>Technical Staffers</h3>\n<p>Tecnical staffers are the people who work" . 
 " behind (or in front!) the scenes of the network.</p>\n<ul>\n";
 foreach($fnusers->stafferList(4) as $ts) {
  $tech = $fnusers->getStaffer($ts);
	echo " <li><a href=\"?staff=$ts\">" . $tech->sRealName . 
	"</a></li>\n";
 }
 echo "</ul>\n";
 
 /** 
  * Trouble checkers! :D 
  */ 
 echo "<h3>Trouble Checkers</h3>\n<p>Trouble checkers work with the category" . 
 " staffers to check for fanlistings breaking network rules; these people help" . 
 " keep the categories running smoothly. Thank you for all your hard work!</p>" . 
 "\n<p style=\"text-align: center;\">";
 $checkers = $fnusers->checkersList(0);
 if(count($checkers) > 0) {
  $s = '';
  foreach($checkers as $c) {
	 $ch = $fnusers->getChecker($c);
	 $s .= "<a href=\"" . $ch->tURL . "\">" . $ch->tName . "</a> &middot; ";
	}
	echo trim($s, " &middot; ");
 } else {
  echo "There is no current trouble checkers at the network!";
 }
 echo "</p>\n";
}
?>
