<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Category Functions <fun-categories.inc.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 

if(class_exists('fncategories') == false) {
 class fncategories {

  /** 
	 * @function  $fncategories->categoryList() 
   * 
   * @param     $b, string; pull by parent; optional 
	 * @param     $p, string; creturn category ID, name or table name 
	 */ 
  public function categoryList($b = 'id', $p = 'id') {
   global $_FN, $fndatabase, $flnetwork;

   $select = "SELECT * FROM `$_FN[categories]`";
   if($b == 'parent') {
    $select .= " WHERE `catParent` = '0'";
   }
   $select .= " ORDER BY `catName` ASC";
   $true    = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'Could not select the categories from' . 
		' the database.', true, $select);
   }

   $all = array();
   while($getItem = $fndatabase->obj($true)) {
	  if($p == 'id') {
     $all[] = $getItem->catID;
		} elseif ($p == 'name') {
		 $all[] = $getItem->catName;
		} elseif ($p == 'table') {
		 $all[] = $getItem->tableName;
		}
   }

   return $all;
  }
	
	/** 
   * @function  $fncategories->getCategory() 
   * @param     $i, int; category ID or table name 
	 * @param     $b, string; pull by ID or table 
   */ 
  public function getCategory($i, $b = 'id') {
   global $_FN, $fndatabase, $flnetwork;

   $select = "SELECT * FROM `$_FN[categories]`";
	 if($b == 'id') {
	  $select .= " WHERE `catID` = '$i' LIMIT 1";
	 } elseif ($b == 'table') {
	  $select .= " WHERE `tableName` = '$i' LIMIT 1";
	 }
   $true = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'Tje script could not select the' . 
		' category name from the database.', false);
   }
   $getItem = $fndatabase->obj($true);

   return $getItem; 
  }

  /** 
   * @function  $fncategories->getCatName() 
   * @param     $i, int; category ID or table name 
	 * @param     $b, string; pull by ID or table 
   */ 
  public function getCatName($i, $b = 'id') {
   global $_FN, $fndatabase, $flnetwork;

   $select = "SELECT `catName` FROM `$_FN[categories]`";
	 if($b == 'id') {
	  $select .= " WHERE `catID` = '$i' LIMIT 1";
	 } elseif ($b == 'table') {
	  $select .= " WHERE `tableName` = '$i' LIMIT 1";
	 }
   $true = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script could not select the' . 
		' category name from the database.', false);
   }
   $getItem = $fndatabase->obj($true);

   return $getItem->catName;
  }

  /** 
   * @function  $fncategories->getCatID() 
   * @param     $n, string; category name or table name  
	 * @param     $b, string; pull by name or table name 
   */ 
  public function getCatID($n, $b = 'table') {
   global $_FN, $fndatabase, $flnetwork;

   $select = "SELECT `catID` FROM `$_FN[categories]`";
	 if($b == 'name') { 
	  $select .= " WHERE `catName` = '$n' LIMIT 1";
	 } elseif ($b == 'table') {
	  $select .= " WHERE `tableName` = '$n' LIMIT 1";
	 }
   $true = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script could not select the' . 
		' category name from the database.', false);
   }
   $getItem = $fndatabase->obj($true);

   return $getItem->catID; 
  }

  /** 
   * @function  $fncategories->tableName() 
   * @param     $i, int; category ID 
   */ 
  public function tableName($i) {
   global $_FN, $fndatabase, $flnetwork;

   $select = "SELECT `tableName` FROM `$_FN[categories]` WHERE `catID` = '$i' LIMIT 1";
   $true   = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script could not select the' . 
		' table name from the database.', false);
   }
   $getItem = $fndatabase->obj($true);

   return $getItem->tableName; 
  }

  /** 
   * @function  $fncategories->catSubcats() 
   * @param     $c, int; parent category ID 
   */ 
  public function catSubcats($c) {
   global $_FN, $fndatabase, $flnetwork;

   $select = "SELECT * FROM `$_FN[categories]` WHERE `catParent` = '$c'";
   $true   = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Script Error', 'The script was unable to select' . 
		' the subcats from the specified category table.', true, $select);
   }

   $all = array();
   while($getItem = $fndatabase->obj($true)) {
    $all[] = $getItem->catID;
   }

   return $all;
  }

  /** 
   * @function  $fncategories->tableEmpty() 
   * @param     $n, string; category name 
   */ 
  public function tableEmpty($n) {
   global $_FN, $flnetwork;

   $select = "SELECT `catID` FROM `$_FN[categories]` WHERE `catName` = '$n'" . 
	 " AND `tableName` = '' LIMIT 1";
   $true = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script could not select the' . 
		' category name from the database.', false);
   } 
   $getItem = $fndatabase->obj($true);

   return $getItem->catID; 
  }

  /** 
   * @function  $fncategories->pullCatNames() 
   * @param     $i, text; category IDs inside a string 
   * @param     $s, character; character that splits the string into an array 
   */ 
  function pullCatNames($i, $s) {

   $cats = '';
   $categories = explode($s, $i);
   foreach($categories as $c) {
    $cats .= $this->getCatName($c) . ', ';
   }
   $cats = trim($cats, ', ');

   return $cats;
  }
	
 }
}

$fncategories = new fncategories();
?>
