<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Update Form <show-update.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
require("b.inc.php");
require(MAINDIR. "rats.inc.php");
require_once("fun.inc.php");
require_once("fun-categories.inc.php");
require_once("fun-check.inc.php");
require_once("fun-listings.inc.php");
require_once("fun-misc.inc.php");
require(MAINDIR . "vars.inc.php");

if(isset($_POST['action']) && $_POST['action'] == 'Send Form') {
 $category = $flnetwork->cleanMys($_POST['category']);
 if(!in_array($category, $fncategories->categoryList())) {
  $flnetwork->displayError('Script Error', 'It appears the category you chose' . 
	' does not exist.', false);
 }
 $table_name_pk = $fncategories->tableName($category);
 $staff_email   = $fnoptions->getCatOption($table_name_pk, 'stafferFormsEmail');
 $name          = $flnetwork->cleanMys($_POST['name']);
 if(empty($name) || !preg_match("/([A-Za-z-\s]+)/i", $name)) { 
  $flnetwork->displayError('Form Error', 'There are invalid characters in' . 
	' the <samp>name</samp> field. Go back and try again.', false);
 } 
 $name = ucwords($name);
 $new_name = $flnetwork->cleanMys($_POST['new_name']);
 if(!empty($new_name)) {
  if(!preg_match("/([A-Za-z-\s]+)/i", $new_name)) { 
   $flnetwork->displayError('Form Error', 'There are invalid characters in' . 
	 ' the <samp>new name</samp> field. Go back and try again.', false);
  } 
 }
 $new_name  = ucwords($new_name);
 $email     = $flnetwork->cleanMys($_POST['email']);
 $new_email = $flnetwork->cleanMys($_POST['new_email']);
 if(
  empty($email) || 
  !preg_match("/([A-Za-z0-9-_\.]+)@(([A-Za-z0-9-_]+\.)+)([a-zA-Z]{2,4})$/i", $email)
 ) {
  $flnetwork->displayError('Form Error', 'The characters specified in the' . 
	' <samp>email</samp> field are not allowed.', false); 
 } 
 if(!empty($new_email)) {
  if(!preg_match("/([A-Za-z0-9-_\.]+)@(([A-Za-z0-9-_]+\.)+)([a-zA-Z]{2,4})$/i", $new_email)) {
   $flnetwork->displayError('Form Error', 'The characters specified in the' . 
	 ' <samp>new email</samp> field are not allowed.', false); 
  }
 }
 $website     = $flnetwork->cleanMys($_POST['website']);
 $new_website = $flnetwork->cleanMys($_POST['new_website']);
 if(empty($website)) { 
  $flnetwork->displayError('Form Error', 'The <samp>website</samp> field is' . 
	' empty; in order to submit a finished form, you must provide the URL to' . 
	' the fanlisting.', false);
 } elseif (preg_match("@(http://)([A-Za-z0-9-_\./?]+)([A-Za-z\.]{2,4})/?$@i", $website) === false) {
  $flnetwork->displayError('Form Error', 'The <samp>website</samp> field is' . 
	' not valid. Please supply a valid site URL or empty the field.', false);
 }
 if(!empty($new_website)) {
  if(preg_match("@(http://)([A-Za-z0-9-_\./?]+)([A-Za-z\.]{2,4})/?$@i", $new_website) === false) {
   $flnetwork->displayError('Form Error', 'The <samp>new website</samp> field is' . 
	 ' not valid. Please supply a valid site URL or empty the field.', false);
  }
 }
 $subject  = $flnetwork->cleanMys($_POST['subject']);
 $subject2 = $flnetwork->cleanMys($_POST['subject'], 'y', 'n');
 if(empty($subject)) {
  $flnetwork->displayError('Form Error', 'The <samp>subject</samp> is empty.', false);
 }
 $new_owner = $flnetwork->cleanMys($_POST['new_owner']);
 $comments  = $flnetwork->cleanMys($_POST['comments']);

 /** 
  * Check for SPAM words and bots! 
  */ 
 foreach($fnlistings->badwords as $b) {
  if(strpos($_POST['extrainfo'], $b) !== false || strpos($_POST['comments'], $b) !== false) {
	 $flnetwork->displayError('SPAM Error', 'SPAM language is not allowed.', false);
  }
 }

 if(preg_match($bots, $_SERVER['HTTP_USER_AGENT']) || empty($_SERVER['HTTP_USER_AGENT'])) {
  $flnetwork->displayError('SPAM Error', 'SPAM bots are not allowed.', false);
 }
 
 /** 
  * Now we will check if the subject exists~ 
	*/ 
 $select = "SELECT * FROM `$table_name_pk` WHERE `ownerName` = '$name' AND" . 
 " `ownerEmail` = '$email' AND `fURL` = '$website' AND `fSubject` LIKE" . 
 " '%$subject%' OR `fSubject` LIKE '%$subject2%'";
 $true  = $fndatabase->query($select);
 $count = $fndatabase->total($true);

 if($count == 0 || $count > 1) {
  echo $fndatabase->error . "<br />\n" . $select;
  $flnetwork->displayError('Database Error', 'The script was unable to select the' . 
	' fanlisting from the database. Please make sure you are using the same e-mail' . 
	' you used to apply for the fanlisting, and the subject is an <em>exact</em>' . 
	' match. If the problem persists, feel free to contact the' . 
	' <a href="contact.php">staff/admin</a>.', false);
 }

 else {
  $sub = "Update Form: " . $fnlistings->replaceSubject($subject);

	$no       = $new_owner == 'y' ? "Yes" : "No";
  $message .= "You have a received a update form" . 
	" for the " . $fncategories->getCatName($category) .  " category:\n\nName:" . 
	" {$name}\nE-Mail: {$email}\nFanlisting URL: <{$website}>\nFanlisting" . 
	" Subject: {$subject}\n\nNew Details:\n----------------------\nNew Owner: $no\n";
  if(!empty($new_name)) {
   $message .= "New Owner's Name: {$new_name}\n";
  }
  if(!empty($new_email)) {
   $message .= "New E-Mail: {$new_email}\n";
  }
  if(!empty($new_website)) {
   $message .= "New Website: <{$new_website}>\n";
  }
  $message .= "----------------------\n\n" . 
	"Category: " . $fncategories->getCatName($category) . "\n\nComments:" . 
	" {$comments}\n\nIP Address: {$_SERVER['REMOTE_ADDR']}\nBrowser:" . 
	" {$_SERVER['HTTP_USER_AGENT']}\n\n";

	$recipient = $staff_email;
	// $recipient = "theirrenegadexxx@gmail.com"; 
  $headers   = "From: {$website_name} <$my_email>\nReply-To: <{$email}>";
  $mail      = mail($recipient, $sub, $message, $headers);
 
  if($mail) {
   echo '<p><span class="success">Success!</span> Your update form was processed' . 
	 ' and sent to the staffer of the category, ready for review by a staff member.' . 
	 ' As there is usually weeks - possibly months - between updates, please give' . 
	 ' the category forms staffer time to process your form and get back to you.' . 
	 "</p>\n<p>If a forms update was posted <em>after</em> your update form was" . 
	 " sent in and you were not contacted feel more than free to contact the" . 
	 " staffer of the category.</p>\n";
	} else {
	 echo "<p><span class=\"error\">Error:</span> The form was unable to be sent" . 
	 " to the appropriate staffer. If the problem persists, feel free to contact" . 
	 " the staffer " . 
	 $fnlistings->javascriptEmail($table_name_pk, 'stafferFormsEmail', 'directly here') . 
	 "</p>\n";
	}
 }
}

 else {
	$formuri = $fnoptions->getOption('formsUpdate');
?>
<p>Below is the form you can use to send in a Update form for your <strong>current</strong> 
(i.e. <em>not</em> upcoming) fanlistings. Be aware if you have multiple fanlistings, 
you can only send in <em>one</em> form at a time for each fanlisting.</p>

<h3>Form</h3>
<form action="<?php echo $formuri; ?>" method="post">

<table class="update_form" width="100%">
<tbody><tr>
 <td style="text-align: right;"><strong>Name:</strong></td>
 <td style="text-align: left;"><input name="name" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right;"><strong>New Owner's Name:</strong></td>
 <td style="text-align: left;"><input name="new_name" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right;"><strong>E-Mail Address:</strong></td>
 <td style="text-align: left;"><input name="email" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right;"><strong>New E-Mail:</strong></td>
 <td style="text-align: left;"><input name="new_email" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right;"><strong>Fanlisting URL:</strong></td>
 <td style="text-align: left;"><input name="website" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right;"><strong>New Fanlisting URL:</strong></td>
 <td style="text-align: left;"><input name="new_website" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right;"><strong>Fanlisting Subject:</strong></td>
 <td style="text-align: left;"><input name="subject" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right;"><strong>Category:</strong></td>
 <td style="text-align: left;">
  <select name="category" style="width: 100%;">
<?php 
 $select = "SELECT * FROM `$_FN[categories]` WHERE	`catParent` = '0' ORDER BY" . 
 " `catName` ASC";
 $true = $fndatabase->query($select);
 if($true == false) {
  echo "   <option>No Category Available</option>\n";
 }

 else {
  while($getItem = $fndatabase->obj($true)) {
   echo "   <option value=\"" . $getItem->catID . "\">" . $getItem->catName . 
	 "</option>\n";
  }
 }
?>
  </select>
 </td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right;"><strong>New Owner?</strong></td> 
 <td style="text-align: left;">
  <input name="new_owner" class="input3" type="radio" value="y"> Yes
  <input name="new_owner" checked="checked" class="input3" type="radio" value="n"> No
 </td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right;"><strong>Comments:</strong></td>
 <td style="text-align: left;"><textarea name="comments" cols="40" rows="10" style="height: 100px; width: 100%;"></textarea></td>
</tr></tbody>
<tbody><tr>
 <td class="tc" colspan="2">
  <input name="action" type="submit" value="Send Form" /> 
	<input type="reset" value="Reset" />
 </td>
</tr></tbody>
</table>
</form>
<?php 
}
?>
