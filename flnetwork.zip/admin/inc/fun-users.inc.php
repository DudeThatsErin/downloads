<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Staffer Functions <fun-users.inc.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 

if(class_exists('fnusers') == false) {
 class fnusers {
 
  public $stafferarray = array(
	 1 => 'Administrator',
	 2 => 'Senior Staffer', 
	 3 => 'Category Staffer',
	 4 => 'Technical Staffer'
	);

  /** 
   * @function  $fnusers->stafferList() 
	 */ 
  public function stafferList($p = '') {
   global $_FN, $fndatabase, $flnetwork;

   $select = "SELECT * FROM `$_FN[staffers]`";
	 if($p != '' && (is_array($p) || in_array($p, array_keys($this->stafferarray)))) {
	  if(is_array($p)) {
		 $s = '';
		 foreach($p as $k) {
	    $s .= " `sStatus` LIKE '%!$k!%' AND";
		 }
		 $select .= " WHERE " . trim($s, " AND");
		} else {
		 $select .= " WHERE `sStatus` LIKE '%!$p!%'";
		}
		$select .= " ORDER BY `sRealName` ASC";
	 } else {
	  $select .= " ORDER BY `sID` ASC";
	 }
   $true   = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to select' . 
		' the staffers from the database.', false);
   }

   $all = array();
   while($getItem = $fndatabase->obj($true)) {
    $all[] = $getItem->sID;
   }

   return $all;
  }
	
	/** 
   * @function  $fnusers->checkersList() 
	 */ 
  public function checkersList($p = '') {
   global $_FN, $fndatabase, $flnetwork;

   $select = "SELECT * FROM `$_FN[checkers]`";
	 if($p != '' && ($p == 0 || $p == '0' || $p == 1)) {
	  $select .= " WHERE `tPending` = '$p'";
	 }
	 $select .= " ORDER BY `tID` ASC";
   $true   = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to select' . 
		' the trouble checkers from the database.', false);
   }

   $all = array();
   while($getItem = $fndatabase->obj($true)) {
    $all[] = $getItem->tID;
   }

   return $all;
  }
	
	/** 
	 * @function  $fnusers->getStaffer() 
	 * @param     $i, int; staffer ID; optional 
	 * @param     $b, string; pull from ID, e-mail, or username and password 
	 */ 
  public function getStaffer($i = '', $b = 'id') {
   global $_FN, $fndatabase, $flnetwork;

	 if($b == 'email') {
	  $i = $flnetwork->cleanMys($i);
	 } elseif ($b == 'id') {
    if($i == '') {
     $u = $flnetwork->cleanMys($_COOKIE['fnusr']);
    } else {
     $u = $i;
	  }
	 } elseif ($b == 'userpass') {
	  $e = $flnetwork->emptyarray(explode('|', $i));
		$u = $flnetwork->cleanMys($e[0], 'y', 'n', 'y');
		$p = $flnetwork->cleanMys($e[1], 'y', 'n', 'y');
	 }

   $select = "SELECT * FROM `$_FN[staffers]`";
   if($b == 'email') {
    $select .= " WHERE `sEmail` = '$u'";
	 } elseif ($b == 'id') {
    $select .= " WHERE `sID` = '$u'";
   } elseif ($b == 'userpass') {
		$select .= " WHERE `sName` = '$u' AND `sPassword` = '$p'";
	 } 
   $select .= " LIMIT 1";
   $true    = $fndatabase->query($select);
   if($true == false) {
    $harrydraco->displayError('Database Error', 'The script was unable to select' . 
		' the specified staffer.', false);
   }
   
	 return $fndatabase->obj($true);
  }
	
	/** 
	 * @function  $fnusers->getChecker() 
	 * @param     $i, int; checker ID; optional 
	 * @param     $b, string; pull from ID or e-mail 
	 */ 
  public function getChecker($i = '', $b = 'id') {
   global $_FN, $fndatabase, $flnetwork;

	 $user   = $flnetwork->cleanMys($i);
   $select = "SELECT * FROM `$_FN[checkers]`";
   if($b == 'email') {
    $select .= " WHERE `tEmail` = '$user'";
	 } elseif ($b == 'id') {
    $select .= " WHERE `tID` = '$user'";
   }
   $select .= " LIMIT 1";
   $true    = $fndatabase->query($select);
   if($true == false) {
    $harrydraco->displayError('Database Error', 'The script was unable to select' . 
		' the specified checker.', false);
   }
   
	 return $fndatabase->obj($true);
  }

  /** 
	 * @function  $fnusers->statistics() 
	 */ 
  function statistics() {
   global $_FN, $fndatabase, $fncategories, $fnlistings, $flnetwork;

   $userid  = $flnetwork->cleanMys($_COOKIE['fnusr']);
   $getItem = $this->getStaffer($userid);

   $cats = $flnetwork->emptyarray(explode('!', $getItem->sCategory));
   $s    = $cats == 1 ? "category" : "categories";
   $cat  = '';
   foreach($cats as $c) {
    $cat .= empty($c) ? '' : '<strong>' . $fncategories->getCatName($c) . 
		'</strong>' . ', ';
   }
   $cat = trim($cat, ', ');
   $cat = $cat . " " . $s;

   $status = $flnetwork->emptyarray(explode('!', $getItem->sStatus));
?>
<p>Your status is <strong><?php echo $this->stafferarray[$status[0]]; ?></strong> 
and you staff the <?php echo $cat; ?>.</p>
<?php 
   if($cats == 1) {
?>
<p class="stats">There is currently 
<strong><?php echo $fnlistings->listingCount('approved', $cats[1]); ?></strong> 
listings, with <em><?php echo $fnlistings->listingCount('upcoming', $cats[1]); ?></em> 
upcoming and <em><?php echo $fnlistings->listingCount('pending', $cats[1]); ?></em> 
pending approval. This makes <strong><?php echo $fnlistings->listingCount('all', $cats[1]); ?></strong> 
total.</p>
<?php 
   } elseif ($cats > 1) {
    $scats = preg_split("/[\s!]+/", $getItem->sCategory);
?>
<table class="statNumbers" width="100%">
<?php 
    for($i = 1; $i < (count($scats) - 1); $i++) {
     $body = "<tbody><tr>\n" . '<td class="right">' . $fncategories->getCatName($scats[$i]) . 
		 "</td>\n" . '<td class="left">' . 
     $fnlistings->listingCount('approved', $scats[$i]) . 
		 ' Approved, ' . $fnlistings->listingCount('upcoming', $scats[$i]). 
     ' Upcoming, ' . $fnlistings->listingCount('pending', $scats[$i]) . 
		 ' Pending (' . $fnlistings->listingCount('all', $scats[$i]) . 
     " Total)</td>\n" . "</tr></tbody>\n";
     $string = empty($scats[$i]) ? '' : $body;
     echo $string;
    }
?>
</table>
<?php 
   }
  }

  /** 
   * @function  $fnusers->userStatus() 
   */ 
  public function userStatus() {
   global $_FN, $flnetwork;

   $userid  = $flnetwork->cleanMys($_COOKIE['fnusr']);
   $getItem = $this->getStaffer($userid);
   $status  = $flnetwork->emptyarray(explode('!', $getItem->sStatus));
   $r       = $status[0];

   return $r;
  }

  /** 
   * @function  $fnusers->getStatusName() 
	 * @param     $i, int; staffer status ID 
   */ 
  public function getStatusName($i) {
   if($i == 1) {
	  return $this->stafferarray[1];
   } elseif ($i == 2) {
	  return $this->stafferarray[2];
   } elseif ($i == 3) {
	  return $this->stafferarray[3];
   } 
  }

  /** 
   * @function  $fnusers->staffer() 
	 * @param     $s, text 
   */ 
  public function staffer($s) {
	 global $flnetwork;
	 
   $cats = $flnetwork->emptyarray(explode('!', $s));
   if(in_array('1', $cats) || in_array(1, $cats)) {
    return 'admin';
   } elseif (in_array('2', $cats) || in_array(2, $cats)) {
    return 'senior';
   } elseif (in_array('3', $cats) || in_array(3, $cats)) {
    return 'category';
   } elseif ($s == '!4!' && count($cats) == 1) {
    return 'technical';
   }
  }

  /** 
   * @function  $fnusers->isCategories() 
   */ 
  public function isCategories() {
   global $flnetwork;

   $userid  = $flnetwork->cleanMys($_COOKIE['fnusr']);
   $getItem = $this->getStaffer($userid);

   return $getItem->sCategory;
  }

  /** 
   * @function  $fnusers->userCategories() 
   */ 
  public function userCategories() {
   global $_FN, $fndatabase, $flnetwork;

   $userid = $flnetwork->cleanMys($_COOKIE['fnusr']);
	 $select = "SELECT `sCategory` FROM `$_FN[staffers]` WHERE `sID` = '$userid'" . 
	 " LIMIT 1";
   $true = $fndatabase->query($select);

   $all = array();
   while($getItem = $fndatabase->obj($true)) {
    $cats = $flnetwork->emptyarray(explode('!', $getItem->sCategory));
    if(empty($cats)) {
	   return array();
    }
    foreach($cats as $c) {
     $all[] .= trim($c);
    }
   } 

   return $all;
  }

  /** 
   * @function  $fnusers->getUserName() 
   */ 
  public function getUserName() {
   global $flnetwork;

   $userid  = $flnetwork->cleanMys($_COOKIE['fnusr']);
   $getItem = $this->getStaffer($userid);

   return $getItem->sName;
  }
	
	/** 
	 * User checks and log functions down harrrr 8D 
	 */ 
	
	/** 
   * @function  $fnusers->check() 
   * @param     $u, string; user username  
   * @param     $p, object; user password 
   */ 
	public function check($u, $p) {
	 global $_FN, $fndatabase, $flnetwork;
	 
	 $select = "SELECT * FROM `$_FN[staffers]` WHERE `sName` = '$u' AND" . 
	 " `sPassword` = '$p'";
	 $true = $fndatabase->query($select);
	 if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to check' . 
		' the specified username and password combination.', true, $select);
   }
	 $count = $fndatabase->total($true);
	 
	 if($count == 1) {
	  return 1;
	 } else {
	  return 0;
	 }
	}
	
	/** 
   * @function  $fnusers->logUser() 
   * @param     $i, int; user ID 
   */ 
	public function logUser($i) {
	 global $_FN, $fndatabase, $flnetwork;
	 
	 $userid = $flnetwork->cleanMys($i);
	 $update = "UPDATE `$_FN[staffers]` SET `sLast` = NOW() WHERE `sID` =" . 
	 " '$userid' LIMIT 1";
	 $true = $fndatabase->query($update);
	}
	
	/** 
   * Build user sha1() hash to match against the current one 
   * 
   * @function  $fnusers->checkUser() 
   */ 
  public function checkUser() {
   global $fnoptions, $flnetwork, $floptions;

   $userid = $flnetwork->cleanMys($_COOKIE['fnusr']);
   if(!in_array($userid, $this->stafferList())) {
    return;
   }
	 
	 $getItem = $this->getStaffer($userid);
   $s       = sha1(
	  substr(sha1($floptions->passHash), 0, 6) .
	  substr(sha1($getItem->sName), 0, 6) .
	  substr(sha1($getItem->sPassword), 0, 6) .
	  substr(sha1($floptions->saltPass), 0, 6)
	 );

   return $s;
  }
	
 }
}

$fnusers = new fnusers();
?>
