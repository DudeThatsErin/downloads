<?php  
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Volunteer Form <show-application.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
require("b.inc.php");
require(MAINDIR. "rats.inc.php");
require_once("fun.inc.php");
require_once("fun-categories.inc.php");
require_once("fun-check.inc.php");
require_once("fun-listings.inc.php");
require_once("fun-misc.inc.php");
require(MAINDIR . "vars.inc.php");

$ak = $fnoptions->getOption('akismetKey');
if(!empty($ak)) {
 require_once("func.microakismet.inc.php");
}

/** 
 * Get options! 
 */ 
$options = (object) array();
if(isset($cat) && in_array($cat, array('staffer', 'troublechecker'))) {
 if($cat == 'staffer') {
  $options->type = 0;
 } elseif ($cat == 'troublechecker') {
  $options->type = 1;
 }
} else {
 $flnetwork->displayError(
  'Script Error', 'The form type has not be set, m\'dear!', false
 );
}

/** 
 * If the form has been set: 
 */ 
if(isset($_POST['action']) && $_POST['action'] == 'Send Form') {
 $formtype = $flnetwork->cleanMys($_POST['type']);
 if(!in_array($formtype, array(0, '0', 1))) {
  $flnetwork->displayError('Form Error', 'The form was unable to be processed' . 
	' -- go back and try again, m\'love!', false);
 }
 $name = $flnetwork->cleanMys($_POST['name']);
 if(empty($name) || !preg_match("/([A-Za-z-\s]+)/i", $name)) { 
  $flnetwork->displayError('Form Error', 'There are invalid characters in' . 
	' the <samp>name</samp> field. Go back and try again.', false);
 } 
 $name  = ucwords($name);
 $email = $flnetwork->cleanMys($_POST['email']);
 if(
  empty($email) || 
  !preg_match("/([A-Za-z0-9-_\.]+)@(([A-Za-z0-9-_]+\.)+)([a-zA-Z]{2,4})$/i", $email)
 ) {
  $flnetwork->displayError('Form Error', 'The characters specified in the' . 
	' <samp>email</samp> field are not allowed.', false); 
 }
 $website = $flnetwork->cleanMys($_POST['website']);
 if(empty($website)) { 
  $flnetwork->displayError('Form Error', 'The <samp>website</samp> field is' . 
	' empty; in order to submit a finished form, you must provide the URL to' . 
	' the fanlisting.', false);
 } elseif (preg_match("@(http://)([A-Za-z0-9-_\./?]+)([A-Za-z\.]{2,4})/?$@i", $website) === false) {
  $flnetwork->displayError('Form Error', 'The <samp>website</samp> field is' . 
	' not valid. Please supply a valid site URL or empty the field.', false);
 }
 if($options->type == 0) {
  $experiencest = $flnetwork->cleanMys($_POST['experiencest']);
  if(empty($experiencest)) {
   $flnetwork->displayError('Form Error', 'The <samp>Do you have experience' . 
	 ' staffing?</samp> field is empty!', false); 
  }
  $whyst = $flnetwork->cleanMys($_POST['whyst']);
  if(empty($whyst)) {
   $flnetwork->displayError('Form Error', 'The <samp>Why would you like to become' . 
	 ' a staffer?</samp> field is empty!', false); 
  }
	$why2st = $flnetwork->cleanMys($_POST['why2st']);
  if(empty($why2st)) {
   $flnetwork->displayError('Form Error', 'The <samp>Why would you make a good' . 
	 ' staffer?</samp> field is empty!', false); 
  }
 } elseif ($options->type == 1) {
  $experiencetc = $flnetwork->cleanMys($_POST['experiencetc']);
  if(empty($experiencetc)) {
   $flnetwork->displayError('Form Error', 'The <samp>Do you have experience' . 
	 ' trouble checking?</samp> field is empty!', false); 
  }
  $whytc = $flnetwork->cleanMys($_POST['whytc']);
  if(empty($whytc)) {
   $flnetwork->displayError('Form Error', 'The <samp>Why would you like to become' . 
	 ' a trouble checker?</samp> field is empty!', false); 
  }
 }
 $hours = $flnetwork->cleanMys($_POST['hours']);
 if(empty($hours)) {
  $flnetwork->displayError('Form Error', 'The <samp>How many hours do you have' . 
	' available in the week?</samp> field is empty!', false); 
 }
 $categories = $flnetwork->cleanMys($_POST['cats']);
 if(empty($categories)) {
  $flnetwork->displayError('Form Error', 'The <samp>What categories would you' . 
	' prefer working with?</samp> field is empty!', false); 
 }
 $categoriesno = $flnetwork->cleanMys($_POST['catsno']);
 if(empty($hours)) {
  $flnetwork->displayError('Form Error', 'The <samp>What categories will you' . 
	' not work with?</samp> field is empty!', false); 
 }
 
 /** 
  * Check for SPAM words and bots, bbCode, JavaScript, and Akismet \o/ 
	* First: spam words! 
  */ 
 foreach($fnlistings->badwords as $b) {
  if(
	 strpos($_POST['hours'], $b) !== false || 
	 strpos($_POST['cats'], $b) !== false || 
	 strpos($_POST['catsnot'], $b) !== false
	) {
	 $flnetwork->displayError('SPAM Error', 'SPAM language is not allowed.', false);
  }
	if($options->type == 0) {
	 if(
	  strpos($_POST['whyst'], $b) !== false || 
	  strpos($_POST['why2st'], $b) !== false
	 ) {
	  $flnetwork->displayError('SPAM Error', 'SPAM language is not allowed.', false);
   }
	} elseif ($options->type == 1) {
	 if(strpos($_POST['whytc'], $b) !== false) {
	  $flnetwork->displayError('SPAM Error', 'SPAM language is not allowed.', false);
   }
	}
 }

 foreach($fnlistings->bbcode as $h) {
  if(
	 strpos($_POST['hours'], $h) !== false || 
	 strpos($_POST['cats'], $h) !== false || 
	 strpos($_POST['catsnot'], $h) !== false
	) {
	 $flnetwork->displayError('SPAM Error', 'bbCode language is not allowed.', false);
  }
 }

 if(preg_match($bots, $_SERVER['HTTP_USER_AGENT']) || empty($_SERVER['HTTP_USER_AGENT'])) {
  $flnetwork->displayError('SPAM Error', 'SPAM bots are not allowed.', false);
 }

 if(!empty($ak)) {
  $vars = array(
   'user_ip' => $_SERVER['REMOTE_ADDR'],
   'user_agent' => $_SERVER['HTTP_USER_AGENT'],
   'referer' => $_SERVER['HTTP_REFERER'],
   'comment_type' => 'volunteer',
   'comment_author' => $name,
   'comment_author_email' => $email,
   'comment_author_url' => $url,
   'comment_content' => $comments
  );
 
  $check = akismet_check($vars);
  if($check == true) {
   $flnetwork->displayError('SPAM Error', 'It appears Akismet thinks you\'re' . 
	 ' SPAM.|While this isn\'t a <em>huge</em> issue it\'s keeping you from being' . 
	 ' added to the pending list. If you believe you\'re not SPAM, feel free to' . 
	 ' join ' . $hide_email . '.', false);
  }
 }
 
 if($options->type == 0) {
  $insert = "INSERT INTO `$_FN[staffers]` (`sCategory`, `sStatus`, `sRealName`," . 
	" `sBio`, `sName`, `sPassword`, `sEmail`, `sEmailShow`, `sURL`, `sUpdated`," . 
	" `sAdded`, `sPending`) VALUES ('', '!2!', '$name', '', '', ''," . 
	" '$email', '0', '$website', '', NOW(), '1')"; 
 } elseif ($options->type == 1) {
  $insert = "INSERT INTO `$_FN[checkers]` (`tCategory`, `tName`, `tEmail`," . 
	" `tURL`, `tPending`, `tUpdated`, `tAdded`) VALUES ('', '$name', '$email'," . 
	" '$website', '1', '', NOW())";
 }
 $fndatabase->query("SET NAMES 'utf8';");
 $true = $fndatabase->query($insert);
 if($true == false) {
  $flnetwork->displayError('Database Error', 'There was an error adding you to' . 
	' the database!', true, $insert);
 }
 
 elseif ($true == true) {
  $which    = $options->type == 0 ? 'staffer' : 'trouble checker';
  $subjectf = "Volunteer: " . ucwords($which);
  $message .= "You have a received a $which volunteer form for the network:\n\n" . 
	"Name: {$name}\nE-Mail: {$email}\nFanlisting URL: <{$website}>\n\n";
	if($options->type == 0) {
	 $message .= "I have experience staffing: " . $_POST['experiencest'] . 
	 "\n\nWhy I would like to become a staffer: " . $_POST['whyst'] . 
	 "\n\nWhy I'd make a good staffer: " . $_POST['why2st'];
	} elseif ($options->type == 1) {
	 $message .= "I have experience trouble checking: " . $_POST['experiencetc'] . 
	 "\n\nWhy I would like to become a trouble checker: " . $_POST['whytc'];
	}
	$message .= "\n\nI have the following hours available in the" . 
	" week: " . html_entity_decode($hours, ENT_QUOTES, 'ISO-8859-15') . 
	"\nCategories I'm interested in: " . html_entity_decode($categories, ENT_QUOTES, 'ISO-8859-15') . 
	"\nCategories I'm not interested in: " . html_entity_decode($categoriesno, ENT_QUOTES, 'ISO-8859-15') . 
	"\n\nIP Address: {$_SERVER['REMOTE_ADDR']}" . 
	"\nBrowser: {$_SERVER['HTTP_USER_AGENT']}\n\n";

  $headers = "From: {$website_name} <$my_email>\nReply-To: <{$email}>";
  $mail    = mail('seniorstaff@alterlistings.org', $subjectf, $message, $headers);
 
  if($mail) {
   echo '<p><span class="success">Success!</span> Your volunteer form was' . 
	 ' processed and sent to the senior staff for review. Please be aware that' . 
	 " sending in a volunteer form does not guarantee automatic approval.</p>\n";
	} else {
	 echo "<p><span class=\"error\">Error:</span> The form was unable to be sent" . 
	 " to the senior staff. If the problem persists, feel free to contact" . 
	 " the senior staff " . 
	 $fnoptions->javascriptEmail('seniorstaff@alterlistings.org', 'directly here.') . 
	 "</p>\n";
	}
 }
}

/** 
 * Default form! 
 */ 
else {
 $w       = $options->type == 0 ? 'staffer' : 'trouble checker';
 $formuri = $options->type == 0 ? $fnoptions->getOption('formsvStaffer') : $fnoptions->getOption('formsvTC');
?>
<p>Below is the form you can use to send in a volunteer form to apply to be a 
<?php echo $w; ?>.</p>

<h3>Form</h3>
<form action="<?php echo $formuri; ?>" method="post">
<input name="type" type="hidden" value="<?php echo $options->type; ?>">

<table class="volunteer_form" width="100%">
<tbody><tr>
 <td style="text-align: right; width: 40%;"><strong>Name:</strong></td>
 <td style="text-align: left;"><input name="name" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right; width: 40%;"><strong>E-mail Address:</strong></td>
 <td style="text-align: left;"><input name="email" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right; width: 40%;"><strong>URL:</strong></td>
 <td style="text-align: left;"><input name="website" type="text" style="width: 100%;"></td>
</tr></tbody>
<?php  
if($options->type == 0) {
?>
<tbody><tr>
 <td style="text-align: right; width: 40%;"><strong>Do you have any experience staffing?</strong></td>
 <td style="text-align: left;"><input name="experiencest" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right; width: 40%;"><strong>Why would you like to become a staffer?</strong></td>
 <td style="text-align: left;">
  <textarea name="whyst" cols="40" rows="10" style="height: 100px; width: 100%;"></textarea>
 </td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right; width: 40%;"><strong>Why do you think you'd make a good staffer?</strong></td>
 <td style="text-align: left;">
  <textarea name="why2st" cols="40" rows="10" style="height: 100px; width: 100%;"></textarea>
 </td>
</tr></tbody>
<?php 
}

elseif ($options->type == 1) {
?>
<tbody><tr>
 <td style="text-align: right; width: 40%;"><strong>Do you have any experience trouble checking?</strong></td>
 <td style="text-align: left;"><input name="experiencetc" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right; width: 40%;"><strong>Why would you like to become a trouble checker?</strong></td>
 <td style="text-align: left;"><textarea name="whytc" cols="40" rows="10" style="height: 100px; width: 100%;"></textarea></td>
</tr></tbody>
<?php  
}
?>
<tbody><tr>
 <td style="text-align: right; width: 40%;"><strong>How many hours do you have available in the week?</strong></td>
 <td style="text-align: left;"><input name="hours" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right; width: 40%;"><strong>What categories would you prefer to work with?</strong></td>
 <td style="text-align: left;"><input name="cats" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right; width: 40%;"><strong>What categories will you not work with?</strong></td>
 <td style="text-align: left;"><input name="catsno" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td class="tc" colspan="2">
  <input name="action" type="submit" value="Send Form"> 
	<input type="reset" value="Reset">
 </td>
</tr></tbody>
</table>
</form>
<?php 
}
?>
