<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Database Functions <fun-db.inc.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 

if(class_exists('fndatabase') == false) {
 class fndatabase {
  
	public $connect  = '';
  public $database = '';

  /**
   * Our initialising function, which connects us to the database 
	 * through the user's defined method. 
	 * 
	 * @access   public 
   * @function $bondq->bondq() 
	 * @since    0.1 
   */
  public function fndatabase($h, $u, $p, $n) {
   global $floptions;

   if($floptions->dbEngine == 'mysqli') {
    $this->database = new mysqli($h, $u, $p, $n)
    or die(
     '<p class="errorButton"><span class="error">ERROR:</span> You cannot' . 
     ' currently connect to MySQL. Make sure all variables are correct in' . 
     ' <samp>rats.inc.php</samp>; if it is a random error, wait it out and see' . 
     ' if it\'ll magically disappear.</p>'
    );
   } else {
    $this->connect = mysql_connect($h, $u, $p) 
    or die(
     '<p class="errorButton"><span class="error">ERROR:</span> You cannot' . 
     ' currently connect to MySQL. Make sure all variables are correct in' . 
     ' <samp>rats.inc.php</samp>; if it is a random error, wait it out and see' . 
     ' if it\'ll magically disappear.</p>'
    );
    $this->database = mysql_select_db($n) 
    or die(
     '<p class="errorButton"><span class="error">ERROR:</span> You cannot' . 
     ' currently connect to your MySQL database. Make sure all variables are' . 
     ' correct in <samp>rats.inc.php</samp>; if it is a random error, wait it' . 
     ' out and see if it\'ll magically disappear.</p>'
    );
   }
  }

  /** 
	 * MySQL-generated error message. 
	 * 
   * @access   public 
   * @function $bondq->error() 
	 * @since    0.1 
   */ 
  public function error() {
   global $floptions;
   return ($floptions->dbEngine == 'mysql' ? mysql_error() : $this->database->error);
  }

  /** 
   * Close or open connection to the local database settings. 
	 * 
   * @access   public 
   * @function $bondq->breach() 
	 * @since    0.1 
   */ 
	public function breach($y = 1) {
	 global $database, $database_host, $database_name, $database_pass, 
	 $database_user, $floptions;
	 
	 switch($y) {
	  case 0:
     if($floptions->dbEngine == 'mysqli') {
      $this->database->close();
      unset($this->database);
     } else {
		  mysql_close($this->connect);
      unset($this->connect);
		  unset($this->database);
     }
		break;
		
		case 1:
		 $this->scorpions($database_host, $database_user, $database_pass, 
     $database_name);
		break;
	 } 
	}

  /** 
   * Escape text via real_escape_string() and -- optionally -- magic 
	 * quotes gpc D: 
	 * 
	 * @access   public 
   * @function $bondq->escape() 
	 * @since    0.1 
   */ 
  public function escape($p) {
   global $floptions;

   $e = trim($p);
   if(get_magic_quotes_gpc()) {
    $e = stripslashes($e);
   }
   $e = $floptions->dbEngine == 'mysqli' ? $this->database->real_escape_string($e) : 
   mysql_real_escape_string($e);

   return $e;
  }

  /** 
   * Return status, error message and row count; query should be 
	 * passed through the $q param. 
   * 
   * @access   public 
   * @function $bondq->counts() 
	 * @since    0.1 
   */ 
  public function counts($q, $e = 1, $m =  '') {
   global $floptions;

   $r = (object) array(
    'message' => '',
    'rows' => 0,
    'status' => false
   );

   $select = $q;
   if($floptions->dbEngine == 'mysqli') {
    $true = $this->database->query($select);
   } else {
    $true = mysql_query($select);
   }
    
   /**  
    * Are we returning strictly the boolean return value, or values 
    * and messages? 
    */ 
   if($e == 1) {
    $r->status = $true == false ? false : true;
   } else {
    if($true == false) {
     $r->status = false;
     $r->message = $m;
    } else {
     $r->status = true;
    }
   }

   /**  
    * Fetch our number of rows, depending on the database method~ 
    */
   $r->rows = $floptions->dbEngine == 'mysqli' ? $true->num_rows : mysql_num_rows($true);

   return $r;
  }

  /** 
   * Instead of repeating the OOP and procedural coding 34859959 
   * times over, we've got a handy function for fetching columns or
	 * an object from the database. \o/ 
   * 
   * @access   public 
   * @function $bondq->fetch() 
	 * @since    0.1 
   */ 
  public function fetch($q, $m = '', $e = '') {
   global $floptions, $flnetwork;

   $select = $q;

   /**  
    * Are there actually an results to pull from? Find this out first 
    * and send us back if we don't~ 
    */ 
   $c = $this->counts($select, 1);
   if($c->rows == 0) {
    return '';
   }

   if($floptions->dbEngine == 'mysqli') {
    $true = $this->database->query($select);
   } else {
    $true = mysql_query($select);
   }
   if($true == false) {
    $o = $e != '' ? $e : 'There was an error in selecting the specified data' . 
    ' from the database.';
    $flnetwork->displayError('Database Error', $o, false);
   }

   /** 
    * Fetch our data, whether we're pulling full rows, or just one value~ :D 
    */
   $getItem = $floptions->dbEngine == 'mysqli' ? $true->fetch_object() : mysql_fetch_object($true);
   $r = $m != '' ? ($m == '*' ? $getItem : $getItem->$m) : $true;

   return $r;
  }

  /** 
   * Insert row into the database; query should be formed 
	 * through the $q param.
   * 
   * @access   public 
   * @function $bondq->insert() 
	 * @since    0.1 
   */ 
  public function insert($q, $e = 0) {
   global $flnetwork, $floptions;

   $r = false;

   $insert = $q;
   if($floptions->dbEngine == 'mysqli') {
    $this->database->query("SET NAMES 'utf8';");
    $true = $this->database->query($insert);
   } else {
    mysql_query("SET NAMES 'utf8';");
    $true = mysql_query($insert);
   }
    
   /**  
    * Are we returning strictly the boolean return value, or values 
    * and messages? 
    */ 
   if($e == 0) {
    $r = $true == false ? false : true;
   } else {
    if($true == false) {
     $flnetwork->displayError('Database Error', 'The script was unable to insert' . 
     'the data.', false);
    } else {
     $r = true;
    }
   }

   return $r;
  }
	
	/** 
	 * Get last ID inserted into the database. 
	 * 
   * @access   public 
   * @function $bondq->lastid() 
	 * @since    0.1  
   */ 
  public function lastid($q) {
   global $floptions;

   if($floptions->dbEngine == 'mysqli') {
    $true = $q->insert_id;
   } else {
    $true = mysql_insert_id($q);
   }

   return $true;
  }

  /** 
	 * Return object (or array if $m is set to 1) of rows affected by 
	 * the query passed through the $q param. 
	 * 
   * @access   public 
   * @function $bondq->obj() 
	 * @since    0.1 
   */ 
  public function obj($q, $m = 0) {
   global $floptions;

   if($m == 0) {
    $getItem = $floptions->dbEngine == 'mysqli' ? $q->fetch_object() : mysql_fetch_object($q);
   } else {
    $getItem = $floptions->dbEngine == 'mysqli' ? $q->fetch_array() : mysql_fetch_array($q);
   }

   return $getItem;
  }

  /** 
	 * Submit query as-is to the database! 
	 * 
   * @access   public 
   * @function $bondq->query() 
	 * @since    0.1 
   */ 
  public function query($q) {
   global $floptions;
	 
	 if($q == '') {
	  return;
	 }

   $select = $q;
   if($floptions->dbEngine == 'mysqli') {
    $true = $this->database->query($select);
   } else {
    $true = mysql_query($select);
   }

   return $true;
  }

  /** 
   * $this->counts() returns the rows, status and an error message 
   * if one is given; $this->total() returns the rows only 
   * 
   * @access   public 
   * @function $bondq->total() 
	 * @since    0.1 
   */ 
  public function total($q) {
   global $floptions;

   $count = $floptions->dbEngine == 'mysqli' ? $q->num_rows : mysql_num_rows($q);

   return $count;
  }

  /** 
	 * Update SQL queries 
	 * 
   * @access   public 
   * @function $bondq->cleanMys() 
	 * @since    0.1 
   */ 
  public function update($q, $e = 1, $m = '') {
   global $flnetwork, $floptions;
   
   $update = $q;
   if($floptions->dbEngine == 'mysqli') {
    $this->database->query("SET NAMES 'utf8';");
    $true = $this->database->query($update);
   } else {
    mysql_query("SET NAMES 'utf8';");
    $true = mysql_query($update);
   }

   if($e == 1) {
    return $true == false ? false : true;
   } else {
    $s = explode("__", $m);
    $s = $flnetwork->emptyarray($s);
    if($true == false) {
     $flnetwork->displayError('Database Error', $s[0], false);
    } else {
     echo "<p class=\"successButton\"><span class=\"success\">Success!</span>" . 
     $s[1] . "</p>\n";
    }
   }
  }
	
 }
}
?>