<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2008 
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Variable <b.inc.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
if(defined('MAINDIR') == false) {
 define('MAINDIR', str_replace('inc', '', dirname(__FILE__)));
}
?>
