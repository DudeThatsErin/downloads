<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Listing Functions <fun-listings.inc.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 

if(class_exists('fnlistings') == false) {
 class fnlistings {
 
  public $cheatAnti       = 'antispamh';
  public $cheatSpam       = 'antispamb';
  public $cheatCaptcha    = 'captchav';
  public $cheatJavascript = 'cheathisSheet';
	
	/** 
	 * Get arrays for checking spam-ish form requests 
	 */ 
	public $badwords        = array(
	 "alert", "bcc:", "cc:", "content-type", "document.cookie", "javascript", 
	 "lxfrlvnqdedq", "vdgcrzdyduup"
	);
	public $bbcode          = array(
   '[b]', '[/b]', '[b', '/b]', '[i]', '[i', '[link]', '[/link]', 
   '[link', '[link=', '/link]', '[url]', '[/url]', '[url', '[url=', '/url]'
  );
 
  /** 
	 * @function  $fnlistings->listingCount() 
   * 
   * @param     $b, string; pull by parent; optional 
	 * @param     $p, string; creturn category ID, name or table name 
	 */ 
  public function listingCount($s = 'all', $a) {
   global $_FN, $fndatabase, $flnetwork, $fncategories;

   $getItem = $fncategories->getCategory($a);
   $select  = "SELECT * FROM `" . $getItem->tableName . "`";
   if($s == 'approved') {
    $select .= " WHERE `fStatus` = '0'";
   } elseif ($s == 'upcoming') {
    $select .= " WHERE `fStatus` = '1'";
   } elseif ($s == 'pending') {
    $select .= " WHERE `fStatus` = '2'";
   }
   $true = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Script Error', 'The script was unable to select' . 
		' the listing count from the specified category table.', true, $select);
   }
   $count = $fndatabase->total($true);

   return $count;
  }
 
  /** 
	 * @function  $fnlistings->replaceSubject() 
	 */ 
  public function replaceSubject($p) {
	 global $flnetwork;
   return $flnetwork->replaceSpec($p);
  }

  /** 
   * @function  $fnoptions->javascriptCheat() 
   * @param     $p, string; sha1() hash 
   */ 
  public function javascriptCheat($p) {
   global $options;
 
   $s = "<script type=\"text/javascript\">\n<!--\n" .
	 " var jsString = '$p';\n document.write('<input name=\"" . $this->cheatJavascript . 
   "\" type=\"hidden\" value=\"' + jsString + '\"" . $options->markup . 
   ">');\n//-->\n</script>\n";
   return $s;
  }
	
	/** 
   * @function  $fnlistings->getListing() 
	 * 
	 * @param     $a, string; table name 
   * @param     $i, int; listing ID or subject 
	 * @param     $b, string; pull by ID or subject 
   */
  public function getListing($a, $i, $b = 'id') {
   global $fndatabase, $flnetwork;
	 
   $select = "SELECT * FROM `$a`";
	 if($b == 'id') {
	  $select .= " WHERE `fID` = '$i'";
	 } elseif ($b == 'subject') {
	  $select .= " WHERE `fSubject` = '$i'";
	 }
	 $select .= " LIMIT 1";
   $true    = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script could not select the' . 
		' listing from the database.', false);
   }
   $getItem = $fndatabase->obj($true);

   return $getItem; 
  }
	
	/** 
   * @function  $fnoptions->getSubject() 
   * @param     $a, string; table name 
	 * @param     $i, int; listing ID 
   */ 
  public function getSubject($a, $i) {
   $getItem = $this->getListing($a, $i);
   return $getItem->fSubject; 
  }

  /** 
   * @function  $fnoptions->getSubcat() 
   * @param     $a, string; table name 
	 * @param     $s, string; listing subject 
   */ 
  public function getSubcat($a, $s) {
   $getItem = $this->getListing($a, $s, 'subject');
   return $getItem->fSubcat; 
  }

  /** 
   * @function  $fnoptions->pullName() 
   * @param     $s, string; subject 
	 * @param     $c, string; table name 
   */ 
  public function pullName($s, $c) {
   $getItem = $this->getListing($c, $s, 'subject');
   return $getItem->ownerName;
  }
	
	/** 
   * @function  $fnoptions->getTrouble() 
   * @param     $i, int; listing ID 
	 * @param     $c, string; table name 
   */ 
  public function getTrouble($i, $c) {
   global $_FN, $fndatabase, $flnetwork;

   $select = "SELECT * FROM `$_FN[troubles]` WHERE `tListing` = '$i' AND" . 
	 " `tCategory` = '$c' LIMIT 1";
   $true = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to select' . 
		' the trouble from the specified listing and table.', true, $select);
   }
   $getItem = $fndatabase->obj($true);
   
	 return $getItem;
  }

  /** 
   * @function  $fnoptions->memberTrouble() 
   * @param     $s, int; listing ID 
	 * @param     $c, string; trouble category 
   */ 
  public function memberTrouble($s, $c) {
   global $_FN, $fndatabase, $flnetwork;

   $getItem        = $this->getTrouble($s, $c);
   $email_template = $getItem->tProblem;

   $select = "SELECT `troubEmailTemplate` FROM `$_FN[troubles_templates]` WHERE" . 
	 " `troubName` = '$email_template' LIMIT 1";
   $true = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to select' . 
		' the email template from the specified listing.', true, $select);
   }
   $getRows = $fndatabase->obj($true);

   return $getRows->troubEmailTemplate;
  }
	
	/** 
   * @function  $fnoptions->javascriptCheat() 
   * @param     $p, string; sha1() hash 
   */
  public function getEmail($s, $c) {
   global $flnetwork;

   $select = "SELECT `authorEmail` FROM `$c` WHERE `fSubject` = '$s' LIMIT 1";
   $true = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to select the' . 
		' subject from the specified category table.|Make sure the category\'s' . 
		' table exists.', true, $select);
   }
   $getItem = $fndatabase->obj($true);

   return $getItem->authorEmail;
  }
	
	/** 
   * @function  $fnlistings->javascriptEmail() 
   * @param     $e, string; e-mail address 
   */ 
  public function javascriptEmail($c, $p, $e = 'e-mail me') {
	 global $fnoptions;
	 $m = $fnoptions->getCatOption($c, $p);
   $s = "<script type=\"text/javascript\">\n<!--\n" . 
	 " var jsEmail = '$m';\n" .
   " document.write('<a h' + 'ref=\"mailto:' + jsEmail + '\">$e</' + 'a>');\n" . 
   "//-->\n</script>\n";
   return $s;
  }
	
 }
}

$fnlistings = new fnlistings();

/** 
 * Our e-mail class! \o/ 
 * 
 * @package     Listings 
 * @subpackage  E-mails  
 * @class       $fnemails 
 * @since       2.0  
 * @version     0.1    
 */ 
if(class_exists('fnemails') == false) {
 class fnemails extends fnlistings {

  /** 
   * @function  $fnoptions->mailOwner() 
	 * @param     $c, string; table name 
   * @param     $s, string; listing subject 
	 * @param     $b, string; subcategory 
   */ 
  public function mailOwner($c, $s, $b = '') {
   global $_FN, $fncategories, $fnoptions, $flnetwork;

   $template = html_entity_decode(
	  $fnoptions->getTemplate('email_approval'), ENT_QUOTES, 'ISO-8859-15'
	 );
	 $subj     = $flnetwork->replaceSpec($s);
	 $getItem  = $this->getListing($c, $s, 'subject');
   $email    = $getItem->ownerEmail;
   $name     = $getItem->ownerName;
   $my_email = $fnoptions->getCatOption($c, 'stafferApplicationsEmail');
	 
	 $g = $fncategories->getCategory($c, 'table');
	 $sb = '';
	 if($b != '') {
	  $sb .= ", listed in the ";
	  $sb .= $g->catSubcats == 1 ? $fncategories->getCatName($b, 'id') : '';
	  $sb .= " subcategory,";
	 }
	 
   $format  = str_replace('+name+', $name, $template);
   $format  = str_replace('+category+', $fncategories->getCatName($c, 'table'), $format);
   $format  = str_replace('+staffer+', $fnoptions->getCatOption($c, 'stafferApplications'), $format);
   $format  = str_replace('+subject+', $subj, $format);
	 $format  = str_replace('+subcategory+', $sb, $format);
   $body    = $format;
   $headers = "From: <$my_email>\nReply-To: <$my_email>";

   if(mail($email, "Approval: " . $subj, $body, $headers)) {
    $r = true;
   } else {
    $r = false;
   }
 
   return $r;
  }

  /** 
   * @function  $fnoptions->mailbyTemplate() 
	 * 
	 * @param     $c, string; table name 
	 * @param     $subcat, string; subcategory 
   * @param     $s, string; listing subject 
	 * @param     $e, string; owner e-mail 
	 * @param     $t, string; template slug 
	 * @param     $n 
   */ 
  public function mailbyTemplate($c, $subcat, $s, $e, $t, $n = '') {
   global $_FN, $flnetwork, $fncategories, $fnoptions;

   $temp     = $n == '' ? $t : 'update_new_owner';
	 $template = html_entity_decode(
	  $fnoptions->getTemplate("email_" . $temp), ENT_QUOTES, 'ISO-8859-15'
	 );
	 $subj     = $flnetwork->replaceSpec($s);
   $getItem  = $this->getListing($c, $s, 'subject');
   $name     = $getItem->ownerName;
   $my_email = $fnoptions->getCatOption($c, 'stafferFormsEmail');
 
   if($t == 'closed') {
    $title = "Closed: ";
   } elseif ($t == 'finished') {
    $title = "Finished: ";
   } elseif ($t == 'update') {
    $title = "Update Info: "; 
   }

   $format = str_replace('+name+', $name, $template);
   $format = str_replace('+category+', $fncategories->getCatName($c, 'table'), $format);
   $format = str_replace('+subcategory+', $fncategories->getCatName($subcat), $format);
   $format = str_replace('+staffer+', $fnoptions->getCatOption($c, 'stafferForms'), $format);
   $format = str_replace('+subject+', $subj, $format);
   $body   = $format;

   $headers = "From: <$my_email>" . "\n";
   $headers .= "Reply-To: <$my_email>";

   if(mail($e, $title . $subj, $body, $headers)) {
    $r = true;
   } else {
    $r = false;
   }
  
   return $r; 
  }

  /** 
   * @function  $fnoptions->mailTrouble() 
	 * 
	 * @param     $cat, string; table name 
   * @param     $s, string; listing subject 
	 * @param     $c, string; template slug 
   */ 
  public function mailTrouble($cat, $s, $c = '') {
   global $_FN, $flnetwork, $fncategories, $fnoptions;

   $trouble_template = $this->memberTrouble($s, $cat);
   if($c == '') {
	  $template = $fnoptions->getTemplate($trouble_template);
    $title    = $fnoptions->templateTitle($trouble_template);
   } else {
	  $template = $fnoptions->getTemplate($c);
    $title    = $fnoptions->templateTitle($c);
	 }
	 
	 $template = html_entity_decode(
	  $template, ENT_QUOTES, 'ISO-8859-15'
	 );
   $getItem  = $this->getListing($cat, $s);
	 $subj     = $flnetwork->replaceSpec($getItem->fSubject);
   $email    = $getItem->ownerEmail;
   $name     = $getItem->ownerName;
   $my_email = $fnoptions->getCatOption($cat, 'stafferTroublesEmail');

   $format = str_replace('+name+', $name, $template);
   $format = str_replace('+category+', $fncategories->getCatName($cat, 'table'), $format);
   $format = str_replace('+staffer+', $fnoptions->getCatOption($cat, 'stafferTroubles'), $format);
   $format = str_replace('+subject+', $subj, $format);
   $body   = $format;

   $headers = "From: <$my_email>" . "\n";
   $headers .= "Reply-To: <$my_email>";

   if(mail($email, $title . ": " . $subj, $body, $headers)) {
    $r = true;
   } else {
    $r = false;
   }
 
   return $r;
  }
	
 }
}

$fnemails = new fnemails();
?>
