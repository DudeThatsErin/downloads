<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Check Functions <fun-check.inc.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 

if(class_exists('fnchecker') == false) {
 class fnchecker {

  public function checkUsername($n) {
   global $_FN, $fndatabase, $flnetwork;

   $select = "SELECT `sName` FROM `$_FN[staffers]` WHERE `sName` = '$n'";
   $true   = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to check your' . 
		' username', false);
   }
   $count = $fndatabase->total($true);
 
   if($count == 1) {
    $r = true;
   } else {
    $r = false;
   }

   return $r;
  }

  public function checkEmail($e) {
   global $_FN, $fndatabase, $flnetwork;

   $select = "SELECT `sEmail` FROM `$_FN[staffers]` WHERE `sEmail` = '$e'";
   $true   = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to check your' . 
		' email address.', false);
   }
   $count = $fndatabase->total($true);
 
   if($count == 1) {
    $r = true;
   } else {
    $r = false;
   }

   return $r;
  }

  public function checkEmailChange() {
   global $_FN, $fndatabase, $flnetwork;
 
   $i      = $flnetwork->cleanMys($_COOKIE['fnusr']);
   $select = "SELECT `sEmail` FROM `$_FN[staffers]` WHERE `sID` = '$i' LIMIT 1";
   $true   = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to check your' . 
		' email address.', false);
   }
   $getItem = $fndatabase->obj($true);
 
   if($getItem == false || empty($getItem->sEmail)) {
    $r = false;
   } else {
    $r = $getItem->sEmail;
	 }

   return $r;
  }

  public function checkPassword($p) {
   global $_FN, $fndatabase, $flnetwork;

   $i = $flnetwork->cleanMys($_COOKIE['fnusr']);
   $select = "SELECT * FROM `$_FN[staffers]` WHERE `sPassword` = '$p' AND `sID`" . 
	 " = '$i' LIMIT 1";
   $true = $fndatabase->query($select);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to check your' . 
		' password.', false); 
   }
   $count = $fndatabase->total($true);
 
   if($count == 1) {
    $r = true;
   } else {
    $r = false;
   }

   return $r;
  }

  public function checkSubject($cat, $subcat, $subject, $s = 'pending') {
   global $fndatabase, $flnetwork;
   
	 $select = "SELECT * FROM `$cat` WHERE `fSubCat` = '$subcat' AND `fSubject`" . 
	 " = '$subject'";
   if($s == 'current') {
    $select .= " AND `fStatus` != '2'";
   }
   $true  = $fndatabase->query($select);
   $count = $fndatabase->total($true);

   if($count == 0) {
    $r = false;
   } else {
    $r = true;
   } 

   return $r;
  }
	
 }
}

$fnchecker = new fnchecker();
?>
