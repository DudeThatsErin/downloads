<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Admin Functions <fun-admin.inc.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 

if(class_exists('fnadmin') == false) {
 class fnadmin {
 
  /** 
	 * Get contact form arrays :D 
	 */ 
	public $sscontact = array(
	 'complaints' => 'Complaints',
	 'donations'  => 'Donations',
	 'downtime'   => 'Downtime',
	 'extensions' => 'Extensions',
	 'general'    => 'General'
	);
	
	public $cscontact = array(
	 'apps'    => 'Applications',
	 'forms'   => 'Forms',
	 'general' => 'General',
	 'report'  => 'Report a Fanlisting'
	);
 
  /** 
   * @function  $fnadmin->isTitle() 
   * @param     $e, string 
   */ 
  public function isTitle($getTitle) {
   if(!empty($getTitle)) {
    return $getTitle;
   } else {
    return 'A Network Management Script';
   }
  } 

  /** 
   * @function  $fnadmin->isPage() 
   */
  public function isPage() {
   return basename($_SERVER['PHP_SELF']);
  }

  /** 
   * @function  $fnadmin->isExt() 
   */
  public function isExt() {
	 global $flnetwork;
   return (isset($_GET['table']) ? $flnetwork->cleanMys($_GET['table']) : '');
  }

  /** 
   * Return a string of the copyright year and the current year; will 
   * return only the current year if $o and $y are the same 
   * 
	 * @function  $fnadmin->isYear() 
	 * @param     $o, digits; four-digit year 
	 */ 
  public function isYear($o) {
   $y = date("Y");
   if($o == $y) {
    return $o;
   } else {
    return $o . "-" . $y;
   }
  }

  /** 
   * @function  $fnadmin->isUser() 
   */
  public function isUser() {
	 global $flnetwork;
   return $flnetwork->cleanMys($_COOKIE['fnusr']);
  }
	
	/** 
	 * @function  $fnadmin->isCurrent() 
	 */ 
	public function isCurrent($c, $a = 0) {
	 $b = $a == 1 ? " border" : '';
	 return ($this->isPage() == $c . '.php' ? " class=\"current{$b}\"" : ($a == 1 ? " class=\"border\"" : ''));
	}
	
 }
}

$fnadmin = new fnadmin();
?>
