<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Application Form <show-application.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
require("b.inc.php");
require(MAINDIR. "rats.inc.php");
require_once("fun.inc.php");
require_once("fun-categories.inc.php");
require_once("fun-check.inc.php");
require_once("fun-listings.inc.php");
require_once("fun-misc.inc.php");
require(MAINDIR . "vars.inc.php");

$ak = $fnoptions->getOption('akismetKey');
if(!empty($ak)) {
 require_once("func.microakismet.inc.php");
}

if(isset($_GET['cat']) && !empty($_GET['cat'])) {
 $cat = $flnetwork->cleanMys($_GET['cat']);
 if(!in_array($cat, $fncategories->categoryList('id', 'table'))) {
  $flnetwork->displayError('Script Error', 'It appears the categpry you are' . 
	' trying to apply in does not exist. Go back and try again.', false);
 }
 echo $flnetwork->replaceSpec($fnoptions->getOption('generalRules'));

 $indi_rules = $fnoptions->getCatOption($cat, 'categoryRules');
 if(!empty($indi_rules)) {
  echo "<h3>Category Rules</h3>\n";
  echo $flnetwork->replaceSpec($indi_rules) . "\n\n";
 }
 
 $formuri = $fnoptions->getOption('formsApps');
?>

<h3>Apply Form</h3>
<form action="<?php echo $formuri; ?>" method="post">
<input name="category" type="hidden" value="<?php echo $cat; ?>">
<?php 
$jk = $fnoptions->getOption('javascriptKey');
if(!empty($jk)) {
 echo $fnlistings->javascriptCheat(sha1($fnoptions->getOption('javascriptKey'))); 
} 
?>

<table class="apply_form" width="100%">
<tbody><tr>
 <td style="text-align: right;"><strong>Name:</strong></td>
 <td style="text-align: left;"><input name="name" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right;"><strong>E-mail Address:</strong></td>
 <td style="text-align: left;"><input name="email" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right;"><strong>Website (HTML Example):</strong></td>
 <td style="text-align: left;"><input name="website" type="text" style="width: 100%;"></td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right;"><strong>Subject:</strong></td>
 <td style="text-align: left;"><input name="subject" type="text" style="width: 100%;"></td>
</tr></tbody>
<?php 
 $getItem = $fncategories->getCategory($cat, 'table');
 $catID   = $fncategories->getCatID($cat);
 if($getItem->catSubcats == 1) {
  $select = $fndatabase->query("SELECT * FROM `$_FN[categories]` WHERE `catParent`" . 
	" = '$catID' ORDER BY `catName` ASC");
  if($fndatabase->total($select) > 0) {
?>
<tbody><tr>
 <td style="text-align: right;"><strong>Subcategory:</strong></td>
 <td style="text-align: left;"><select name="subcategory" class="input1" style="width: 100%;">
<?php  
   while($getItem = $fndatabase->obj($select)) {
    echo "   <option value=\"" . $getItem->catID . "\">" . $getItem->catName . 
		"</option>\n";
   }
?>
  </select>
 </td>
</tr></tbody>
<?php 
  }
 }
?>
<tbody><tr>
 <td style="text-align: right;"><strong>Extra Info:</strong></td>
 <td style="text-align: left;">
  <textarea name="extrainfo" cols="40" rows="10" style="height: 100px; width: 100%;"></textarea>
 </td>
</tr></tbody>
<tbody><tr>
 <td style="text-align: right;"><strong>Comments:</strong></td>
 <td style="text-align: left;">
  <textarea name="comments" cols="40" rows="10" style="height: 100px; width: 100%;"></textarea>
 </td>
</tr></tbody>
<tbody><tr>
 <td class="tc" colspan="2">
  <input name="action" type="submit" value="Apply!"> 
  <input type="reset" value="Reset">
 </td>
</tr></tbody>
</table>
</form>
<?php 
}

elseif (isset($_POST['action']) && $_POST['action'] == 'Apply!') {
 $category = $flnetwork->cleanMys($_POST['category']);
 if(empty($category) || !in_array($category, $fncategories->categoryList('id', 'table'))) {
  $flnetwork->displayError('Script Error', 'It appears the category you are trying' . 
	' to apply in does not exist. Go back and try again.', false);
 }
 $item        = $fncategories->getCategory($category, 'table');
 $staff_email = $fnoptions->getCatOption($category, 'stafferApplicationsEmail');
 $name        = $flnetwork->cleanMys($_POST['name']);
 if(empty($name) || !preg_match("/([A-Za-z-\s]+)/i", $name)) { 
  $flnetwork->displayError('Form Error', 'There are invalid characters in' . 
	' the <samp>name</samp> field. Go back and try again.', false);
 } 
 $name = ucwords($name);
 $email = $flnetwork->cleanMys($_POST['email']);
 if(
  empty($email) || 
  !preg_match("/([A-Za-z0-9-_\.]+)@(([A-Za-z0-9-_]+\.)+)([a-zA-Z]{2,4})$/i", $email)
 ) {
  $flnetwork->displayError('Form Error', 'The characters specified in the' . 
	' <samp>email</samp> field are not allowed.', false); 
 }
 $website = $flnetwork->cleanMys($_POST['website']);
 if(empty($website)) { 
  $flnetwork->displayError('Form Error', 'The <samp>website</samp> field is' . 
	' empty.', false);
 } elseif (preg_match("@(http://)([A-Za-z0-9-_\./?]+)([A-Za-z\.]{2,4})/?$@i", $website) === false) {
  $flnetwork->displayError('Form Error', 'The <samp>website</samp> field is' . 
	' not valid. Please supply a valid site URL or empty the field.', false);
 }
 $subcategory = $flnetwork->cleanMys($_POST['subcategory']);
 $subcategoryArray = $fncategories->catSubcats($fncategories->getCatID($category));
 if(isset($_POST['subcategory'])) {
  if(empty($subcategory)) {
   $flnetwork->displayError('Script Error', 'The <samp>subcategory</samp> is empty;' . 
	 ' please make sure to fill out the field by entering the series of the' . 
	 ' character.', false);
	}
 } else {
  $subcategory = '';
 }
 $subject = $flnetwork->cleanMys($_POST['subject']);
 if(empty($subject)) {
  $flnetwork->displayError('Script Error', 'The <samp>subject</samp> is empty.', false);
 } elseif ($fnchecker->checkSubject($category, $subcategory, $subject, 'current') == true) {
  $flnetwork->displayError('Script Error', 'The <samp>fanlisting subject</samp> you' . 
	' are trying to apply for already exists. Please make sure to check if the' . 
	' fanlisting is approved (upcoming or otherwise), and that you have used the' . 
	' correct title for the subject.', false);
 }
 $extrainfo = $flnetwork->cleanMys($_POST['extrainfo']);
 if(empty($extrainfo)) {
  $flnetwork->displayError('Script Error', 'The <samp>extra info</samp> field is' . 
	' empty. It is required you provide a link to information about the subject' . 
	' you are applying for.', false);
 }
 $comments = $flnetwork->cleanMys($_POST['comments']);

 /** 
  * Check for SPAM words and bots, bbCode, JavaScript, and Akismet \o/ 
	* First: spam words! 
  */ 
 foreach($fnlistings->badwords as $b) {
  if(strpos($_POST['extrainfo'], $b) !== false || strpos($_POST['comments'], $b) !== false) {
	 $flnetwork->displayError('SPAM Error', 'SPAM language is not allowed.', false);
  }
 }

 foreach($fnlistings->bbcode as $h) {
  if(strpos($_POST['extrainfo'], $h) !== false || strpos($_POST['comments'], $h) !== false) {
	 $flnetwork->displayError('SPAM Error', 'bbCode language is not allowed.', false);
  }
 }

 if(preg_match($bots, $_SERVER['HTTP_USER_AGENT']) || empty($_SERVER['HTTP_USER_AGENT'])) {
  $flnetwork->displayError('SPAM Error', 'SPAM bots are not allowed.', false);
 }

 $jk = $fnoptions->getOption('javascriptKey');
 if(!empty($jk)) {
  if(
	 !isset($_POST[$fnlistings->cheatJavascript]) || 
	 $_POST[$fnlistings->cheatJavascript] != sha1($jk)
	) {
   $flnetwork->displayError('Form Error', 'It appears you have JavaScript' . 
	 ' turned off. As it is required to have JavaScript enabled, I suggest you' . 
	 ' go back and enable it.', false);
  }
 }

 if(!empty($ak)) {
  $vars = array(
   'user_ip' => $_SERVER['REMOTE_ADDR'],
   'user_agent' => $_SERVER['HTTP_USER_AGENT'],
   'referer' => $_SERVER['HTTP_REFERER'],
   'comment_type' => 'join',
   'comment_author' => $name,
   'comment_author_email' => $email,
   'comment_author_url' => $url,
   'comment_content' => $comments
  );
 
  $check = akismet_check($vars);
  if($check == true) {
   $flnetwork->displayError('SPAM Error', 'It appears Akismet thinks you\'re' . 
	 ' SPAM.|While this isn\'t a <em>huge</em> issue it\'s keeping you from being' . 
	 ' added to the pending list. If you believe you\'re not SPAM, feel free to' . 
	 ' join ' . $hide_email . '.', false);
  }
 }

 /** 
  * Now we can add the listing! 
  */ 
 $insert = "INSERT INTO `$category` (`ownerName`, `ownerEmail`, `ownerURL`," . 
 " `fSubcat`, `fSubject`, `fURL`, `fStatus`, `fAdded`, `fAppr`, `fUpdated`)" . 
 " VALUES ('$name', '$email', '$website', '$subcategory', '$subject', '', '2'," . 
 " NOW(), '', '')";
 $true = $fndatabase->query($insert);
 if($true == false) {
  $flnetwork->displayError('Database Error', 'The script was unable to add your' . 
	' listing to the database.', true, $insert);
 } 
 
 elseif ($true == true) {
  $subname  = isset($_POST['subcategory']) ? $fncategories->getCatName($subcategory) : '';
  $subjectf = "Application: " . $fnlistings->replaceSubject($subject);
  $message .= "You have a received a new application for the " . 
  $fncategories->getCatName($category, 'table') .  " category:\n\nName: {$name}" . 
	"\nE-Mail: {$email}\nURL: <{$website}>\n\n" . 
	"Subject: " . $fnlistings->replaceSubject($subject) . 
	"\nCategory: " . $fncategories->getCatName($category, 'table') . "\n";
  if(isset($_POST['subcategory'])) {
   $message .= "Subcategory: {$subname}\n\n";
  } else {
   $message .= "\n";
  }
  $message .= "Extra Info: " . html_entity_decode($extrainfo) . 
	"\nComments: " . html_entity_decode($comments) . 
	"\n\nIP Address: {$_SERVER['REMOTE_ADDR']}\nBrowser:" . 
	" {$_SERVER['HTTP_USER_AGENT']}\n\nTo moderate this listing, go here:" . 
	" <{$admin_http}>";

  $headers = "From: {$website_name} <$my_email>\nReply-To: <{$email}>";
  $mail    = mail($staff_email, $subjectf, $message, $headers);
	if($mail) {
   echo '<p><span class="success">Success!</span> Your application was processed' . 
	 ' and entered into the database, ready for review by a staff member. As there' . 
	 ' is usually weeks - possibly months - between application updates, please' . 
	 ' given the category applications staffer time to process your application' . 
	 " and get back to you.</p>\n<p>If a applications update was posted <em>after" . 
	 '</em> your application was sent in and you were not contacted, feel more' . 
	 " than free to contact the staffer of the category, or the senior staff.</p>\n";
	} else {
	 echo "<p><span class=\"error\">Error:</span> The application was added to" . 
	 " the database, but an e-mail was unable to be sent to the applications" . 
	 " staffer. While the staffer will see the application in the database, you" . 
	 " are more than free to check on your application by contact form, or by " . 
	 $fnlistings->javascriptEmail($category, 'stafferApplicationsEmail', 'direct e-mail') . 
	 "</p>\n";
	}
 }
}

/**  
 * Index 
 */ 
else {
?>
<p>Below you can choose the category you wish to apply for a fanlisting in. 
Categories that aren't linked are deprecated or aren't available for 
applications.</p>

<table class="index" style="width: 100%;">
<?php 
 $select = "SELECT * FROM `$_FN[categories]` WHERE `catParent` = '0' ORDER BY" . 
 " `catName` ASC";
 $true  = $fndatabase->query($select);
 $count = $fndatabase->total($true);

for($i = 0; $i < $count; $i++) {
 $getItem = $fndatabase->obj($true);
 if($i % 2 == 0) {
  echo "<tr>\n";
 }
 echo ' <td class="tc"><a href="?cat=' . $getItem->tableName . 
 '">' . $getItem->catName . "</a></td>\n";
 if(($i % 2) == (2 - 1) || ($i + 1) == $count) {
  echo "</tr>\n";
 }
}
?>
</table>
<?php 
}
?>
