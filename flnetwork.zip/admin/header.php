<!DOCTYPE html>

<html lang="en">

<head>
 <meta charset="utf-8">
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 <title> <?php echo $fnoptions->getOption('siteName'); ?> &#8212; <?php echo $fnadmin->isTitle($getTitle); ?> </title>
 <link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>

<div id="container">

<header>
 <h1><?php echo $fnoptions->getOption('siteName'); ?></h1>
</header>

<div id="wrapper">

<nav>
<?php 
if($fnusers->userStatus() == 1) {
?>
<menu>
 <li<?php echo $fnadmin->isCurrent('categories', 1); ?>><a href="categories.php">Categories</a></li>
 <li<?php echo $fnadmin->isCurrent('templates'); ?>><a href="templates.php">E-Mail Templates</a></li>
<?php 
if($fnadmin->isPage() == 'templates.php') {
?>
 <li class="last">
  <menu>
   <li>&#187; <a href="templates.php?g=new">Add Template</a></li>
   <li>&#187; <a href="templates.php?g=old">Edit Template</a></li>
   <li>&#187; <a href="templates.php?g=erase">Delete Template</a></li>
  </menu>
 </li>
<?php 
}
?>
 <li<?php echo $fnadmin->isCurrent('templates_troubles'); ?>><a href="templates_troubles.php">Troubles Templates</a></li>
<?php 
if($fnadmin->isPage() == 'templates_troubles.php') {
?>
 <li class="last">
  <menu>
   <li>&#187; <a href="templates_troubles.php?g=new">Add Template</a></li>
   <li>&#187; <a href="templates_troubles.php?g=old">Edit Template</a></li>
   <li>&#187; <a href="templates_troubles.php?g=erase">Delete Template</a></li>
  </menu>
 </li>
<?php 
}
?>
 <li<?php echo $fnadmin->isCurrent('options'); ?>><a href="options.php">Options</a></li>
 <li<?php echo $fnadmin->isCurrent('codes'); ?>><a href="codes.php">Display Codes</a></li>
</menu>

<menu>
 <li<?php echo $fnadmin->isCurrent('staffers', 1); ?>><a href="staffers.php">Staffers</a></li>
<?php 
if($fnadmin->isPage() == 'staffers.php') {
?>
 <li class="last">
  <menu>
   <li>&#187; <a href="staffers.php?g=new">Add Staffer</a></li>
   <li>&#187; <a href="staffers.php?g=old">Edit Staffer</a></li>
   <li>&#187; <a href="staffers.php?g=erase">Delete Staffer</a></li>
  </menu>
 </li>
<?php 
} 
?>
 <li<?php echo $fnadmin->isCurrent('checkers'); ?>><a href="checkers.php">Checkers</a></li>
<?php
if($fnadmin->isPage() == 'checkers.php') {
?>
 <li class="last">
  <menu>
   <li>&#187; <a href="checkers.php?g=new">Add Checker</a></li>
   <li>&#187; <a href="checkers.php?g=old">Edit Checker</a></li>
   <li>&#187; <a href="checkers.php?g=erase">Delete Checker</a></li>
  </menu>
 </li>
<?php 
} 
?>
</menu>
<?php 
}
?>

<menu>
 <li<?php echo $fnadmin->isCurrent('tables', 1); ?>><a href="tables.php">Category Tables</a></li>
<?php 
 $categories = $fnusers->userCategories();
 if(!empty($categories)) {
?>
 <li class="last">
  <menu>
<?php 
 foreach($categories as $tables) {
  $s = empty($tables) ? '' : "    <li>&#187; <a href=\"tables.php?table=" . 
  $flnetwork->cleanMys($fncategories->tableName($tables)) . 
	'">' . $fncategories->getCatName($tables) . "</a></li>\n";
  echo $s;
 }
?>
  </menu>
 </li> 
<?php 
}
?>
 <li<?php echo $fnadmin->isCurrent('cat_options'); ?>><a href="cat_options.php">Category Options</a></li>
<?php 
 $categories = $fnusers->userCategories();
 if(!empty($categories)) {
?>
 <li class="last">
  <menu>
<?php 
 foreach($categories as $tables) {
  $s = empty($tables) ? '' : "   <li>&#187; <a href=\"cat_options.php?table=" . 
  $flnetwork->cleanMys($fncategories->tableName($tables)) . 
	'">' . $fncategories->getCatName($tables) . "</a></li>\n";
  echo $s;
 }
?>
  </menu>
 </li> 
<?php
}
?>
 <li<?php echo $fnadmin->isCurrent('troubles'); ?>><a href="troubles.php">Troubles</a></li>
<?php 
 $categories = $fnusers->userCategories();
 if(!empty($categories)) {
?>
 <li class="last">
  <menu>
<?php 
 foreach($categories as $tables) {
  $s = empty($tables) ? '' : "   <li>&#187; <a href=\"troubles.php?table=" . 
  $flnetwork->cleanMys($fncategories->tableName($tables)) . 
	'">' . $fncategories->getCatName($tables) . "</a></li>\n";
  echo $s;
 }
?>
  </menu>
 </li> 
<?php 
}
?>
</menu>

<menu class="lastmenu">
 <li<?php echo $fnadmin->isCurrent('profile', 1); ?>><a href="profile.php">Update Profile</a></li>
 <li<?php echo $fnadmin->isCurrent('index'); ?>>
  <a href="<?php echo $fnoptions->getOption('adminHttp'); ?>">Control Panel</a>
 </li>
 <li id="lg"><a href="<?php echo basename($_SERVER['PHP_SELF']); ?>?g=logout">&#187; Logout</a></li>
</menu>
</nav>

<section id="content">
