<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Variables <vars.inc.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 

/**
 * SPAM bots 
 */ 
$bots = "/(Indy|Blaiz|Java|libwww-perl|Python|OutfoxBot|User-Agent|PycURL|" . 
"AlphaServer|T8Abot|Syntryx|WinHttp|WebBandit|nicebot|Jakarta|curl|Snoopy|" . 
"PHPcrawl|id-search|WebAlta Crawler|Baiduspider+|Gaisbot|KaloogaBot|Gigabo" . 
"t|ia_archiver)/i";

/** 
 * Administrator details 
 */ 
$website_name = $fnoptions->getOption('siteName');
$website_url  = $fnoptions->getOption('siteURL');

/** 
 * Get admin paths! 
 */ 
$admin_http  = $fnoptions->getOption('adminHttp');
$admin_panel = $fnoptions->getOption('adminPath');

/** 
 * Get month array for dates 
 */ 
$get_date_array = array(
 '01' => 'January',
 '02' => 'February',
 '03' => 'March',
 '04' => 'April',
 '05' => 'May',
 '06' => 'June',
 '07' => 'July',
 '08' => 'August',
 '09' => 'September',
 '10' => 'October',
 '11' => 'November',
 '12' => 'December'
);

/** 
 * Pagination 
 */ 
$per_approved = $fnoptions->getOption('perApproved');
$per_page     = $fnoptions->getOption('perPage');

/** 
 * Rules :D 
 */ 
$rules = $fnoptions->getOption('generalRules');

/** 
 * Get e-mail and JavaScript HTML 
 */ 
$my_email  = $fnoptions->getOption('siteEmail');
$via_email = "<script type=\"text/javascript\">\n<!--\n" .
" var jsEmail = '$my_email';\n" .
" document.write('<a h' + 'ref=\"mailto:' + jsEmail + '\">via email</' + " .
"'a>');\n//-->\n</script>";
?>
