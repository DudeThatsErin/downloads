<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Categories <categories.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
$getTitle = "Trouble Checkers";
require("pro.inc.php");
require("vars.inc.php");
require("header.php");

/** 
 * Grab our header and pagination variables :D 
 */ 
$sp = !isset($_GET['g']) ? " <span><a href=\"checkers.php?g=new\">Add Checker</a></span>" : '';
echo "<h2>{$getTitle}$sp</h2>\n";

if(!isset($_GET['p']) || empty($_GET['p']) || !ctype_digit($_GET['p'])) {
 $page = 1;
} else {
 $page = $flnetwork->cleanMys((int)$_GET['p']);
}
$start = $database->real_escape_string((($page * $per_page) - $per_page));

if($fnusers->userStatus() == 1) {
 if(isset($_GET['g']) && $_GET['g'] == 'new') {
?>
<form action="checkers.php" enctype="multipart/form-data" method="post">
<fieldset>
 <legend>Checker Details</legend>
 <p><label><strong>Name:</strong></label> 
 <input name="name" class="input1" type="text"></p>
 <p><label><strong>E-mail Address:</strong></label> 
 <input name="email" class="input1" type="text"></p>
 <p><label><strong>URL:</strong></label> 
 <input name="url" class="input1" type="text"></p>
</fieldset>

<fieldset>
 <legend>Categories</legend>
 <p class="tc"><span class="error">NOTE:</span> You can choose multiple 
 categories for the staffer.</p>
 <p><label><strong>Categories:</strong></label> 
 <select name="category[]" class="input1" multiple="multiple" size="10">
<?php 
 $select = "SELECT * FROM `$_FN[categories]` WHERE `catParent` = '0' ORDER BY `catName` ASC";
 $true   = $database->query($select);
 if($true == false) { 
  echo "  <option>No Categories Available</option>\n";
 } 

 else {
  while($getItem = $true->fetch_object()) {
   echo "  <option value=\"" . $getItem->catID . '">' . $getItem->catName . 
	 "</option>\n";
  }
 }
?>
 </select></p>
</fieldset>

<fieldset>
 <legend>Staffer Controls</legend>
 <p><label><strong>Pending Checker?</strong></label> 
<?php 
 if($getItem->sPending == 0) {
?>
 <input name="pending" checked="checked" class="input3" type="radio" value="0"> No
 <input name="pending" class="input3" type="radio" value="1"> Yes
<?php
 } elseif ($getItem->sPending == 1) {
?>
 <input name="pending" checked="checked" class="input3" type="radio" value="1"> Yes
 <input name="pending" class="input3" type="radio" value="0"> No
<?php 
 }
?>
</p>
</fieldset>

<fieldset>
 <legend>Submit</legend>
 <p class="tc">
  <input name="action" type="submit" value="Add Checker"> 
	<input type="reset" value="Reset">
 </p>
</fieldset>
</form>
<?php 
 }

 elseif (isset($_POST['action']) && $_POST['action'] == 'Add Checker') {
  $name = $flnetwork->cleanMys($_POST['name']);
  if(empty($name) || !preg_match("/([A-Za-z\s]+)/i", $name)) { 
   $flnetwork->displayError('Form Error', 'The <samp>name</samp> field is invalid.', false);
  }
  $email = $flnetwork->cleanMys(strtolower($_POST['email']));
  if(
	 empty($email) ||
	 !preg_match("/([A-Za-z0-9-_\.]+)@(([A-Za-z0-9-_]+\.)+)([a-zA-Z]{2,4})$/i", $email)
	) {
   $flnetwork->displayError('Form Error', 'The characters specified in the' . 
	 ' <samp>email</samp> field are not allowed.', false); 
  }
  $url = $flnetwork->cleanMys($_POST['url']);
  if(!strstr($url, 'http://')) {
   $flnetwork->displayError('Form Error', 'The <samp>site URL</samp> field does' . 
	 ' not start with http:// and therefore is not valid. Try again.', false);
  } 
  $category = array();
  $category = $_POST['category'];
  if(empty($category)) {
   $flnetwork->displayError('Form Error', 'The <samp>category</samp> field is' . 
	 ' empty. Go back and enter at least one category.', false);
  }
  $category = array_map(array($flnetwork, 'cleanMys'), $category);
  $pending  = $flnetwork->cleanMys($_POST['pending']);
  $cat      = implode('!', $category);
  $cat      = '!' . trim($cat, '!') . '!';

  $insert = "INSERT INTO `$_FN[checkers]` (`tCategory`, `tName`, `tEmail`, `tURL`," . 
	" `tPending`, `tUpdated`, `tAdded`) VALUES ('$cat', '$name', '$email', '$url'," . 
	" '$pending', '0000-00-00 00:00:00', NOW())";
  $database->query("SET NAMES 'utf8';");
  $true = $database->query($insert);

  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to add the' . 
	 ' checker to the database.', true, $select);
  } elseif ($true == true) {
   echo "<p class=\"successButton\"><span class=\"success\">SUCCESS!</span> The" . 
	 " trouble checker was added to the database!</p>\n";
   echo $flnetwork->backLink('checkers');
  }
 }

 /** 
  * Edit 
  */ 
 elseif (isset($_GET['g']) && $_GET['g'] == 'old') {
  if(empty($_GET['d']) || !isset($_GET['d'])) {
?>
<form action="checkers.php" method="get">
<input name="get" type="hidden" value="old">
<fieldset> 
 <legend>Choose Checker</legend>
 <p><label><strong>Checker:</strong></label> <select name="d" class="input1">
<?php 
 $select = "SELECT * FROM `$_FN[checkers]` ORDER BY `sName` ASC";
 $true = $database->query($select);
 if($true == false) { 
  echo "  <option>No Checkers Available</option>\n";
 }

 else {
  while($getItem = $true->fetch_object()) {
   echo "  <option value=\"" . $getItem->tID . '">' . $getItem->tName . 
	 "</option>\n";
  }
 }
?>
 </select></p>
  <p class="tc"><input class="input2" type="submit" value="Edit Checker"></p>
</fieldset>
</form>
<?php 
 }

 if(!empty($_GET['d'])) {
  $id = $flnetwork->cleanMys($_GET['d']);
  if(!is_numeric($id)) {
   $flnetwork->displayError('Form Error', 'You selected an invalid trouble' . 
	 ' checker.', false);
  }

  $select = "SELECT * FROM `$_FN[checkers]` WHERE `tID` = '$id' LIMIT 1";
  $true   = $database->query($select);
  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to select' . 
	 ' that specific user.', true, $select);
  }
  $getItem = $true->fetch_object();
?>
<form action="checkers.php" enctype="multipart/form-data" method="post">
<input name="id" type="hidden" value="<?php echo $getItem->tID; ?>">

<fieldset>
 <legend>Checker Details</legend>
 <p><label><strong>Name:</strong></label> 
 <input name="name" class="input1" type="text" value="<?php echo $getItem->tName; ?>"></p>
 <p><label><strong>E-Mail Address:</strong></label> 
 <input name="email" class="input1" type="text" value="<?php echo $getItem->tEmail; ?>"></p>
 <p><label><strong>URL:</strong></label> 
 <input name="url" class="input1" type="text" value="<?php echo $getItem->tURL; ?>"></p>
</fieldset>

<fieldset>
 <legend>Categories</legend>
 <p class="noteButton">You can choose multiple categories for the staffer.</p>
 <p><label><strong>Categories:</strong></label> 
 <select name="category[]" class="input1" multiple="multiple" size="10">
<?php 
 $select = "SELECT * FROM `$_FN[categories]` WHERE `catParent` = '0' ORDER BY" . 
 " `catName` ASC";
 $true = $database->query($select);
 if($true == false) { 
  echo "  <option>No Categories Available</option>\n";
 }

 else {
  $cats = explode('!', $getItem->tCategory);
  while($getCat = $true->fetch_object()) {
   echo "  <option";
	 if(in_array($getCat->catID, $cats)) { 
	  echo ' selected="selected"'; 
	 }
	 echo ' value="' . $getCat->catID . '">' . $getCat->catName . "</option>\n";
  }
 }
?>
 </select></p>
</fieldset>

<fieldset>
 <legend>Admin Controls</legend>
 <p><label><strong>Pending Checker?</strong></label> 
<?php 
if($getItem->sPending == 0) {
?>
 <input name="pending" checked="checked" class="input3" type="radio" value="0"> No
 <input name="pending" class="input3" type="radio" value="1"> Yes
<?php 
} elseif ($getItem->sPending == 1) {
?>
 <input name="pending" checked="checked" class="input3" type="radio" value="1"> Yes
 <input name="pending" class="input3" type="radio" value="0"> No
<?php 
}
?>
 </p>
</fieldset>

<fieldset>
 <legend>Submit</legend>
 <p class="tc">
  <input name="action" type="submit" value="Edit Checker"> 
  <input name="action" type="submit" value="Delete Checker"> 
  <input type="reset" value="Reset">
 </p>
</fieldset>
</form>
<?php 
  }
 }

 elseif (
  (isset($_POST['action'])) && 
  ($_POST['action'] == 'Edit Checker' || $_POST['action'] == 'Delete Checker')
 ) {
  $id = $flnetwork->cleanMys($_POST['id']);
  if(empty($id) || !ctype_digit($id)) {
   $flnetwork->displayError('Form Error', 'Your ID is empty. This means you selected' . 
	 ' an incorrect trouble checker or you\'re trying to access something that' . 
	 ' doesn\'t exist. Go back and try again.', false);
  } 
  $name = $flnetwork->cleanMys($_POST['name']);
  if(empty($name) || !preg_match("/([A-Za-z\s]+)/i", $name)) { 
   $flnetwork->displayError('Form Error', 'The <samp>name</samp> field is invalid.', false);
  }
  $email = $flnetwork->cleanMys(strtolower($_POST['email']));
  if(
	 empty($email) ||
	 !preg_match("/([A-Za-z0-9-_\.]+)@(([A-Za-z0-9-_]+\.)+)([a-zA-Z]{2,4})$/i", $email)
	) {
   $flnetwork->displayError('Form Error', 'The characters specified in the' . 
	 ' <samp>email</samp> field are not allowed.', false); 
  }
  $url = $flnetwork->cleanMys($_POST['url']);
  if(!strstr($url, 'http://')) {
   $flnetwork->displayError('Form Error', 'The <samp>site URL</samp> field does' . 
	 ' not start with http:// and therefore is not valid. Try again.', false);
  } 
  $category = array();
  $category = $_POST['category'];
  if(empty($category)) {
   $flnetwork->displayError('Form Error', 'The <samp>category</samp> field is' . 
	 ' empty. Go back and enter at least one category.', false);
  }
  $category = array_map(array($flnetwork, 'cleanMys'), $category);
  $pending  = $flnetwork->cleanMys($_POST['pending']);
  $cat      = implode('!', $category);
  $cat      = '!' . trim($cat, '!') . '!';

  $update = "UPDATE `$_FN[checkers]` SET `tCategory` = '$cat', `tName` = '$name'," . 
	" `tEmail` = '$email', `tURL` = '$url', `tPending` = '$pending', `tUpdated`" . 
	" = NOW() WHERE `tID` = '$id' LIMIT 1";
	$delete = "DELETE FROM `$_FN[checkers]` WHERE `tID` = '$id' LIMIT 1";
	
	if($_POST['action'] == 'Delete Entry') {
   $true = $database->query($delete);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to delete the' . 
		' checker.', true, $update);
   } elseif ($true == true) {
    echo "<p class=\"successButton\"><span class=\"success\">Success!</span> The" . 
		" checker was delete!</p>\n";
   }
	} else {
   $database->query("SET NAMES 'utf8';");
   $true = $database->query($update);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to edit the' . 
		' checker.', true, $update);
   } elseif ($true == true) {
    echo "<p class=\"successButton\"><span class=\"success\">Success!</span> The" . 
		" <samp>$name</samp> checker was edited!</p>\n";
   }
	}
	echo $flnetwork->backLink('checkers');
 }

 /** 
  * Index 
  */ 
 else {
?>
<p>Welcome to <samp>checkers.php</samp>, the page to add trouble checkers (who 
haven't registered themselves) and edit or delete your current ones! Below is 
the list of checkers. To edit or delete a current one, click "Edit" or "Delete" 
by the appropriate checker.</p>

<?php
  $select = "SELECT * FROM `$_FN[checkers]` ORDER BY `tName`, `tPending` ASC LIMIT $start, $per_page";
  $true = $database->query($select);
  if($true == false) {
   $flnetwork->displayError('Database Error', 'Unable to select the checkers.', true, $select);
  }
  $count = $true->num_rows;

  if($count > 0) {
?>
<table class="index">
<thead><tr>
 <th>Checker ID</th>
 <th>Status</th>
 <th>Name</th>
 <th>E-Mail</th>
 <th>Categor(y/ies)</th>
<th>Action</th>
</tr></thead>
<?php
   while($getItem = $true->fetch_object()) {
	  $status = $getItem->tPending == 1 ? "<em>Pending</em>" : "Current";
    $cats   = explode('!', $getItem->tCategory);
    $c = '';
    foreach($cats as $cat) {
     $c .= $fncategories->getCatName($cat) . ', ';
    }
    $c = trim($c, ', ');

    if($getItem->tPending == 0) {
     $n = '<strong>' . $getItem->tName . '</strong>';
    } elseif ($getItem->tPending == 1) {
     $n = '<em>' . $getItem->tName . '</em>';
    }
?>
<tbody><tr>
 <td class="tc"><?php echo $getItem->tID; ?></td>
  <td class="tc"><?php echo $status; ?>
 <td class="tc"><?php echo $n; ?></td>
 <td class="tc"><?php echo $getItem->tEmail; ?></td>
 <td class="tc"><?php echo $c; ?></td>
 <td class="tc">
  <a href="checkers.php?g=old&#38;d=<?php echo $getItem->tID; ?>">
	 <img src="icons/edit.png" alt="">
	</a>
 </td>
</tr></tbody>
<?php 
   } 
   echo "</table>\n";

   echo '<p id="pagination">Pages: ';
   $select = "SELECT * FROM `$_FN[checkers]`";
   $true   = $database->query($select);
   $total  = $true->num_rows;
   $pages  = ceil($total/$per_page);

   for($i = 1; $i <= $pages; $i++) {
    if($page == $i) {
     echo $i . " ";
    } else {
     echo '<a href="checkers.php?page=' . $i . '">' . $i . '</a> ';
    }
   }

   echo "</p>\n";
  } 

  else {
   echo "<p class=\"tc\">Currently no trouble checkers!</p>\n";
  }
 }
} else {
?>
<p class="errorButton"><span class="error">ERROR!</span> Only the admin and senior
staff are allowed to access this area.</p>
<?php 
}

require("footer.php");
?>
