/** 
 * @copyright  jQuery Copyright (c) John Resig 
 * @license    Dual Licenses MIT/GPL Version 2 
 * @author     Tess <http://scripts.wyngs.net/> 
 * @version    1.6.1 
 * @compatible 1.4.2, 1.5, 1.5.1, 1.6.1 
 */ 

$(document).ready(function() {
 /** 
  * Initiate object and methods 
  */ 
 var flnetwork = {
  getForm: function(b, w) {
   if(b == 1) {
	  $('p#loginform input#username').val('Username');
	 }
	 if(w == 1) {
    $('p#loginform input#password').val('Password');
	 }
	}
 };
 
 if($('body').attr('id') == 'loginpage') {
  /** 
   * If we've just loaded the form (or the form isn't in focus) 
   */ 
	flnetwork.getForm(1, 1);
 
  /**
   * If we're focusing on the form: 
   */
  $('p#loginform input#username').click(function() {
   $('p#loginform input#username').val('');
  });
 
  $('p#loginform input#password').click(function() {
   $('p#loginform input#password').val('');
  });

  $('p#loginform input#username').blur(function() {
   if($(this).val() == '' || $(this).val() == 'Username') {
    flnetwork.getForm(1, 0);
	 }
  });
 
  $('p#loginform input#password').blur(function() {
   if($(this).val() == '' || $(this).val() == 'Password') {
    flnetwork.getForm(0, 1);
	 }
  });
 }
 
 /** 
  * Get title, ~clean it~, and add it to the slug field :D 
  */ 
 $('input#title').blur(function() {
  if($('input#title').val() == '') {
	 return;
	} else {
   if($('input#slug').val() == '') {
	  var clean = tess.clean($('input#title').val());
	  $('input#slug').val(clean);
   }
	}
 });
});