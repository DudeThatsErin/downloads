<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Categories <categories.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
$getTitle = "Categories";
require("pro.inc.php");
require("vars.inc.php");
require("header.php");

/** 
 * Grab our header and pagination variables :D 
 */ 
$sp = !isset($_GET['g']) ? " <span><a href=\"categories.php?g=new\">Add Category</a></span>" : '';
echo "<h2>{$getTitle}$sp</h2>\n";

if(!isset($_GET['p']) || empty($_GET['p']) || !is_numeric($_GET['p'])) { 
 $page = 1;
} else {
 $page = $flnetwork->cleanMys((int)$_GET['p']);
}
$start = $fndatabase->escape((($page * $per_page) - $per_page));

if($fnusers->userStatus() == 1) {
 if(isset($_GET['g']) && $_GET['g'] == 'new') {
?>
<form action="categories.php" method="post">
<fieldset>
 <legend>Category Details</legend>
 <p><label><strong>Category:</strong></label> 
 <input name="category" class="input1" type="text"></p>
 <p><label><strong>Parent Category:</strong></label> 
 <select name="parent" class="input1" size="10">
<?php 
 $select = "SELECT * FROM `$_FN[categories]` WHERE `catParent` = '0' ORDER BY" . 
 " `catName` ASC";
 $true = $fndatabase->query($select);
 if($true == false) { 
  echo "  <option>No Categories Available</option>\n";
 }

 else {
  while($getItem = $fndatabase->obj($true)) {
   echo "  <option value=\"" . $getItem->catID . '">' . $getItem->catName . 
	 "</option>\n";
  }
 }
?>
 </select></p>
</fieldset>

<fieldset>
 <legend>Table Details</legend>
 <p>The script will create a table of the new category; it is suggested the 
 table name be user-friendly, with no spaces, all lowercase, and no heavy 
 symbols ($, %, &#38;, etc.).</p>
 <p><label><strong>Table Name:</strong></label> 
 <input name="table_name" class="input1" type="text"></p>
 <p><label><strong>Does this category ustilise subcategories?</strong><br>
 Check the box next to "yes" if the cateogry uses a subcategory or a series field.</label> 
 <input name="subcat" checked="checked" class="input3" type="radio" value="y"> Yes 
 <input name="subcat" class="input3" type="radio" value="n"> No</p>
</fieldset>

<fieldset>
 <legend>Submit</legend>
 <p class="tc">
  <input name="action" class="input2" type="submit" value="Add Category"> 
  <input class="input2" type="reset" value="Reset">
 </p>
</fieldset>
</form>
<?php 
 }

 elseif (isset($_POST['action']) && $_POST['action'] == 'Add Category') {
  $name = $flnetwork->cleanMys($_POST['category']);
  if(empty($name)) {
   $flnetwork->displayError('Form Error', 'In order to create a category, you must' . 
	 ' enter a name first. :P', false);
  }
  $parent = isset($_POST['parent']) && in_array($_POST['parent'], $fncategories->categoryList()) ? 
	$flnetwork->cleanMys($_POST['parent']) : '0';
  $table = $flnetwork->slug($flnetwork->cleanMys($_POST['table_name']));
  if(($parent == '0' || $parent == 0) && empty($table)) {
   $flnetwork->displayError('Form Error', 'Please provide a table name.', false);
  }
	$subcat = isset($_POST['subcat']) ? ($_POST['subcat'] == 'y' ? 1 : 0) : 0;

  $insert = "INSERT INTO `$_FN[categories]` (`catName`, `catParent`," . 
	" `tableName`, `catSubcats`) VALUES ('$name', '$parent', '$table', '$subcat')";
  $fndatabase->query("SET NAMES 'utf8';");
  $true = $fndatabase->query($insert);

  $o = $table . "_options";
  if(($parent == '0' || $parent == 0) && !empty($table)) {
   $create = "CREATE TABLE `$table` (
   `fID` int(10) NOT NULL AUTO_INCREMENT,
   `ownerName` varchar(255) NOT NULL,
   `ownerEmail` varchar(255) NOT NULL,
   `ownerURL` varchar(255) NOT NULL,
   `fSubCat` varchar(255) NOT NULL,
   `fSubject` varchar(255) NOT NULL,
   `fURL` varchar(255) NOT NULL,
   `fStatus` tinyint(1) NOT NULL DEFAULT '2',
   `fAdded` datetime NOT NULL,
	 `fAppr` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
   `fUpdated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
    PRIMARY KEY (`fID`),
    UNIQUE KEY `authorEmail` (`ownerEmail`, `fSubject`(50))
   ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
   $success = $fndatabase->query($create);
   if($success == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to create' . 
		' the <samp>' . $table . '</samp> category table.', true, $create);
   }

   $createOptions = "CREATE TABLE `$o` (
   `optName` varchar(255) NOT NULL,
   `optText` text NOT NULL,
   UNIQUE KEY (`optName`)
   ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
   $successOptions = $fndatabase->query($createOptions);
   if($successOptions == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to create' . 
		' the <samp>' . $o . '</samp> category option table.', true, $createOptions);
   }
 
   $query = "INSERT INTO `$o` VALUES ('categoryRules', ''),
   ('stafferApplications', ''),
   ('stafferApplicationsEmail', ''),
   ('stafferForms', ''),
   ('stafferFormsEmail', ''),
   ('stafferTroubles', ''),
   ('stafferTroublesEmail', '')";
   $fndatabase->query("SET NAMES 'utf8';");
   $result = $fndatabase->query($query);
   if($result == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to add to' . 
		' the <samp>' . $o . '</samp> category option table.', true, $query);
   }
  }
 
  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to add the' . 
	 ' category to the database.', true, $insert);
  } elseif ($true == true) {
   echo '<p class="successButton nb"><span class="success">SUCCESS!</span> Your' . 
	 " category was added to the database!</p>\n";
	 if(isset($success)) {
	  if($success) {
	   echo '<p class="successButton nb"><span class="success">SUCCESS!</span> Your <samp>' . 
		 $table . '</samp> table was created!</p>';
	  }
	 }
	 if(isset($successOption)) {
	  if($successOption) {
	   echo '<p class="successButton nb"><span class="success">SUCCESS!</span> Your <samp>' . 
		 $o . '</samp> table was created!</p>';
	  }
	 }
   echo $flnetwork->backLink('cat');
  }
 }

 /** 
  * Edit Category 
  */ 
 elseif (isset($_GET['g']) && $_GET['g'] == 'old') {
  if(empty($_GET['d']) || !isset($_GET['d'])) {
?>
<form action="categories.php" method="get">
<input name="g" type="hidden" value="old">

<fieldset> 
 <legend>Choose Category</legend>
 <p><label><strong>Category:</strong></label> <select name="d" class="input1">
<?php 
 $select = "SELECT * FROM `$_FN[categories]` WHERE `catParent` = '0' ORDER BY" . 
 " `catName` ASC";
 $true = $fndatabase->query($select);
 if($true == false) { 
  echo "  <option>No Categories Available</option>\n";
 }

 else {
  while($getCat = $fndatabase->obj($true)) {
   $catid = $getCat->catID;
   echo "  <option value=\"" . $getCat->catID . '">' . $getCat->catName . "</option>\n";
	 $q2 = $fndatabase->query("SELECT * FROM `$_FN[categories]` WHERE `catParent` =" . 
	 " '$catid' ORDER BY `catName` ASC");
	 while($getCat2 = $fndatabase->obj($q2)) {
    echo "  <option value=\"" . $getCat2->catID . '">' . 
	  $fncategories->getCatName($getCat2->catParent) . 
	  " &raquo; " . $getCat2->catName . "</option>\n";
	 }
  }
 }
?>
 </select></p>
 <p class="tc"><input class="input2" type="submit" value="Edit Category"></p>
</fieldset>
</form>
<?php 
 }

 if(!empty($_GET['d']) && in_array($_GET['d'], $fncategories->categoryList())) {
  $id     = $flnetwork->cleanMys($_GET['d']);
  $select = "SELECT * FROM `$_FN[categories]` WHERE `catID` = '$id' LIMIT 1";
  $true   = $fndatabase->query($select);
  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to select' . 
	 ' that specific category.', true, $select);
  }
  $getItem = $fndatabase->obj($true);
?>
<form action="categories.php" method="post">
<input name="id" type="hidden" value="<?php echo $getItem->catID; ?>">

<fieldset>
 <legend>Edit Category</legend>
 <p><label><strong>Category:</strong></label> 
 <input name="category" class="input1" type="text" value="<?php echo $getItem->catName; ?>"></p>
 <p><label><strong>Does this category use subcategories?</strong><br>
 Check the button next to "yes" if the cateogry uses subcategory or a series field.</label> 
 <input name="subcat" <?php if($getItem->catSubcats == 1) echo " checked=\"checked\""; ?>class="input3" type="radio" value="1"> Yes 
 <input name="subcat" <?php if($getItem->catSubcats == 0) echo " checked=\"checked\""; ?>class="input3" type="radio" value="0"> No</p>
 <p class="clear"></p>
 <p class="tc">
  <input name="action" class="input2" type="submit" value="Edit Category"> 
  <input name="action" class="input2" type="submit" value="Delete Category">
 </p>
</fieldset>
<?php 
  }
 }

 elseif (isset($_POST['action']) && $_POST['action'] == 'Edit Category') {
  $id = $flnetwork->cleanMys((int)$_POST['id']);
  if(empty($id) || !ctype_digit($id)) {
   $flnetwork->displayError('Form Error', 'Your ID is empty. This means you selected' . 
	 ' an incorrect category or you\'re trying to access something that doesn\'t' . 
	 ' exist. Go back and try again.', false);
  }
	$name = $flnetwork->cleanMys($_POST['category']);
  if(empty($name)) {
   $flnetwork->displayError('Form Error', 'In order to edit a category, you must' . 
	 ' enter a name first. :P', false);
  }
	$subcat = isset($_POST['subcat']) ? ($_POST['subcat'] == 'y' ? 1 : 0) : 0;

  $update = "UPDATE `$_FN[categories]` SET `catName` = '$name', `catSubcats` =" . 
	" '$sb' WHERE `catID` = '$id' LIMIT 1";
  $delete = "DELETE FROM `$_FN[categories]` WHERE `catID` = '$id' LIMIT 1";
	if($_POST['action'] == 'Delete Category') {
   $true = $fndatabase->query($delete);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to delete the' . 
		' category.|Make sure your category table exists.', true, $delete);
   } elseif ($true == true) {
    echo "<p class=\"successButton\"><span class=\"success\">SUCCESS!</span> Your" . 
	  " category was deleted!</p>\n";
   }
	} else {
	 $fndatabase->query("SET NAMES 'utf8';");
   $true = $fndatabase->query($update);
   if($true == false) {
    $flnetwork->displayError('Database Error', 'The script was unable to edit the' . 
		' category.|Make sure your category table exists.', true, $update);
   } elseif ($true == true) {
    echo "<p class=\"successButton\"><span class=\"success\">SUCCESS!</span> Your" . 
	  " category was edited!</p>\n";
   }
	}
	echo $flnetwork->backLink('cat');
 }

 /** 
  * Index 
  */ 
 else {
?>
<p>Welcome to <samp>categories.php</samp>, the page to add categories and edit 
or delete your current ones! Below is your list of categories. To edit or delete 
a current one, click "Edit" or "Delete" by the appropriate category.</p>
<?php 
  $select = "SELECT * FROM `$_FN[categories]` WHERE `catParent` = '0' ORDER BY" . 
	" `catName` ASC LIMIT $start, $per_page";
  $true  = $fndatabase->query($select);
  $count = $fndatabase->total($true);

  if($count > 0) {
?>
<table class="index">
<thead><tr>
 <th>Category ID</th>
 <th>Name</th>
 <th>Table Name</th>
 <th>Action</th>
</tr></thead>
<?php 
   while($getItem = $fndatabase->obj($true)) {
    $catid = $getItem->catID;
?>
<tbody><tr>
 <td class="tc"><?php echo $getItem->catID; ?></td>
 <td class="tc"><?php echo $getItem->catName; ?></td>
 <td class="tc"><samp><?php echo $getItem->tableName; ?></samp></td>
 <td class="floatIcons tc">
  <a href="categories.php?g=old&#38;d=<?php echo $getItem->catID; ?>">
	 <img src="img/icons/edit.png" alt="">
	</a>
 </td>
</tr></tbody>
<?php 
    $pull = $fndatabase->query("SELECT * FROM `$_FN[categories]` WHERE `catParent`" . 
		" = '$catid' ORDER BY `catName` ASC");
    while($items = $fndatabase->obj($pull)) {
?>
<tbody class="subcategory"><tr>
 <td class="tc"><?php echo $items->catID; ?></td>
 <td class="tc"><?php echo $fncategories->getCatName($items->catParent) . " &#187; " . $items->catName; ?></td>
 <td class="tc"><samp>&#8212;</samp></td>
 <td class="floatIcons tc">
  <a href="categories.php?g=old&#38;d=<?php echo $items->catID; ?>">
	 <img src="img/icons/edit.png" alt="">
	</a>
 </td>
</tr></tbody>
<?php 
    }
   } 
   echo "</table>\n";

   echo '<p id="pagination">Pages: ';
   $total = count($fncategories->categoryList('parent'));
   $pages = ceil($total / $per_page);

   for($i = 1; $i <= $pages; $i++) {
    if($page == $i) {
     echo $i . " ";
    } else { 
     echo '<a href="categories.php?p=' . $i . '">' . $i . '</a> ';
    }
   }

    echo "</p>\n"; 
   } else {
    echo '<p class="tc">Currently no categories!</p>' . "\n";
   }
	}
} else {
?>
<p class="errorButton"><span class="error">ERROR!</span> Only the admin and senior
staff are allowed to access this area. As you are neither, it is suggested you hit 
the "Back" button in your browser.</p>
<?php 
}

require("footer.php");
?>
