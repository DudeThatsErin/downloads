<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Profile <profile.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
$getTitle = "Profile";
require("pro.inc.php");
require("header.php");

echo "<h2>{$getTitle}</h2>\n";

$user_id = $flnetwork->cleanMys($_COOKIE['fnusr']);
if(empty($user_id) || !is_numeric($user_id)) {
 $flnetwork->displayError('Form Error', 'Oops! It appears your session ID is invalid.' . 
 ' Log out and log back in. If the problem persists, feel more than free to free' . 
 ' to contact one of the senior staffers ' . $via_email . '.', false);
 require("footer.php");
}
$user_name = $fnusers->getUserName();

if(isset($_POST['action']) && $_POST['action'] == 'Update Profile') {
 $name = $flnetwork->cleanMys($_POST['name']);
 if(empty($name)) { 
  $flnetwork->displayError('Form Error', 'The <samp>name</samp> field is empty.', 
	false);
 }
 $password  = $flnetwork->cleanMys($_POST['password']);
 $passwordn = $flnetwork->cleanMys($_POST['passwordn']);
 $passwordv = $flnetwork->cleanMys($_POST['passwordv']);
 if(!empty($passwordn)) {
  if(empty($passwordv)) {
	 $flnetwork->displayError('Form Error', 'In order to create a new password, you' . 
	 ' need to fill out both new password fields.', false);
	} elseif ($passwordn !== $passwordv) {
	 $flnetwork->displayError('Form Error', 'In order to create a new password, both' . 
	 ' passwords need to match.', false);
	}
 } 
 if(!empty($passwordn) && !empty($passwordv)) {
  $pass = $passwordn;
 } else {
  $pass = $password;
 }
 $email = $flnetwork->cleanMys($_POST['email']);
 if(
  empty($email) || 
  !preg_match("/([A-Za-z0-9-_\.]+)@(([A-Za-z0-9-_]+\.)+)([a-zA-Z]{2,4})$/i", $email)
 ) {
  $flnetwork->displayError('Form Error', 'The characters specified in the' . 
	' <samp>email</samp> field are not allowed.', false); 
 }
 if($fnchecker->checkEmailChange() !== $email) {
  if($fnchecker->checkPassword(sha1($password)) != sha1($password)) { 
   $flnetwork->displayError('Form Error', 'If you change your e-mail, you must provide' . 
	 ' your current password. If you have forgotten your password (which I find' . 
	 ' unlikely if you are logged in), you can change it above <em>first</em> or' . 
	 ' request a change via <a href="contact.php">the senior staff &raquo;</a>.', false);
  }
 }
 $url = $flnetwork->cleanMys($_POST['url']);
 if(!empty($url)) {
  if(preg_match("@(http://)([A-Za-z0-9-_\./?]+)([A-Za-z\.]{2,4})/?$@i", $url) === false) {
   $flnetwork->displayError('Form Error', 'The <samp>website</samp> field is' . 
	 ' not valid. Please supply a valid site URL or empty the field.', false);
  }
 }
 $show_email = $flnetwork->cleanMys($_POST['show_email']);
 $show_email = !is_numeric($showemail) || $showemail > 1 ? 0 : $show_email; 
 $bio        = $flnetwork->cleanMys($_POST['bio'], 'n');

 $update = "UPDATE `$_FN[staffers]` SET `sRealName` = '$name', `sBio` = '$bio',";
 if(!empty($passwordn) && !empty($passwordv)) { 
  $update .= " `sPassword` = SHA1('$pass'),";
 }
 $update .= " `sEmail` = '$email', `sURL` = '$url', `sEmailShow` =" . 
 " '$show_email', `sUpdated` = NOW() WHERE `sID` = '$user_id' LIMIT 1";
 $true = $database->query($update);

 if($true == false) {
  $flnetwork->displayError('Database Error', 'The script could not update your' . 
	' information. If the problems persists, feel free to let the senior know' . 
	' <a href="contact.php">via contact form</a>.', false);
 } elseif ($true == true) {
  echo '<p class="successButton"><span class="success">SUCCESS!</span> You have' . 
	' successfully updated your information! If you changed your password, it is' . 
	" displayed below:\n";
  if(!empty($passwordn) && !empty($passwordv)) {
   echo "<code style=\"text-align: center;\">\n<samp>Password:</samp> {$pass}\n</code></p>\n";
  } else {
   echo "</p>\n";
	}
	echo "<p class=\"successButton\">Thank you for keeping your information" . 
	" up-to-date! :D</p>\n"; 
 }
 echo $flnetwork->backLink('profile');
}


else {
 $userid  = $flnetwork->cleanMys($_COOKIE['fnusr']);
 $getItem = $fnusers->getStaffer($userid);
?>
<p>You can update the following variables of your profile below. Please be aware 
that most of the information you give is for public display, with the exception 
of your e-mail and real name.</p>

<form action="profile.php" enctype="multipart/form-data" method="post">
<fieldset>
 <legend>Details</legend>
 <p><label><strong>Real Name:</strong></label> 
 <input name="name" class="input1" type="text" value="<?php echo $getItem->sRealName; ?>"></p>
 <p><label><strong>E-mail Address</strong><br>
 If changed, you <em>must</em> provide your current password below:</label> 
 <input name="email" class="input1" type="text" value="<?php echo $getItem->sEmail; ?>"></p>
 <p class="clear"></p>
 <p><label><strong>Show your e-mail address?</strong></label> 
<?php 
if($getItem->sEmailShow == 1) {
?>
 <input name="show_email" checked="checked" class="input3" type="radio" value="1"> No (Leave)
 <input name="show_email" class="input3" type="radio" value="0"> Yes
<?php 
} elseif ($getItem->sEmailShow == 0) {
?>
 <input name="show_email" checked="checked" class="input3" type="radio" value="0"> Yes (Leave)
 <input name="show_email" class="input3" type="radio" value="1"> No
<?php
}
?>
 </p>
 <p><label><strong>URL:</strong></label> 
 <input name="url" class="input1" type="text" value="<?php echo $getItem->sURL; ?>"></p>
</fieldset>

<fieldset>
 <legend>Password</legend>
 <p class="tc"><em>Current Password</em> is only required if you need to change 
 your password or e-mail address; if you are changing your password, you 
 <em>must</em> enter a password. One will <em>not</em> be generated for you.</p>
 <p><label><strong>Current Password:</strong><br>
 You only need to give your current password if you are changing your e-mail or 
 password.</label> <input name="password" class="input1" type="password"></p>
 <p class="clear"></p>
 <p><label style="height: 80px;"><strong>New Password</strong>:<br>
 Type your new password in twice.</label> 
 <input name="passwordn" class="input1" type="password"><br>
 <input name="passwordv" class="input1" type="password"></p>
</fieldset>

<fieldset>
 <legend>Profile Changes</legend>
 <p><strong>Biography</strong> (<abbr title="Hypertext Markup Language">HTML</abbr> allowed):<br>
  <textarea name="bio" cols="60" rows="20" style="height: 250px; width: 100%;">
<?php echo $getItem->sBio; ?>
  </textarea>
 </p>
</fieldset>

<fieldset>
<legend>Submit</legend>
 <p class="tc">
  <input name="action" type="submit" value="Update Profile"> 
  <input type="reset" value="Reset">
 </p>
</fieldset>
</form>
<?php 
}

require("footer.php");
?>
