<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Install File <install.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
require("rats.inc.php");
require("inc/fun.inc.php");
require("install_vars.php");
?>
<!DOCTYPE html>
 
<html lang="en">

<head>
 <meta charset="utf-8">
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 <title> Install </title>
 <link href="style.css" rel="stylesheet" type="text/css">
</head>

<body>

<div id="install">
<h2>Install Script</h2>
<?php 
if(isset($_POST['action']) && $_POST['action'] == 'Install Script') {
 $my_name = $flnetwork->cleanMys($_POST['my_name']);
 if(empty($my_name) || !preg_match("/([A-Za-z-_\s])/i", $my_name) || strlen($my_name) > 20) {
  $flnetwork->displayError('Form Error', 'The <samp>name</samp> field must be' . 
	' above below 20 characters, and only contain letters, spaces and periods.', 
	false);
 }
 $my_email = $flnetwork->cleanMys($_POST['my_email']);
 if(empty($my_email)) {
  $flnetwork->displayError('Form Error', 'You have not filled out the <samp>' . 
	'email</samp> field.</p>', false);
 } elseif (!preg_match("/([A-Za-z0-9-_\.]+)@(([A-Za-z0-9-_]+\.)+)([a-zA-Z]{2,4})$/i", $my_email)) {
  $flnetwork->displayError('Form Error', 'The characters specified in the' . 
	' <samp>email</samp> field are not allowed.', false); 
 }
 $adm_path = $flnetwork->cleanMys($_POST['adm_path']);
 $adm_http = $flnetwork->cleanMys($_POST['adm_http']);
 if(
  !strrchr($adm_path, '/') || 
  (empty($adm_path) || empty($adm_http))
 ) {
  $flnetwork->displayError('Form Error', 'The admin paths are empty or are' . 
	' missing trailing slashes. Enter the proper path.', false);
 } 
 $site_name = $flnetwork->cleanMys($_POST['site_name']);
 if(empty($site_name)) {
  $flnetwork->displayError('Error', 'The <samp>site name</samp> field is empty.', 
	false);
 }
 $site_url = $flnetwork->cleanMys($_POST['website']);
 if(empty($site_url)) {
  $flnetwork->displayError('Error', 'The <samp>website</samp> field is empty.', false);
 }
 $email       = $flnetwork->cleanMys($_POST['email']);
 $admin_email = $flnetwork->cleanMys($_POST['use_admin_email']);
 if($admin_email != 'y') {
  if(
   empty($email) || 
   !preg_match("/([A-Za-z0-9-_\.]+)@(([A-Za-z0-9-_]+\.)+)([a-zA-Z]{2,4})$/i", $my_email)
  ) {
   $flnetwork->displayError('Form Error', 'The characters specified in the' . 
	 ' <samp>email</samp> field are not allowed.', false); 
  }
 }
 $mail = $admin_email == 'y' ? $my_email : $email;
 $password = $flnetwork->cleanMys($_POST['password']);
 $passwordv = $flnetwork->cleanMys($_POST['passwordv']);
 if(!empty($password)) {
  if(empty($passwordv)) {
	 $flnetwork->displayError('Form Error', 'In order to create your password, you' . 
	 ' need to fill out both new password fields.', false);
	} elseif ($password !== $passwordv) {
	 $flnetwork->displayError('Form Error', 'In order to create your password, both' . 
	 ' passwords need to match.', false);
	}
 } 
 if(empty($password) && empty($passwordv)) {
  $pass = substr(md5(mt_rand(80, 900)), 0, 6) . substr(md5(date("YmdHis")), 0, 6);
 } else {
  $pass = $password;
 }
 $passhash = md5(date("YmdHis"));

 $create = "CREATE TABLE `$_FN[categories]` (
  `catID` mediumint(6) NOT NULL AUTO_INCREMENT,
  `catName` varchar(255) NOT NULL,
  `catParent` mediumint(6) NOT NULL DEFAULT '0',
  `tableName` varchar(255) NOT NULL,
  `catSubcats` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`catID`),
  UNIQUE KEY `catParent` (`catParent`, `catName`(50))
 ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
 $true = $fndatabase->query($create);
 if($true == false) {
  exit('<p><span style="color: #FF0000;">ERROR:</span> ' . $fndatabase->error() . "<br>\n<em>" . $create . '</em></p>');
 }

 $create = "CREATE TABLE `$_FN[checkers]` (
  `tID` smallint(2) NOT NULL AUTO_INCREMENT,
  `tCategory` varchar(255) NOT NULL,
  `tName` varchar(25) NOT NULL,
  `tEmail` varchar(255) NOT NULL,
  `tURL` varchar(255) NOT NULL,
	`tPending` tinyint(1) NOT NULL DEFAULT '1',
	`tUpdated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
	`tAdded` datetime NOT NULL,
  PRIMARY KEY (`tID`)
 ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
 $true = $fndatabase->query($create);
 if($true == false) {
  exit('<p><span style="color: #FF0000;">ERROR:</span> ' . $fndatabase->error() . 
	"<br>\n<em>" . $create . '</em></p>');
 }

 $create = "CREATE TABLE `$_FN[options]` (
  `name` varchar(255) NOT NULL,
  `text` text NOT NULL,
  UNIQUE KEY (`name`)
 ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
 $true = $fndatabase->query($create);
 if($true == false) {
  exit('<p><span style="color: #FF0000;">ERROR:</span> ' . $fndatabase->error() . 
	"<br>\n<em>" . $create . '</em></p>');
 }

 $insert = "INSERT INTO `$_FN[options]` VALUES ('adminName', '$my_name'),
 ('adminHttp', '$adm_http'),
 ('adminPath', '$adm_path'), 
 ('siteName', '$site_name'), 
 ('siteURL', '$site_url'),
 ('siteEmail', '$mail'),
 ('perApproved', '25'),
 ('perPage', '12'), 
 ('generalRules', ''),
 ('markup', 'xhtml'),
 ('akismetKey', ''),
 ('javascriptKey', ''),
 ('passwordHash', '$passhash'),
 ('formsApps', ''),
 ('formsClosed', ''),
 ('formsContact', ''),
 ('formsContactStaff', ''),
 ('formsFinished', ''),
 ('formsUpdate', ''),
 ('formsvStaffer', ''),
 ('formsvTC', '')";
 $fndatabase->query("SET NAMES 'utf8';");
 $true = @$fndatabase->query($insert);
 if($true == false) {
  exit('<p><span class="mysql">Error:</span> ' . $fndatabase->error() . "<br />\n<em>" . $insert . '</em></p>');
 }

 $create = "CREATE TABLE `$_FN[staffers]` (
  `sID` mediumint(6) NOT NULL AUTO_INCREMENT,
  `sCategory` varchar(255) NOT NULL,
  `sStatus` varchar(255) NOT NULL DEFAULT '!2!',
	`sOtherDuties` varchar(255) NOT NULL,
  `sRealName` varchar(255) NOT NULL,
  `sBio` longtext NOT NULL,
  `sName` varchar(25) NOT NULL,
  `sPassword` varchar(255) NOT NULL,
  `sEmail` varchar(255) NOT NULL,
  `sEmailShow` tinyint(1) NOT NULL DEFAULT '1',
  `sURL` varchar(255) NOT NULL,
  `sUpdated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `sAdded` datetime NOT NULL,
  `sPending` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`sID`),
  UNIQUE KEY `sName` (`sName`),
  UNIQUE KEY `sEmail` (`sEmail`)
 ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
 $true = $fndatabase->query($create);
 if($true == false) {
  exit('<p><span style="color: #FF0000;">ERROR:</span> ' . $fndatabase->error() . 
	"<br>\n<em>" . $create . '</em></p>');
 }

 $insert = "INSERT INTO `$_FN[staffers]`" . 
 " (`sCategory`, `sStatus`, `sOtherDuties`, `sRealName`, `sBio`, `sName`," . 
 " `sPassword`, `sEmail`, `sEmailShow`, `sURL`, `sUpdated`, `sAdded`," . 
 " `sPending`) VALUES ('','!1!2!', '', '', '', '$my_name', SHA1('$pass')," . 
 " '$my_email', '0', '', '0000-00-00 00:00:00', NOW(), '0')";
 $fndatabase->query("SET NAMES 'utf8';");
 $result = $fndatabase->query($insert);

 $create = "CREATE TABLE `$_FN[templates]` (
  `tempName` varchar(255) NOT NULL,
  `tempTitle` varchar(255) NOT NULL,
  `tempTemplate` text NOT NULL,
  UNIQUE KEY `tempName` (`tempName`)
 ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
 $true = $fndatabase->query($create);
 if($true == false) {
  exit('<p><span style="color: #FF0000;">ERROR:</span> ' . $fndatabase->error() . 
	"<br>\n<em>" . $create . '</em></p>');
 }
 
 $insert = "INSERT INTO `$_FN[templates]` VALUES ('email_approval', 'Approval', '$approval'),
 ('email_closed', 'Closed', '$closedform'),
 ('email_finished', 'Finished', '$finished'),
 ('email_troubleremoval', 'Trouble Removal', '$removal'),
 ('email_troublewarning', 'Trouble Warning', '$warning'),
 ('email_update', 'Update Info', '$updateinfo')";
 $fndatabase->query("SET NAMES 'utf8';");
 $result = $fndatabase->query($insert);
 if($result == false) {
  exit('<p><span style="color: #FF0000;">ERROR:</span> ' . $fndatabase->error() . 
	"<br>\n<em>" . $insert . '</em></p>');
 }

 $create = "CREATE TABLE `$_FN[troubles]` (
  `tID` int(10) NOT NULL auto_increment,
  `tProblem` varchar(255) NOT NULL,
  `tListing` varchar(255) NOT NULL,
  `tCategory` varchar(255) NOT NULL default '',
  `tAdded` datetime NOT NULL,
  PRIMARY KEY  (`tID`)
 ) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
 $true = $fndatabase->query($create);
 if($true == false) {
  exit('<p><span style="color: #FF0000;">ERROR:</span> ' . $fndatabase->error() . 
	"<br>\n<em>" . $create . '</em></p>');
 }

 $create = "CREATE TABLE `$_FN[troubles_templates]` (
  `troubName` varchar(255) NOT NULL,
  `troubEmailTemplate` varchar(255) NOT NULL,
  `troubDesc` text NOT NULL,
  UNIQUE KEY `troubName` (`troubName`)
 ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
 $true = $fndatabase->query($create);
 if($true == false) {
  exit('<p><span style="color: #FF0000;">ERROR:</span> ' . $fndatabase->error() . 
	"<br>\n<em>" . $create . '</em></p>');
 }
?>
<p class="successButton"><span class="success">Success!</span> The installation 
process has ended and you have created your tables! Below is your login 
information:</p> 
<code style="text-align: center;">
 <samp>Username:</samp> <?php echo $my_name; ?><br>
 <samp>Password:</samp> <?php echo $pass; ?>
</code>
<p>For security purposes, please remember to delete this file from your server. The next step is to 
<a href="index.php">log in</a>! :D</p>
<?php 
}

else {
?>
<p>Welcome to <samp>install.php</samp>, where you will be able to install the 
your network script! Please be aware that you must edit your config file prior 
to running this installation. After running the installation, delete this file 
from your webserver <em>as soon as you finish</em>. Consult the 
<samp>readme.txt</samp> file for further instructions.</p>

<form action="install.php" method="post">
<fieldset>
 <legend>User Details</legend>
 <p class="tc">Your user details will be the first account at the network. Your 
 <samp>name</samp> will be the username you log in with and as such, only 
 letters are allowed.</p>
 <p><label><strong>Name:</strong></label> <input name="my_name" class="input1" type="text"></p>
 <p><label style="height: 90px;"><strong>Password</strong><br>
 Type the password twice; if the fields are left blank, one will be generated
 for you:</label> 
 <input name="password" class="input1" type="password"><br>
 <input name="passwordv" class="input1" type="password"></p>
 <p class="clear"></p>
 <p><label><strong>E-mail Address:</strong></label> 
 <input name="my_email" class="input1" type="text"></p>
</fieldset>

<fieldset>
<legend>Paths</legend>
<?php 
 $adminPath = str_replace('install.php', '', $_SERVER['SCRIPT_FILENAME']);
 $adminURI  = 'http://' . $_SERVER['SERVER_NAME'] . str_replace('install.php', '', $_SERVER['PHP_SELF']);
?>
 <p>
  <label><strong>Admin Paths:</strong><br>
   Admin paths are the path and <abbr title="Uniform Resource Identifier">URI</abbr> 
	 to your admin panel. All paths and URLs are already set for you, although 
	 they can be changed to the desired path.
  </label> 
  <input name="adm_path" class="input1" type="text" value="<?php echo $adminPath; ?>"><br>
  <input name="adm_http" class="input1" type="text" value="<?php echo $adminURI; ?>">
 </p>
</fieldset>

<fieldset>
 <legend>Network Details</legend>
 <p><label><strong>Site Name:</strong></label> 
 <input name="site_name" class="input1" type="text"></p>
 <p><label><strong>Site E-mail:</strong></label> 
 <input name="email" class="input1" type="text"></p>
 <p><label><strong>Is the site e-mail address the same as the user one?</strong></label>
 <input name="use_admin_email" class="input3" type="radio" value="y"> Yes
 <input name="use_admin_email" checked="checked" class="input3" type="radio" value="n"> No</p>
 <p class="clear"></p>
 <p><label><strong>Website:</strong></label> 
 <input name="website" class="input1" type="text"></p>
</fieldset>

<fieldset>
 <legend>Submit</legend>
 <p class="tc"><input name="action" class="input2" type="submit" value="Install Script"></p>
</fieldset>
</form>
<?php 
}
?>
</div>

</body>
</html>
