<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Troubles <troubles.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
$getTitle = "Troubles";
require("pro.inc.php");
require("header.php");
require("vars.inc.php");

echo "<h2>{$getTitle}</h2>\n";

if(!isset($_GET['p']) || empty($_GET['p']) || !is_numeric($_GET['p'])) { 
 $page = 1;
} else {
 $page = $flnetwork->cleanMys((int)$_GET['p']);
}
$start = $fndatabase->escape((($page * $per_page) - $per_page));

/** 
 * Tables 
 */ 
if(isset($_GET['table']) && !empty($_GET['table'])) {
 if(!isset($_GET['g'])) {
  $table_name = $flnetwork->cleanMys($_GET['table']);
  $categories = $fncategories->categoryList('id', 'table');
  if(!in_array($table_name, $categories)) {
   $flnetwork->displayError('Form Error', 'It appears the table you are trying to' . 
	 ' view does not exist. Go back and try again.', false);
  }
?>
<p>Below are the listings troubled in your category. Be aware before eding that 
you <em>must</em> make sure the fanlistings are marked by the correct trouble.</p>
<?php 
  $select = "SELECT * FROM `$_FN[troubles]` WHERE `tCategory` = '$table_name'" . 
	" ORDER BY `tAdded` DESC";
  $true = $fndatabase->query($select);
  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to select' . 
	 ' the troubled listings.', true, $select);
  }
  $count = $fndatabase->total($true);
 
  if($count > 0) {
?>
<form action="troubles.php" method="post">
<input name="table" type="hidden" value="<?php echo $table_name; ?>">

<table class="index">
<thead><tr>
 <th>&#160;</th>
 <th>Subject</th>
 <th>Problem</th>
 <th>Category</th>
 <th>Date Troubled</th>
 <th>Action</th>
</tr></thead>
<?php
   while($getItem = $fndatabase->obj($true)) {
	  $sb      = $fnlistings->getSubject($table_name, $getItem->tListing);
		$subject = $getItem->tAdded <= date("Y-m-d", strtotime("-1 week")) ?
		"<ins>" . $sb . "</ins>" : $sb;
?>
<tbody><tr>
 <td class="tc"><input name="subject_edit[]" type="checkbox" value="<?php echo $getItem->tListing; ?>"></td>
 <td class="tc"><?php echo $subject; ?>
 </td>
 <td class="tc"><?php echo $getItem->tProblem; ?></td>
 <td class="tc"><?php echo $fncategories->getCatName($getItem->tCategory, 'table'); ?></td>
 <td class="tc"><?php echo date("F jS, Y", strtotime($getItem->tAdded)); ?></td>
 <td class="floatIcons tc">
  <a href="troubles.php?table=<?php echo $table_name; ?>&#38;g=old&#38;d=<?php echo $getItem->tID; ?>">
	 <img src="img/icons/edit.png" alt="">
	</a>
 </td>
</tr></tbody>
<?php 
   }
?>
<tfoot><tr>
 <td class="tc" colspan="6">With Checked: 
  <input name="action" class="input2" type="submit" value="Send Trouble E-mail">
  <input name="action" class="input2" type="submit" value="Send Trouble Warning">
  <input name="action" class="input2" type="submit" value="Delete Listings">
 </td>
</tr></tfoot>
</table>
</form>
<?php 
   echo "\n<p id=\"pagination\">Pages: ";
   $select = "SELECT * FROM `$_FN[troubles]`";
   $true   = $fndatabase->query($select);
   $total  = $fndatabase->total($true);
   $pages  = ceil($total / $per_page);

   for($i = 1; $i <= $pages; $i++) {
    if($page == $i) {
     echo $i . " ";
    } else {
     echo '<a href="troubles.php?page=' . $i . '">' . $i . '</a> ';
    }
   }
   echo "</p>\n"; 
  } else {
   echo "<p class=\"tc\">Currently no listings on troubles!</p>";
	}
 }
  
 /**
  * Edit 
  */ 
 elseif (isset($_GET['g']) && $_GET['g'] == 'old') {
  $table_name_edit = $flnetwork->cleanMys($_GET['table']);
  $old_id          = $flnetwork->cleanMys((int)$_GET['d']);

  $select = "SELECT * FROM `$_FN[troubles]` WHERE `tID` = '$old_id' LIMIT 1";
  $true   = $fndatabase->query($select);
  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to select' . 
	 ' the specified listing.', true, $select);
  }
  $getItem = $fndatabase->obj($true);
?>
<p>You are about to edit the <strong><?php echo $getItem->tListing; ?></strong> 
fanlisting in the 
<strong><?php echo $fncategories->getCatName($table_name_edit, 'table'); ?></strong> 
category. Any changes you may make cannot be undone. To proceed, click the 
"Edit Member" button. :D</p>

<form action="troubles.php" method="post">
<input name="id" type="hidden" value="<?php echo $getItem->tID; ?>">
<input name="table" type="hidden" value="<?php echo $table_name_edit; ?>">

<fieldset>
 <legend>Problem</legend>
 <p><label><strong>Problem</strong>:</label> <select name="problem" class="input1">
<?php 
 $select = "SELECT * FROM `$_FN[troubles_templates]` ORDER BY `troubName` ASC";
 $true = $fndatabase->query($select);
 if($true == false) { 
  echo "  <option>No Troubles Templates Available</option>\n";
 }

 else {
  while($getCat = $fndatabase->obj($true)) {
   echo '  <option value="' . $getCat->troubName . '"'; 
	 if($getCat->troubName == $getItem->tProblem) { 
	  echo ' selected="selected"'; 
	 }
	 echo '>' . $getCat->troubName . "</option>\n";
  }
 }
?>
 </select></p>
</fieldset>

<fieldset>
 <legend>Added</legend>
 <p class="noteButton">You can change the date the listing was troubled on (e.g., 
 if there is an extension):</p>
 <p><label><strong>Month:</strong></label> <select name="month" class="input1">
<?php 
 $dateArray = $get_date_array;
 foreach($dateArray as $dA => $dA2) {
  echo '<option value="' . $dA . '"';
  if($dA == date("m", strtotime($getItem->tAdded))) { 
   echo ' selected="selected"';
  }
  echo '>' . $dA2 . "</option>\n";
 }
?>
 </select></p>
 <p><label><strong>Day:</strong></label> 
 <input name="day" class="input1" type="text" value="<?php echo date('d', strtotime($getItem->tAdded)); ?>"></p>
 <p><label><strong>Year:</strong></label> 
 <input name="year" class="input1" type="text" value="<?php echo date('Y', strtotime($getItem->tAdded)); ?>"></p>
</fieldset>

<fieldset>
 <legend>Submit</legend>
 <p class="tc"><input name="action" class="input2" type="submit" value="Edit Listing"></p>
</fieldset>
</form>
<?php 
 }
}

/** 
 * Edit 
 */ 
elseif (isset($_POST['action']) && $_POST['action'] == 'Edit Listing') {
 $id = $flnetwork->cleanMys((int)$_POST['id']);
 if(empty($id) || !is_numeric($id)) {
  $flnetwork->displayError('Form Error', 'Your ID is empty or invalid. This means' . 
	' you selected an incorrect listing or you\'re trying to access something' . 
	' that doesn\'t exist. Go back and try again.', false);
 }
 $table_post_edit = $flnetwork->cleanMys($_POST['table']);
 if(!in_array($table_post_edit, $fncategories->categoryList('id', 'table'))) {
  $flnetwork->displayError('Form Error', 'It appears the table you are trying to' . 
	' view does not exist. Go back and try again.', false);
 }
 $problem = $flnetwork->cleanMys($_POST['problem']);
 if(empty($problem) || !in_array($problem, $fnoptions->troublesList())) {
  $flnetwork->displayError('Form Error', 'The <samp>problem</samp> is invalid.', false);
 }
 $year  = $flnetwork->cleanMys($_POST['year'], 'y', 'n', 'n');
 $month = $flnetwork->cleanMys($_POST['month'], 'y', 'n', 'n');
 $day   = $flnetwork->cleanMys($_POST['day'], 'y', 'n', 'n');
 if(empty($year) || empty($month) || empty($day)) {
  $flnetwork->displayError('Form Error', 'The <samp>date</samp> field is empty.', false);
 } elseif (!is_numeric($year) || !is_numeric($month) || !is_numeric($day)) {
  $flnetwork->displayError('Form Error', 'The <samp>date</samp> field is not' . 
	' a digit.', false);
 } elseif (strlen($year) > 4) {
  $flnetwork->displayError('Form Error', 'The <samp>year</samp> field needs' . 
	' to be the length of 4 digits.', false);
 } elseif (strlen($month) > 2 || strlen($day) > 2) {
  $flnetwork->displayError('Form Error', 'The <samp>month or day</samp> field' . 
	' needs to be the length of 2 digits.', false);
 }
 $date = $flnetwork->cleanMys($year . '-' . $month . '-' . $day);

 $update = "UPDATE `$_FN[troubles]` SET `tProblem` = '$problem', `tAdded` =" . 
 " '$date' WHERE `tID` = '$id' LIMIT 1";
 $true = $fndatabase->query($update);
 if($true == false) {
  $flnetwork->displayError('Database Error', 'The script was unable to edit the' . 
	' listing.', true, $update);
 } else {
  echo '<p class="successButton"><span class="success">SUCCESS!</span> The' . 
	" listing was edited!</p>\n";
 }
 echo $flnetwork->backLink('troubles', $table_post_edit);
}

/** 
 * Send our a trouble e-mail to all troubles :'D 
 */ 
elseif (isset($_POST['action']) && $_POST['action'] == 'Send Trouble E-mail') {
 $table_now = $flnetwork->cleanMys($_POST['table']);
 if(empty($_POST['subject_edit'])) {
  $flnetwork->displayError('Form Error', 'You need to select a listing (or two)' . 
	' in order to send the trouble e-mail.', false);
 }
 foreach($_POST['subject_edit'] as $s) {
  $mail = $fnemails->mailTrouble($table_now, $s);
	if($mail) {
   echo '<p class="successButton"><span class="success">SUCCESS!</span> The' . 
	 " troubles e-mail has been sent to the owner of <samp>" . $fnlistings->getSubject($table_now, $s) . 
	 "</samp>!</p>\n";
  }
 }
 echo $flnetwork->backLink('troubles', $table_now);
}

/** 
 * Send out a reminder e-mail to troubled listing(s)  
 */ 
elseif (isset($_POST['action']) && $_POST['action'] == 'Send Trouble Warning') {
 $table_now = $flnetwork->cleanMys($_POST['table']);
 if(empty($_POST['subject_edit'])) {
  $flnetwork->displayError('Form Error', 'You need to select a listing (or two)' . 
	' in order to send the trouble e-mail.', false);
 }
 foreach($_POST['subject_edit'] as $s) {
  $mail = $fnemails->mailTrouble($table_now, $s, 'email_troublewarning');
	if($mail) {
   echo "<p class=\"successButton\"><span class=\"success\">SUCCESS!</span> The" . 
	 " trouble warning e-mail has been sent to the owner of <samp>" . $fnlistings->getSubject($table_now, $s) . 
	 "</samp>!</p>\n";
  }
 }
 echo $flnetwork->backLink('troubles', $table_now);
}

/** 
 * Delete the selected listing(s) 
 */ 
elseif (isset($_POST['action']) && $_POST['action'] == 'Delete Listings') {
 $table_now = $flnetwork->cleanMys($_POST['table']);
 if(empty($_POST['subject_edit'])) {
  $flnetwork->displayError('Form Error', 'You need to select a listing (or two)' . 
	' in order to send the trouble e-mail.', false);
 }
 foreach($_POST['subject_edit'] as $s) {
  $delete = "DELETE FROM `$_FN[troubles]` WHERE `tListing` = '$s' LIMIT 1";
  $true   = $fndatabase->query($delete);
	if($true == true) {
   echo "<p class=\"successButton\"><span class=\"success\">SUCCESS!</span>" . 
	 " The listing was deleted from troubles!</p>\n";
  }
 }
 echo $flnetwork->backLink('troubles', $table_now);
}

/** 
 * Index 
 */ 
else {
?>
<p>Welcome to <samp>troubles.php</samp>, the page to troubled listings! Below is the list of 
categories. To edit troubled listings in your category, click "View Listings" by the appropriate
category.</p>
<?php 
 $categories_list = count($fncategories->categoryList('parent'));
 $select          = "SELECT * FROM `$_FN[categories]` WHERE `catParent` = '0'" . 
 " ORDER BY `catName` ASC LIMIT $start, $categories_list";
 $true = $fndatabase->query($select);
 if($true == false) {
  $flnetwork->displayError('Database Error', 'The script could not select the' . 
	' categories from the database.', true, $select);
 }
 $count = $fndatabase->total($true);

 if($count > 0) {
?>
<table class="index">
<thead><tr>
 <th>Category</th>
 <th>Category Table Name</th>
 <th>Action</th>
</tr></thead>
<?php 
  while($getItem = $fndatabase->obj($true)) {
?>
<tbody><tr>
 <td class="tc"><?php echo $getItem->catName; ?></td>
 <td class="tc"><samp><?php echo $getItem->tableName; ?></samp></td>
 <td class="tc"><a href="troubles.php?table=<?php echo $getItem->tableName; ?>">View Listings</a></td>
</tr></tbody>
<?php 
  }
  echo "</table>\n";

  echo "\n<p id='pagination'>Pages: ";
  $total = count($fncategories->categoryList('parent'));
  $pages = ceil($total / $per_page);

  for($i = 1; $i <= $pages; $i++) {
   if($page == $i) {
    echo $i . " ";
   } else {
    echo '<a href="troubles.php?page=' . $i . '">' . $i . '</a> ';
   }
  }

  echo "</p>\n"; 
 } else {
  echo "<p class=\"tc\">Current no category tables!</p>\n";
 }
}

require("footer.php");
?>
