<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Troubles Templates <templates.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
$getTitle = "Troubles Templates";
require("pro.inc.php");
require("header.php");

/** 
 * Grab our header :D 
 */ 
$sp = !isset($_GET['g']) ? " <span><a href=\"templates_troubles.php?g=new\">Add" . 
" Troubles Template</a></span>" : '';
echo "<h2>{$getTitle}$sp</h2>\n";

if($fnusers->userStatus() == 1) {
 if(isset($_GET['g']) && $_GET['g'] == 'new') {
?>
<p>Adding a troubles template is not like adding a e-mail template; a troubles 
template must have a e-mail template already created 
(see <a href="templates.php">&#187; E-mail Templates</a>), as each troubles 
template needs a e-mail template.</p>
<p class="noteButton">Neither <abbr title="Hypertext Markup Language">HTML</abbr>, 
nor bbCode, is allowed in the description.</p>

<form action="templates_troubles.php" method="post">
<fieldset>
 <legend>Add Template</legend>
 <p><label><strong>Name:</strong></label> <input name="name" class="input1" type="text"></p>
 <p><label><strong>E-mail Template:</strong></label> <select name="template" class="input1">
<?php 
 $select = "SELECT * FROM `$_FN[templates]` ORDER BY `tempTitle` ASC";
 $true = $fndatabase->query($select);
 if($true == false) { 
  echo "  <option>No Templates Available</option>\n";
 }

 else {
  while($getCat = $fndatabase->obj($true)) {
   echo '  <option value="' . $getCat->tempName . '">' . $getCat->tempTitle . "</option>\n";
  }
 }
?>
 </select></p>
 <p><strong>Description</strong><br>
  <textarea name="desc" cols="50" rows="16" style="height: 150px; width: 100%;"></textarea>
 </p>
 <p class="tc">
  <input name="action" class="input2" type="submit" value="Add Template"> 
  <input class="input2" type="reset" value="Reset">
 </p>
</fieldset>
</form>
<?php 
 }

 elseif (isset($_POST['action']) && $_POST['action'] == 'Add Template') {
  $name = $flnetwork->cleanMys($_POST['name']);
  if(empty($name)) {
   $flnetwork->displayError('Form Error', 'The <samp>template name</samp> field' . 
	 ' is empty.', false);
  }
  $template = $flnetwork->cleanMys($_POST['template']);
  if(empty($template) || !in_array($template, $fnoptions->templatesList())) {
   $flnetwork->displayError('Form Error', 'The <samp>email template</samp> field' . 
	 ' is invalid.', false);
  }
  $desc = $flnetwork->cleanMys($_POST['desc'], 'n', 'y', 'n');
  if(empty($desc)) {
   $flnetwork->displayError('Form Error', 'The <samp>description</samp> field is' . 
	 ' empty.', false);
  }

  $insert = "INSERT INTO `$_FN[troubles_templates]` (`troubName`," . 
	" `troubEmailTemplate`, `troubDesc`) VALUES ('$name', '$template', '$desc')";
  $fndatabase->query("SET NAMES 'utf8';");
  $true = $fndatabase->query($insert);

  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script unable to add the' . 
	 ' template to the database.', true, $insert);
  } elseif ($true == true) {
   echo '<p class="successButton"><span class="success">SUCCESS!</span> Your' . 
	 ' <samp>' . $name . '</samp> troubles template was added to the database!' . 
	 "</p>\n";
   echo $flnetwork->backLink('temp_trob');
  }
 }

 /** 
  * Edit 
  */ 
 elseif (isset($_GET['g']) && $_GET['g'] == 'old') {
  $name   = str_replace('+', " ", $flnetwork->cleanMys($_GET['name']));
  $select = "SELECT * FROM `$_FN[troubles_templates]` WHERE `troubName` =" . 
	" '$name' LIMIT 1";
  $true = $fndatabase->query($select);
  if($true == false) {
   $flnetwork->displayError('Database Error', 'Unable to select template from the database.|' . 
   'Make sure your templates table exists.', false, $select);
  }
  $getItem = $fndatabase->obj($true);
?>
<form action="templates_troubles.php" method="post">
<input name="name" type="hidden" value="<?php echo $getItem->troubName; ?>">

<fieldset>
 <legend>Edit Template</legend>
 <p><label><strong>Template Name:</strong></label> 
 <input name="tname" class="input1" type="text" value="<?php echo $getItem->troubName; ?>"></p>
 <p><label>E-mail Template:</strong></label> <select name="template" class="input1">
<?php 
 $select = "SELECT * FROM `$_FN[templates]` ORDER BY `tempTitle` ASC";
 $true = $fndatabase->query($select);
 if($true == false) { 
  echo "  <option>No Templates Available</option>\n";
 }

 else {
  while($getCat = $fndatabase->obj($true)) {
   echo '  <option value="' . $getCat->tempName . '"'; 
	 if($getCat->tempName == $getItem->troubEmailTemplate) { 
	  echo ' selected="selected"'; 
	 }
	 echo '>' . $getCat->tempTitle . "</option>\n";
  }
 }
?>
 </select></p>
 <p class="tc"><strong>Description</strong><br>
  <textarea name="desc" cols="50" rows="16" style="height: 150px; width: 100%;">
<?php echo $getItem->troubDesc; ?>
  </textarea>
 </p>
 <p class="tc"><input name="action" class="input2" type="submit" value="Edit Template"></p>
</fieldset>
</form>
<?php 
 }

 elseif (isset($_POST['action']) && $_POST['action'] == 'Edit Template') {
  $name = $flnetwork->cleanMys($_POST['name']);
  if(empty($name)) {
   $flnetwork->displayError('Form Error', 'Your template name is empty. This means' . 
	 ' you selected an incorrect template or you\'re trying to access something' . 
	 ' that doesn\'t exist. Go back and try again.', false);
  } 
  $tname = $flnetwork->cleanMys($_POST['tname']);
  if(empty($tname)) {
   $flnetwork->displayError('Form Error', 'The <samp>template name</samp> field' . 
	 ' is empty.', false);
  }
  $template = $flnetwork->cleanMys($_POST['template']);
  if(empty($template) || !in_array($template, $fnoptions->templatesList())) {
   $flnetwork->displayError('Form Error', 'The <samp>email template</samp> field' . 
	 ' is invalid.', false);
  }
  $desc = $flnetwork->cleanMys($_POST['desc'], 'n', 'y', 'n');
  if(empty($desc)) {
   $flnetwork->displayError('Form Error', 'The <samp>description</samp> field is' . 
	 ' empty.', false);
  }

  $update = "UPDATE `$_FN[troubles_templates]` SET `troubName` = '$tname'," . 
	" `troubEmailTemplate` = '$template', `troubDesc` = '$desc' WHERE `troubName`" . 
	" = '$name' LIMIT 1";
  $fndatabase->query("SET NAMES 'utf8';");
  $true = $fndatabase->query($update);

  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to edit' . 
	 ' the template.', true, $update);
  } elseif ($true == true) {
   echo '<p class="successButton"><span class="success">SUCCESS!</span> Your' . 
	 " troubles template was edited!</p>\n";
   echo $flnetwork->backLink('temp_trob');
  }
 }

 /** 
  * Delete 
  */ 
 elseif (isset($_GET['g']) && $_GET['g'] == 'erase') {
  $name   = $flnetwork->cleanMys($_GET['name']);
  $select = "SELECT * FROM `$_FN[troubles_templates]` WHERE `troubName` =" . 
	" '$name' LIMIT 1";
  $true = $fndatabase->query($select);
  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to select' . 
	 ' template from the database.', false, $select);
  }
  $getItem = $fndatabase->obj($true);
?>
<form action="templates_troubles.php" method="post">
<input name="name" type="hidden" value="<?php echo $getItem->troubName; ?>">

<fieldset>
 <p>You are about to delete the <strong><?php echo $getItem->troubName; ?></strong> 
 template. Please be aware that once you delete a template, it is gone forever. 
 This cannot be undone! To continue, click the "Delete Template" button.</p>
 <legend>Delete Template</legend>
 <p><label><strong>Template Name:</strong></label> 
  <span style="padding: 0 1%; width: 48%"><samp><?php echo $getItem->troubName; ?></samp></span>
 </p>
 <p class="tc"><input name="action" class="input2" type="submit" value="Delete Template"></p>
</fieldset>
</form>
<?php 
 }

 elseif (isset($_POST['action']) && $_POST['action'] == 'Delete Template') {
  $name = $flnetwork->cleanMys($_POST['name']);
  if(empty($name)) {
   $flnetwork->displayError('Form Error', 'Your template name is empty. This means' . 
	 ' you selected an incorrect template or you\'re trying to access something' . 
	 ' that doesn\'t exist. Go back and try again.', false);
  } 

  $update = "DELETE FROM `$_FN[troubles_templates]` WHERE `troubName` = '$name'" . 
	" LIMIT 1";
  $true = $fndatabase->query($update);

  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to delete' . 
	 ' the template.', true, $update);
  } elseif ($true == true) {
   echo '<p class="successButton"><span class="success">SUCCESS!</span> Your' . 
	 " troubles template was deleted!</p>\n";
   echo $flnetwork->backLink('temp_trob');
  }
 }

 /** 
  * Index 
  */ 
 else {
?>
<p>Welcome to <samp>templates_troubles.php</samp>, the page designed for creating, 
editing and delete trouble templates. :D On installation, the script installed 
three default e-mail templates: <samp>Dead Link</samp>, <samp>Inactivity</samp>
and <samp>Trouble Warning</samp>. They can be edited and deleted.</p>
<p><strong>Note:</strong> Please be aware these are not e-mail templates, but 
trouble templates. Each troubles template should have it's own e-mail template.</p>
<?php
  $select = "SELECT * FROM `$_FN[troubles_templates]` ORDER BY `troubName` ASC";
  $true   = $fndatabase->query($select);
  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script was unable to select' . 
	 ' the troubles templates from the database.', true, $select);
  }
  $count = $fndatabase->total($true);

  if($count > 0) {
?>
<h3>Templates</h3>
<table class="index">
<thead><tr>
 <th>Name</th>
 <th>Description</th>
 <th>E-Mail Template</th>
 <th>Action</th>
</tr></thead>
<?php
   while($getItem = $fndatabase->obj($true)) {
	  $n = str_replace(" ", '+', $getItem->troubName);
?>
<tbody><tr>
 <td class="tc"><?php echo $getItem->troubName; ?></td>
 <td class="tc"><?php echo $getItem->troubDesc; ?></td>
 <td class="tc"><?php echo $getItem->troubEmailTemplate; ?></td>
 <td class="floatIcons tc">
  <a href="templates_troubles.php?g=old&#38;name=<?php echo $n; ?>">
	 <img src="img/icons/edit.png" alt="">
	</a> 
  <a href="templates_troubles.php?g=erase&#38;name=<?php echo $n; ?>">
	 <img src="img/icons/delete.png" alt="">
	</a>
 </td>
</tr></tbody>
<?php 
   }
   echo "</table>\n";
  } else {
   echo "<p class=\"tc\">Currently no trouble templates!</p>\n";
  }
 }
} else {
?>
<p class="errorButton"><span class="error">ERROR!</span> Only the admin and 
senior staff are allowed to access this area.</p>
<?php 
}

require("footer.php");
?>
