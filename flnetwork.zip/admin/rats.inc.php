<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2008 
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Configuration <rats.inc.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
if(basename($_SERVER['PHP_SELF']) === 'rats.inc.php') {
 die("<p>ERROR: <em>Nobody ever told [her] it was the wrong way</em>...<br>" . 
 "Sorry m'dear, you cannot access this file directly!</p>\n");
}
$_FN = array();

# ----------------------------------------------------------- 
/* 
 * Database Variables  
 * 
 * $database_host - MySQL Host (usually localhost) 
 * $database_user - MySQL username  
 * $database_pass - MySQL password  
 * $database_name - MySQL name 
 */ 
# ----------------------------------------------------------- 
$database_host = "localhost";
$database_user = "root";
$database_pass = "";
$database_name = "flnetwork";

# ----------------------------------------------------------- 
/* 
 * Table Prefix 
 * 
 * Table prefix before your table names. 
 */
# ----------------------------------------------------------- 
$_FN['prefix'] = "hatelistings_";

# ----------------------------------------------------------- 
/* 
 * STOP EDITING HERE! 
 * 
 * Below this line are sensitive lines that should NOT be 
 * messed with unless you know exactly what you're doing. 
 */ 
# ----------------------------------------------------------- 
if((!isset($_FN['prefix']) || empty($_FN['prefix'])) 
|| (strpos($_FN['prefix'], '_') == false)) {
 $prefix = "flnetwork_";
} else {
 $prefix = $_FN['prefix'];
}

/**  
 * Table varrrrriables 
 */  
$_FN['categories']         = $prefix . "categories";
$_FN['checkers']           = $prefix . "checkers";
$_FN['options']            = $prefix . "options";
$_FN['staffers']           = $prefix . "staffers";
$_FN['troubles']           = $prefix . "troubles";
$_FN['troubles_templates'] = $prefix . "troubles_templates";
$_FN['templates']          = $prefix . "templates";

/** 
 * Set our $pumpinoptions object with the script URL 
 * and version, and the current month which we'll use for our 
 * salted hash for logging in 
 */ 
$floptions = (object) array(
 'dbEngine' => 'mysql',
 'passHash' => sha1('7496n4hg$6jT5nj7&kEjR'),
 'saltPass' => date("F")
);

/**  
 * Now we initialise our database jaaaaazzz :D 
 */ 
require("inc/fun-db.inc.php");
$fndatabase = new fndatabase(
 $database_host, $database_user, $database_pass, $database_name
);

/** 
 * We want the options path set ahead of time, so set a constant here \o/ 
 */ 
if(basename($_SERVER['PHP_SELF']) != 'install.php') {
 $selectOpt = "SELECT `text` FROM `$_FN[options]` WHERE `name` = 'adminPath' LIMIT 1";
 $trueOpt   = $fndatabase->query($selectOpt);
 if($trueOpt == false) {
  die('The script was unable to select the admin path from the database.');
 }
 define('FLNPATH', $fndatabase->fetch($selectOpt, 'text'));
}
?>
