<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Category Options <cat_options.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
$getTitle = "Category Option Tables";
require("pro.inc.php");
require("vars.inc.php");
require("header.php");

echo "<h2>{$getTitle}</h2>\n";

if(!isset($_GET['page']) || empty($_GET['page']) || !is_numeric($_GET['page'])) { 
 $page = 1;
} else {
 $page = $flnetwork->cleanMys((int)$_GET['page']);
}
$start = $fndatabase->escape((($page * $per_page) - $per_page));

if(isset($_GET['table']) && !empty($_GET['table'])) {
 $table_name = $flnetwork->cleanMys($_GET['table']);
 if(!in_array($table_name, $fncategories->categoryList('id', 'table'))) {
  $flnetwork->displayError('Script Error', 'It appears the table you are trying to view does not exist.' . 
	' Go back and try again.', false);
 }
?>
<p>Below are the options from the 
<samp><?php echo $fncategories->getCatName($table_name, 'table'); ?></samp> category.</p>

<form action="cat_options.php" method="post">
<input name="table" type="hidden" value="<?php echo $table_name; ?>">

<fieldset>
 <legend>Applications Staffer</legend>
 <p><label><strong>Apply applications staffer as all?</strong><br>
 This options applies the applications staffer as the staffer for all staffing 
 duties.</label>
 <input name="apply_all" class="input3" type="radio" value="y"> Yes
 <input name="apply_all" checked="checked" class="input3" type="radio" value="n"> No</p>
 <p class="clear"></p>
 <p><label><strong>Staffer:</strong></label> <select name="appstaffer" class="input1">
<?php 
 $select = "SELECT * FROM `$_FN[staffers]` WHERE `sPending` = '0' ORDER BY `sName` ASC";
 $true   = $fndatabase->query($select);
 if($true == false) {
  echo "<option>No Staffer Available</option>\n";
 }

 else {
  while($getStaff = $fndatabase->obj($true)) {
   $staffs = explode('!', $fnoptions->getCatOption($table_name, 'stafferApplications'));
   echo '<option value="' . $getStaff->sName . '"';
	 if(in_array($getStaff->sName, $staffs)) { 
	  echo ' selected="selected"';
	 }
	 echo '>' . $getStaff->sName . "</option>\n";
  }
 }
?>
 </select></p>
 <p><label><strong>E-mail:</strong></label> 
 <input name="appemail" class="input1" type="text" 
 value="<?php echo $fnoptions->getCatOption($table_name, 'stafferApplicationsEmail'); ?>"></p>
</fieldset>

<fieldset>
 <legend>Forms Staffer</legend>
 <p><label><strong>Staffer:</strong></label> <select name="formstaffer" class="input1">
<?php 
 $select = "SELECT * FROM `$_FN[staffers]` WHERE `sPending` = '0' ORDER BY `sName` ASC";
 $true   = $fndatabase->query($select);
 if($true == false) {
  echo "<option>No Staffer Available</option>\n";
 }

 else {
  while($getStaff = $fndatabase->obj($true)) {
   $staffs = explode('!', $fnoptions->getCatOption($table_name, 'stafferForms'));
   echo '<option value="' . $getStaff->sName . '"';
	 if(in_array($getStaff->sName, $staffs)) { 
	  echo ' selected="selected"';
	 }
	 echo '>' . $getStaff->sName . "</option>\n";
  }
 }
?>
 </select></p>
 <p><label><strong>E-mail:</strong></label> 
 <input name="formemail" class="input1" type="text" 
 value="<?php echo $fnoptions->getCatOption($table_name, 'stafferFormsEmail'); ?>"></p>
</fieldset>

<fieldset>
 <legend>Troubles Staffer</legend>
 <p><label><strong>Staffer:</strong></label> <select name="trostaffer" class="input1">
<?php 
 $select = "SELECT * FROM `$_FN[staffers]` WHERE `sPending` = '0' ORDER BY `sName` ASC";
 $true   = $fndatabase->query($select);
 if($true == false) {
  echo "<option>No Staffer Available</option>\n";
 }

 else {
  while($getStaff = $fndatabase->obj($true)) {
   $staffs = explode('!', $fnoptions->getCatOption($table_name, 'stafferTroubles'));
   echo '<option value="' . $getStaff->sName . '"';
	 if(in_array($getStaff->sName, $staffs)) { 
	  echo ' selected="selected"';
	 }
	 echo '>' . $getStaff->sName . "</option>\n";
  }
 }
?>
 </select></p>
 <p><label><strong>E-mail:</strong></label> 
 <input name="troemail" class="input1" type="text" 
 value="<?php echo $fnoptions->getCatOption($table_name, 'stafferTroublesEmail'); ?>"></p>
</fieldset>

<fieldset>
 <legend>Category Options</legend>
 <p>
  <strong>Rules</strong> (use <samp>&lt;menu&gt;</samp>, <samp>&lt;ul&gt;</samp> 
	or <samp>&lt;ol&gt;</samp> <em>only</em>)<br>
  <textarea name="rules" cols="60" rows="20" style="height: 250px; width: 100%;">
<?php echo $fnoptions->getCatOption($table_name, 'categoryRules'); ?>
  </textarea>
 </p>
</fieldset>

<fieldset>
 <legend>Submit</legend>
 <p class="tc"><input name="action" class="input2" type="submit" value="Edit Options"></p>
</fieldset>
</form>
<?php 
 }

 elseif (isset($_POST['action']) && $_POST['action'] == 'Edit Options') {
  $table_name_now = $flnetwork->cleanMys($_POST['table']);
  if(!in_array($table_name_now, $fncategories->categoryList('id', 'table'))) {
   $flnetwork->displayError('Form Error', 'The <samp>table name</samp> field' . 
	 ' invalid. Go back and try again.', false);
  }
	$appemail = $flnetwork->cleanMys($_POST['appemail']);
	$appstaff = $flnetwork->cleanMys($_POST['appstaffer']);
	if(isset($_POST['apply_all']) && $_POST['apply_all'] == 'y') {
	 $formemail = $appemail;
	 $formstaff = $appstaff;
   $troemail  = $appemail;
	 $trostaff  = $appstaff;
	} else {
	 $formemail = $flnetwork->cleanMys($_POST['formemail']);
	 $formstaff = $flnetwork->cleanMys($_POST['formstaffer']);
   $troemail  = $flnetwork->cleanMys($_POST['trobemail']);
	 $trostaff  = $flnetwork->cleanMys($_POST['trostaffer']);
	}
  if(
	 empty($appemail) || 
	 (
	  (isset($_POST['apply_all']) && $_POST['apply_all'] == 'n') && 
		(empty($formemail) || empty($troemail))
	 )
	) {
   $flnetwork->displayError('Form Error', 'The <samp>email address</samp> field' . 
	 ' invalid. Go back and try again.', false);
  }
  if($fnoptions->getCatOption($table_name_now, 'stafferApplicationsEmail') != $appemail) {
   $fnoptions->editCatOption('stafferApplicationsEmail', $appemail, $table_name_now);
  }
	if($fnoptions->getCatOption($table_name_now, 'stafferFormsEmail') != $formemail) {
   $fnoptions->editCatOption('stafferFormsEmail', $formemail, $table_name_now);
  }
	if($fnoptions->getCatOption($table_name_now, 'stafferTroublesEmail') != $troemail) {
   $fnoptions->editCatOption('stafferTroublesEmail', $troemail, $table_name_now);
  }
  if($fnoptions->getCatOption($table_name_now, 'stafferApplications') != $appstaff) {
   $fnoptions->editCatOption('stafferApplications', $appstaff, $table_name_now);
  }
	if($fnoptions->getCatOption($table_name_now, 'stafferForms') != $formstaff) {
   $fnoptions->editCatOption('stafferForms', $formstaff, $table_name_now);
  }
	if($fnoptions->getCatOption($table_name_now, 'stafferTroubles') != $trostaff) {
   $fnoptions->editCatOption('stafferTroubles', $trostaff, $table_name_now);
  }
	$rules = $flnetwork->cleanMys($_POST['rules'], 'n', 'y', 'n');
  if($fnoptions->getCatOption($table_name_now, 'categoryRules') != $rules) {
   $fnoptions->editCatOption('categoryRules', $rules, $table_name_now);
	}
	
  echo $flnetwork->backLink('cat_options', $table_name_now);
 }

 else {
?>
<p>Below are the category tables that hold your category's options. Each 
category table was created when a <a href="categories.php">category</a> was 
created, along with options for each category table, the page you are visiting 
now.</p>
<?php
  $select = "SELECT * FROM `$_FN[categories]` WHERE `catParent` = '0' ORDER BY" . 
	" `catName` ASC LIMIT $start, $per_page";
  $true = $fndatabase->query($select);
  if($true == false) {
   $flnetwork->displayError('Database Error', 'The script could not select the' . 
	 ' categories from the database.', true, $select);
  }
  $count = $fndatabase->total($true);

  if($count > 0) {
?>
<table class="index">
<thead><tr>
 <th>Category</th>
 <th>Action</th>
</tr></thead>
<?php 
   while($getItem = $fndatabase->obj($true)) {
?>
<tbody><tr>
 <td class="tc"><?php echo $getItem->catName; ?></td>
 <td class="tc"><a href="cat_options.php?table=<?php echo $getItem->tableName; ?>">Category Options</a></td>
</tr></tbody>
<?php 
   }
   echo "</table>\n";

   echo "\n<p id=\"pagination\">Pages: ";
   $total = count($fncategories->categoryList('parent'));
   $pages = ceil($total / $per_page);

   for($i = 1; $i <= $pages; $i++) {
    if($page == $i) {
     echo $i . " ";
    } else { 
     echo '<a href="cat_options.php?page=' . $i . '">' . $i . '</a> ';
    }
   }
   echo "</p>\n"; 
  }

  else {
?>
<p class="tc">Current no category option tables!</p>
<?php 
  }
}

require("footer.php");
?>
