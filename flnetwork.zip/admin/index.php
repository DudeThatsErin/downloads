<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Home <index.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
$getTitle = "Control Panel";
require("pro.inc.php");
require("vars.inc.php");
require("header.php");

echo "<h2>{$getTitle}</h2>\n";

if($fnusers->userStatus() == 1) {
?>
<p>Welcome to the script for managing 
<strong><?php echo $fnoptions->getOption('siteName'); ?></strong>! The control 
panel of your script is where you'll be able to view statistics (number of 
listings, etc.) and use this as a refresh stop. Navigation is simple, and is to 
the left. Have fun running the network! :D</p>
<?php 
} else {
?>
<p>Welcome to <samp><?php echo $fnoptions->getOption('siteName'); ?></samp>, the 
script for managing your categor(y/ies)! Below is your stats for your categories. 
To the left is your admin panel, where you will be able to manage your 
categor(y/ies) and update your profile and biography. Have fun staffing at 
<strong><?php echo $fnoptions->getOption('siteName'); ?></strong>!</p>
<?php 
}
?>

<h3>Statistics</h3>
<?php	 
echo $fnusers->statistics();

require("footer.php");
?>
