<?php 
$approval = $fndatabase->escape("Hello +name+,

Congratulations! Your application to build and run the +subject+ fanlisting, listed in the +subcategory+ subcategory, has been approved at The Hatelistings Network! We recommend you save this e-mail for future reference.

While we truly cannot wait to see your fanlisting up and running, there are few basic rules for building the fanlisting:

1.) Have your fanlisting up within 8 weeks (2 months) of receiving this e-mail.
2.) A link back to the The Hatelistings Network must be up at ALL times.
3.) Link back buttons are highly recommended, especially for those interested in linking back to the fanlisting by image.
4.) Everyone must be allowed to join the fanlisting.

We sincerely hope you have fun building your fanlisting! Once done, remember to send in a Finished form. If you have any questions, feel more than free to ask. Congratulations again and good luck! :D

--
+staffer+
+category+ Category
<http://physicalfanlistings.net>");
$finished = $fndatabase->escape("Hello +name+,

Thank you for submitting a Finished form at The Hatelistings Network. Your form has been processed, and your fanlisting listed.

--
+staffer+
+category+ Category
<http://physicalfanlistings.net>");
$updateinfo = $fndatabase->escape("Hello +name+,

Thank you for sending in a Update form at The Hatelistings Network. Your listing, +subject+, has been updated per your request. Thank you for keeping your information up to date!

--
+staffer+
+category+ Category
<http://physicalfanlistings.net>");
$closedform = $fndatabase->escape("Hello +name+,

Thank you for sending in a closed form at The Hatelistings Network. Your listing, +subject+, has been closed per your request. Thank you for your time!

--
+staffer+
+category+ Category
<http://physicalfanlistings.net>");
$removal = $fndatabase->escape("Hello +name+,

Thank you for responding to the troubles e-mail and fixing the problem. Your fanlisting, +subject+, has been removed from the troubles list at The Hatelistings Network.

--
+staffer+
+category+ Category
<http://physicalfanlistings.net>");
$warning = $fndatabase->escape("Hello +name+,

This is a second warning of your fanlisting being listed on troubles at The Hatelistings Network. If you do not fix the problem stated in the first e-mail and reply to this e-mail in 24 hours, your fanlisting will be removed from the network.

--
+staffer+
+category+ Category
<http://physicalfanlistings.net>");
?>
