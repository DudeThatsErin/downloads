<?php 
/* 
 /////////////////////////////////////////////////////////////
 flnetwork (c) 2009 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 * @copyright  2009  
 * @license    GPL Version 3; BSD Modified 
 * @author     Tess <treibend@gmail.com> 
 * @file       Options <options.php> 
 * @since      March 2nd, 2010 
 * @version    1.0 
 */ 
$getTitle = "Options";
require("pro.inc.php");
require("header.php");

echo "<h2>{$getTitle}</h2>\n";

if($fnusers->userStatus() == 1) {
 if(isset($_POST['action']) && $_POST['action'] == 'Edit Options') {
  $name = $flnetwork->cleanMys($_POST['admin_name']);
  if(empty($name)) {
   $flnetwork->displayError('Form Error', 'Your <samp>name</samp> field is empty.', false);
  }
  if($fnoptions->getOption('adminName') != $name) {
   $fnoptions->editOption('adminName', $name);
  }
	$email = $flnetwork->cleanMys($_POST['site_email']);
  if(empty($email)) {
   $flnetwork->displayError('Form Error', 'The <samp>email</samp> field is empty.', false);
  } elseif (!preg_match("/([A-Za-z0-9-_\.]+)@(([A-Za-z0-9-_]+\.)+)([a-zA-Z]{2,4})$/i", $email)) {
   $flnetwork->displayError('Form Error', 'The e-mail address you supplied appears' . 
	 ' to be invalid. Go back and try again.', false);
  } 
  if($fnoptions->getOption('siteEmail') != $email) {
   $fnoptions->editOption('siteEmail', $email);
	}
  $site_name = $flnetwork->cleanMys($_POST['site_name']);
  if(empty($site_name)) {
   $flnetwork->displayError('Form Error', 'The <samp>site name</samp> field is' . 
	 ' empty. Go back and enter a name.', false);
  }
  if($fnoptions->getOption('siteName') != $site_name) {
   $fnoptions->editOption('siteName', $site_name);
  }
  $site_url = $flnetwork->cleanMys($_POST['site_url']);
  if(empty($site_url)) {
   $flnetwork->displayError('Form Error', 'The <samp>site URI</samp> field is' . 
	 ' empty. Go back and enter a name.', false);
  }
  if($fnoptions->getOption('siteURL') != $site_url) {
   $fnoptions->editOption('siteURL', $site_url);
  }
  $adm_path = $flnetwork->cleanMys($_POST['adminPath']);
  $adm_http = $flnetwork->cleanMys($_POST['adminHttp']);
  if(!strrchr($adm_http, '/') || !strrchr($adm_path, '/')) {
   $flnetwork->displayError('Form Error', 'One or more of the admin paths need' . 
	 ' trailing slashes.', false);
  } 
  if($fnoptions->getOption('adminPath') != $adm_path) {
   $fnoptions->editOption('adminPath', $adm_path);
  } 
	if($fnoptions->getOption('adminHttp') != $adm_http) {
   $fnoptions->editOption('adminHttp', $adm_http);
  }
	$akismet_key_input    = $flnetwork->cleanMys($_POST['akismet_key_input']);
  $javascript_key_input = $flnetwork->cleanMys($_POST['javascript_key_input']);
  if(isset($_POST['generate']) && $_POST['generate'] == 'y') {
   $javascript_key_input2 = substr(md5(date("YmdHis")), 0, 10) . substr(md5(mt_rand(90, 985)), 0, 15);
  } else {
   $javascript_key_input2 = $javascript_key_input;
  }
	if(!empty($akismet_key_input)) {
	 if($fnoptions->getOption('akismetKey') != $akismet_key_input) {
    $fnoptions->editOption('akismetKey', $akismet_key_input);
   }
	}
	if(
	 (isset($_POST['generate']) && $_POST['generate'] == 'y') ||
	 !empty($javascript_key_input)
	) {
	 if($fnoptions->getOption('javascriptKey') != $javascript_key_input2) {
    $fnoptions->editOption('javascriptKey', $javascript_key_input2);
   }
	}
	$per_page = $flnetwork->cleanMys($_POST['per_page']);
  $per_app  = $flnetwork->cleanMys($_POST['per_app']);
  if(!is_numeric($per_page) || !is_numeric($per_app)) {
   $flnetwork->displayError('Form Error', 'Your pagination fields are not numbers.' . 
	 ' Go back and enter a <em>digit</em>.', false);
  } elseif (strlen($per_page) > 2 || strlen($per_app) > 2) {
   $flnetwork->displayError('Form Error', 'The script does not allow pagination' . 
	 ' queries longer than 2 digits. Go back and enter a different number.', false);
  }
  if($fnoptions->getOption('perPage') != $per_page) {
   $fnoptions->editOption('perPage', $per_page);
  }
	if($fnoptions->getOption('perApproved') != $per_app) {
   $fnoptions->editOption('perApproved', $per_app);
  }
	$forms_apps     = $flnetwork->cleanMys($_POST['forms_apps']);
	$forms_closed   = $flnetwork->cleanMys($_POST['forms_finished']);
	$forms_contact  = $flnetwork->cleanMys($_POST['forms_contact']);
	$forms_contact2 = $flnetwork->cleanMys($_POST['forms_contact2']);
	$forms_finished = $flnetwork->cleanMys($_POST['forms_closed']);
	$forms_update   = $flnetwork->cleanMys($_POST['forms_update']);
	$forms_vstaff   = $flnetwork->cleanMys($_POST['forms_vstaff']);
	$forms_vtc      = $flnetwork->cleanMys($_POST['forms_vtc']);
	if($fnoptions->getOption('formsApps') != $forms_apps) {
   $fnoptions->editOption('formsApps', $forms_apps);
  }
	if($fnoptions->getOption('formsClosed') != $forms_closed) {
   $fnoptions->editOption('formsClosed', $forms_closed);
  }
	if($fnoptions->getOption('formsContact') != $forms_contact) {
   $fnoptions->editOption('formsContact', $forms_contact);
  }
	if($fnoptions->getOption('formsContactStaff') != $forms_contact2) {
   $fnoptions->editOption('formsContactStaff', $forms_contact2);
  }
	if($fnoptions->getOption('formsFinished') != $forms_finished) {
   $fnoptions->editOption('formsFinished', $forms_finished);
  }
	if($fnoptions->getOption('formsUpdate') != $forms_update) {
   $fnoptions->editOption('formsUpdate', $forms_update);
  }
	if($fnoptions->getOption('formsvStaffer') != $forms_vstaff) {
   $fnoptions->editOption('formsvStaffer', $forms_vstaff);
  }
	if($fnoptions->getOption('formsvTC') != $forms_vtc) {
   $fnoptions->editOption('formsvTC', $forms_vtc);
  }
	$general_rules_opt = trim($_POST['rules']); 
  if($fnoptions->getOption('generalRules') != $general_rules_opt) {
   $fnoptions->editOption('generalRules', $general_rules_opt);
  }
  echo $flnetwork->backLink('options');
 }

 else {
?>
<p>Below are the options you entered when you installed the script. All options can be edited, however, no options 
can be currently added (although this might change in future releases).</p>

<form action="options.php" method="post">
<fieldset>
 <legend>Admin Details</legend>
 <p><label><strong>Admin Name:</strong></label> 
 <input name="admin_name" class="input1" type="text" value="<?php echo $fnoptions->getOption('adminName'); ?>"></p>
 <p><label><strong>Admin E-Mail:</strong></label> 
 <input name="site_email" class="input1" type="text" value="<?php echo $fnoptions->getOption('siteEmail'); ?>"></p>
 <p><label><strong>Site Name:</strong></label> 
 <input name="site_name" class="input1" type="text" value="<?php echo $fnoptions->getOption('siteName'); ?>"></p>
 <p><label><strong>Site</strong> <abbr title="Uniform Resource Indentifier">URI</abbr>:</label> 
 <input name="site_url" class="input1" type="text" value="<?php echo $fnoptions->getOption('siteURL'); ?>"></p>
</fieldset>

<fieldset>
<?php 
 $ap = $fnoptions->getOption('adminPath');
 $ah = $fnoptions->getOption('adminHttp');

 if(empty($ap)) {
  $adminPath = str_replace('options.php', '', $_SERVER['SCRIPT_FILENAME']);
 } else {
  $adminPath = $fnoptions->getOption('adminPath');
 }

 if(empty($ah)) {
  $adminURI = 'http://' . $_SERVER['SERVER_NAME'] . str_replace('options.php', '', $_SERVER['PHP_SELF']);
 } else {
  $adminURI = $fnoptions->getOption('adminHttp');
 }
?>
 <legend>Paths</legend>
 <p><label><strong>Admin Paths:</strong><br>
 Admin paths are the path and <abbr title="Uniform Resource Identifier">URI</abbr> 
 to your admin panel. All paths and URLs are already set for you if empty, 
 although they can be changed to the desired path.
 </label> <input name="adminPath" class="input1" type="text" value="<?php echo $adminPath; ?>"><br>
 <input name="adminHttp" class="input1" type="text" value="<?php echo $adminURI; ?>"></p>
</fieldset>

<fieldset>
 <legend>Anti-SPAM</legend>
 <p><label><strong>Akismet Key:</strong></label> 
 <input name="akismet_key_input" class="input1" 
 type="text" value="<?php echo $fnoptions->getOption('akismetKey'); ?>"></p>
 <p><label><strong>JavaScript Key:</strong></label> 
 <input name="javascript_key_input" class="input1" 
 type="text" value="<?php echo $fnoptions->getOption('javascriptKey'); ?>"></p>
 <p><label><strong>Generate Javascript key?</strong></label> 
 <input name="generate" class="input3" type="radio" value="y"> Yes
 <input name="generate" checked="checked" class="input3" type="radio" value="n"> No</p>
</fieldset>

<fieldset>
 <legend>URL Options</legend>
 <p><label><strong>Per Page:</strong><br>
 Pagination for the admin panel/others as a whole.
 </label> 
 <input name="per_page" class="input1" type="text" value="<?php echo $fnoptions->getOption('perPage'); ?>"></p>
 <p class="clear"></p>
 <p><label><strong>Per Approved:</strong><br>
 Pagination for the approved listings.
 </label> 
 <input name="per_app" class="input1" type="text" value="<?php echo $fnoptions->getOption('perApproved'); ?>"></p>
</fieldset>

<fieldset>
 <legend>Form URLs</legend>
 <p><label><strong>Applications:</strong></label> 
 <input name="forms_apps" class="input1" type="text" value="<?php echo $fnoptions->getOption('formsApps'); ?>"></p>
 <p><label><strong>Closed Form:</strong></label> 
 <input name="forms_closed" class="input1" type="text" value="<?php echo $fnoptions->getOption('formsClosed'); ?>"></p>
 <p><label><strong>Contact Form (Senior Staff):</strong></label> 
 <input name="forms_contact" class="input1" type="text" value="<?php echo $fnoptions->getOption('formsContact'); ?>"></p>
 <p><label><strong>Contact Form (Category Staff):</strong></label> 
 <input name="forms_contact2" class="input1" type="text" value="<?php echo $fnoptions->getOption('formsContactStaff'); ?>"></p>
 <p><label><strong>Finished Form:</strong></label> 
 <input name="forms_finished" class="input1" type="text" value="<?php echo $fnoptions->getOption('formsFinished'); ?>"></p>
 <p><label><strong>Update Form:</strong></label> 
 <input name="forms_update" class="input1" type="text" value="<?php echo $fnoptions->getOption('formsUpdate'); ?>"></p>
 <p><label><strong>Volunteer: Staff Form:</strong></label> 
 <input name="forms_vstaff" class="input1" type="text" value="<?php echo $fnoptions->getOption('formsvStaffer'); ?>"></p>
 <p><label><strong>Volunteer: TC Form:</strong></label> 
 <input name="forms_vtc" class="input1" type="text" value="<?php echo $fnoptions->getOption('formsvTC'); ?>"></p>
</fieldset>

<fieldset>
 <legend>General Rules</legend>
 <p>General rules are not <em>all</em> of the rules in on the network rules page. 
 These rules will appear right before the category's specific rules on the apply 
 form. It is suggested these be a breakdown of the rules of the network.</p>
 <p>
  <textarea name="rules" cols="60" rows="20" style="height: 200px; margin: 0 1% 0 0; width: 98%;">
<?php echo $fnoptions->getOption('generalRules'); ?>
  </textarea>
 </p>
</fieldset>

<fieldset>
 <legend>Submit</legend>
 <p class="tc"><input name="action" class="input2" type="submit" value="Edit Options"></p>
</fieldset>
</form>
<?php 
 }
}

else {
?>
<p class="errorButton"><span class="error">ERROR!</span> Only the senior staff 
are allowed to access this area.</p>
<?php 
}

require("footer.php");
?>
