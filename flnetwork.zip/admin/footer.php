</section>

</div>

<footer>
 <p><strong><?php echo $fnoptions->getOption('siteName'); ?></strong> &#169; 
 <?php echo $fnadmin->isYear('2011'); ?></p>
</footer>

</div>

</body>
</html>
