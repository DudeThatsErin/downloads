<?php 
require("header.php");
?>
<h2>Volunteer: Trouble Checker</h2>
<?php 
# -----------------------------------------------------------
require("fig.inc.php");
# ----------------------------------------------------------- 
$cat = 'troublechecker';
# -----------------------------------------------------------
require(FNPATH . "inc/show-volunteer.php");
# -----------------------------------------------------------
?>
<?php 
require("footer.php");
?>
