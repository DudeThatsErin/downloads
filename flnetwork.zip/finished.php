<?php 
require("header.php");
?>
<h2>Finished Form</h2>
<?php 
# -----------------------------------------------------------
require("fig.inc.php");
# -----------------------------------------------------------
require(FNPATH . "inc/show-finished.php");
# -----------------------------------------------------------
?>
<?php 
require("footer.php");
?>
