<?php 
require("header.php");
?>
<h2>Forms</h2>
<ul>
<li><a href="closed.php">Closed</a></li>
<li><a href="finished.php">Finished</a></li>
<li><a href="update.php">Update Information</a></li>
<li><a href="contact.php">Contact a Staffer</a></li>
</ul>
<?php
require("footer.php");
?>
