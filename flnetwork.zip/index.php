<?php 
require("header.php");
?>
<h2>Welcome</h2>
<p>Welcome to <strong>The Hatelistings Network</strong> at Hatelistings.org! Whether 
you are new to the fanlisting concept, or an experienced veteran, we invite you 
to explore the realm of hatelistings - fanlistings dedicated to the dislike of
a subject, from models, to actors, to singers and back. Why not browse around 
the network and see what the big deal is about?</p>

<h3>What is a fanlisting?</h3>
<p>A fanlisting is simply an online listing of fans of a subject, such as a TV 
show, actor, or musician, that is created by an individual and open for fans 
from around the world to join. &#8211; <a href="http://www.thefanlistings.org/">The Fanlistings Network</a></p>
<?php 
require("footer.php");
?>
