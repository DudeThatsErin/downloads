<?php 
require("header.php");
?>
<h2>Approved Fanlisting</h2>
<?php 
# -----------------------------------------------------------
require("fig.inc.php");
# -----------------------------------------------------------
require(FNPATH . "inc/show-approved.php");
# -----------------------------------------------------------
?>
<?php
require("footer.php");
?>
