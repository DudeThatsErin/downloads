<?php 
/** 
 * Template Name: Staff 
 * 
 * @package WordPress 
 */ 

get_header(); 
?>
<?php 
require(ABSPATH . "staff.php");
?>
<?php 
get_sidebar();
get_footer(); 
?>
