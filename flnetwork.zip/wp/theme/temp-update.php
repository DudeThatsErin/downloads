<?php 
/** 
 * Template Name: Update 
 * 
 * @package WordPress 
 */ 

get_header(); 
?>
<?php 
require(ABSPATH . "update.php");
?>
<?php 
get_sidebar();
get_footer(); 
?>
