<?php 
/** 
 * Template Name: Contact: Category Staff 
 * 
 * @package WordPress 
 */ 

get_header(); 
?>
<?php 
require(ABSPATH . "contact-staff.php");
?>
<?php 
get_sidebar();
get_footer(); 
?>
