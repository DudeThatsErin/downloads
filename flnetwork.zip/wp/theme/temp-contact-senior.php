<?php 
/** 
 * Template Name: Contact: Senior Staff 
 * 
 * @package WordPress 
 */ 

get_header(); 
?>
<?php 
require(ABSPATH . "contact-senior.php");
?>
<?php 
get_sidebar();
get_footer(); 
?>
