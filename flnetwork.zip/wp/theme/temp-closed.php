<?php 
/** 
 * Template Name: Closed 
 * 
 * @package WordPress 
 */ 

get_header(); 
?>
<?php 
require(ABSPATH . "closed.php");
?>
<?php 
get_sidebar();
get_footer(); 
?>
