<?php 
/** 
 * Template Name: Apply 
 * 
 * @package WordPress 
 */ 

get_header(); 
?>
<?php 
require(ABSPATH . "apply.php");
?>
<?php 
get_sidebar();
get_footer(); 
?>
