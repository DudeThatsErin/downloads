<?php 
/** 
 * Template Name: Approved 
 * 
 * @package WordPress 
 */ 

get_header(); 
?>
<?php 
require(ABSPATH . "approved.php");
?>
<?php 
get_sidebar();
get_footer(); 
?>
