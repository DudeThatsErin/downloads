<?php 
/** 
 * Template Name: Volunteer: Trouble Checker 
 * 
 * @package WordPress 
 */ 

get_header(); 
?>
<?php 
require(ABSPATH . "checker.php");
?>
<?php 
get_sidebar();
get_footer(); 
?>
