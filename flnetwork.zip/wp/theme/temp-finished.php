<?php 
/** 
 * Template Name: Finished 
 * 
 * @package WordPress 
 */ 

get_header(); 
?>
<?php 
require(ABSPATH . "finished.php");
?>
<?php 
get_sidebar();
get_footer(); 
?>
