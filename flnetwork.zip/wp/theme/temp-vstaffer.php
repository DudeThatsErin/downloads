<?php 
/** 
 * Template Name: Volunteer: Staffer
 * 
 * @package WordPress 
 */ 

get_header(); 
?>
<?php 
require(ABSPATH . "staffer.php");
?>
<?php 
get_sidebar();
get_footer(); 
?>
