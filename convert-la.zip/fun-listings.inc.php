<?php 
# 'FUN-LISTINGS.INC' FILE 
/* ----------------------------------------------------------
Tess Ally 2007 � Listing Admin 
------------------------------------------------------------- */

# -- Listings List Function ---------------------------------
# -----------------------------------------------------------
function listingsList($b = 'id', $j = '') {
 global $_ST;

 $select = "SELECT * FROM `$_ST[main]`";
 if($j != '' && $j == 'current') {
  $select .= " WHERE `status` = '0'";
 } elseif ($j != '' && $j == 'upcoming') {
  $select .= " WHERE `status` = '1'";
 }
 if($b == 'subject') {
  $select .= " ORDER BY `subject` ASC";
 }
 $true = mysql_query($select);
 if($true == false) {
  echo $select;
  displayError('Database Error', 'The script was unable to select the listings.', 
  true, $select);
 }

 $all = array();
 while($getItem = mysql_fetch_array($true)) {
  $all[] = $getItem['id'];
 }

 return $all;
}

# -- Check Listings -----------------------------------------
# -----------------------------------------------------------
function checkListings($c, $s) {
 global $_ST;

 $select = "SELECT * FROM `$_ST[main]` WHERE `category` LIKE '%!$c!%' AND `show` = '0'";
 if($s == 'current') {
  $select .= " AND `status` = '0'";
 } elseif ($s == 'upcoming') {
  $select .= " AND `status` = '1'";
 } elseif ($s == 'pending') {
  $select .= " AND `status` = '2'";
 }
 $true = mysql_query($select);
 if($true == false) {
  displayError('Database Error', 'Could not select the category from the database.', false);
 }

 if(mysql_num_rows($true) > 0) {
  $valid = 1;
 } else {
  $valid = 0;
 }

 return $valid;
}

# -- Listing Template (for individual listings) -------------
# -----------------------------------------------------------
function listingTemplate($i, $t, $u, $s, $m) {
 global $_ST;

 # -- Should never get here, but just in case ---------------
 if($i == 0) {
  return "";
 }

 $select = "SELECT `$t` FROM `$_ST[main]` WHERE `id` = '$i' LIMIT 1";
 $true = mysql_query($select);
 if($true == false) {
  displayError('Database Error', 'Unable to select the listing affiliates template.', false);
 }
 $template = mysql_fetch_array($true);

 if(empty($template['affiliates'])) {
  return "";
 }

 if($t == 'affiliates') {
  $v = 'aff';
 } elseif ($t == 'joined') {
  $v = 'jnd';
 } elseif ($t == 'listings') {
  $v = 'img';
 } elseif ($t == 'wishlist') {
  $v = 'wsh';
 }

 $image = getOption($v . '_http') . $m;

 $format = html_entity_decode($template['affiliates']);
 $format = str_replace('{subject}', $s, $format);
 $format = str_replace('{url}', $u, $format);
 $format = str_replace('{image}', $image, $format);

 return $format;
}

# -- Pull Image (direct) ------------------------------------
# -----------------------------------------------------------
function pullImage($id) {
 global $_ST;

 $select = "SELECT `image` FROM `$_ST[main]` WHERE `id` = '$id' LIMIT 1";
 $true = mysql_query($select);
 if($true == false) {
  displayError('Database Error', 'Unable to select the image from the specific' . 
	' site.|Make sure your table(s) exist.', true, $select);
 }
 $getItem = mysql_fetch_object($true);

 return $getItem->image;
}

# -- Pull Listing Subject(s) --------------------------------
# -----------------------------------------------------------
function pullSubjects($i, $s) {
 if($s == '!') {
  $a = "/[\s!]+/";
 } else {
  $a = "/[\s|]+/";
 }

 $subj = '';
 $subjects = preg_split($a, $i);
 foreach($subjects as $u) {
  if($u != '' && $u != " " && $u != ' 0 ') {
   $subj .= getSubject($u) . ', ';
  }
 }
 $subj = trim($subj, ', ');

 return $subj;
}

# -- Pull Listing Subject(s) for Links ----------------------
# -----------------------------------------------------------
function pullSubjects_Links($i, $s) {
 global $my_updates, $qwebs;

 if($s == '!') {
  $a = "/[\s!]+/";
 } else {
  $a = "/[\s|]+/";
 }

 if(strpos($qwebs, '/') !== false) {
  $myw = $qwebs;
 } else {
  $myw = $qwebs . '/'; 
 }
 
 if(strpos($my_updates, 'index.php') !== false) {
  $q = $myw . '?s=';
 } else {
  $q = $my_updates . '?s=';
 }
 
 $subj = '';
 $subjects = preg_split($a, $i);
 foreach($subjects as $u) {
  if($u != '' && $u != " " && $u != ' 0 ') {
   if(getOption('updates_prettyurls') == 'y') {
    $w = $myw . 's/' . $u;
   } else {
    $w = $q . $u;
   }
	 $subj .= '<a href="' . $w . '">' . getSubject($u) . '</a>, ';
  }
 }
 $subj = trim($subj, ', ');

 return $subj;
}

# -- Get 'all' Listings Function ----------------------------
# -----------------------------------------------------------
function pullList($s = 'all', $b = 'all', $d = '') {
global $_ST;

$select = "SELECT * FROM `$_ST[main]` WHERE `show` = '0'";
if($s != 'all') {
 if($s == 'current') {
  $select .= " AND `status` = '0'";
 } elseif ($s == 'upcoming') {
  $select .= " AND `status` = '1'";
 } elseif ($s == 'pending') { 
  $select .= " AND `status` = '2'";
 }
}
 
if($b != 'all' && $d != '' && ctype_digit($d)) {
 $select .= " AND`category` LIKE '%!$d!%'";
}
$select .= " ORDER BY `subject` ASC";

$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the all listings.|Make sure your tables exists.', false);
}

$all = array();
while($getItem = mysql_fetch_array($true)) {
 $all[] = $getItem['id'];
}

return $all;
} 

# -- Get 'all' Listings (+ Count) Function ------------------
# -----------------------------------------------------------
function pullListCount($s = 'all', $b = 'all', $d = '') {
global $_ST;

$select = "SELECT * FROM `$_ST[main]` WHERE `show` = '0'";
if($s != 'all') {
 if($s == 'current') {
  $select .= " AND `status` = '0'";
 } elseif ($s == 'upcoming') {
  $select .= " AND `status` = '1'";
 } elseif ($s == 'pending') { 
  $select .= " AND `status` = '2'";
 }
}
 
if($b != 'all' && $d != '' && ctype_digit($d)) {
 $select .= " AND `category` LIKE '%!$d!%'";
}
$select .= " ORDER BY `subject` ASC";

$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the all listings.|Make sure your tables exists.', false);
}

$all = 0;
if(mysql_fetch_array($true) > 0) {
 $all += mysql_num_rows($true);
}

$categories = categoryList('list', 'child', $d);
foreach($categories as $c) {
 $select = "SELECT * FROM `$_ST[main]` WHERE `category` LIKE '%!$c!%' AND `show` = '0'";
 $true = mysql_query($select);
 if(mysql_num_rows($true) > 0) {
  $all += mysql_num_rows($true);
 }
}

return $all;
} 

# -- Get Listing Template -----------------------------------
#    (show-owned.php)
# -----------------------------------------------------------
function getTemplate_Listings($id, $b = '') {
 global $_ST, $resultImage;

 $select = "SELECT * FROM `$_ST[main]` WHERE `id` = '$id' LIMIT 1";
 $true = mysql_query($select);
 if($true == false) {
  displayError('Database Error', 'Cannot select the specified ID from the database.', false);
 }
 $getItem = mysql_fetch_array($true);
 $fid = $getItem['id'];

 if($b != '') {
  $p = mysql_real_escape_string($b);
 } else {
  $p = 'listings_template';
 }

 $select = "SELECT `template` FROM `$_ST[templates]` WHERE `name` = '$p'";
 $true = mysql_query($select);
 if($true == false) {
  displayError('Database Error', 'Cannot select the specified template from the database.' . 
  '|Make sure your templates have been created or are turned off if not in use.', false);
 }
 $template = mysql_fetch_array($true);
 
 $approved = getMemberCount($fid, '0');
 $pending = getMemberCount($fid, 1);
 $updated = getUpdated($fid);

 $format = html_entity_decode($template['template']);
 $format = str_replace('{subject}', $getItem['subject'], $format);
 $format = str_replace('{title}', $getItem['title'], $format);
 $format = str_replace('{url}', $getItem['url'], $format);
 $format = str_replace('{desc}', html_entity_decode($getItem['desc']), $format);
 $format = str_replace('{categories}', pullCatNames($getItem['category'], '!'), $format);
 $format = str_replace('{image}', getOption('img_http') . $getItem['image'], $format);
 $format = str_replace('{approved}', $approved, $format);
 $format = str_replace('{pending}', $pending, $format);
 $format = str_replace('{since}', date($getItem['date'], strtotime($getItem['since'])), $format);
 $format = str_replace('{updated}', $updated, $format);

 return $format;
}

# -- Show Default Listings ----------------------------------
# -----------------------------------------------------------
function showListings($s, $d) {
 global $_ST, $_SORT;

 $query = cleanMys($_SERVER['QUERY_STRING']);
 if(isset($query) && !empty($query)) {
  $_URL = '?' . str_replace('&', '&amp;', $query) . '&amp;';
 } else {
  $_URL = '?';
 }

 $ids = categoryList('list', 'parent');

 if($d == 'list') {
  echo "<table class=\"owned\" width=\"100%\">\n";
	echo "<tfoot><tr>\n<td class=\"tc\" colspan=\"2\">&raquo; <a href=\"" . $_URL . 
	"sort=all\">All Categories</a></td>\n</tr></tfoot>\n";
  foreach($ids as $id) {
   $catid = $id;
   if((checkListings($id, $s) == 1) 
	 || (checkListings($id, $s) == 0 && countChildren($catid) > 0 && childrenListings($catid) > 0)) {
	  echo "<tbody><tr>\n";
	  echo "<td class=\"left\"><a href=\"" . $_URL . 'sort=' . $id . '">' . getCatName($id) . "</a></td>\n";
	  echo '<td class="center">' . pullListCount($s, 'id', $id) . "</td>\n";
	  echo "</tr></tbody>\n";
   } 
   if($_SORT == 'y') {
    $lists = categoryList('default', 'child', $catid);
    foreach($lists as $list) {
     if(checkListings($list['catid'], $s) == 1) {
	    echo "<tbody><tr>\n";
	    echo "<td class=\"left\"><a href=\"" . $_URL . 'sort=' . $list['catid'] . '">' . getCatName($list['parent']) . 
	    " &raquo; " . getCatName($list['catid']) . "</a></td>\n";
	    echo '<td class="center">' . pullListCount($s, 'id', $list['catid']) . "</td>\n";
	    echo "</tr></tbody>\n";
     }
    }
   }
  } 
  echo "</table>\n";
 }

 elseif ($d == 'all') {
  if($s == 'current') {
   $s = '0';
  } elseif ($s == 'upcoming') {
   $s = 1;
  } elseif ($s == 'pending') {
   $s = 2;
  }
  $select = "SELECT * FROM `$_ST[main]` WHERE `status` = '$s' AND `show` = '0'";
  $true = mysql_query($select);
 
  $sql = "SELECT `template` FROM `$_ST[templates]` WHERE `name` = 'listings_template'";
  $yes = mysql_query($sql);
  if($yes == false) {
   displayError('Database Error', 'Cannot select the specified template from the database.' . 
   '|Make sure your templates have been created or are turned off if not in use.', false);
  }
  $template = mysql_fetch_array($yes);

  echo "<div class=\"sec\">";
  while($getItem = mysql_fetch_array($true)) {
   echo getTemplate_Listings($getItem['id']);
  }
  echo "</div>\n";
 }

}
?>
