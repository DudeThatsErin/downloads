<?php
# 'FUN-MISC.INC' FILE 
/* ----------------------------------------------------------
Tess Ally 2007 � STFU T-Rex! Admin 
------------------------------------------------------------- */

# -- Edit Option Function -----------------------------------
# -----------------------------------------------------------
function editOption($option, $value) {
global $_ST;

if(get_magic_quotes_gpc()) {
 $value = stripslashes($value);
}
 
$value = mysql_real_escape_string($value);

$update = "UPDATE `$_ST[options]` SET `text` = '$value' WHERE `name` = '$option' LIMIT 1";
@mysql_query("SET NAMES 'utf8';");
$true = mysql_query($update);
 if($true == false) {
  displayError('Database Error', 'Unable to update the specified option.|Make sure your table exists.', true, $update);
 } 
 
 else {
  echo '<p class="successButton"><span class="success">SUCCESS!</span> Your <samp>' . $option . 
	"</samp> option has been edited! :D</p>\n";
 }
}

# -- Get Option Function ------------------------------------
# -----------------------------------------------------------
function getOption($option) {
global $_ST;

$select = "SELECT `text` FROM `$_ST[options]` WHERE `name` = '$option' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Cannot select option from the database.|Make sure your options table exists.');
}
$getItem = mysql_fetch_array($true);

return $getItem['text'];
} 

# -- Edit Listing Variable Function -------------------------
# -----------------------------------------------------------
function editListing($id, $option, $value) {
global $_ST;

if(get_magic_quotes_gpc()) {
 $value = stripslashes($value);
}
$value = mysql_real_escape_string($value);

$update = "UPDATE `$_ST[main]` SET `$option` = '$value' WHERE `id` = '$id' LIMIT 1";
@mysql_query("SET NAMES 'utf8';");
$true = mysql_query($update);
 if($true == false) {
  displayError('Database Error', 'Unable to update the specified listing variable.|' . 
	'Make sure your table exists.', true, $update);
 } 
 
 else {
  echo '<p class="successButton"><span class="success">SUCCESS!</span> Your <samp>' . $option . 
	"</samp> listing option has been edited! :D</p>\n";
 }
}

# -- Get Option Function ------------------------------------
# -----------------------------------------------------------
function getVar($id, $option) {
global $_ST;

$select = "SELECT `$option` FROM `$_ST[main]` WHERE `id` = '$id' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Cannot select listing variable from the database.|' . 
 'Make sure your options table exists.', true, $select);
}
$getItem = mysql_fetch_array($true);

return $getItem[$option];
} 

# -- Count Function -----------------------------------------
# -----------------------------------------------------------
function getCount($c, $y = 'n') {
global $_ST;

$select = "SELECT * FROM";
if($c == 'cat') {
 $select .= " `$_ST[categories]`";
} elseif ($c == 'joined') {
 $select .= " `$_ST[joined]`";
} elseif ($c == 'current') {
 if($y == 'n') {
  $select .= " `$_ST[main]` WHERE `status` = '0'";
 } elseif ($y == 'y') {
  $select .= " `$_ST[main]` WHERE `status` = '0' AND `show` = '0'";
 }
} elseif ($c == 'upcoming') {
 if($y == 'n') {
  $select .= " `$_ST[main]` WHERE `status` = '1'";
 } elseif ($y == 'y') {
  $select .= " `$_ST[main]` WHERE `status` = '1' AND `show` = '0'";
 }
} elseif ($c == 'pending') {
 if($y == 'n') {
  $select .= " `$_ST[main]` WHERE `status` = '2'";
 } elseif ($y == 'y') {
  $select .= " `$_ST[main]` WHERE `status` = '2' AND `show` = '0'";
 }
} elseif ($c == 'approved') {
 $select .= " `$_ST[members]` WHERE `mPending` = '0'";
} elseif ($c == 'unapproved') {
 $select .= " `$_ST[members]` WHERE `mPending` = '1'";
} elseif ($c == 'affiliates')
 $select .= " `$_ST[affiliates]`";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the specific table.|Make sure your table(s) exist.');
}
$count = mysql_num_rows($true);

return $count;
}

# -- Get Affiliates Function --------------------------------
# -----------------------------------------------------------
function getAffiliates($i) {
global $_ST;

$select = "SELECT * FROM `$_ST[affiliates]` WHERE `aID` = '$i' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select affiliates from the specified listing.|' . 
 'Make sure your affiliates table exists.', false);
}
$getItem = mysql_fetch_array($true);

return $getItem;
}

# -- Pull Quote Templates -----------------------------------
# -----------------------------------------------------------
function pullQuotes($i, $r = 1, $n) {
global $_ST;

$select = "SELECT * FROM `$_ST[quotes]` WHERE `fNiq` = '$i'";
if($r == 1) {
 $select .= " ORDER BY RAND()";
}
$select .= " LIMIT $n";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Cannot select the quotes from the specified listing.', false);
}
$getItem = mysql_fetch_array($true);
 
$select = "SELECT `quotes` FROM `$_ST[main]` WHERE `id` = '$i' LIMIT 1";
 $true = mysql_query($select);
  $getBasic = mysql_fetch_object($true);
 
$format = str_replace('{quote}', $getItem['qQuote'], html_entity_decode($getBasic->quotes));
$format = str_replace('{author}', $getItem['qAuthor'], $format);

return $format;
}

# -- Pull Templates (direct) --------------------------------
# -----------------------------------------------------------
function pullTemplates($template) {
global $_ST;

$select = "SELECT `template` FROM `$_ST[templates]` WHERE `name` = '$template' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Cannot select the template from the database.|Make sure your templates table exists.');
}
$getItem = mysql_fetch_array($true);

return $getItem['template'];
}

# -- Pull Affiliates Image (direct) -------------------------
# -----------------------------------------------------------
function pullImage_Affiliate($i) {
global $_ST;

$select = "SELECT `aImage` FROM `$_ST[affiliates]` WHERE `aID` = '$i' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the image from the specific site.|Make sure your table(s) exist.', true, $select);
}
$getItem = mysql_fetch_array($true);

return $getItem['aImage'];
}

# -- Count Affiliates Function ------------------------------
#  <index.php>
# -----------------------------------------------------------
function countAffiliates($i) {
global $_ST;

$select = "SELECT * FROM `$_ST[affiliates]` WHERE `fNiq` = '$i' OR `fNiq` LIKE '%!$i!%'";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the affiliates from the specified listing.|' . 
 'Make sure your affiliates table exists.', true, $select);
}
$count = mysql_num_rows($true);

return $count;
}

# -- All Members Function ----------------------------------
# -----------------------------------------------------------
function allAffiliates($i = 'n') {
global $_ST;

$select = "SELECT * FROM `$_ST[affiliates]`";
if($i != 'n' && is_numeric($i)) {
 $select .= " WHERE `fNiq` = '$i' OR `fNiq` LIKE '%!$i!%'";
}
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the affiliates.|Make sure your affiliates table exists.', false);
}

$all = array();
while($getItem = mysql_fetch_array($true)) {
 $all[] = $getItem['aID'];
}

return $all;
}
?>
