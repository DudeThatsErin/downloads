<?php 
# 'FUN.INC' FILE 
/* ----------------------------------------------------------
Tess Ally 2007 � Listing Admin 
------------------------------------------------------------- */

# -- Get Cleaning Function ----------------------------------
# -----------------------------------------------------------
function cleanMys($post, $p = 'all', $s = 'all', $e = 'all') {
 if($p == 'all') {
  $post = strip_tags($post);
 }
 
 if($s == 'all') {
  $post = trim(htmlentities($post, ENT_QUOTES, 'UTF-8'));
 } elseif ($s == 'nom') {
  $post = trim($post);
 } else {
  $post = trim(htmlentities($post, ENT_NOQUOTES, 'UTF-8'));
 }
	
 if($e == 'all') {
  if(get_magic_quotes_gpc()) {
   $post = stripslashes($post);
	}
  $post = mysql_real_escape_string($post);
 }
 
 $post = trim($post);
 return $post;
}

# -- Get Cleaning Search Function ---------------------------
#  Cleans search queries! ----------------------------------- 
# -----------------------------------------------------------
function cleanSearch($s, $c = 'clean') {
 $s = trim($s);
 if($c == 'clean') {
  $s = str_replace(' ', '+', $s);
  $s = str_replace('.', 'DOTIE', $s);
  $s = str_replace('&', 'ANDIE', $s);
	$s = str_replace('%26', 'ANDIE', $s);
  $s = str_replace('@', 'ATTIE', $s);
	$s = str_replace('%40', 'ATTIE', $s);
	$s = str_replace('-', 'DASHI', $s);
	$s = str_replace('_', 'SCORE', $s);
 } elseif ($c == 'declean') {
  $s = str_replace('+', ' ', $s);
  $s = str_replace('DOTIE', '.', $s);
  $s = str_replace('ANDIE', '&', $s);
  $s = str_replace('ATTIE', '@', $s);
	$s = str_replace('DASHI', '-', $s);
	$s = str_replace('SCORE', '_', $s);
 }
 return $s;
}

# -- Get Formatting Journal Function ------------------------
#  Formats posts to DW, IJ and LJ ---------------------------
# -----------------------------------------------------------
function cleanLJ($post, $p = 'all', $s = 'all') {
 if($p == 'all') {
  $post = strip_tags($post);
 }
 
 if($s == 'all') {
  $post = trim(htmlentities($post, ENT_QUOTES, 'UTF-8'));
 } elseif ($s == 'nom') {
  $post = trim($post);
 } else {
  $post = trim(htmlentities($post, ENT_NOQUOTES, 'UTF-8'));
 }

 # -- Adds line breaks! --------------------------------------
 $post = str_replace(array("\r\n", "\r"), "\n", $post);
 $post = preg_replace('|(?<!<br />)\s*\n\n|', "<br /><br />\n", $post);

 return $post;
}

# -- Get Favourite Field Replacing Function -----------------
#  Replaces any blank favourite fields with "NONE" if -------
#  empty and cleans each field ------------------------------ 
# -----------------------------------------------------------
function replaceArray($p) {
 if(empty($p) || $p == " ") {
  $p = "NONE";
 }
 $p = cleanMys($p);
 return $p;
}

# -- Get Emptying Array Function ----------------------------
#  Empties array of empty fields ----------------------------
# -----------------------------------------------------------
function emptyarray($a) {
 $n = array();
 $e = array();

 foreach($a as $k) {
  $k = trim($k);
  $e[] = '0';

  if(!in_array($k, $e) && $k != "") {
   $n[] = $k;
  }
 }
	 
 return $n;
}

# -- Connect/disconnect to our regular connection ----------- 
# ----------------------------------------------------------- 
function breach($y = 1) {
 global $connect, $database, $database_host, $database_name, $database_pass, 
 $database_user;
	 
 switch($y) {
	case 0:
	 mysql_close($connect);
	 unset($connect);
	 unset($database);
  break;
		
  case 1:
	 $connect = mysql_connect($database_host, $database_user, $database_pass)
	  or die("<p><span style=\"color: #FF0000;\">Error:</span> Unable to connect" . 
	  " to the database host!</p>\n");
	 $database = mysql_select_db($database_name)
	  or die("<p><span style=\"color: #FF0000;\">Error:</span> Unable to connect" . 
	  " to the database!</p>\n");
  break;
 } 
}

# -- Logout Function ---------------------------------------- 
# ----------------------------------------------------------- 
function logout() {
 setcookie('lalog', '', time() - 3600, '/');
 header("Location: " . isPage());
 die('Logging you out, m\'dear...');
}

# -- Get Form Formatting Function ---------------------------
#  Replaces empty form fields (for $_ST['main']) with -------
#  default values, or defined values before the script ------
/* 
 ============================================================ 
 Parameters 
 $d = Form name  
 $c = Defined value; empty by default 
 ============================================================ 
*/ 
# -----------------------------------------------------------
function formDefault($d, $c = '') {
 switch($d) {
  case 'delete': # Delete 
	if(!empty($c)) {
	 $n = $c;
	} else {
	 $n = 'delete.php';
	}
	break;
	case 'form': # Affiliates/Site Form 
	if(!empty($c)) {
	 $n = $c;
	} else {
	 $n = 'site.php';
	}
	break;
	case 'join': # Join 
	if(!empty($c)) {
	 $n = $c;
	} else {
	 $n = 'join.php';
	}
	break;
	case 'reset': # Reset Password 
	if(!empty($c)) {
	 $n = $c;
	} else {
	 $n = 'reset.php';
	}
	break;
	case 'update': # Update Information
	if(!empty($c)) {
	 $n = $c;
	} else {
	 $n = 'update.php';
	}
	break;
 }
 return $n;
}

# -- Get Replace Symbol Function ----------------------------
#  Replaces HTML entities, in place of html_entity_decode() -
# -----------------------------------------------------------
function replaceSpec($p) {
 $e = trim($p);
 $e = str_replace('&amp;', '&', $e);
 $e = str_replace('&Eacute;', '�', $e);
 $e = str_replace('&eacute;', '�', $e);
 $e = str_replace('&#039;', "'", $e);
 $e = str_replace('&quot;', '"', $e);
 return $e;
}

# -- Get 'displayError' Function ----------------------------
# -----------------------------------------------------------
function displayError($e, $b, $a = true, $q = 'n') {
 global $connect;

 echo "<h3>" . $e . "</h3>\n";

 if($e == 'Database Error') {
  $c = "mysql";
 } elseif ($e == 'Script Error') {
  $c = "php";
 } else {
  $c = "error";
 }
 
 if($e == 'Database Error') {
  $p = "mysqlButton";
 } elseif ($e == 'Script Error') {
  $p = "errorButton";
 } else {
  $p = "errorButton";
 }

 $o = explode('|', $b);
 foreach($o as $i) {
  echo "<p class=\"{$p} tb\">" . $i . "</p>\n";
 }

 if(isset($_COOKIE['stalog']) && $a == true) {
  echo "<h3>Debug Mode</h3>\n<p>There seems to be a few (hopefully minor) issues with the script:</p>\n"; 
  echo "<p class=\"$p\"><span class=\"$class\">MySQL Errors:</span> ";
  if($q != 'nom') {
   echo mysql_error($connect);
   echo "\n<br><em>" . $q . "</em></p>\n";
  } else {
   echo "</p>\n";
  }
 }
 
 exit();
}

# -- Get backLink() Function ---------------------------------
#  Returns links to previous page(s) -------------------------
/* 
 ============================================================ 
 Parameters 
 $type = Page type  
 $id   = Query ID, usually by editing 
 $s    = Search ID 
 $e    = Extra field (usually '&amp;opt=option') 
 ============================================================ 
*/ 
# -----------------------------------------------------------
function backLink($type, $id = 'n', $s = '', $e = 'n') {

if($type == 'aff') {
 if($id != 'n') {
  $link = "\n" . '<p class="backLink"><a href="affiliates.php?get=old&amp;id=' . $id . '">&laquo; Back to Affiliate</a>' . "</p>\n";
 } else {
  $link = "\n" . '<p class="backLink"><a href="affiliates.php">&laquo; Back to Affiliates</a>' . "</p>\n";
 }
}
elseif ($type == 'cat') {
 $link = "\n" . '<p class="backLink"><a href="categories.php">&laquo; Back to Categories</a>' . "</p>\n";
}
elseif ($type == 'codes') {
 if($id != 'n') {
  $link = "\n" . '<p class="backLink"><a href="codes.php?listing=' . $id . '">&laquo; Back to "' . getSubject($id) . '" Codes</a>' . "</p>\n";
 } else {
  $link = "\n" . '<p class="backLink"><a href="codes.php">&laquo; Back to Codes</a>' . "</p>\n";
 }
}
elseif ($type == 'codes_categories') {
 $link = "\n" . '<p class="backLink"><a href="codes-categories.php">&laquo; Back to Codes Categories</a>' . "</p>\n";
}
elseif ($type == 'codes_donors') {
 $link = "\n" . '<p class="backLink"><a href="codes-donors.php">&laquo; Back to Donors</a>' . "</p>\n";
}
elseif ($type == 'codes_sizes') {
 $link = "\n" . '<p class="backLink"><a href="codes-sizes.php">&laquo; Back to Sizes</a>' . "</p>\n";
}
elseif ($type == 'emails') {
 $link = "\n" . '<p class="backLink"><a href="emails.php">&laquo; Back to Emails</a>' . "</p>\n";
}
elseif ($type == 'joined') {
 if($s != '' && ctype_digit($s)) {
  $link = "\n" . '<p class="backLink"><a href="joined.php?get=searchCategories' . 
	'&amp;cat_id=' . $s . '">&laquo; Back to Joined</a>' . "</p>\n";
 } else {
  $link = "\n" . '<p class="backLink"><a href="joined.php">&laquo; Back to Joined</a>' . "</p>\n";
 }
}
elseif ($type == 'kim') {
 $link = "\n" . '<p class="backLink"><a href="kim.php">&laquo; Back to KIM</a>' . "</p>\n";
}
elseif ($type == 'listings') {
 if($id != 'n' && $e == 'n') {
  $link = "\n" . '<p class="backLink"><a href="listings.php?get=manage&amp;id=' . 
	$id . '">&laquo; Back to Listing</a>' . "</p>\n";
 } elseif ($id != 'n' && $e != 'n') {
  $y = explode('opt=', $e);
  $x = ucwords($y[1]);
  $ex = $e != 'n' ? $x : "";
  $link = "\n" . '<p class="backLink"><a href="listings.php?get=manage&amp;id=' . 
	$id . $e . '">&laquo; Back to Listing ' . $ex . "</a></p>\n";
 } else {
  $link = "\n" . '<p class="backLink"><a href="listings.php">&laquo; Back to Listings</a>' . "</p>\n";
 }
}
elseif ($type == 'lyrics') {
 if($id != 'n' && $id == 'albums') {
  $link = "\n" . '<p class="backLink"><a href="lyrics.php?g=' . $id . '">&laquo; Back to Albums</a>' . "</p>\n";
 } elseif ($id != 'n' && $id == 'songs') {
  $link = "\n" . '<p class="backLink"><a href="lyrics.php?g=' . $id . '">&laquo; Back to Songs</a>' . "</p>\n";
 } else {
  $link = "\n" . '<p class="backLink"><a href="lyrics.php">&laquo; Back to Lyrics</a>' . "</p>\n";
 }
}
elseif ($type == 'mem') {
 if($id != 'n') {
  $link = "\n" . '<p class="backLink"><a href="members.php?get=old&amp;id=' . $id . '">&laquo; Back to Member</a>' . "</p>\n";
 } else {
  $link = "\n" . '<p class="backLink"><a href="members.php">&laquo; Back to Members</a>' . "</p>\n";
 }
}
elseif ($type == 'options') {
 if($id != 'n') {
  $link = "\n" . '<p class="backLink"><a href="options.php?g=' . $id . '">&laquo; Back to ' . ucwords($id) . "</a></p>\n";
 } else {
  $link = "\n" . '<p class="backLink"><a href="options.php">&laquo; Back to Options</a>' . "</p>\n";
 }
}
elseif ($type == 'quotes') {
 $link = "\n" . '<p class="backLink"><a href="quotes.php">&laquo; Back to Quotes</a>' . "</p>\n";
} 
elseif ($type == 'temp') {
 $link = "\n" . '<p class="backLink"><a href="templates.php">&laquo; Back to Templates</a>' . "</p>\n";
}
elseif ($type == 'temp_e') {
 $link = "\n" . '<p class="backLink"><a href="templates_emails.php">&laquo; Back to E-Mail Templates</a>' . "</p>\n";
}
elseif ($type == 'updates') {
 if($id != 'n') {
  $link = "\n" . '<p class="backLink"><a href="updates.php?get=old&amp;id=' . $id . '">&laquo; Back to Entry</a>' . "</p>\n";
 } else {
  $link = "\n" . '<p class="backLink"><a href="updates.php">&laquo; Back to Updates</a>' . "</p>\n";
 }
}
elseif ($type == 'updates_comments') {
 if($id != 'n') {
  $link = "\n" . '<p class="backLink"><a href="updates-comments.php?get=old&amp;id=' . 
	$id . '">&laquo; Back to Comment</a>' . "</p>\n";
 } else {
  $link = "\n" . '<p class="backLink"><a href="updates-comments.php">&laquo; Back to Comments</a>' . "</p>\n";
 }
}
elseif ($type == 'wishlist') {
 $link = "\n" . '<p class="backLink"><a href="wishlist.php">&laquo; Back to Wishlist</a>' . "</p>\n";
}

return $link;
}
?>
