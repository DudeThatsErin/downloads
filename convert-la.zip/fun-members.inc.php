<?php 
# 'FUN-MEMBERS.INC' FILE 
/* ----------------------------------------------------------
Tess Ally 2007 � Listing Admin 
------------------------------------------------------------- */

# -- All Members Function ----------------------------------
# -----------------------------------------------------------
function getMembersList($i = 'n', $p = 1, $b = 'desc') {
 global $_ST;

 $select = "SELECT * FROM `$_ST[members]`";
 if($i != 'n' && ctype_digit($i)) {
  $select .= " WHERE `fNiq` = '$i'";
  if($p == 0) {
   $select .= " AND `mPending` = '0'";
  }
 } else {
  if($p == 0) {
   $select .= " WHERE `mPending` = '0'";
  }
 }
 $ad = $b == 'desc' ? "DESC" : "ASC";
 $select .= " ORDER BY `mAdd` $ad";
 $true = mysql_query($select);
 if($true == false) {
  displayError('Database Error', 'Unable to select the members.|Make sure your members table exists.', false);
 }

 $all = array();
 while($getItem = mysql_fetch_array($true)) {
  $all[] = $getItem['mID'];
 }

 return $all;
}

function allMembers($i = 'n', $p = 1) {
 return getMembersList($i, $p);
}

# -- Get Listings Function ----------------------------------
# -----------------------------------------------------------
function getListings($i, $b = 'array') {
 global $_ST, $connect, $database_host, $database_user, $database_pass, $database_name;

 $perLink = mysql_connect($database_host, $database_user, $database_pass)
	or die("<p><span style=\"color: #FF0000;\">Error:</span> Unable to connect to" . 
  " the database host!</p>\n");
 $perData = mysql_select_db($database_name)
	or die("<p><span style=\"color: #FF0000;\">Error:</span> Unable to connect to" . 
  " the database!</p>\n");

 $select = "SELECT * FROM `$_ST[main]` WHERE `id` = '$i' LIMIT 1";
 $true = mysql_query($select, $perLink);
 if($true == false) {
  displayError('Database Error', 'The script was unable to select the specified' . 
  ' listing.|Make sure your listings table exists.', true, $select);
 }
 $getItem = $b == 'array' ? mysql_fetch_array($true) : mysql_fetch_object($true);

 if($i === 0 || empty($getItem)) {
  /* 
   *  Return if we're dealing with Collective or it's empty 
   */ 
  $getItem = array();
 } 

 return $getItem;
}

# -- Members List Function ----------------------------------
# -----------------------------------------------------------
function membersList($i) {
 global $_ST;

 $select = "SELECT * FROM `$_ST[members]` WHERE `fNiq` = '$i' LIMIT 1";
 $true = mysql_query($select);
 if($true == false) {
  displayError('Database Error', 'The script was unable to select the specified' . 
  ' members.|Make sure your members table exists.', false);
 }
 $getItem = mysql_fetch_array($true);

 return $getItem;
}

# -- Get Member (from ID) Function --------------------------
#  <listings.php>, <members.php>
# -----------------------------------------------------------
function getMembers($id, $type = 'id', $k = '', $b = 'array') {
 global $_ST, $_KY, $connect;

 $y = $k != '' && in_array($k, listingsList()) ? $k : $_KY['listing_id'];
 $listing = getListings($y);
 if(!empty($listing['dbhost']) && !empty($listing['dbuser']) && !empty($listing['dbname'])) {
  $c1 = mysql_connect($listing['dbhost'], $listing['dbuser'], $listing['dbpass'])
	 or die("<p><span style=\"color: #FF0000;\">Error:</span> Unable to connect to the database host!</p>\n");
	$d1 = mysql_select_db($listing['dbname'])
	 or die("<p><span style=\"color: #FF0000;\">Error:</span> Unable to connect to the database!</p>\n");
 } else {
  $c1 = $connect;
 }

 if($listing['dblist'] == 1) {
  if($listing['dbtype'] == 'enth') {
	 $select = "SELECT * FROM `$listing[dbtabl]`";
   if($type == 'id') { 
    $select .= " WHERE `id` = '$id'";
   } elseif ($type == 'email') {
    $select .= " WHERE `email` = '$id'";
   }
   $select .= " LIMIT 1";
	} elseif ($listing['dbtype'] == 'fanbase') {
	 $select = "SELECT * FROM `$listing[dbtabl]`";
   if($type == 'id') { 
    $select .= " WHERE `id` = '$id'";
   } elseif ($type == 'email') {
    $select .= " WHERE `email` = '$id'";
   }
   $select .= " LIMIT 1";
	}
 } 
 else {
  $select = "SELECT * FROM `$_ST[members]`";
  if($type == 'id') { 
   $select .= " WHERE `mID` = '$id'";
  } elseif ($type == 'email') {
   $select .= " WHERE `mEmail` = '$id'";
  }
  $select .= " LIMIT 1";
 }
 $true = mysql_query($select, $c1);
 if($true == false) {
  displayError('Database Error', 'The script was unable to select the specified' . 
  ' member.|Make sure your members table exists.', true, $select);
 }
 
 if($listing['dblist'] == 1) {
  $getItem = mysql_fetch_array($true);
  if($listing['dbtype'] == 'enth') {
   if($b == 'array') {
	  $sendArray = array(
	   'mID' => $getItem['id'],
		 'mName' => $getItem['name'],
		 'mEmail' => $getItem['email'],
		 'mURL' => $getItem['url'],
		 'mPending' => $getItem['pending']
	  );
   } elseif ($b == 'object') {
    $sendArray = (object) array(
	   'mID' => $getItem['id'],
		 'mName' => $getItem['name'],
		 'mEmail' => $getItem['email'],
		 'mURL' => $getItem['url'],
		 'mPending' => $getItem['pending']
	  );
   }
	} elseif ($listing['dbtype'] == 'fanbase') {
	 $pending = $getItem['apr'] == 'y' ? 0 : 1;
   if($b == 'array') {
	  $sendArray = array(
	   'mID' => $getItem['id'],
		 'mName' => $getItem['name'],
		 'mEmail' => $getItem['email'],
		 'mURL' => $getItem['url'],
		 'mPending' => $pending
	  );
   } elseif ($b == 'object') {
    $sendArray = (object) array(
	   'mID' => $getItem['id'],
		 'mName' => $getItem['name'],
		 'mEmail' => $getItem['email'],
		 'mURL' => $getItem['url'],
		 'mPending' => $pending
	  );
   }
	}
 } else {
  $sendArray = $b == 'array' ? mysql_fetch_array($true) : mysql_fetch_object($true);
 }
 
 if($listing['dblist'] == 1) {
  mysql_close($c1);
	breach(1);
 }

 return $sendArray;
}

# -- Get Subject Name Function ------------------------------
#  <members.php>
# -----------------------------------------------------------
function getSubject($id) {
global $_ST;

if($id == 0) {
 return "Whole Collective";
}

$select = "SELECT `subject` FROM `$_ST[main]` WHERE `id` = '$id' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Could not select the title from the database.', true, $select);
}
$getItem = mysql_fetch_array($true);

return $getItem['subject']; 
}

# -- Get Member Name Function -------------------------------
#  <members.php>
# -----------------------------------------------------------
function memberName($i) {
global $_ST;

$select = "SELECT `mName` FROM `$_ST[members]` WHERE `mID` = '$i' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Could not select the title from the database.', true, $select);
}
$getItem = mysql_fetch_array($true);

return $getItem['mName']; 
}

# -- Pull Member E-Mails from Listing Function --------------
#  <emails.php>
# -----------------------------------------------------------
function pullMembers($i) {
global $_ST;

$select = "SELECT * FROM `$_ST[members]` WHERE `fNiq` = '$i' AND `mPending` = '0'";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the members from the specified listing.|' . 
 'Make sure your member table exists.', true, $select);
}

$all = array();
while($getItem = mysql_fetch_array($true)) {
 $all[] = $getItem['mEmail'];
}

return $all;
}

# -- Count Members Function ---------------------------------
#  <listings.php>
# -----------------------------------------------------------
function countMembers($i, $s = '') {
 global $_ST, $connect;
 
 $listing = getListings($i);
 if(!empty($listing['dbhost']) && !empty($listing['dbuser']) && !empty($listing['dbname'])) {
  $c1 = mysql_connect($listing['dbhost'], $listing['dbuser'], $listing['dbpass'])
	 or die("<p><span style=\"color: #FF0000;\">Error:</span> Unable to connect to the database host!</p>\n");
	$d1 = mysql_select_db($listing['dbname'])
	 or die("<p><span style=\"color: #FF0000;\">Error:</span> Unable to connect to the database!</p>\n");
 } else {
  $c1 = $connect;
 }

 if($listing['dblist'] == 1) {
  if($listing['dbtype'] == 'enth') {
	 $select = "SELECT * FROM `$listing[dbtabl]`";
   if($s != '') {
    if($s == 0) {
     $select .= " WHERE `pending` = '0'";
    } elseif ($s == 1) {
     $select .= " WHERE `pending` = '1'";
    }
   }
	} elseif ($listing['dbtype'] == 'fanupdate') {
	 $select = "SELECT * FROM `$listing[dbtabl]`";
   if($s != '') {
    if($s == 0) {
     $select .= " WHERE `apr` = 'y'";
    } elseif ($s == 1) {
     $select .= " WHERE `apr` = 'n'";
    }
   }
	}
 }
 
 else {
  $select = "SELECT * FROM `$_ST[members]` WHERE `fNiq` = '$i'";
  if($s != '') {
   if($s == 0) {
    $select .= " AND `mPending` = '0'";
   } elseif ($s == 1) {
    $select .= " AND `mPending` = '1'";
   }
  }
 }
 
 $true = mysql_query($select, $c1);
 if($true == false) {
  displayError('Database Error', 'Cannot count members from the specified listing.', false);
 }
 $count = mysql_num_rows($true);
 
 if($listing['dblist'] == 1) {
  mysql_close($c1);
	breach(1);
 }

 return $count;
}

# -- Get Additional Encode and Decode Function -------------- 
# ----------------------------------------------------------- 
function additional($b, $n) {
 if($n == 'decode') {
  $e = cleanMys($b);
	$e = str_replace("_", " ", $e);
 }
 
 elseif ($n == 'encode') {
  $e = cleanMys($b);
	$e = str_replace(" ", "_", $e);
 }
 
 return trim($e);
}

# -- Add to Favourite Field(s) Function ---------------------
# ----------------------------------------------------------- 
function addtoFave($a, $e) { 
 $n = array();
 $x = array();
 $b = explode("|", $e);
 $b = emptyarray($b);
 $z = emptyarray($a);
 $c = count($z);
 if(count($c) >= count($b)) {
  return false;
 }

 $i = 0;
 foreach($b as $d) {
  if($i == count($b)) {
	 break;
	}
  $n[] = $d;
	$x[] = $i;
	$i++;
 }
 for($q = 0; $q < $c; $q++) {
  if(!in_array($q, $x)) {
	 $n[] = "NONE";
	}
 }
 $w = implode("|", $n);
 $w = "|" . trim($w, "|") . "|";
	
 return $w;
}

# -- Erase a favourite field from each member... function ---
# ----------------------------------------------------------- 
function eraseFave($a, $e, $i) { 
 $n = array();
 $b = explode("|", $a);
 $b = emptyarray($b);

 $i = 0;
 foreach($b as $k) {
  $k = trim($k);

  if($i != $e && $k != "") {
   $n[] = $k;
  }
	$i++;
 }
 $w = implode("|", $n);
 $w = "|" . trim($w, "|") . "|";
	
 return $w;
}

# -- Get Format Template Function ---------------------------
# -----------------------------------------------------------
function format($i, $t, $m = '', $e = 'id') {
global $_ST, $_KY, $connect, $database_host, $database_user, $database_pass, 
$database_name, $fave_field, $mark;

$perLink = mysql_connect($database_host, $database_user, $database_pass)
 or die("<p><span style=\"color: #FF0000;\">Error:</span> Unable to connect to the database host!</p>\n");
$perData = mysql_select_db($database_name)
 or die("<p><span style=\"color: #FF0000;\">Error:</span> Unable to connect to the database!</p>\n");

$select = "SELECT `$t` FROM `$_ST[main]` WHERE `id` = '$i' LIMIT 1";
$true = mysql_query($select, $perLink);
if($true == false) {
 displayError('Database Error', 'Unable to select the specified template.', false);
}
$getItem = mysql_fetch_array($true);

switch($t) {
 case 'members':
 if(empty($getItem['members'])) {
  $getItem['members'] = '<li>{name}<br' . $mark . '>' .
	'{email} &amp;middot; {url}</li>' . "\n";
 }
 break;
 case 'members_header':
 if(empty($getItem['members_header'])) {
  $getItem['members_header'] = "<ol>\n";
 }
 break;
 case 'members_footer':
 if(empty($getItem['members_footer'])) {
  $getItem['members_footer'] = "</ol>\n";
 }
 break;
}

if($m != '') {
 $member = getMembers($m, $e);
 if($member['mVisible'] == 0) {
  $email = javascriptEmail($member['mEmail']);
 } else
  $email = "<del>E-Mail</del>";
 
 if(!empty($member['mURL'])) {
  $url = "<a href=\"" . $member['mURL'] . "\" title=\"External Link: " . shortURL($member['mURL']) . "\">URL &raquo;</a>";
 } else
  $url = "<del>URL</del>";
}

# -- Favourite fields are bitches, I tell you, BITCHES! --
$fields = @explode('|', $fave_field);
$answers = @explode('|', $member['mExtra']);
$answers = emptyarray($answers);
$ffHead = "<p class=\"faveField\">\n";
if(count($fields) == 1) {
 $ffBody = "<span class=\"faveField1\"><strong>" . $fields[0] . ":</strong> " . str_replace('NONE', "All", $answers[0]) . "\n</span>\n";
} elseif (count($fields) > 1) {
 $n = 0;
 foreach($fields as $f) {
	$n1 = $n + 1;
	$ffBody .= "<span class=\"faveField$n1\"><strong>" . $f . ":</strong> " . 
	str_replace('NONE', "All", $answers[$n]) . "</span> <br$mark>\n";
	$n++;
 }
 $ffBody = rtrim($ffBody, "<br$mark>\n") . ">\n";
}
$ffFoot = "\n</p>\n";

$format = html_entity_decode($getItem[$t]);
if($m != '') {
 $format = str_replace('{name}', $member['mName'], str_replace('&amp;', '&', $format));
 $format = str_replace('{email}', $email, $format);
 $format = str_replace('{url}', $url, $format);
 $format = str_replace('{country}', $member['mCountry'], $format);
 if(strpos($getItem[$t], '{fave_field}') !== false) {
  $format = str_replace('{fave_field}', $ffHead . $ffBody . $ffFoot, $format);
 }
}

return $format;
}

# -- Fave Field Function ------------------------------------
#  <show-join.php>
# -----------------------------------------------------------
function favejoin() {
global $fave_field, $fave_field_e, $fave_fields_db, $mark;

# -- Should never get here, but you never know! -------------
if(empty($fave_fields_db) && empty($fave_field)) {
 return "";
}

 if(!empty($fave_fields_db)) {
  $fields_db = explode('|', $fave_fields_db);
	$fields_db = emptyarray($fields_db);

  if($fields_db == 0) {
   return "";
  }
 
  elseif (count($fields_db) == 1) {
   echo "<p><label>" . ucwords(additional($fields_db[0], 'decode')) . 
	 ":</label> <input name=\"fave[]\" class=\"input1\" type=\"text\"" . $mark . "></p>";
  } 
 
  elseif (count($fields_db) > 1) {
   $n = 0;
	 foreach($fields_db as $f) {
	  echo "<p><label>" . ucwords(additional($f, 'decode')) . 
		":</label> <input name=\"fave[]\" class=\"input1\" type=\"text\"" . $mark . "></p>";
 	  $n++;
   }
  }
 }

 else {
  $fields = explode('|', $fave_field);
	$fields = emptyarray($fields);

  if($fields == 0) {
   return "";
  }
 
  elseif (count($fields) == 1) {
   if(isset($fave_field_e) && is_array($fave_field_e)) {
    echo "<p><label>" . ucwords($fields[0]) . ":</label> <select name=\"fave[]\" class=\"input1\">\n";
	  foreach($fave_field_e as $f2 => $f3) {
	   foreach($f3 as $f4) {
	    echo "<option>" . $f4 . "</option>\n";
		 }
	  }
	  echo "</select></p>\n";
   } else {
	  echo "<p><label>" . ucwords($fields[0]) . ":</label> <input name=\"fave[]\" class=\"input1\" type=\"text\"" . $mark . "></p>";
   }
  } 
 
  elseif (count($fields) > 1) {
   $n = 0;
	 foreach($fields as $f) {
	  if(isset($fave_field_e) && is_array($fave_field_e)) {
	   foreach($fave_field_e as $f2 => $f3) {
      echo "<p><label>" . ucwords($f2) . ":</label> <select name=\"fave[]\" class=\"input1\">\n";
	    foreach($f3 as $f4) {
	     echo "<option>" . $f4 . "</option>\n";
	    }
	    echo "</select></p>\n";
	   }
    } else {
	   echo "<p><label>" . ucwords($f) . ":</label> <input name=\"fave[]\" class=\"input1\" type=\"text\"" . $mark . "></p>";
	  }
		/*if($n == ($count - 1)) {
		 break;
		}*/
 	  $n++;
   }
  }
 }
}

# -- Fave Field Function ------------------------------------
#  <show-members.php>
# 
#  Check if $fave_field is empty AND if $e if empty first! 
# -----------------------------------------------------------
function faveDisplay($e) {
global $fave_field, $mark;

 if((isset($fave_field) && !empty($fave_field)) && (!empty($e))) {
  $fields = explode('|', $fave_field);
	$answers = explode('|', $e);
	$answers = emptyarray($answers);
	echo "<p class=\"faveField\">\n";
	if(count($fields) == 1) {
	 echo "<span class=\"faveField1\">";
	 echo "<strong>" . $fields[0] . ":</strong> " . $answers[0] . "\n";
	 echo "</span>\n";
	} elseif (count($fields) > 1) {
	$n = 0;
	 foreach($fields as $f) {
		echo "<span class=\"faveField{$n}\">";
		echo "<strong>" . $f . ":</strong> " . str_replace('NONE', "All", $answers[$n]) . "<br$mark>\n";
		echo "</span>\n";
		$n++;
	 }
	}
	echo "\n</p>\n";
 } else
  return "";
}

# -- Members Pagination Function ----------------------------
#  <show-members.php>
# -----------------------------------------------------------
function membersPagination($s, $q = '') {
 global $_ST, $_KY, $_URL, $connect, $page, $per_page;

 $listing = getListings($_KY['listing_id']);
 if(!empty($listing['dbhost']) && !empty($listing['dbuser']) 
 && !empty($listing['dbpass']) && !empty($listing['dbname'])) {
  # Force new co-nnec-tion! 
  $c1 = mysql_connect($listing['dbhost'], $listing['dbuser'], $listing['dbpass'])
	 or die("<p><span style=\"color: #FF0000;\">Error:</span> Unable to connect to the database host!</p>\n");
	$d1 = mysql_select_db($listing['dbname'])
	 or die("<p><span style=\"color: #FF0000;\">Error:</span> Unable to connect to the database!</p>\n");
 }

 echo "<p id=\"pagination\">\n";
 if($listing['dblist'] == 1) {
  if($listing['dbtype'] == 'enth') {
	 $select = "SELECT * FROM `$listing[dbtabl]` WHERE `pending` = '0'";
   if($s == 'country') {
    $select .= " AND `country` = '$q'";
   }
	 $true = @mysql_query($select, $c1);
	} elseif ($listing['dbtype'] == 'fanbase') {
	 $select = "SELECT * FROM `$listing[dbtabl]` WHERE `apr` = 'y'";
   if($s == 'country') {
    $select .= " AND `country` = '$q'";
   }
	 $true = @mysql_query($select, $c1);
	}
 }
 
 else {
  $select = "SELECT * FROM `$_ST[members]` WHERE `fNiq` = '$_KY[listing_id]' AND `mPending` = '0'";
  if($s == 'country') {
   $select .= " AND `mCountry` = '$q'";
  }
	$true = @mysql_query($select, $connect);
 }
 $total = @mysql_num_rows($true);
 $pages = ceil($total/$per_page);
 
 $prev = ($page - 1);
 if($page > 1) {
  echo '<a href="' . $_URL . 'page=' . $prev . '">&laquo; Previous</a> ';
 } else {
  echo '&laquo; Previous ';
 }

 for($i = 1; $i <= $pages; $i++) {
  if($page == $i) {
   echo $i . " ";
  } else {
   echo '<a href="' . $_URL . 'page=' . $i . '">' . $i . '</a> ';
  } 
 }
		
 $next = ($page + 1);
 if($page < $pages) {
  echo '<a href="' . $_URL . 'page=' . $next . '">Next &raquo;</a>';
 } else {
  echo 'Next &raquo;';
 }
 echo "\n</p>\n";
 if(!empty($listing['dbhost']) && !empty($listing['dbuser']) 
 && !empty($listing['dbpass']) && !empty($listing['dbname'])) {
  mysql_close($c1);
 }
}

# -- Members Sort Function ----------------------------------
#  <show-members.php>
# -----------------------------------------------------------
function membersSort($s, $b, $p) {
global $_ST, $_KY, $_SORT, $_URL, $connect, $fave_field, $mark, $start, $per_page;

 $listing = getListings($_KY['listing_id']);
 if(!empty($listing['dbhost']) && !empty($listing['dbuser']) 
 && !empty($listing['dbpass']) && !empty($listing['dbname'])) {
  $c1 = mysql_connect($listing['dbhost'], $listing['dbuser'], $listing['dbpass'])
	 or die("<p><span style=\"color: #FF0000;\">Error:</span> Unable to connect to the database host!</p>\n");
	$d1 = mysql_select_db($listing['dbname'])
	 or die("<p><span style=\"color: #FF0000;\">Error:</span> Unable to connect to the database!</p>\n");
 }

 switch($s) {
  case 'all':
	if($listing['dblist'] == 1) {
	 if($listing['dbtype'] == 'enth') {
	  $select = "SELECT * FROM `$listing[dbtabl]` WHERE `pending` = '0'";
	  $select .= " ORDER BY `name` ASC LIMIT $start, $per_page";
		$true = @mysql_query($select, $c1);
	 } elseif ($listing['dbtype'] == 'fanbase') {
	  $select = "SELECT * FROM `$listing[dbtabl]` WHERE `apr` = 'y'";
	  $select .= " ORDER BY `name` ASC LIMIT $start, $per_page";
		$true = @mysql_query($select, $c1);
	 }
	}
	else {
	 $select = "SELECT * FROM `$_ST[members]` WHERE `fNiq` = '$_KY[listing_id]' AND `mPending` = '0'";
	 $select .= " ORDER BY `mName` ASC LIMIT $start, $per_page";
	 $true = @mysql_query($select, $connect);
	}
  if($true == false) {
   displayError('Script Error', 'Unable to select the members from the specified listing.', false);
  }
	
	echo format($_KY['listing_id'], 'members_header');
	while($getItem = mysql_fetch_array($true)) {
	 $get_id_now = $b == 1 ? 'id' : 'mID';
	 echo format($_KY['listing_id'], 'members', $getItem[$get_id_now]);
	}
	echo format($_KY['listing_id'], 'members_footer');
	break; 
	
	case 'country':
	if(isset($_GET['name'])) {
	$g = str_replace('+', ' ', cleanMys($_GET['name']));
	if($b == 1) {
	 if($p == 'enth') {
	  $select = "SELECT * FROM `$listing[dbtabl]` WHERE `pending` = '0' AND `country` = '$g'";
	  $select .= " ORDER BY `name` ASC LIMIT $start, $per_page";
		$true = @mysql_query($select, $c1);
	 } elseif ($p == 'fanbase') {
	  $select = "SELECT * FROM `$listing[dbtabl]` WHERE `apr` = 'y' AND `country` = '$g'";
	  $select .= " ORDER BY `name` ASC LIMIT $start, $per_page";
		$true = @mysql_query($select, $c1);
	 }
	}
	else {
	 $select = "SELECT * FROM `$_ST[members]` WHERE `fNiq` = '$_KY[listing_id]' AND `mPending` = '0' AND `mCountry` = '$g'";
	 $select .= " ORDER BY `mName` ASC LIMIT $start, $per_page";
	 $true = @mysql_query($select, $connect);
	}
	if($true == false) {
	 displayError('Database Error', 'Unable to select the members from the specified country.', false);
	}
	 
	echo "<p class='tc'>Members from the country, <strong>" . ucwords($g) . "</strong>.</p>\n";
	echo format($_KY['listing_id'], 'members_header');
	 while($getItem = mysql_fetch_array($true)) {
	  $get_id_now = $b == 1 ? $getItem['email'] : $getItem['mID'];
		$get_id_top = $p == 'enth' ? 'email' : 'id';
		$get_id_opt = $b == 1 ? $get_id_top : 'id';
	  echo format($_KY['listing_id'], 'members', $get_id_now, $get_id_opt);
	 }
	 echo format($_KY['listing_id'], 'members_footer');
	} else {
	 echo membersDefault('country');
	}
	break; 
	
	case 'name':
	if($listing['dblist'] == 1) {
	 if($listing['dbtype'] == 'enth') {
	  $select = "SELECT * FROM `$listing[dbtabl]` WHERE `pending` = '0'";
	  $select .= " ORDER BY `name` ASC LIMIT $start, $per_page";
		$true = @mysql_query($select, $c1);
	 } elseif ($listing['dbtype'] == 'fanbase') {
	  $select = "SELECT * FROM `$listing[dbtabl]` WHERE `apr` = 'y'";
	  $select .= " ORDER BY `name` ASC LIMIT $start, $per_page";
		$true = @mysql_query($select, $c1);
	 }
	}
	else {
	 $select = "SELECT * FROM `$_ST[members]` WHERE `fNiq` = '$_KY[listing_id]' AND `mPending` = '0'";
	 $select .= " ORDER BY `mName` ASC LIMIT $start, $per_page";
	 $true = @mysql_query($select, $connect);
	}
  if($true == false) {
   displayError('Script Error', 'Unable to select the members from the specified listing.', false);
  }
	
	echo format($_KY['listing_id'], 'members_header');
	while($getItem = mysql_fetch_array($true)) {
	 $get_id_now = $b == 1 ? 'id' : 'mID';
	 echo format($_KY['listing_id'], 'members', $getItem[$get_id_now]);
	}
	echo format($_KY['listing_id'], 'members_footer');
	break;
 }
}

# -- Default Members ----------------------------------------
#  <show-members.php>
# -----------------------------------------------------------
function membersDefault($s) {
global $_ST, $_KY, $_URL, $connect, $mark;

 $listing = getListings($_KY['listing_id']);
 if(!empty($listing['dbhost']) && !empty($listing['dbuser']) 
 && !empty($listing['dbpass']) && !empty($listing['dbname'])) {
  $c1 = mysql_connect($listing['dbhost'], $listing['dbuser'], $listing['dbpass'])
	 or die("<p><span style=\"color: #FF0000;\">Error:</span> Unable to connect to the database host!</p>\n");
	$d1 = mysql_select_db($listing['dbname'])
	 or die("<p><span style=\"color: #FF0000;\">Error:</span> Unable to connect to the database!</p>\n");
 }

 switch($s) {
  case 'all':
	 echo membersSort('all');
	break; 
	
	case 'country':
	if($listing['dblist'] == 1) {
	 if($listing['dbtype'] == 'enth') {
	  $select = "SELECT DISTINCT `country` FROM `$listing[dbtabl]` WHERE `pending` = '0' ORDER BY `country` ASC";
		$true = mysql_query($select, $c1);
	 } elseif ($listing['dbtype'] == 'fanbase') {
	  $select = "SELECT DISTINCT `country` FROM `$listing[dbtabl]` WHERE `apr` = 'y' ORDER BY `country` ASC";
		$true = mysql_query($select, $c1);
	 }
	}
	else {
	 $select = "SELECT DISTINCT `mCountry` FROM `$_ST[members]` WHERE `fNiq` = '$_KY[listing_id]'"; 
	 $select .= " AND `mPending` = '0' ORDER BY `mCountry` ASC";
	 $true = mysql_query($select, $connect);
	}
	if($true == false) {
	 displayError('Database Error', 'Unable to select the members from the specified listing.', false);
	}
 
  echo "<ol>\n";
  while($getItem = mysql_fetch_object($true)) {
	 $type = $listing['dblist'] == 1 ? $getItem->country : $getItem->mCountry;
	 echo '<li><a href="' . $_URL . "sort=country&amp;name=" . 
	 str_replace(' ', '+', $type) . "\">$type</a></li>\n";
	}
  echo "</ol>\n";
	break; 
	
  case 'list':
	 echo "<ol>\n";
   echo '<li><a href="' . $_URL . 'sort=name' . '"' . ">by Name</a></li>\n";
   echo '<li><a href="' . $_URL . 'sort=country' . '"' . ">by Country</a></li>\n";
   echo "</ol>\n";
	break;
	
	case 'name':
	 echo membersSort('name');
	break;
 }
 
 if(!empty($listing['dbhost']) && !empty($listing['dbuser']) 
 && !empty($listing['dbpass']) && !empty($listing['dbname'])) {
  mysql_close($c1);
 }
}
?>
