<?php
# 'INDEX' FILE 
/* 
-------------------------------------------------------------
Tess Ally 2007 � Listing Admin 
------------------------------------------------------------- 
*/
require("../rats.inc.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
 "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title> <?php echo $_ST['version']; ?> &#8212; Convert </title>
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="install">
<h2>Convert</h2>
<p>Whoa! You've hit <samp>/covert/</samp>, the file archive for converting over various fanlisting 
lists that range from members of Enthusiast, to updates from FanUpdate! Below are your
conversion options, awaiting to be used!</p>
<p class="noteButton">Other convert files will be created at my own discretion &#8212; if you'd like
a convert file made, feel more than free to e-mail me at <strong>theirrenegadexxx@gmail.com</strong>! :D</p>
<p class="noteButton">If you are running any image-based conversions, be aware you <ins>must</ins> upload the
images from the old destination to the new one <em>if</em> there is a new destination. If not, the images should
show up, as they will not be renamed.</p>
<ol>
 <li><a href="convert-from-codesort.php">CodeSort: Convert Codes (by Listing)</a></li>
 <li><a href="convert-from-enth_affiliates.php">Enthusiast: Convert Affiliates</a></li>
 <li><a href="convert-from-enth_joined.php">Enthusiast: Convert Joined</a></li>
 <li><a href="convert-from-enth_members.php">Enthusiast: Convert Members</a></li>
 <li><a href="import-from-enth_categories.php">Enthusiast: Import Categories</a></li>
 <li><a href="convert-from-fanupdate.php">FanUpdate: Convert Updates (by Whole Collective and Listing)</a></li>
 <li><a href="listingadmin_members.php">Listing Admin: Importing and Exporting Members</a></li>
 <li><a href="convert-from-phpfanbase.php">PHPFanBase: Convert Members</a></li>
</ol>
</div>

</body>
</html>
