<?php 
/* 
 /////////////////////////////////////////////////////////////
 Listing Admin (c) 2007 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 *  @copyright   2007 
 *  @license     GPL Version 3; BSD Modified 
 *  @author      Tess <theirrenegadexxx@gmail.com> 
 *  @file        <listingadmin_members.php> 
 *  @since       September 12th, 2011  
 *  @version     2.3alpha  
 */ 
require("../rats.inc.php");
require("../fun.inc.php");
require("../fun-listings.inc.php");
require("../fun-members.inc.php");
require("../fun-misc.inc.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
 "http://www.w3.org/TR/html4/strict.dtd">

<html lang="en">

<head>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 <title> <?php echo $_ST['version']; ?> &#8212; Convert from Enthusiast: Members </title>
 <link href="../style.css" rel="stylesheet" type="text/css">
</head>

<body>

<div id="install">
<h2>Listing Admin: Importing and Exporting</h2>
<?php 
function formatExport($s, $b = 'bb', $c = 'encode') {
 $p = trim($s);
 if($c == 'encode') {
  $p = str_replace('@', 'ATTIE', $p);
  if($b == 'bb') {
   $p = str_replace('.', 'DOTTY', $p);
   $p = str_replace('_', 'SCORY', $p);
   $p = str_replace('-', 'DASHY', $p);
  } elseif ($b == 'la') {
   $p = str_replace('.', 'DOTTIE', $p);
   $p = str_replace('_', 'SCORIE', $p);
   $p = str_replace('-', 'DASHIE', $p);
  }
 } elseif ($c == 'decode') {
  $p = str_replace('ATTIE', '@', $p);
  if($b == 'bb') {
   $p = str_replace('DOTTY', '.', $p);
   $p = str_replace('SCORY', '_', $p);
   $p = str_replace('DASHY', '-', $p);
  } elseif ($b == 'la') {
   $p = str_replace('DOTTIE', '.', $p);
   $p = str_replace('SCORIE', '_', $p);
   $p = str_replace('DASHIE', '-', $p);
  }
 }
 return $p;
}

$get_script_array = array(
 'bellabuffs' => 'BellaBuffs',
 'enthusiast' => 'Enthusiast',
 'listingadmin' => 'Listing Admin',
 'phpfanbase' => 'phpFanBase'
);

if(isset($_POST['action']) && $_POST['action'] == 'Convert Members') {
 $type = cleanMys($_POST['type']);
 if(empty($type) || !in_array($type, array('import', 'export'))) {
  displayError('Form Error', 'Eeek, something went wrong there!' . 
  ' In order to import/export something, the correct form for each must be' . 
  ' used, m\'dear!', false);
 }

 if($type == 'import') {
  $script = cleanMys($_POST['script']);
  if(empty($script) || !in_array($script, array_keys($get_script_array))) {
   displayError('Form Error', 'The given script to export to' . 
   ' appears to be invalid! :x', false);
  }
  if(
   isset($_FILES['importfile']) && 
   !empty($_FILES['importfile']['name']) && 
   !empty($_FILES['importfile']['tmp_name'])
  ) {
   $file = $_FILES['importfile'];  
   if(!preg_match("/.txt$/", $file['name']) || filetype($file['tmp_name']) != 'file') {
    displayError('Form Error', 'Only a <samp>.txt</samp> file is allowed to be' . 
    ' imported; if you\'re importing a .sql file, import it to your database' . 
    ' instead, and fill out the database settings in the form. :D', false);
   }
  }
  $fanlistingid = cleanMys($_POST['fanlistingid']);
  if(empty($fanlistingid) || !in_array($fanlistingid, listingsList())) {
   displayError('Form Error', 'In order to export affiliates' . 
   '/members, you need to supply a fanlisting ID, love. :D', false);
  }
  $usedb = 0;
  if(
   ($script != 'bellabuffs' && $script != 'listingadmin') && 
   (isset($_POST['tablename']))
  ) {
   $usedb = 1;
   if(
    isset($_POST['dbhost']) && isset($_POST['dbuser']) && isset($_POST['dbname'])
   ) {
    $dbhost = cleanMys($_POST['dbhost']);
    $dbuser = cleanMys($_POST['dbuser']);
    $dbpass = cleanMys($_POST['dbpass']);
    $dbname = cleanMys($_POST['dbname']);
   }
  }
  $tablename = cleanMys($_POST['tablename']);
  if(
   ($script != 'bellabuffs' && $script != 'listingadmin') && 
   (!isset($_POST['tablename']) || empty($tablename))
  ) {
   displayError('Form Error', 'If you\'re importing a members list that is not' . 
   ' Listing Admin or BellaBuffs, you must provide the members table.', false);
  }
  if(isset($_POST['toggle']) && $_POST['toggle'] == 'y') {
   $favefield = 1;
   if(isset($_POST['fave']) && count($_POST['fave']) > 0) {
    $faves = array();
    $faves =  $_POST['fave'];
    $faves = array_map('cleanMys', $faves);
   }
  } else {
   $favefield = 0;
  }

  /* 
   *  Check if we're using different database variables, and proceed from 
   *  there (if not, pull members from the same database; if so close our 
   *  current connection, and open a new one with the new database settings) 
   */ 
  if($usedb == 1) {
   if(
    $database_host == $dbhost && $database_user == $dbuser && 
    $database_name == $dbname
   ) { 
    $query = "SELECT * FROM `$tablename`";
    $result = mysql_query($query);
    if($result == false) {
     displayError('Database Error', 'There was an error trying to pull from the' . 
     ' table you specified in the form.', true, $query);
    }
    $array = array();
    while($item = mysql_fetch_object($result)) {
     /* 
      *  Grab favourite field(s)! :D 
      */ 
     if($favefield == 1) {
      if($script == 'enthusiast') {
       $h = array();
       foreach($faves as $f) {
	      if(!empty($f)) {
	       if(empty($item->$f)) {
		      $h[] = 'NONE';
		     } else {
          $h[] = $item->$f;
		     }
		    }
	     }
	     $ff = implode("|", $h);
	     $ff = '|' . trim($p, '|') . '|';
      } else {
       $ff = '';
      }
     } else {
      $ff = '';
     }

     $ps = $script == 'phpfanbase' ? '' : $item->password;
     $ap = $script == 'phpfanbase' ? ($item->apr == 'y' ? 0 : 1) : $item->pending;
     $se = $script == 'phpfanbase' ? ($item->hideemail == 'y' ? 1 : 0) : 
     ($item->showemail == 0 ? 1 : 0);
     $da = $script == 'enthusiast' ? $item->added : date("Y-m-d");
     $array[$item->email] = (object) array(
      'name' => $item->name,
      'email' => $item->email,
      'url' => $item->url, 
      'country' => str_replace('USA', 'United States', $item->country),
      'password' => $ps,
      'fave' => $ff,
      'show' => $se,
      'pending' => $ap,
      'update' => 'n',
      'added' => $da
     );
    }
   } 

   else {
    mysql_close($connect);
    $c1 = mysql_connect($dbhost, $dbuser, $dbpass) 
     or die("Error: The script was unable to connect to the database host you" . 
     " specified.");
    $d1 = mysql_select_db($dbname) 
     or die("Error: The script was unable to connect to the database you" . 
     " specified.");

    $query = "SELECT * FROM `$tablename`";
    $result = mysql_query($query, $c1);
    if($result == false) {
     exit("<h3>Database Error</h3>\n<p class=\"mysqlButton\"><span class=\"" . 
     'mysql\">Error:</span> There was an error trying to pull from the table' . 
     " you specified in the form.</p>\n<h3>MySQL Error(s)</h3>\n<p><em>$query" . 
     "</em><br>\n" . mysql_error() . "</p>\n");
    }
    $array = array();
    while($item = mysql_fetch_object($result)) {
     /* 
      *  Grab favourite field(s)! :D 
      */ 
     if($favefield == 1) {
      if($script == 'enthusiast') {
       $h = array();
       foreach($faves as $f) {
	      if(!empty($f)) {
	       if(empty($item->$f)) {
		      $h[] = 'NONE';
		     } else {
          $h[] = $item->$f;
		     }
		    }
	     }
	     $ff = implode("|", $h);
	     $ff = '|' . trim($p, '|') . '|';
      } else {
       $ff = '';
      }
     } else {
      $ff = '';
     }

     $ps = $script == 'phpfanbase' ? '' : $item->password;
     $ap = $script == 'phpfanbase' ? ($item->apr == 'y' ? 0 : 1) : $item->pending;
     $se = $script == 'phpfanbase' ? ($item->hideemail == 'y' ? 1 : 0) : 
     ($item->showemail == 0 ? 1 : 0);
     $da = $script == 'enthusiast' ? $item->added : date("Y-m-d");
     $array[$item->email] = (object) array(
      'name' => $item->name,
      'email' => $item->email,
      'url' => $item->url, 
      'country' => str_replace('USA', 'United States', $item->country),
      'password' => $ps,
      'fave' => '',
      'show' => $se,
      'pending' => $ap,
      'update' => 'n',
      'added' => $da
     );
    }
    mysql_close($c1);
    breach(1);
   }
  }

  /* 
   *  Grab the members from the text file instead! \o/ 
   */ 
  elseif ($usedb == 0) {
   if(isset($_FILES['importfile']) && !empty($file['tmp_name'])) {
    $members = file($file['tmp_name']);
    if($members == 0 || $members == false) {
     displayError('File Error', 'The file you supplied appears to be empty!', 
     false);
    }

    $array = array();
    foreach($members as $m) {
     if($script == 'bellabuffs') {
      list($name, $email, $show, $url, $country, $fave) = explode(',', $m);
      $se = $show == "yes" ? 0 : 1;
      $array[$email] = (object) array(
       'name' => $name,
       'email' => formatExport($email, 'bb', 'decode'),
       'url' => $url, 
       'country' => $country,
       'password' => '',
       'fave' => formatExport($fave, 'bb', 'decode'),
       'show' => $se,
       'pending' => 0,
       'update' => 'n',
       'added' => date("Y-m-d")
      );
     } elseif ($script == 'listingadmin') {
      list($email, $listing, $name, $url, $country, $password, $fave, $visible, 
      $pending, $update, $added) = explode('__', $m);
      $array[$email] = (object) array(
       'name' => $name,
       'email' => formatExport($email, 'la', 'decode'),
       'url' => formatExport($url, 'la', 'decode'), 
       'country' => $country,
       'password' => $password,
       'fave' => $fave,
       'show' => $visible,
       'pending' => 0,
       'update' => $update,
       'added' => $added
      );
     }
    }
   }
  }

  /* 
   *  Now that we have our array, let's add our members! :D :D :D  
   */ 
  foreach($array as $member => $obj) {
   $insert = "INSERT INTO `$_ST[members]` (`mEmail`, `fNiq`, `mName`, `mURL`," . 
   " `mCountry`, `mPassword`, `mExtra`, `mVisible`, `mPending`, `mUpdate`," . 
   " `mAdd`) VALUES ('" . $obj->email . "', '" . $fanlistingid . "', '" . $obj->name . 
   "', '" . $obj->url . "', '" . $obj->country . "', '" . $obj->password . 
   "', '" . $obj->fave . "', '" . $obj->show . "', '" . $obj->pending . 
   "', '" . $obj->update . "', '" . $obj->added . "')";
   mysql_query("SET NAMES 'utf8';");
   $true = mysql_query($insert);
   if($true == false) {
    displayError('Database Error', 'There was an error inserting the member into' . 
    ' the listing.', true, $insert);
   } else {
    echo "<p class=\"successButton\"><span class=\"success\">Success!</span> The" . 
    " <strong>" . $obj->name . "</strong> (<samp>" . $obj->email . "</samp>) was added to" . 
    " the listing! :D</p>\n";
   }
  }
 } 

 /* 
  *  Not a whole lot of code going on here -- well; when you compare it to 
  *  the above -- as we're only pulling and prompting~ :D 
  */ 
 elseif ($type == 'export') {
  $script = cleanMys($_POST['script']);
  if(empty($script) || !in_array($script, array_keys($get_script_array))) {
   displayError('Form Error', 'The given script to export to' . 
   ' appears to be invalid! :x', false);
  }
  $fanlistingid = cleanMys($_POST['fanlistingid']);
  if(empty($fanlistingid) || !in_array($fanlistingid, listingsList())) {
   displayError('Form Error', 'In order to export affiliates' . 
   '/members, you need to supply a fanlisting ID, love. :D', false);
  }
   
  $array = getMembersList($fanlistingid, 1, 'asc');
  $listing = getListings($fanlistingid, 'object');
  $str = '';
  foreach($array as $a) {
   $member = getMembers($a, 'id', $fanlistingid, 'object');
   if($script == 'bellabuffs') {
    $favefields = emptyarray(explode("|", $listing->fave_fields));
    $ff = count($favefields) == 1 ? str_replace(',', '|', trim(str_replace("|", '', $member->mFave))) : '';
    $se = $member->mPending == 0 ? "yes" : "no";
    $str .= $member->mName . "," . formatExport($member->mEmail) . 
    "," . $se . "," . $member->mURL . "," . $ff . "\n";
   } elseif ($script == 'enthusiast') {
    $se = $member->mVisible == 1 ? 0 : 1;
    $str .= "('" . $member->mEmail . "', '" . $member->mName . "', '" . $member->mCountry . 
    "', '" . $member->mURL . "',";
    if($listing->fave_fields != '') {
     $ff = emptyarray(explode('|', $listing->fave_fields));
     $mm = emptyarray(explode('|', $member->mExtra));
     if(!empty($mm) && count($mm) > 0) {
      foreach($mm as $k) {
       $str .= " '" . str_replace('NONE', '', $k) . "',";
      }
     } else {
      foreach($ff as $f) {
       $str .= " '',";
      }
     }
    }
    $str .= " '" . $member->mPending . "', '" . $member->mPassword . 
    "', " . $se . ", 1, '" . $member->mAdd . '\')' .  ",\n";
   } elseif ($script == 'listingadmin') {
    $str .= formatExport($member->mEmail, 'la') . "__0__" . $member->mName . 
    "__" . formatExport($member->mURL, 'la') . "__" . $member->mCountry . 
    "__" . $member->mPassword . "__" . $member->mExtra . "__" . $member->mVisible . 
    "__" . $member->mPending . "__" . $member->mUpdate . "__" . $member->mAdd . "\n";
   }
  }

  /* 
   *  Format string before we do anything :D 
   */ 
  $finalstr = '';
  if($script == 'bellabuffs') {
   $finalstr .= trim($str, "\n");
  } elseif ($script == 'enthusiast') {
   $finalstr .= "CREATE TABLE IF NOT EXISTS `table` (
 `email` varchar(64) NOT NULL default '',
 `name` varchar(128) NOT NULL default '',
 `country` varchar(128) NOT NULL default '',
 `url` varchar(255) default NULL,";
   if(!empty($listing->fave_fields)) {
    $ff = emptyarray(explode('|', $listing->fave_fields));
    foreach($ff as $f) {
     $d = strtolower(str_replace(array('(', ')'), '', $f));
     $finalstr .= "
 `$d` varchar(255) NOT NULL,";
    }
   }
   $finalstr .= "
 `pending` tinyint(1) NOT NULL default '0',
 `password` varchar(255) NOT NULL default '',
 `showemail` tinyint(1) NOT NULL default '1',
 `showurl` tinyint(1) NOT NULL default '1',
 `added` date default NULL,
 PRIMARY KEY (`email`),
 FULLTEXT KEY `email` (`email`, `name`, `country`, `url`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

";
   $finalstr .= "INSERT INTO `table` (`email`, `name`, `country`, `url`,";
   if(!empty($listing->fave_fields)) {
    $ff = emptyarray(explode('|', $listing->fave_fields));
    foreach($ff as $f) {
     $d = strtolower(str_replace(array('(', ')'), '', $f));
     $finalstr .= " `$d`,";
    }
   }
   $finalstr .= " `pending`, `password`, `showemail`, `showurl`, `added`) VALUES\n";
   $finalstr .= rtrim($str, ",\n") . ";\n";
  } elseif ($script == 'listingadmin') {
   $finalstr .= trim($str, "\n") . "\n";
  }

  /* 
   *  Prompt the user to save the file; depending on the script, it'll be 
   *  a .sql or .txt file~ 
   */ 
  if(isset($_POST['savefile']) && $_POST['savefile'] == 'y') {
   /** 
    *  ob_end_clean() cleans the output buffering (aka, any PHP and HTML 
    *  current on the page), and flushes it; this allows us to save the  
    *  file with just the data :D 
    */ 
   ob_end_clean();

   $headername = $script == 'enthusiast' ? 'table.sql' : 'members.txt';
   $headertype = $script == 'enthusiast' ? 'text/x-sql' : 'text/plain';
   header('Content-Description: File Transfer');
   header('Content-Disposition: attachment; filename=' . $headername);
   header('Content-Transfer-Encoding: binary');
   header('Content-Type: ' . $headertype);

   echo $finalstr;
   exit();
  }
    
  else {
   $sw = $script == 'enthusiast' || $script == 'phpfanbase' ? '.sql' : '.txt';
   echo "<p class=\"noteButton\">Copy and paste the text below into a blank" . 
   " file, and save it with a <samp>$sw</samp> extension.</p>\n";
   echo "<code>$finalstr</code>\n";
  }
 }

 echo "<p class=\"noteButton\">If there are no errors above, you have" . 
 " successfully completed importing/exporting the members. :D</p>\n";
 echo "<p class=\"backLink\">&#187; <a href=\"listingadmin_members.php\">Back" . 
 " to the Conversion File</a></p>\n";
 echo "<p class=\"backLink\">&#187; <a href=\"" . getOption('adm_http') . 
 'convert/' . "\">Back to Convert Index</a></p>\n";
 echo "<p class=\"backLink\">&#187; <a href=\"" . getOption('adm_http') . 
 "\">Back to Control Panel</a></p>\n";
}

# -- Get Index ----------------------------------------------
else {
?>
<p>Welcome to <samp>/convert/listingadmin_members.php</samp>, where you can 
import and export your fanlistings to other member lists formats &#8211; or 
import other Listing Admin members lists! :D</p>
<p class="noteButton"><span class="note">For those importing Listing Admin
members list(s):</span> Please be aware the previous owner before you (or you 
yourself) must have used this file also, as Listing Admin uses a specific 
format, and importing will not work otherwise.</p>

<form action="listingadmin_members.php" enctype="multipart/form-data" method="post">
<p class="noMargin">
 <input name="type" type="hidden" value="import">
</p>

<fieldset>
 <legend>Import</legend>
 <p><label><strong>Script:</strong><br>
 This is the script we're importing; basically, if we're adding members from a 
 table from Enthusiast, we're importing an Enthusiast table; if we're importing 
 a members list from BellaBuffs, we're importing a BellaBuffs members list, and 
 so on.</label> <select name="script" class="input1">
<?php  
 $scriptarray = $get_script_array;
 foreach($scriptarray as $sk => $sv) {
  echo " <option";
  if($sk == 'enthusiast') {
   echo " selected=\"selected\"";
  }
  echo " value=\"$sk\">$sv</option>\n";
 }
?>
 </select></p>
 <p style="clear: both; margin: 0 0 20px 0;"></p>
 <p><label><strong>File:</strong><br>
 This should only be a .txt file containing members, <ins>not</ins> a .sql file.
 If you have a .sql file, import it to your database, and use the database settings
 below the fanlisting ID.</label> 
 <input name="importfile" class="input1" type="file"></p>
 <p style="clear: both; margin: 0 0 20px 0;"></p>
 <p><label><strong>Listing ID</strong><br>
 This will be the listing ID you're importing your members to.</label> 
 <input name="fanlistingid" class="input1" type="text"></p>
 <p style="clear: both; margin: 0 0 20px 0;"></p>
 <p class="noteButton">The following database settings only need to be filled
 out if you're importing members from a script other than Listing Admin and 
 BellaBuffs. While the table name is required, the database settings are not, 
 and if left blank, the script will assume the script's database tables are 
 in the same database as your Listing Admin tables.</p>
 <p><label><strong>Database Host:</strong></label> 
 <input name="dbhost" class="input1" type="text"></p>
 <p><label><strong>Database Username:</strong></label> 
 <input name="dbuser" class="input1" type="text"></p>
 <p><label><strong>Database Password:</strong></label> 
 <input name="dbpass" class="input1" type="text"></p>
 <p><label><strong>Database Name:</strong></label> 
 <input name="dbname" class="input1" type="text"></p>
 <p><label><strong>Table Name:</strong></label> 
 <input name="tablename" class="input1" type="text"></p>
 <p id="add"><label><strong>Add additional (favourite) fields?</strong><br>
 Only tick the checkbox if your table or .txt file has favourite fields.</label> 
 <input name="toggle" class="input3" id="toggle" 
 onclick="toggleField('toggleField'); return false" type="checkbox" value="y"> Yes</p>
 <p style="clear: both; margin: 0 0 20px 0;"></p>
 <div id="toggleField" style="display: none;">
 <p class="noteButton">If you're importing from Enthusiast, type in the name
 of the fields in your table (e.g., <samp>favchar</samp>, 
 <samp>favoriteseason</samp>); if you're importing from BellaBuffs, leave the 
 fields blank, but the checkbox checked; and if you're 
 importing from Listing Admin, don't fill in the fields, as the favourite field(s) 
 is automatically added if the checkbox is checked.</p>
<?php 
 for($i = 1; $i < 6; $i++) {
  echo " <p><label><strong>Favourite Field " . $i . ":</strong></label>" . 
  " <input name=\"fave[]\" class=\"input1\" type=\"text\"></p>\n";
 }
?>
 </div>
 <p class="tc"><input name="action" class="input2" type="submit" value="Convert Members"></p>
</fieldset>
</form>

<form action="listingadmin_members.php" method="post">
<p class="noMargin">
 <input name="type" type="hidden" value="export">
</p>

<fieldset>
 <legend>Export</legend>
 <p><label><strong>Script:</strong></label> <select name="script" class="input1">
<?php  
 $scriptarray = $get_script_array;
 foreach($scriptarray as $sk => $sv) {
  echo " <option";
  if($sk == 'enthusiast') {
   echo " selected=\"selected\"";
  }
  echo " value=\"$sk\">$sv</option>\n";
 }
?>
 </select></p>
 <p><label><strong>Listing ID</strong><br>
 This will be the listing ID we're exporting (i.e. the listing we're pulling
 members from).</label> 
 <input name="fanlistingid" class="input1" type="text"></p>
 <p style="clear: both; margin: 0 0 20px 0;"></p>
 <p><label><strong>Save file to harddrive?</strong><br>
 If you check the box, the script will prompt you to save a .txt or .sql file 
 to your computer; if you uncheck the box, the script will display a textbox 
 for you to copy and paste the text there to a .txt or .sql file.
 </label> <input name="savefile" checked="checked" class="input3" type="checkbox" value="y"> Yes</p>
 <p style="clear: both; margin: 0 0 5px 0;"></p>
 <p class="tc"><input name="action" class="input2" type="submit" value="Convert Members"></p>
</fieldset>
</form>
<?php
}
?>
</div>

<script type="text/javascript">
<!-- 
function toggleField(div) {
 var block = document.getElementById(div);
 if(block.style.display == 'none') {
  block.style.display = 'block';
 } else {
  block.style.display = 'none';
 }
}
//--> 
</script>

</body>
</html>
