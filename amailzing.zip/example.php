<!-- EXAMPLE.PHP -->
<!-- aMAILzing 1.0 -->
<!-- If you want to, use this form as a reference when creating your own email form :) -->

<html>
<head>
<title>aMAILzing 1.0</title>
</head>

<body>


<!-- Print the thank you message, if there is one! -->
<?php echo stripslashes($_GET[message])?> <br />



<form method="post" action="amailzing.php" enctype="multipart/form-data">

<input type="text" name="nameREQUIRED" /> Name (required) <br /><br />

<input type="text" name="emailREQUIRED" /> Email (required) <br /><br />

<input type="text" name="website" /> Website <br /><br />

<textarea name="message" cols="30" rows="7"> </textarea> <br /><br />

<input type="file" name="attachment" /> Attachment <br /><br />

<input type="submit" value="Send the email!" /><br /><br />

Powered by <a href="http://scripts.inexistent.org">aMAILzing</a>.
</form>

</body>
</html>