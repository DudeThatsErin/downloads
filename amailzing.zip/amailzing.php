<?php
// aMAILzing version 1.1 - http://scripts.inexistent.org
// Copyright �2005, 2007, Christine R., cineee@gmail.com
// Last updated December 2nd, 2007.
// Please don't redistribute without written permission. :)

// To change the settings, simply change "email@email.com" to the email address
// you wish for the emails to be sent to, and "Thanks for your email, 
// I'll get back on you later!" to the confirmation message you want to be shown
// when everything is working just fine and the message was sent! :)
// Please avoid use of quoation signs. (")

$myemail = "cineee@gmail.com";

$thankyou = "Thank you for your email! I'll get back to you as soon as possible. :)";


// If you're using file uploads, you may want to specify allowed file extensions.
// To allow all extensions, simply remove the line below. (or put "//" in front of it)

$allowed_fileuploads = "png gif jpg zip rar html";


// If you find yourself receiving a lot of spam, something as easy as asking an addition question
// may decrease the amount noticeably, if not get rid of the spam entirely. To utilize this
// simple way of doing it, add an extra input to your form, in which you promt the visitor to
// enter the sum of 5 and 6. Give the input the name of "math". Then uncomment (remove //'s)
// the following three lines.

// if($_POST['math'] != '11' && $_POST['math'] != 'eleven'){
// 	die("Come on, that's kindergarten-level math. ;) Try again! What's the answer to 5+6?");
// }












// Don't edit anything below this line, unless you know what you are doing! :)




// Make sure nobody gets stuck in infinite loops.

if(!$_POST)
	die('Please don\'t access this file directly.');









// Gather all the required fields. Remove the REQUIRED part from their names. 
// The bug which made the required fields appear last in the email has been fixed.

while(list($key,$val) = each($_POST)) {
	if(stristr($key,'REQUIRED')){
		$key = str_replace('REQUIRED','',$key);
		$fields[$key] = $val;
		if($val == ''){
			$missing[] = '<b>'.$key.'</b>';
		}
	} else {
		$fields[$key] = $val;
	}
}





// If there is a myemail value in the form, send the email to it instead!

if(isset($fields['myemail']))
	$myemail = $fields['myemail'];






// Set default values if there exists none.

if(isset($fields['name'])){ $name = $fields['name']; } else { $name = "aMAILzing"; }
if(isset($fields['email'])){ $email = $fields['email']; } else { $email = $myemail; }
if(isset($fields['subject'])){ $subject = $fields['subject']; } else { $subject = "Web Form"; }





// Validate inputs for email injections.

reset($_POST);

$injection = false;

foreach($_POST as $key => $value){
	if(preg_match("/(content-type|bcc:|cc:|script|onclick|onmouseover)/i", $value)){
		$injection = true;
	}
}









// Write the start of the email body.

$message =  "The following form was sent to you from your website!\n";
$message .= "-----------------------------------------------------------\n";
$message .= "Ip: ".$_SERVER['REMOTE_ADDR']."\n";
$message .= "Host: ".@gethostbyaddr($_SERVER['REMOTE_ADDR'])."\n";
$message .= "Browser: ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "Referrer: ".$_SERVER['HTTP_REFERER']."\n\n";





// Find all the fields, and add them to the email.

foreach($fields as $k=>$v) {
	if($v && !stristr($k,'REQUIRED'))
		if(is_array($v))
			$message .= ucfirst($k).": ".implode(', ', $v)."\n\n";
		else
			$message .= ucfirst($k).": $v\n\n";
}





// Write the rest of the email body.

$message .= "-----------------------------------------------------------\n";
$message .= "Powered by aMAILzing - http://scripts.inexistent.org";
$message = stripslashes($message);







// Write the headers.

$mail_boundary = "x".md5(time())."x";
$header = "From: $name <$email>\n";
$header .= "MIME-Version: 1.0\n";
$header .= "Content-type: multipart/mixed; boundary=\"{$mail_boundary}\"\n";
$header .= "X-Priority: 3\n";
$header .= "X-MSMail-Priority: Normal\n";
$header .= "X-Mailer: aMAILzing 1.1 http://scripts.inexistent.org\n";
$header .= "This is a multi-part message in MIME format.\n\n";
$header .= "--{$mail_boundary}\n";
$header .= "Content-type: text/plain; charset=\"iso-8859-1\"\n";
$header .= "Date: ".date('R')."\n";
$header .= "Content-Transfer-Encoding:7bit\n\n";
$header .= $message."\n\n";






// Attach the uploaded files, if there is any.

if($_FILES){

	if (get_magic_quotes_runtime() == 1){
		set_magic_quotes_runtime(0);
	}

	foreach($_FILES as $key=>$value){

		foreach($value as $key2 => $value2){
			$$key2 = $value2;
		}

		if (is_uploaded_file($tmp_name)) {    
			if(isset($allowed_fileuploads)){
				$fileextensions = explode(' ', $allowed_fileuploads);
				$thisfile = explode('.', $name);
				$thisfile = array_pop($thisfile);

				if(!in_array($thisfile, $fileextensions)){
					die("The type of file is not allowed as attachments. Please go back and upload another file.");
				}
			}


			$fp = fopen($tmp_name,'rb');
			$read = fread($fp,$size);
			fclose($fp);

			$file = base64_encode($read);
			$file = chunk_split($file);

			$header .= "--$mail_boundary\n";
			$header .= "Content-type: $type; name=\"$name\"\n";
			$header .= "Content-Transfer-Encoding:base64\n";
			$header .= "Content-Disposition: attachment; filename=\"$name\"\n\n";
			$header .= $file."\n\n";
		}
	}
}







// Now, lets deal with what we've got so far!

$valid_email = eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$", $email);

if(!isset($missing) && $valid_email && $injection != true) {
	mail($myemail,$subject,'',$header);

} elseif(!$valid_email){
	$thankyou = "Your email address doesnt seem to be valid - please doublecheck it.";

} elseif($injection == true){
	die("Email injection attempt detected and blocked.");

} else {
	if(count($missing)>1){
		$last = array_pop($missing);
		$themissing = implode(', ',$missing).' and '.$last;
		$plu = 's';
	} else {
		$themissing = $missing[0];
	}
	$thankyou = "Sorry, but you do not seem to have filled out the field$plu ".$themissing.". Please go back and fill out all the required fields!";
}






// And, in the very end, we've got to catch the referrers and redirect back to where we came from.

$ref = getenv("HTTP_REFERER");
if (stristr($ref,'?'))
	$sep = "&";
else
	$sep = "?";

$thankyou .= ' <small>Powered by <a href="http://scripts.inexistent.org">aMAILzing</a>.</small>';
$thankyou = urlencode($thankyou);



header("Location: $ref${sep}message=$thankyou");

// If you want a separate thankyou page, change the above to
// header("Location: filename.html");
// or
// header("Location: filename.html?message=$thankyou");


// And then, we're done!

?>