<?php
require("header.php");
?>
<h1>Members</h1>
<?php 
require("fig.inc.php");
require(KAPATH . "show-members.php");
?>
<?php
require("footer.php");
?>