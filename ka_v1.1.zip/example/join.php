<?php
require("header.php");
?>
<h1>Join</h1>
<?php 
require("fig.inc.php");
require(KAPATH . "show-join.php");
?>
<?php
require("footer.php");
?>
