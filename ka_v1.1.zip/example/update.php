<?php
require("header.php");
?>
<h1>Update</h1>
<?php 
require("fig.inc.php");
require(KAPATH . "show-update.php");
?>
<?php
require("footer.php");
?>
