<?php
# 'FIG.INC' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin 
------------------------------------------------------------- */

# -- Database Variables -------------------------------------
#  $database_host - MySQL Host (usually localhost)
#  $database_user - MySQL username 
#  $database_pass - MySQL password 
#  $database_name - MySQL database name (if you're pulling 
#  your listings from Enthusiast or a personal script, be 
#  sure this database is the same database your Enthusiast
#  tables are held in!) 
# -----------------------------------------------------------
$database_host = "localhost";
$database_user = "";
$database_pass = "";
$database_name = "";

# -- Table Variables ----------------------------------------
#  $_KA['optionsTable'] - Options table 
# -----------------------------------------------------------
$_KA['optionsTable'] = "ka_options";

# -- STOP EDITING HERE! -------------------------------------
# -----------------------------------------------------------
# 
#  Below this line are sensitive lines that should NOT be 
#  messed with unless you know exactly what you're doing.
# 
# -----------------------------------------------------------
# -----------------------------------------------------------

# -- Get MySQL ----------------------------------------------
# -----------------------------------------------------------
$connect = mysql_connect($database_host, $database_user, $database_pass)
 or die('<p><span class="error">Error:</span> You cannot currently connect to MySQL.' . 
 ' Make sure all variables are correct in <samp>rats.inc.php</samp>; if it is a random' . 
 ' error, wait it out and see if it\'ll magically disappear.</p>');
$database = mysql_select_db($database_name)
 or die('<p><span class="error">Error:</span> You cannot currently connect to your database.' . 
 ' Make sure all variables are correct in <samp>rats.inc.php</samp>; if it is a random' . 
 ' error, wait it out and see if it\'ll magically disappear.</p>');
 
# -- Run Query ----------------------------------------------
# -----------------------------------------------------------
$select = "SELECT `text` FROM `$_KA[optionsTable]` WHERE `name` = 'adm_path' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 exit('ERROR: Unable to select the specified options. Make sure your option table exists.');
}
$getItem = mysql_fetch_array($true);
define('KAPATH', $getItem['text']); 
?>
