</div>

<div id="footer">
<p><strong>KIM Script</strong></p>
</div>

</div>

</body>
</html>
