<?php
function isPages() {
 return basename($_SERVER['PHP_SELF']);
}

function isTitle() {
 $b = basename($_SERVER['PHP_SELF']);
 return ucwords(str_replace('.php', '', $b));
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
 "http://www.w3.org/TR/html4/strict.dtd">

<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title> KIM Script &#8212; <?php echo isTitle(); ?> </title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="container">

<div id="header">
<h1>(Dummy) KIM Script</h1>
<h1 id="sub">A KIM List Management Script</h1>
</div>

<div id="navigation">
<ul>
<?php if(isPages() == 'index.php') { ?>
<li class="c"><a href="index.php">Home</a></li>
<?php } else { ?>
<li><a href="index.php">Home</a></li>
<?php } if(isPages() == 'join.php') { ?>
<li class="c"><a href="join.php">Join</a></li>
<?php } else { ?>
<li><a href="join.php">Join</a></li>
<?php } if(isPages() == 'update.php') { ?>
<li class="c"><a href="update.php">Update</a></li>
<?php } else { ?>
<li><a href="update.php">Update</a></li>
<?php } if(isPages() == 'list.php') { ?>
<li class="c"><a href="list.php">Members</a></li>
<?php } else { ?>
<li><a href="list.php">Members</a></li>
<?php } if(isPages() == 'lost.php') { ?>
<li class="c"><a href="lost.php">Reset Password</a></li>
<?php } else { ?>
<li><a href="lost.php">Reset Password</a></li>
<?php } ?>
<li id="lg"><a href="/admin/">&raquo; Admin Panel</a></li>
</ul>
</div>

<div id="content">
