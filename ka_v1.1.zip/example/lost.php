<?php
require("header.php");
?>
<h1>Lost Password</h1>
<?php 
require("fig.inc.php");
require(KAPATH . "show-reset.php");
?>
<?php
require("footer.php");
?>
