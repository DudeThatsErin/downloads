<?php
require("header.php");
?>
<h1>Welcome</h1>
<p>Welcome to the <strong>dummy</strong> version of the installed KIM script on your server. These files are meant for a temporary measure, though you can use any of the coding provided.</p>
<?php
require("fig.inc.php");
require(KAPATH . "show-stats.php");
?>
<?php
require("footer.php");
?>