// README.TXT FILE 
// KIM Admin 1.1
// ----------------------------------------------------------

// LEGALITY CRAP
----------------
By using this script, you agree I, Tess Ally, am NOT responsible
for any errors that may occur on YOUR site. I created KIM Admin 
as a way for people to easily manage a KIM script (and a secure 
one at that!) and not to deliberately cause you headaches. You 
also agree that by using this, you will not distribute it under 
your name, and/or without my written consent.

The credit link can be removed. I'm neither a stickler for crediting, 
nor will I murder you in your sleep if you fail to. That is, of 
course, not to say I would be unappreciative!

// NOTES/REQUIREMENTS
---------------------
I've used the following resources creating this script. Any other
versions from these versions I cannot account for. I will neither 
be creating scripts, nor testing them in PHP 4.

 * PHP 5.2.6, 5.2.8
 * MySQL 5.0.51b, 5.1.30, 5.1.33
 
// FEATURES & DOCUMENTATION
---------------------------
v1.0 (Beta)
-------------------
 * Option of adding listing values to a database or pulling
   from a secondary database (much like CodeSort and FanUpdate). 
 * Member Functions 
  * Multiple fanlistings per email 
  * Approval (for adding/updating) and Update (for editing information straight
	from the admin panel) email option
	* Personal or generated password
	* Password reset
	* Admin Panel search of listings and email
	* show_members Functions 
	 * Option of a bulleted list, dropdown menu or all members display
	 * Pagination for all options 
 * Anti-SPAM Functions
  * Akismet Option (optional)
	* JavaScript "cheat" (optional)
	* "bad words" and "bots" list (not currently able to edit)
 * Options
  * Statistics template (for show-stats.php)
  * HTML MarkUp choice (XHTML or HTML) 

v1.0
-------------------
 * E-Mail function
  * E-Mail templates added to options table
  * E-Mail a member
  * E-Mail members from a listing
 * Multiple adding of values.inc.php
 * "Add Member" option added to members.php (for easy adding!)
 * "Previous Owner" field added to members table
 * "Send Me My Details" option for show-join.php
 * BellaBuffs conversion file (bellabuffs-convert.php)
 * New search function in members.php (by e-mail)
 
v1.1
-------------------
 * Five templates added: three templates for a members template (the
 header, footer and template itself) and two for approving and 
 updating members.
 * Field added to members table; this is for ensuring the owner knows 
 if the member has joined or simply update their information.
 * Multipling approving, updating and rejecting added to members.php
 * Bugfix of show-members.php (pagination)
 * Several bugfixes and tweaks made to func.inc.php
 * values.php renamed to listings.php
 * SPAM protection tweaked; the script now checks for bbCode in the
 form and only has <em>one</em> JavaScript field (if enabled).

// POSSIBLE FUTURE FEATURES(?)
------------------------------
 * Currently none at this time.
 
// INSTALLATION INSTRUCTIONS
----------------------------
Follow the instructions below to install the script.

 1.) Unzip the files by program/computer (depending on your platform)
 into a folder of your choice.
 
 2.) Open 'rats.inc.php' in the editor of your choice. Edit the essential
 variables. If your read through the WHOLE entire file (no skimming),
 all information about each variable is there.
 
 3.) Once edited, upload all the files in your folder onto your site
 through your FTP program of choice. I'd recommend you upload these
 to subfolder.
  
  Example: http://yoursite.com/kim_admin_folder/

  * The /example folder does not need to be uploaded, though it has a 
  required file (fig.inc.php) in the folder, as well as code snippets 
  for you to take examples from. 
	
 4.) Once uploaded, run install.php in a browser of your choice.
 
  Example: http://yoursite.com/kim_admin_folder/install.php
	
 5.) Before running the script, once again, make sure all the variables 
 in your config file are set correctly. Run it, and an success message should
 appear. Once the installation finishes, delete the file from your server
 immediately! This is important!  Even if you forget to delete the file, your 
 script will exit and display an error message until you delete the file from 
 your server.
 
 Be sure to check your config file thoroughly before reporting errors.
 Messages such as 'Cannot connect to the database' and 'unknown username
 and password' are most likely on your end.

-----
 
 1.) Once you've installed the script, there's finally the includes. With
 the .zip file came a folder named "example", which is NOT required to
 upload, but holds example pages. It also gives you a feel of what the
 front-end will look like. This is what a include will look like:

 <?php
 require("fig.inc.php");
 require(KAPATH . "show-join.php");
 ?>

 The pages that can be included are: show-join.php, show-members.php,
 show-update.php, show-stats.php, show-reset.php and fig.inc.php

 The fig.inc.php file included in /example is REQUIRED to include any of
 listed files. To find all code snippets of them, go to codes.php in your
 Admin Panel.
 
// UPGRADE INSTRUCTIONS
From Version 1.0 Beta to 1.0
-----------------------
 Before starting, make sure you have installed KIM Admin 1.0 Beta PRIOR to this 
 version. If this is a fresh installation, the upgrade file does NOT need to be 
 run.
 
 1.) Upload ALL files/folders (excluding install.php) into the same directory
 you installed 1.0 Beta. This includes overwriting the current files on your
 server.
 
 2.) Run upgrade_v1beta-v1.php in your browser and follow the instructions there. For 
 example:
 
  http://yoursite.com/kim_admin_folder/upgrade_v1beta-v1.php
 
 3.) Once the success message appears, delete the file from your server
 and log in.
 
 NOTE: Two e-mail templates were installed; to edit them, go to options.php.

-----

 1.) For those still using config.php for displaying the forms and members
 list: replace config.php with fig.inc.php - it was suggested that the 
 config file be uniquely named, especially with those using Enthusiast. It's
 not strictly required, but I'll be referring the config file as fig.inc.php
 from now on. 
 
// UPGRADE INSTRUCTIONS
From Version 1.0 to 1.1
-----------------------
 Before starting, make sure you have installed KIM Admin 1.0 PRIOR to this 
 version. If this is a fresh installation, the upgrade file does NOT need to be 
 run.
 
 1.) Upload ALL files/folders (excluding install.php) into the same directory
 you installed 1.0 Beta. This includes overwriting the current files on your
 server. THIS IS IMPORTANT!
 
 2.) Run upgrade.php in your browser and follow the instructions there. For 
 example:
 
  http://yoursite.com/kim_admin_folder/upgrade.php
 
 3.) Once the success message appears, delete the file from your server
 and log in.
 
 NOTE: values.php is now listings.php; make sure to delete values.php from
 your server.

// E-MAIL TEMPLATES
-------------------
The following templates are for the member and e-mail templates (found in options.php):

  {fan-name}  - Member name
	{fan-email} - Member E-Mail
	{fan-url}   - Member URL
  {listing}   - Listing member belongs to
	
	{site-join}   - URL to your KIM join form 
	{site-kim}    - URL to your KIM URL
	{site-list}   - URL to actual KIM list
	{site-update} - URL to your KIM update form
	
  {site-owner} - That would be you
  {site-name}  - Name of your website
  {site-url}   - URL to your website
 
// HOW-TO
---------
 1.) How do I use NL-CovertToPHP?
 --------------------------------
 When using NL-CovertToPHP, you can include the display code (found in
 codes.php) in any normal query string. For instance, let's say you want it
 included in collective.php?kim; any normal query string would look like:
 
 if(isset($_SERVER['QUERY_STRING']) && $_SERVER['QUERY_STRING'] == 'kim') {
 
 }
 
 Simply change that to:
 
 if(isset($_SERVER['QUERY_STRING']) && subtr_count($_SERVER['QUERY_STRING'], 'kim')) {
 
 }
 
 ...and so on.
 
 2.) How do I change the look of my members list in show_members.php?
 ---------------------------------------------------------------------------------
 As of the current version (1.0), there's no way to do this unless you go into
 func.inc.php and edit manually from there, which is something I wouldn't
 recommend in the least. This is defintiely something I'm thinking about solving
 in a coming release.
 
// CUSTOMIZATION
----------------
You can customize the script through CSS using these classes and IDs that are
already defined.

 #show-join, #show-update
 ------------------------
 * DIV id in show-join.php and show-update.php, in which you can apply any 
 special form or paragraph styles to these particular pages only. Example:
 
 #show-join input, #show-update input {
 
 } 
 
 #show-update textarea {
 
 }
 
 #show-join p {
 
 }
 
 ...and so on.
 
 #show-members
 -------------
 * DIV id in show-members.php, which will help with styling your bulleted
 list/dropdown menu easier. See above.
 
* To edit your statistics look, go to options.php in your Admin Panel.
 
// CREDITS, RESOURCES AND EXITS
-------------------------------
 Credits/Resources
 -----------------
 * SPAM
  * Most SPAM resources were found from Jem's second version of PHP Mail Form 
      <http://www.jemjabella.co.uk/scripts/free-php-mail-form>
    Such as "bad/SPAM" words by array, several different known bots and the
		dreaded ereg() function for e-mails.
	* MicroAkismet
	    <http://vanhegan.net/software/akismet/>
		
 Exits
 -----
 * phpFan Add-On for KIM
   If you find you're unsatisfied with KIM Admin, and you're using Enthusiast as 
	 a fanlisting script (much less phpFan itself), I'd recommend using the phpFan 
	 Add-On for KIM found here:
     <http://scripts.ishallnotcare.org/phpfan-add-ons/>
   As of the current version, it only caters to users with Enthusiast, though 
	 it's been mentioned this will change in the future.
	
MICROAKISMET LICENCE
--------------------
Copyright (c) 2007, Gaby Vanhegan <gaby@vanhegan.net>
All rights reserved.
  
Redistribution and use in source and binary forms, with or without 
modification, are permitted provided that the following conditions are met:
  
 * Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
        
 * Redistributions in binary form must reproduce the above copyright 
   notice, this list of conditions and the following disclaimer in the 
   documentation and/or other materials provided with the distribution.
        
 * Neither the name 'vanhegan.net' nor the names of its contributors 
   may be used to endorse or promote products derived from this software 
   without specific prior written permission.
  
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE 
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 
