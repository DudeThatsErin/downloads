<?php
# 'SHOW-STATS' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin 
------------------------------------------------------------- */
require("rats.inc.php");
require_once("func.inc.php");

echo format('sts_temp');
?>
