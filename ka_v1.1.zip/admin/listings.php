<?php
# 'LISTINGS' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin 
------------------------------------------------------------- */
$getTitle = "Listings";
require("pro.inc.php");
require("vars.inc.php");
require("header.php");

echo "<h2>{$getTitle}</h2>\n";

if(!isset($_GET['page']) || empty($_GET['page']) || !ctype_digit($_GET['page'])) {
 $page = 1;
} else 
 $page = cleanMys((int)$_GET['page']);
$start = mysql_real_escape_string((($page * $per_page) - $per_page));

if($_KA['scriptData'] != 'y') {
if(isset($_GET['get']) && $_GET['get'] == 'new') {
$id = cleanMys((int)$_GET['id']) + 1;
?>
<form action="listings.php" method="post">
<?php
for($i = 1; $i < $id; $i++) {
?>
<fieldset>
<legend>Details</legend>
<input name="numeric[]" type="hidden" value="<?php echo $i; ?>">
<p><label>Subject:</label> <input name="subject[]" class="input1" type="text"></p>
<p><label>URL:</label> <input name="url[]" class="input1" type="text" value="http://"></p>
</fieldset>
<?php
}
?>

<fieldset>
<legend>Submit</legend>
<p class="tc"><input name="action" class="input2" type="submit" value="Add Listing"> 
<input class="input2" type="reset" value="Reset"></p>
</fieldset>
</form>
<?php
}

elseif (isset($_POST['action']) && $_POST['action'] == 'Add Listing') {
foreach($_POST['numeric'] as $field => $value) {
$subject = cleanMys($_POST['subject'][$field]);
 if(empty($subject)) {
 displayError('Script Error', 'Your <samp>subject</samp> is empty.', false);
 } 
$url = cleanMys($_POST['url'][$field]);
 if(empty($url)) {
 displayError('Script Error', 'Your <samp>URL</samp> is empty.', false);
 } elseif ($url == 'http://') {
 displayError('Script Error', 'Your <samp>site url</samp> is not valid.', false);
 } elseif (!strstr($url, 'http://')) {
 displayError('Script Error', 'Your <samp>site url</samp> does not start with http:// and therefore is not valid. Try again.', false);
 }
 
$insert = "INSERT INTO `$_KA[valuesTable]` (`fSubject`, `fURL`) VALUES ('$subject', '$url')";
@mysql_query("SET NAMES 'utf8';");
$true = mysql_query($insert);

if($true == false) {
 displayError('Database Error', 'Unable to add the <strong>' . $subject . '</strong> listing' . 
 ' to the database.', true, $insert);
} elseif ($true == true) {
 echo '<p class="successButton"><span class="success">Success!</span> Your <samp>' . $subject . '</samp> listing' . 
 " was added to the database! :D</p>\n";
 }
}
echo backLink('list');
}

/* -- Edit --------------------------------------------------------------------- */

elseif (isset($_GET['get']) && $_GET['get'] == 'old') {
if(empty($_GET['id']) || !isset($_GET['id'])) {
?>
<form action="listings.php" method="get">
<input name="get" type="hidden" value="old">
<fieldset> 
<legend>Choose Listing</legend>
<p><label>Listing:</label> <select name="id" class="input1" size="6">
<?php 
$select = "SELECT * FROM `$_KA[valuesTable]` ORDER BY `fSubject` ASC";
$true = mysql_query($select);
if($true == false) { 
 echo "<option>No Listings Available</option>\n";
}

else {
 while($getItem = mysql_fetch_array($true)) {
  echo '<option value="' . $getItem['fID'] . '">' . $getItem['fSubject'] . "</option>\n";
 }
}
?>
</select></p>
<p class="tc"><input class="input2" type="submit" value="Edit Listing"></p>
</fieldset>
</form>
<?php
}

if(!empty($_GET['id'])) {
$id = cleanMys((int)$_GET['id']);
 if(!ctype_digit($id)) {
 displayError('Script Error', 'Your ID is not a number. Go back and try again.', false);
 }

$select = "SELECT * FROM `$_KA[valuesTable]` WHERE `fID` = '$id' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select that specific category.|Make sure the ' . 
 'ID is not empty and the category table exists.');
}
$getItem = mysql_fetch_array($true);
?>
<form action="listings.php" enctype="multipart/form-data" method="post">
<input name="id" type="hidden" value="<?php echo $getItem['fID']; ?>" />

<fieldset>
<legend>Details</legend>
<p><label>Subject:</label> <input name="subject" class="input1" type="text" value="<?php echo $getItem['fSubject']; ?>"></p>
<p><label>URL:</label> <input name="url" class="input1" type="text" value="<?php echo $getItem['fURL']; ?>"></p>
</fieldset>

<fieldset>
<legend>Submit</legend>
<p class="tc"><input name="action" class="input2" type="submit" value="Edit Listing"></p>
</fieldset>
</form>
<?php
}
}

elseif (isset($_POST['action']) && $_POST['action'] == 'Edit Listing') {
$id = cleanMys((int)$_POST['id']);
 if(empty($id)) {
 displayError('Script Error', 'Your ID is empty. This means you selected an incorrect listing or' . 
 ' you\'re trying to access something that doesn\'t exist. Go back and try again.', false);
 } elseif (!ctype_digit($id)) {
 displayError('Script Error', 'Your ID is not a number. Go back and try again.', false);
 }
$subject = cleanMys($_POST['subject']);
 if(empty($subject)) {
 displayError('Script Error', 'Your <samp>subject</samp> is empty.', false);
 } 
$url = cleanMys($_POST['url']);
 if(empty($url)) {
 displayError('Script Error', 'Your <samp>URL</samp> is empty.', false);
 } elseif ($url == 'http://') {
 displayError('Script Error', 'Your <samp>site url</samp> is not valid.', false);
 } elseif (strstr($url, 'www.') || !strstr($url, 'http://')) {
 displayError('Script Error', 'Your <samp>site url</samp> does not start with http:// and therefore is not valid. Try again.', false);
 } elseif (filter_var($url, FILTER_VALIDATE_URL) == false) {
 displayError('Script Error', 'Your <samp>site URL</samp> appears to be invalid. Make sure your website' . 
 ' starts with <samp>http://</samp> and contains no invalid characters.', false);
 }

$update = "UPDATE `$_KA[valuesTable]` SET `fSubject` = '$subject', `fURL` = '$url' WHERE `fID` = '$id' LIMIT 1";
@mysql_query("SET NAMES 'utf8';");
$true = mysql_query($update);
if($true == false) {
 displayError('Database Error', 'Unable to edit the listing.', true, $update);
} elseif ($true == true) {
  echo '<p class="successButton"><span class="success">Success!</span> Your listing was edited!</p>' . "\n";
  echo backLink('list', $id);
	echo backLink('list');
 }
}

/* -- Delete ------------------------------------------------------------------- */

elseif (isset($_GET['get']) && $_GET['get'] == 'erase') {
if(empty($_GET['id']) || !isset($_GET['id'])) {
?>
<form action="listings.php" method="get">
<input name="get" type="hidden" value="erase">
<fieldset> 
<legend>Choose Listing</legend>
<p><label>Category:</label> <select name="id" class="input1" size="6">
<?php 
$select = "SELECT * FROM `$_KA[valuesTable]` ORDER BY `siteTitle` ASC";
$true = mysql_query($select);
if($true == false) { 
 echo "<option>No Listings Available</option>\n";
}

else {
 while($getItem = mysql_fetch_array($true)) {
  echo '<option value="' . $getItem['fID'] . '">' . $getItem['fSubject'] . "</option>\n";
 }
}
?>
</select></p>
<p class="tc"><input class="input2" type="submit" value="Delete Listing"></p>
</fieldset>
</form>
<?php
}

if(!empty($_GET['id'])) {
$id = cleanMys((int)$_GET['id']);
 if(!ctype_digit($id)) {
 displayError('Script Error', 'Your ID is not a number. Go back and try again.', false);
 }
 
$select = "SELECT * FROM `$_KA[valuesTable]` WHERE `fID` = '$id' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select that specific listing.', true, $select);
}
$getItem = mysql_fetch_array($true);
?>
<p>You are about to delete the <strong><?php echo $getItem['fSubject']; ?></strong> listing; please be aware that once you 
delete a listing, it is gone forever. <em>This cannot be undone!</em> To proceed, click the "Delete Listing" button. :)</p>

<form action="listings.php" method="post">
<input name="id" type="hidden" value="<?php echo $getItem['fID']; ?>" />

<fieldset>
<legend>Delete Listing</legend>
<p class="tc">Deleting <strong><?php echo $getItem['fSubject'] ?></strong></p>
<p class="tc"><input name="action" class="input2" type="submit" value="Delete Listing"></p>
</fieldset>
</form>
<?php
}
}

elseif (isset($_POST['action']) && $_POST['action'] == 'Delete Listing') {
$id = cleanMys((int)$_POST['id']);
 if(empty($id) || !ctype_digit($id)) {
 displayError('Script Error', 'Your ID is empty or invalid. This means you selected an incorrect listing or' . 
 ' you\'re trying to access something that doesn\'t exist. Go back and try again.', false);
 } 
 
$delete = "DELETE FROM `$_KA[valuesTable]` WHERE `fID` = '$id' LIMIT 1";
$true = mysql_query($delete);
if($true == false) {
 displayError('Database Error', 'Unable to delete the listing.', true, $delete);
} elseif ($true == true) {
 echo '<p class="successButton"><span class="success">Success!</span> Your listing was deleted!</p>';
 echo backLink('list');
 }
}

/* -- Index -------------------------------------------------------------------- */

else {
?>
<p>Welcome to <samp>values.php</samp>, the page to add listings, and edit and delete your current ones! Please be aware
this isn't for creating a listing in general, but to add any current ones for your KIM members to add themselves to. More
on this can be found in the <samp>readme.txt</samp> file.</p>
<p>Below is your list of listings. To edit or delete a current one, click "Edit" or "Delete" by the appropriate listing.</p>
<form action="listings.php" method="get">
<input name="get" type="hidden" value="new">
<fieldset>
<legend>Add Listings</legend>
<p><label>Number of Listing:</label> <select name="id" class="input1">
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
<option>7</option>
<option>8</option>
<option>9</option>
<option>10</option>
</select></p>
<p class="tc"><input type="submit" value="Add Listings"></p>
</fieldset>
</form>
<?php
$select = "SELECT * FROM `$_KA[valuesTable]` ORDER BY `fSubject` DESC LIMIT $start, $per_page";
$true = @mysql_query($select);
$count = @mysql_num_rows($true);

if($count > 0) {
?>
<table class="index" width="100%"><thead><tr>
<th>ID</th>
<th>Subject</th>
<th>Action</th>
</tr></thead>
<?php
while($getItem = mysql_fetch_array($true)) {
?>
<tbody><tr>
<td class="tc"><?php echo $getItem['fID']; ?></td>
<td class="tc"><?php echo '<a href="' . $getItem['fURL'] . '">' . $getItem['fSubject'] . '</a>'; ?></td>
<td class="tc" width="30%">(<a href="listings.php?get=old&amp;id=<?php echo $getItem['fID']; ?>">Edit</a>) |
(<a href="emails.php?type=multiple&amp;id=<?php echo $getItem['fID']; ?>">E-Mail</a>) | 
 (<a href="listings.php?get=erase&amp;id=<?php echo $getItem['fID']; ?>">Delete</a>)</td>
</tr></tbody>
<?php
} 
echo "</table>\n";

echo "\n<p id=\"pagination\">";
$select = "SELECT * FROM `$_KA[valuesTable]`";
 $true = mysql_query($select);
  $total = mysql_num_rows($true);
$pages = ceil($total/$per_page);

$prev = ($page - 1);
if($page > 1) {
echo '<a href="listings.php?page=' . $prev . '">&laquo; Previous</a> ';
} else {
echo '&laquo; Previous ';
}

for($i = 1; $i <= $pages; $i++) {
 if($page == $i) {
  echo $i . " ";
 } else { 
  echo '<a href="listings.php?page=' . $i . '">' . $i . '</a> ';
 }
}

$next = ($page + 1);
if($page < $pages) {
echo '<a href="listings.php?page=' . $next . '">Next &raquo;</a>';
} else {
echo 'Next &raquo;';
}

echo "</p>\n";
} 

 else {
  echo "<p class=\"tc\">Currently no listings!</p>\n";
 }
}
} # -- End if() {} -----------------------------------

else {
$select = "SELECT * FROM `$_KA[otherTable]` ORDER BY `$_KA[listingsSb]` ASC LIMIT $start, $per_page";
$true = @mysql_query($select);
$count = @mysql_num_rows($true);

if($count > 0) {
?>
<table class="index" width="100%"><thead><tr>
<th>ID</th>
<th>Subject</th>
<th>Action</th>
</tr></thead>
<?php
while($getItem = mysql_fetch_array($true)) {
?>
<tbody><tr>
<td class="tc"><?php echo $getItem[$_KA[listingsID]]; ?></td>
<td class="tc"><?php echo $getItem[$_KA[listingsSb]]; ?></td>
<td class="tc" width="30%">(<a href="emails.php?type=multiple&amp;id=<?php echo $getItem[$_KA[listingsID]]; ?>">E-Mail</a>)</td>
</tr></tbody>
<?php
} 
echo "</table>\n";

echo "\n<p id=\"pagination\">";
$select = "SELECT * FROM `$_KA[otherTable]`";
 $true = mysql_query($select);
  $total = mysql_num_rows($true);
$pages = ceil($total/$per_page);

$prev = ($page - 1);
if($page > 1) {
echo '<a href="listings.php?page=' . $prev . '">&laquo; Previous</a> ';
} else {
echo '&laquo; Previous ';
}

for($i = 1; $i <= $pages; $i++) {
 if($page == $i) { 
  echo $i . " ";
 } else { 
  echo '<a href="listings.php?page=' . $i . '">' . $i . '</a> ';
 }
}

$next = ($page + 1);
if($page < $pages) {
echo '<a href="listings.php?page=' . $next . '">Next &raquo;</a>';
} else {
echo 'Next &raquo;';
}

echo "</p>\n";
} 
 else {
  echo "<p class=\"tc\">Currently no listings!</p>\n";
 }
}

require("footer.php");
?>

