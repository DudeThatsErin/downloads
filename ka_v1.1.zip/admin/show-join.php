<div id="show-join">
<?php
# 'SHOW-JOIN' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin 
------------------------------------------------------------- */
require("rats.inc.php");
require_once("func.inc.php");
require("vars.inc.php");
if($_KA['akismet_opt'] == 'y') {
 require_once("func.microakismet.inc.php");
}

# -- Get Variables ------------------------------------------
$nots = array("alert", "ass", "bcc:", "beastial", "bestial", "billiard", 
"billiard type", "billiards", "blowjob", "buy", "cc:", "clit", 
"content-type", "cum", "cock", "cum", "cunilingus", "cunillingus", "cunnilingus", 
"cunt", "dick", "document.cookie", "ejaculate", "fag", "felatio", "fellatio", 
"ffxi", "fuk", "fuks", "gangbang", "gangbanged", "gil", "grumpies", "javascript", 
"jism", "lxfrlvnqdedq", "maple", "mesos", "onclick", "onload", "poker", 
"porn", "purchasing", "pussies", "pussy", "runescape", "sex", "shuffleboard", 
"silicone", "silkroad", "snooker", "spunk", "sro", "vdgcrzdyduup", "viagra", 
"warcraft", "weapons", "wow gold");
$hots = array('[b]', '[/b]', '[b', '/b]', '[i]', '[i', '[link]', '[/link]', 
'[link', '[link=', '/link]', '[url]', '[/url]', '[url', '[url=', '/url]');
$bots = "/(Indy|Blaiz|Java|libwww-perl|Python|OutfoxBot|User-Agent|PycURL|" . 
"AlphaServer|T8Abot|Syntryx|WinHttp|WebBandit|nicebot|Jakarta|curl|Snoopy|" . 
"PHPcrawl|id-search|WebAlta Crawler|Baiduspider+|Gaisbot|KaloogaBot|Gigabot|" . 
"Gaisbot|ia_archiver)/i";

# -- Get POST -----------------------------------------------
if(isset($_POST['action']) && $_POST['action'] == 'Join List') {

# -- Get variables, check 'em -------------------------------
$name = cleanMys($_POST['name']);
 if(empty($name)) { 
 displayError('Script Error', 'You have not filled out the <samp>name</samp> field.', false);
 } elseif (!preg_match("/^[A-Za-z]+$/", $name)) { 
 displayError('Script Error', 'There are invalid characters in the <samp>name</samp> field. Go back and try again.', false);
 } elseif (strlen($name) > 20) {
 displayError('Script Error', 'Your <samp>name</samp> is too long. Go back and shorten it.</p>', false);
 } elseif (str_word_count($name) > 1) {
 displayError('Script Error', 'Your <samp>name</samp> is too long. Please make sure your name is one word and no longer than' . 
 ' 20 letters.', false);
 }
$email = cleanMys(strtolower($_POST['email']));
 if(empty($email)) {
 displayError('Script Error', 'You have not filled out the <samp>email</samp> field.</p>', false);
 } 
 # From Jem of jemjabella.co.uk (http://www.jemjabella.co.uk/scripts/free-php-mail-form)
 elseif (!ereg("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,6})$", $email)) {
 displayError('Script Error', 'The characters specified in the <samp>email</samp> field are not allowed.', false); 
 } elseif (filter_var($email, FILTER_VALIDATE_EMAIL) == false) {
 displayError('Script Error', 'Your <samp>e-mail</samp> appears to be invalid.', false);
 } elseif ($email === $my_email) {
 displayError('Script Error', 'Are you trying to use my email address? *tsks* Go back and try again.', false);
 }
$url = cleanMys($_POST['url']);
 if(!empty($url)) {
  if(!strstr($url, 'http://')) {
  displayError('Script Error', 'Your <samp>site URL</samp> does not start with http:// and therefore' . 
  ' is not valid. Try again.', false);
  } elseif (filter_var($url, FILTER_VALIDATE_URL) == false) {
  displayError('Script Error', 'Your <samp>site URL</samp> appears to be invalid.', false);
  }
 }
$listing = cleanMys((int)$_POST['listing']);
$listingArray = listingsList();
 if(empty($listing) || !ctype_digit($listing) || !in_array($listing, $listingArray)) {
 displayError('Script Error', 'In order to be added to the KIM list, you need to choose a listing.', false);
 }  
$passwordn = cleanMys($_POST['passwordn']);
$passwordv = cleanMys($_POST['passwordv']);
 if(!empty($passwordn)) {
  if(empty($passwordv)) {
  displayError('Script Error', 'In order to update your password, you need to fill' . 
	' out both new password fields or leave both empty.', false);
  }
 } 
 if(empty($passwordn) && empty($passwordv)) {
  $pass = substr(md5(mt_rand(90, 900)), 0, 6) . substr(md5(date("YmdHis")), 0, 6);
 } else {
  $pass = $passwordn;
 }
$visible = cleanMys($_POST['visible']);
 if(!ctype_digit($visible) || $visible > 1) { 
 displayError('Script Error', 'Your <samp>visible</samp> field is not valid.', false);
 }
$comments = cleanMys($_POST['comments']);
 if(strlen(trim($comments)) > 500) { 
 displayError('Script Error', 'Your <samp>comment</samp> is too long. Go back and shorten it.', false);
 }
$emailMe = cleanUpt($_POST['emailMe']);

# -- Check for SPAM words, mhmm? ----------------------------
foreach($nots as $b) {
 if(strpos($_POST['comments'], $b) !== false) {
  displayError('SPAM Error', 'SPAM language is not allowed.', false);
 }
}

# -- Check for bbCode ---------------------------------------
foreach($hots as $h) {
 if(strpos($_POST['comments'], $h) !== false) {
	displayError('SPAM Error', 'bbCode language is not allowed.', false);
 }
}

# -- Check for SPAM bots ------------------------------------
if(preg_match($bots, $_SERVER['HTTP_USER_AGENT']) || empty($_SERVER['HTTP_USER_AGENT'])) {
 displayError('SPAM Error', 'SPAM bots are not allowed.', false);
}

# -- Get (somewhat) expensive JavaScript Cheat --------------
if($_KA['jscheat_opt'] == 'y') {
 if(!isset($_POST['cheatcheatCheater']) || $_POST['cheatcheatCheater'] != md5($_KA['jscheat_key'])) {
  displayError('Script Error', 'It appears you have JavaScript turned off. As it is required to have JavaScript' . 
  ' enabled, I suggest you go back and enable it.', false);
 }
}

# -- Last Check, m'dears ------------------------------------
if($_KA['akismet_opt'] == 'y') {
$vars = array();
$vars['user_ip'] = $_SERVER['REMOTE_ADDR'];
$vars['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
$vars['referer'] = $_SERVER['HTTP_REFERER'];
$vars['comment_type'] = 'join';
$vars['comment_author'] = $name;
$vars['comment_author_email'] = $email;
$vars['comment_author_url'] = $url;
$vars['comment_content'] = $comments;
 
$check = akismet_check($vars);
 if($check == true) {
	displayError('SPAM Error', 'It appears Akismet thinks you\'re SPAM.|While this isn\'t a <em>huge</em> issue' . 
	' it\'s keeping you from being added to the list. If you believe you\'re not SPAM, feel free to' . 
	' join ' . $hide_address . '.', false);
 }
}

# -- Now we will add zee member -----------------------------
$insert = "INSERT INTO `$_KA[mainTable]`" . 
" (`mEmail`, `fNiq`, `mName`, `mURL`, `mPassword`, `mVisible`, `mPending`, `mPrevious`, `mUpdate`, `mAdd`)" .
" VALUES ('$email', '$listing', '$name', '$url', MD5('$pass'), '$visible', 1, 0, 'n', CURDATE())";
@mysql_query("SET NAMES 'utf8';");
$true = mysql_query($insert);
 if($true == false) {
  displayError('Database Error', 'Could not insert you as a member.', false);
 } 
 elseif ($true == true) {
 if(strpos($adminH, '/') !== false) {
  $_ADM = $adminH . 'members.php';
 } else
  $_ADM = $adminH . '/members.php';
 
 # Mail to ME: 
 $subject = $websiteName . " KIM: New Member";

 $message = "You have a received a new member at your KIM list:\n\n";
 $message .= "Name: {$name}\n";
 $message .= "E-Mail: {$email}\n";
 if(!empty($url))
  $message .= "URL: <$url}>\n";
 $message .= "Listing: " . getSubject($listing) . "\n\n";
 $message .= "Comments: {$comments}\n\n";
 $message .= "IP Address: {$_SERVER['REMOTE_ADDR']}\n\n";
 $message .= "To moderate (or delete) this member, go here: <{$_ADM}>";

 $headers = "From: KIM Admin <$you>" . "\n";
 $headers .= "Reply-To: <{$email}>";

 $mmail = @mail($my_email, $subject, $message, $headers);
 
 # Mail to THEM: 
 $them_subject = $websiteName . " KIM: Information";

 $them_message = "Hello {$name},\n\n";
 $them_message .= "You have received this email because you (or someone else) used this email address " .
 "to sign up as a member of {$websiteName}'s KIM list. If this is in error, " .
 "please reply to this email and tell me and I will remove you from the list as soon as possible.\n\n";
 $them_message .= "Currently, you have been placed on the members pending list for approval, and are not yet " .
 "part of the listing. If in two weeks, you have not yet been notified of your approval and you are " . 
 "not yet listed at the members list, please feel free to email me and check up on your application.\n\n";
 $them_message .= "The information you submitted to this list is shown below. Please keep this " .
 "information for future reference.\n\n";

 $them_message .= "Name: {$name}\n";
 $them_message .= "E-Mail: {$email}\n";
 if(!empty($url))
  $them_message .= "URL: <$url}>\n";
 $them_message .= "Password: " . $pass . "\n";
 $them_message .= "Listing: " . getSubject($listing) . "\n\n"; 

 $them_message .= "Thank you for joining the list! :D\n\n";
 $them_message .= "--\n{$my_name}\n{$websiteName} KIM List <{$websiteURL}>";

 $them_headers = "From: {$my_name} <$my_email>\n";
 $them_headers .= "Reply-To: <$my_email>";

 if($emailMe == 'yes') {
  $tmail = @mail($email, $them_subject, $them_message, $them_headers);
 }
	
	if($emailMe == 'yes') {
	 if($tmail) {
    echo('<p><span class="success">Success!</span> Your application was processed and you are now listed under the ' . 
    'pending list for approval. Your information has been sent to you. :)</p>' . "\n");
   } elseif (!$tmail) {
	  echo('<p><span class="success">Success!</span> Your application was processed and you are now listed under the ' . 
    'pending list for approval. However, we were unable to send your information to you.</p>' . "\n");
	 }
	} elseif ($emailMe != 'yes') {
	 echo('<p><span class="success">Success!</span> Your application was processed and you are now listed under the ' . 
    'pending list for approval.');
	}
 }
} 

else {
if($_KA['markup'] == 'xhtml') {
 $mark = " /";
} else
 $mark = "";
?>
<p>Please use the form below for joining the list only. Hit the submit button only once,
as your application is entered into the database, and ready for approval. If you
have any problems, feel more than free to contact me <?php echo $hide_address; ?>. 
Required fields are marked with the asterisk symbol (*).</p>

<form action="<?php echo getOption('website_join'); ?>" method="post">
<?php 
if($_KA['jscheat_opt'] == 'y') {
 echo javascriptCheat(md5($_KA['jscheat_key'])); 
} 
?>
<fieldset>
<legend>Join Form</legend>
<p><label>* Name:</label> <input name="name" class="input1" type="text"<?php echo $mark; ?>></p>
<p><label>* E-Mail:</label> <input name="email" class="input1" type="text"<?php echo $mark; ?>></p>
<p><label>URL:</label> <input name="url" class="input1" type="text"<?php echo $mark; ?>></p>
<p><label style="float: left; padding: 0 1%; width: 48%;"><strong>Password</strong><br<?php echo $mark; ?>>
Type in your password (if desired) twice for verification (a random one is generated otherwise):</label> 
<input name="passwordn" class="input1" style="width: 48%;" type="password"<?php echo $mark; ?>><br<?php echo $mark; ?>>
<input name="passwordv" class="input1" style="width: 48%;" type="password"<?php echo $mark; ?>></p>
<p style="clear: both; margin: 0 0 1% 0;"></p>
<p><label>* Listing:</label> <select name="listing" class="input1">
<?php 
if($_KA['scriptData'] == 'y') {
 $select = "SELECT * FROM `$_KA[otherTable]` WHERE `status` = '2' ORDER BY `$_KA[listingsSb]` ASC";
} else {
 $select = "SELECT * FROM `$_KA[valuesTable]` ORDER BY `fSubject` ASC";
}
$true = @mysql_query($select);
if($true == false) {
 echo "<option>No Listings Available</option>\n";
}

else {
 while($getItem = mysql_fetch_array($true)) {
  if($_KA['scriptData'] == 'y') {
	 $_id = $getItem[$_KA[listingsID]];
	 $_sb = $getItem[$_KA[listingsSb]];
	} else {
	 $_id = $getItem['fID']; 
	 $_sb = $getItem['fSubject'];
	}
  echo '<option value="' . $_id . '">' . $_sb . "</option>\n";
 }
} 
?>
</select></p>
<p><label>Show E-Mail:</label> <input name="visible" checked="checked" class="input3" type="radio" value="0"<?php echo $mark; ?>> Yes 
<input name="visible" class="input3" type="radio" value="1"<?php echo $mark; ?>> No</p>
<p><label>Comments:</label> <textarea name="comments" class="input1" cols="50" rows="10"></textarea></p>
<p class="tc"><input name="emailMe" checked="checked" class="input3" type="checkbox" value="yes"
<?php echo $mark; ?>> Send Me My Details!</p>
<?php
# -- Edit the following, and the KA world will drop on you: ---- 
# -- (i.e. Editing the values will make the script break.) -----
?>
<p class="tc"><input name="action" class="input2" type="submit" value="Join List"<?php echo $mark; ?>> 
<input class="input2" type="reset" value="Reset"<?php echo $mark; ?>></p>
</fieldset>
</form>

<p style="text-align: center;">
Powered by <a href="<?php echo $_KA['scriptURI']; ?>"><?php echo $_KA['version']; ?></a>
</p>
<?php
}
?>
</div>
