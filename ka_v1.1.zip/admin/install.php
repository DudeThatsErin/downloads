<?php
# 'INSTALL' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin 
------------------------------------------------------------- */
require("rats.inc.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
 "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title> <?php echo $_KA['version']; ?> &#8212; Install </title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="install">
<h2>Install Script</h2>
<?php
if(isset($_POST['action']) && $_POST['action'] == 'Install Script') {
$bots = "/(Indy|Blaiz|Java|libwww-perl|Python|OutfoxBot|User-Agent|PycURL|" . 
"AlphaServer|T8Abot|Syntryx|WinHttp|WebBandit|nicebot|Jakarta|curl|Snoopy|" . 
"PHPcrawl|id-search)/i";
if(preg_match($bots, $_SERVER['HTTP_USER_AGENT']) || empty($_SERVER['HTTP_USER_AGENT'])) {
 exit('<p class="error">Known SPAM bots aren\'t allowed.</p>');
}

if(empty($_KA['mainTable']) || empty($_KA['optionsTable'])) {
 exit('<p class="error">Your tables are empty; go back to your config file and <em>enter something</em>.</p>');
}

if($_KA['scriptData'] != 'n') {
 if(empty($_KA['otherTable']) || !isset($_KA['otherTable'])) {
	exit('<p class="error">Your config file reads that you\'re pulling your listings out of another table ' . 
	', therefore you must provide a table for <samp>$_KA[\'otherTable\']</samp>.</p>');
 }
}

if($_KA['scriptData'] != 'y') {
 if(empty($_KA['valuesTable']) || !isset($_KA['valuesTable'])) {
  exit('<p class="error">Your config file reads that you\'re NOT pulling your listings out of a another table' . 
	', therefore you must provide a table for <samp>$_KA[\'valuesTable\']</samp>.</p>');
 }
}

# Validate and Such:
function cleanInput($post, $type = 'all') {
 if($type == 'all') {
  $post = strip_tags($post);
 }
 $post = htmlentities($post, ENT_QUOTES, 'UTF-8');
 
 if(get_magic_quotes_gpc())
  $post = stripslashes($post);
 
 $post = mysql_real_escape_string($post);
 return $post;
}

function replaceEs($post) {  
 $post = trim(htmlentities($post, ENT_NOQUOTES, 'UTF-8'));
 if(get_magic_quotes_gpc())
  $post = stripslashes($post);
 $post = mysql_real_escape_string($post);
 return $post;
}

$your_name = cleanInput($_POST['name']);
 if(empty($your_name)) {
 exit('<p class="error">Your <samp>name</samp> field is empty.</p>');
 }
$email = cleanInput($_POST['email']);
 if(empty($email)) {
 exit('<p class="error">Your <samp>email</samp> field is empty.</p>');
 } 
 # From Jem of jemjabella.co.uk (http://www.jemjabella.co.uk/scripts/free-php-mail-form)
 elseif (!ereg("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,6})$", $email)) {
 exit('<p class="error">The characters specified in the <samp>email</samp> field are not allowed.</p>'); 
 }
$wname = cleanInput($_POST['wname']);
$wurl = cleanInput($_POST['wurl']);
$wkim = cleanInput($_POST['wkim']);
$wjoin = cleanInput($_POST['wjoin']);
$wupdate = cleanInput($_POST['wupdate']);
$wlist = cleanInput($_POST['wlist']);
$wlost = cleanInput($_POST['wlost']);
$adm_path = cleanInput($_POST['adm_path']);
$adm_http = cleanInput($_POST['adm_http']);
 if(!strrchr($adm_path, '/')) {
 exit('<p class="error">One or more of your paths need trailing slashes. Add them.</p>');
 } elseif (empty($adm_path) || empty($adm_http)) {
 exit('<p class="error">Your admin and image paths are empty. Enter the proper path.</p>');
 }
$membersort = cleanInput($_POST['member_sort']);
$membersortArray = array('all', 'drop', 'list');
 if(empty($membersort)) {
 $m = 'list';
 } else {
 $m = $membersort;
 }
 if(!empty($membersort)) {
  if(!in_array($membersort, $membersortArray)) {
  exit('<p class="error">Your <samp>member sort</samp> field must be "drop" or "list".</p>');
  }
 }
$members = cleanInput($_POST['members'], 'nom');
$stats = cleanInput($_POST['stats'], 'nom');
 if(empty($members)) {
 $mm = '&lt;li&gt;&lt;strong&gt;{name}&lt;/strong&gt;&lt;br /&gt;;
 {email} &middot; {url}&lt;br /&gt;
 &lt;em&gt;Listing:&lt;/em&gt; {listing}&lt;br /&gt;
 {previous_owner}
 &lt;/li&gt;';
 } else 
 $mm = $members;
 if(empty($stats)) {
 $ss = '&lt;p class=&quot;stats&quot;&gt;
 Members: {approved} ({pending} Pending)
 Last Updated: {updated}
 Part Of: &lt;a href=&quot;http://yourwebsite.com/&quot;&gt;My Website&lt;/a&gt;
 &lt;/p&gt;';
 } else
 $ss = $stats;
$mh = cleanInput($_POST['membersh'], 'nom');
$mf = cleanInput($_POST['membersf'], 'nom');
$per_page = cleanInput((int)$_POST['per_page']);
 if(!ctype_digit($per_page)) {
 exit('<p class="error">Your pagination fields aren\'t numbers. Go back and enter a <em>digit</em>.</p>');
 } elseif (strlen($per_page) > 2) {
 exit('<p class="error">The script does not allow pagination queries longer than 2 digits. Go back and enter a different number.</p>');
 }

# Create Table: 
$create = "CREATE TABLE `$_KA[mainTable]` (
`mID` int(10) NOT NULL AUTO_INCREMENT,
`mEmail` varchar(255) NOT NULL,
`fNiq` mediumint(5) unsigned NOT NULL,
`mName` varchar(100) NOT NULL,
`mURL` varchar(255) NOT NULL,
`mPassword` varchar(255) NOT NULL,
`mVisible` tinyint(1) NOT NULL DEFAULT '0',
`mPending` tinyint(1) NOT NULL DEFAULT '0',
`mPrevious` tinyint(1) NOT NULL DEFAULT '0',
`mUpdate` enum('y', 'n') NOT NULL DEFAULT 'n',
`mAdd` date NOT NULL,
PRIMARY KEY (`mID`),
UNIQUE KEY `mName` (`fNiq`, `mEmail`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
$true = @mysql_query($create);
if($true == false) {
 exit('<p><span class="mysql">Error:</span> ' . mysql_error() . "<br />\n<em>" . $create . '</em></p>');
}

# Create "Other" Table (for collectives):
$create = "CREATE TABLE `$_KA[valuesTable]` (
`fID` mediumint(5) NOT NULL AUTO_INCREMENT,
`fSubject` varchar(255) NOT NULL,
`fURL` varchar(255) NOT NULL,
PRIMARY KEY (`fID`),
UNIQUE KEY `fSubject` (`fURL`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
$true = @mysql_query($create);
if($true == false) {
 exit('<p><span class="mysql">Error:</span> ' . mysql_error() . "<br />\n<em>" . $create . '</em></p>');
}

# -- Add E-Mail Templates: --
$adopting = mysql_real_escape_string("Hello {fan-name},

You are receiving this e-mail because you (or someone else) used this email address to sign up as a member of {site-name}'s KIM list. If this is in error, please reply to this email and tell me and I will remove you from the list as soon as possible.

The {listing} listing has been put up for adoption, and you are currently listed as a new potentional owner of this listing. If you are interested in adopting this listing, reply to this e-mail or use this form <{site-url}/adopt>. I look forward to hearing from you! :)

--
{site-owner}
{site-name} KIM List
<{site-url}>");
$closing = mysql_real_escape_string("Hello {fan-name},

You are receiving this e-mail because you (or someone else) used this email address to sign up as a member of {site-name}'s KIM list. If this is in error, please reply to this email and tell me and I will remove you from the list as soon as possible.

The {listing} listing has closed, and you are currently listed as a new potentional owner of this listing. If you are interested in opening this listing and receiving the members list, reply to this e-mail. I look forward to hearing from you! :)

--
{site-owner}
{site-name} KIM List
<{site-url}>");
$approve = mysql_real_escape_string("Hello {fan-name},

This is a notice to let you know that you have been removed from the pending list at the {site-name} KIM list and added to the members list. You can now see your information here: <{site-list}>

If you need to change your information, you can do so here: <{site-update}>. :D

--
{site-owner}
{site-name} KIM <{site-url}>");
$update = mysql_real_escape_string("Hello {fan-name},

This is a notice to let you know that you have been removed from the pending list at the {site-name} KIM list and your information has been updated at your request. Your information is below: 

Name: {fan-name}
E-Mail Address: {fan-email}
URL: {fan-url}
Listing: {listing}

If this has been an error, or the information listed is wrong, feel more than free to reply to this message and let me know. Thank you for keeping your information up to date! :D

--
{site-owner}
{site-name} KIM <{site-url}>");

# Create and Insert Options Table: 
$create = "CREATE TABLE `$_KA[optionsTable]` (
`name` varchar(255) NOT NULL,
`text` text NOT NULL,
UNIQUE KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
$true = @mysql_query($create);
if($true == false) {
 exit('<p><span class="mysql">Error:</span> ' . mysql_error() . "<br />\n<em>" . $create . '</em></p>');
}

$insert = "INSERT INTO `$_KA[optionsTable]` VALUES ('your_name', '$your_name'),
('your_email', '$email'), 
('adm_http', '$adm_http'), 
('adm_path', '$adm_path'),
('website_name', '$wname'),
('website_url', '$wurl'),
('website_kim', '$wkim'),
('website_join', '$wjoin'),
('website_update', '$wupdate'),
('website_list', '$wlist'),
('website_reset', '$wlost'),
('mem_sort', '$m'),
('mem_temp', '$mm'),
('mem_head', '$mh'),
('mem_foot', '$mf'),
('apr_temp', '$approve'),
('upd_temp', '$update'),
('sts_temp', '$ss'),
('per_page', '$per_page'),
('adp_temp', '$adopting'),
('cls_temp', '$closing')";
@mysql_query("SET NAMES 'utf8';");
$true = @mysql_query($insert);
if($true == false) {
 exit('<p><span class="mysql">Error:</span> ' . mysql_error() . "<br />\n<em>" . $insert . '</em></p>');
}
?>
<p class="successButton"><span class="success">Success!</span> The installation process has ended and you have created your table! 
For security purposes, please remember to delete this file from your server. Have fun and <a href="index.php">log in</a>! :D</p>
<?php
}

else {
?>
<p>Welcome to <samp>install.php</samp>, the tool to installing and running your KIM script. There is only one
step, which is reviewing your information, entering your desired options (that can be altered to different values
at a later date) and installing the databases.</p>
<p>Please be aware that you must edit your config file prior to running this installation. After running the installation, 
delete this file from your webserver <em>as soon as you finish</em>. Consult the <samp>readme.txt</samp> file for 
further instructions.</p>

<form action="install.php" method="post">
<?php
$adminPath = str_replace('install.php', '', $_SERVER['SCRIPT_FILENAME']);
$adminURI = 'http://' . $_SERVER['SERVER_NAME'] . str_replace('install.php', '', $_SERVER['PHP_SELF']);

$tM = '&lt;li&gt;&lt;strong&gt;{name}&lt;/strong&gt;&lt;br /&gt;
{email} &amp;middot; {url}&lt;br /&gt;
&lt;em&gt;Listing:&lt;/em&gt; {listing}&lt;br /&gt;
{previous_owner}&lt;/li&gt;';
$tS = '&lt;p class="stats"&gt;
Members: {approved} ({pending} Pending)
Last Updated: {updated}
Part Of: &lt;a href="http://yourwebsite.com/"&gt;My Website&lt;/a&gt;
&lt;/p&gt;';
$mH = '&lt;ol&gt;';
$mF = '&lt;/ol&gt;';
?>
<fieldset>
<legend>Info</legend>
<p class="tc">You are creating the <samp><?php echo $_KA['mainTable']; ?></samp>, <samp><?php echo $_KA['optionsTable']; ?></samp> and
<samp><?php echo $_KA['valuesTable']; ?></samp> tables. If this is incorrect, correct the values in <samp>rats.inc.php</samp> and 
refresh the page.</p>
</fieldset>

<fieldset>
<legend>Your Details</legend>
<p><label><strong>Your Name:</strong></label> <input name="name" class="input1" type="text"></p>
<p><label><strong>E-Mail Address:</strong></label> <input name="email" class="input1" type="text"></p>
<p><label><strong>Website Name:</strong></label> <input name="wname" class="input1" type="text"></p>
<p><label><strong>Website URL:</strong></label> <input name="wurl" class="input1" type="text"></p>
</fieldset>

<fieldset>
<legend>KIM Details</legend>
<p><label><strong>KIM URL:</strong><br>
URL to your KIM site/page (for instance: <samp>http://yourwebsite.com/kim/</samp>)
</label> <input name="wkim" class="input1" type="text"></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>KIM Join Form:</strong><br>
URL to your KIM join form (for instance: <samp>http://yourwebsite.com/kim/join.php</samp>)
</label> <input name="wjoin" class="input1" type="text"></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>KIM Update Form:</strong><br>
URL to your update form (for instance: <samp>http://yourwebsite.com/kim/update.php</samp>)
</label> <input name="wupdate" class="input1" type="text"></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>KIM Members List:</strong><br>
URL to your members list (for instance: <samp>http://yourwebsite.com/kim/list.php</samp>)
</label> <input name="wlist" class="input1" type="text"></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>KIM Lost Password:</strong><br>
URL to your lost password form (for instance: <samp>http://yourwebsite.com/kim/lost.php</samp>)
</label> <input name="wlost" class="input1" type="text"></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>Member Sort:</strong><br>
Sorting for the members (for <samp>show-list.php</samp>). Can be either "drop" for
a dropdown menu, "list" for a bulleted list and "all" to display all members.
</label> <input name="member_sort" class="input1" type="text"></p>
</fieldset>

<fieldset>
<legend>Options</legend>
<p><label><strong>Admin Paths:</strong><br>
Admin paths are the path and <abbr title="Uniform Resource Identifier">URI</abbr> to your admin
panel. All paths and URLs are already set for you, although they can be changed to the desired path.
</label> <input name="adm_path" class="input1" type="text" value="<?php echo $adminPath; ?>"><br>
         <input name="adm_http" class="input1" type="text" value="<?php echo $adminURI; ?>"></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>Members Template:</strong><br>
Template for your members list (which will be displayed in <samp>show-members.php</samp>).
</label> <textarea name="members" cols="50" rows="8" style="height: 100px; width: 48%;"><?php echo $tM; ?></textarea></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>Members Header Template:</strong><br>
Header template for your members list (which will be displayed in <samp>show-members.php</samp>; optional).
</label> <textarea name="membersh" cols="50" rows="8" style="height: 100px; width: 48%;"><?php echo $mH; ?></textarea></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>Members Footer Template:</strong><br>
Footer template for your members list (which will be displayed in <samp>show-members.php</samp>; optional).
</label> <textarea name="membersf" cols="50" rows="8" style="height: 100px; width: 48%;"><?php echo $mF; ?></textarea></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>Statistic Template:</strong><br>
Template for your KIM statistics (which will be displayed if <samp>show-stats.php</samp> is used).
</label> <textarea name="stats" cols="50" rows="8" style="height: 100px; width: 48%;"><?php echo $tS; ?></textarea></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>Per Page:</strong><br>
Pagination for the admin panel/others as a whole.
</label> <input name="per_page" class="input1" type="text" value="12"></p>
</fieldset>

<fieldset>
<legend>Submit</legend>
<p class="tc"><input name="action" class="input2" type="submit" value="Install Script"></p>
</fieldset>
</form>
<?php
}
?>
</div>

</body>
</html>
