<?php
# 'OPTIONS' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin  
------------------------------------------------------------- */
$getTitle = "Options";
require("pro.inc.php");
require("header.php");

echo "<h2>{$getTitle}</h2>\n";

if(isset($_POST['action']) && $_POST['action'] == 'Edit Options') {
$your_name = cleanMys($_POST['your_name']);
 if(empty($your_name)) {
 displayError('Script Error', 'Your <samp>your name</samp> is empty. Go back and enter a name.', false);
 }
 if(getOption('your_name') != $your_name)
  editOption('your_name', $your_name);
$your_email = cleanMys($_POST['your_email']);
 if(empty($your_name)) {
 displayError('Script Error', 'Your <samp>your email</samp> is empty. Go back and enter a type.', false);
 }
 # From Jem of jemjabella.co.uk (http://www.jemjabella.co.uk/scripts/free-php-mail-form)
 elseif (!ereg("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,6})$", $your_email)) {
 displayError('Script Error', 'Your <samp>your email</samp> appears to be invalid.', false);
 } elseif (filter_var($your_email, FILTER_VALIDATE_EMAIL) == false) {
 displayError('Script Error', 'Your <samp>your e-mail</samp> appears to be invalid.', false);
 }
 if(getOption('your_email') != $your_email)
  editOption('your_email', $your_email);
$wname = cleanMys($_POST['wname']);
 if(empty($wname)) {
 displayError('Script Error', 'Your <samp>website name</samp> is empty. Go back and enter a name.', false);
 }
 if(getOption('website_name') != $wname)
  editOption('website_name', $wname);
$wurl = cleanMys($_POST['wurl']);
 if(empty($wname)) {
 displayError('Script Error', 'Your <samp>website URL</samp> is empty. Go back and enter a name.', false);
 } elseif (filter_var($wurl, FILTER_VALIDATE_URL) == false) {
 displayError('Script Error', 'Your <samp>website URL</samp> appears to be invalid.', false);
 }
 if(getOption('website_url') != $wurl)
  editOption('website_url', $wurl);
$wkim = cleanMys($_POST['wkim']);
 if(empty($wkim)) {
 displayError('Script Error', 'Your <samp>website kim URL</samp> is empty. Go back and enter a name.', false);
 } elseif (filter_var($wkim, FILTER_VALIDATE_URL) == false) {
 displayError('Script Error', 'Your <samp>website kim URL</samp> appears to be invalid.', false);
 }
 if(getOption('website_kim') != $wkim)
  editOption('website_kim', $wkim);
$wjoin = cleanMys($_POST['wjoin']);
 if(empty($wjoin)) {
 displayError('Script Error', 'Your <samp>website join form</samp> is empty. Go back and enter a name.', false);
 }
 if(getOption('website_join') != $wjoin)
  editOption('website_join', $wjoin);
$wupdate = cleanMys($_POST['wupdate']);
 if(empty($wupdate)) {
 displayError('Script Error', 'Your <samp>website update form</samp> is empty. Go back and enter a name.', false);
 }
 if(getOption('website_update') != $wupdate)
  editOption('website_update', $wupdate);
$wlist = cleanMys($_POST['wlist']);
 if(empty($wlist)) {
 displayError('Script Error', 'Your <samp>website list</samp> is empty. Go back and enter a name.', false);
 }
 if(getOption('website_list') != $wlist)
  editOption('website_list', $wlist);
$wlost = cleanMys($_POST['wlost']);
 if(empty($wlost)) {
 displayError('Script Error', 'Your <samp>lost password</samp> is empty. Go back and enter a name.', false);
 }
 if(getOption('website_reset') != $wlost)
  editOption('website_reset', $wlost);
$mem_sort = cleanMys($_POST['member_sort']);
$membersortArray = array('all', 'drop', 'list');
 if(empty($mem_sort)) {
 displayError('Script Error', 'Your <samp>member sort</samp> is empty. Go back and enter a name.', false);
 } elseif (!in_array($mem_sort, $membersortArray)) {
 displayError('Script Error', 'Your <samp>member sort</samp> field must be "drop" or "list".', false);
 }
 if(getOption('mem_sort') != $mem_sort)
  editOption('mem_sort', $mem_sort);
$per_page_opt = cleanMys((int)$_POST['per_page']);
 if(!ctype_digit($per_page_opt)) {
 displayError('Script Error', 'Your pagination fields aren\'t numbers. Go back and enter a <em>digit</em>.', false);
 } elseif (strlen($per_page_opt) > 2) {
 displayError('Script Error', 'The script does not allow pagination queries longer than 2 digits.' . 
 ' Go back and enter a different number.', false);
 }
 if(getOption('per_page') != $per_page_opt)
  editOption('per_page', $per_page_opt);
$adm_path = cleanMys($_POST['adm_path']);
$adm_http = cleanMys($_POST['adm_http']);
 if(!strrchr($adm_path, '/')) {
 displayError('Script Error', 'One or more of your paths need trailing slashes. Add them.', false);
 } elseif (empty($adm_path) || empty($adm_http)) {
 displayError('Script Error', 'Your admin paths are empty. Enter the proper path.', false);
 }
 if(getOption('adm_path') != $adm_path)
  editOption('adm_path', $adm_path);
 if(getOption('adm_http') != $adm_http)
  editOption('adm_http', $adm_http);
$adp_temp = trim($_POST['adopt']);
 if(getOption('adp_temp') != $adp_temp)
  editOption('adp_temp', $adp_temp);
$apr_temp = trim($_POST['approve']);
 if(getOption('apr_temp') != $apr_temp)
  editOption('apr_temp', $apr_temp);
$cls_temp = trim($_POST['close']);
 if(getOption('cls_temp') != $cls_temp)
  editOption('cls_temp', $cls_temp);
$upd_temp = trim($_POST['update']);
 if(getOption('upd_temp') != $upd_temp)
  editOption('upd_temp', $upd_temp);
$mem_temp = trim($_POST['members']);
$mem_temp = str_replace('&', '&amp;', $mem_temp);
 if(getOption('mem_temp') != $mem_temp)
  editOption('mem_temp', $mem_temp);
$mem_temp_head = trim($_POST['membersh']);
$mem_temp_head = str_replace('&', '&amp;', $mem_temp_head);
 if(getOption('mem_head') != $mem_temp_head)
  editOption('mem_head', $mem_temp_head);
$mem_temp_foot = trim($_POST['membersf']);
$mem_temp_foot = str_replace('&', '&amp;', $mem_temp_foot);
 if(getOption('mem_foot') != $mem_temp_foot)
  editOption('mem_foot', $mem_temp_foot);
$sts_temp = trim($_POST['stats']);
$sts_temp = str_replace('&', '&amp;', $sts_temp);
 if(getOption('sts_temp') != $sts_temp)
  editOption('sts_temp', $sts_temp);

echo '<p class="successButton"><span class="success">Success!</span> Your options have been updated!</p>';
echo backLink('opt');
}

else {
?>
<p>Below are the options you entered when you installed the script. All options can be edited, however, no options 
can be currently added (although this might change in future releases).</p>

<form action="options.php" method="post">
<fieldset>
<legend>Your Web Details</legend>
<p><label><strong>Name:</strong></label> <input name="your_name" class="input1" type="text" 
value="<?php echo getOption('your_name'); ?>"></p>
<p><label><strong>E-Mail Address:</strong></label> 
<input name="your_email" class="input1" type="text" value="<?php echo getOption('your_email'); ?>"></p>
<p><label><strong>Website Name:</strong></label> 
<input name="wname" class="input1" type="text" value="<?php echo getOption('website_name'); ?>"></p>
<p><label><strong>Website URL:</strong></label> 
<input name="wurl" class="input1" type="text" value="<?php echo getOption('website_url'); ?>"></p>
</fieldset>

<fieldset>
<legend>KIM Details</legend>
<p><label><strong>KIM URL:</strong><br>
URL to your KIM site/page (for instance: <samp>http://yourwebsite.com/kim/</samp>)
</label> <input name="wkim" class="input1" type="text" value="<?php echo getOption('website_kim'); ?>"></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>KIM Join Form:</strong><br>
URL to your KIM join form (for instance: <samp>http://yourwebsite.com/kim/join.php</samp>)
</label> <input name="wjoin" class="input1" type="text" value="<?php echo getOption('website_join'); ?>"></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>KIM Update Form:</strong><br>
URL to your update form (for instance: <samp>http://yourwebsite.com/kim/update.php</samp>)
</label> <input name="wupdate" class="input1" type="text" value="<?php echo getOption('website_update'); ?>"></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>KIM Members List:</strong><br>
URL to your members list (for instance: <samp>http://yourwebsite.com/kim/list.php</samp>)
</label> <input name="wlist" class="input1" type="text" value="<?php echo getOption('website_list'); ?>"></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>KIM Lost Password:</strong><br>
URL to your lost password form (for instance: <samp>http://yourwebsite.com/kim/lost.php</samp>)
</label> <input name="wlost" class="input1" type="text" value="<?php echo getOption('website_reset'); ?>"></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>Member Sort:</strong><br>
Sorting for the members (for <samp>show-list.php</samp>). Can be either "drop" for
a dropdown menu, "list" for a bulleted list or "all" to display all members.
</label> <input name="member_sort" class="input1" type="text" value="<?php echo getOption('mem_sort'); ?>"></p>
</fieldset>

<fieldset>
<legend>Pagination</legend>
<p><label><strong>Per Page:</strong><br>
For pagination queries and the members list
</label> <input name="per_page" class="input1" type="text" value="<?php echo getOption('per_page'); ?>"></p>
</fieldset>

<fieldset>
<legend>Paths</legend>
<p><label><strong>Admin Paths:</strong><br>
Admin paths are the path and <abbr title="Uniform Resource Identifier">URI</abbr> to your admin
panel. All paths and URLs are already set for you, although they can be changed to the desired path.
</label> <input name="adm_path" class="input1" type="text" value="<?php echo getOption('adm_path'); ?>"><br>
         <input name="adm_http" class="input1" type="text" value="<?php echo getOption('adm_http'); ?>"></p>
</fieldset>

<fieldset>
<legend>Templates</legend>
<p><label><strong>Members Template:</strong><br>
Template for your members list (which will be displayed on <samp>show-members.php</samp>).
</label> <textarea name="members" cols="50" rows="8" style="height: 100px; width: 48%;">
<?php echo getOption('mem_temp'); ?></textarea></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>Members Header Template:</strong><br>
Header template for your members list (which will be displayed on <samp>show-members.php</samp>; optional).
</label> <textarea name="membersh" cols="50" rows="8" style="height: 100px; width: 48%;">
<?php echo getOption('mem_head'); ?></textarea></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>Members Foot Template:</strong><br>
Footer template for your members list (which will be displayed on <samp>show-members.php</samp>; optional).
</label> <textarea name="membersf" cols="50" rows="8" style="height: 100px; width: 48%;">
<?php echo getOption('mem_foot'); ?></textarea></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>Statistic Template:</strong><br>
Template for your KIM statistics (which will be displayed if <samp>show-stats.php</samp> is used).
</label> <textarea name="stats" cols="50" rows="8" style="height: 100px; width: 48%;">
<?php echo getOption('sts_temp'); ?></textarea></p>
</fieldset>

<fieldset>
<legend>E-Mail Templates</legend>
<p><label><strong>Adopting Template:</strong><br>
Template for your e-mails to members (for adopting out listings).
</label> <textarea name="adopt" cols="50" rows="8" style="height: 100px; width: 48%;">
<?php echo getOption('adp_temp'); ?></textarea></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>Approval Template:</strong><br>
E-mail template for approving members.
</label> <textarea name="approve" cols="50" rows="8" style="height: 100px; width: 48%;">
<?php echo getOption('apr_temp'); ?></textarea></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>Closing Template:</strong><br>
Template for your e-mails to members (for closing listings).
</label> <textarea name="close" cols="50" rows="8" style="height: 100px; width: 48%;">
<?php echo getOption('cls_temp'); ?></textarea></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>Update Template:</strong><br>
E-mail template for updating members.
</label> <textarea name="update" cols="50" rows="8" style="height: 100px; width: 48%;">
<?php echo getOption('upd_temp'); ?></textarea></p>
</fieldset>

<fieldset>
<legend>Submit</legend>
<p class="tc"><input name="action" class="input2" type="submit" value="Edit Options"></p>
</fieldset>
</form>
<?php
}

require("footer.php");
?>
