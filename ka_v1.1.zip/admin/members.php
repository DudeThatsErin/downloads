<?php
# 'MEMBERS' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin 
------------------------------------------------------------- */
$getTitle = "Members";
require("pro.inc.php");
require("vars.inc.php");
require("header.php");

echo "<h2>{$getTitle}</h2>\n";

if(!isset($_GET['page']) || empty($_GET['page']) || !ctype_digit($_GET['page'])) {
 $page = 1;
} else 
 $page = cleanMys((int)$_GET['page']);
$start = mysql_real_escape_string((($page * $per_page) - $per_page));

if(isset($_GET['get']) && $_GET['get'] == 'new') {
?>
<p><samp>members.php?get=new</samp> is the outlet to adding a member of listing. Please note
there will NOT be an e-mail sent out to them of their information or approval. This is simply
a extra measure.</p>

<form action="members.php" enctype="multipart/form-data" method="post">
<fieldset>
<legend>Member Details</legend>
<p><label>Name:</label> <input name="name" class="input1" type="text"></p>
<p><label>E-Mail:</label> <input name="email" class="input1" type="text"></p>
<p><label>URI:</label> <input name="url" class="input1" type="text"></p>
<p><label>Show E-Mail:</label> <input name="visible" checked="checked" type="radio" value="0"> Show
<input name="visible" type="radio" value="1"> Hide</p>
<p><label>Previous Owner:</label> <input name="previous" checked="checked" type="radio" value="1"> Yes
<input name="previous" type="radio" value="0"> No</p>
</fieldset>

<fieldset>
<legend>Password</legend>
<p><label>Password:</label> <input name="password" class="input1" type="password"></p>
<p><label>Generate Password:<br>
Tick this if you'd like a random password given. (Please note if this is checked, this 
option will override any password you enter above.)</label>
<input name="generate" checked="checked" class="input3" type="checkbox" value="yes"></p>
</fieldset>

<fieldset>
<legend>Listing</legend>
<p><label>Listing:</label> <select name="listing" class="input1" size="4">
<?php 
if($_KA['scriptData'] == 'y') {
 $select = "SELECT * FROM `$_KA[otherTable]` ORDER BY `$_KA[listingsSb]` ASC";
} else {
 $select = "SELECT * FROM `$_KA[valuesTable]` ORDER BY `fSubject` ASC";
}
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Could not select the listings.|Make sure your listings table exists.');
}

while($getCat = mysql_fetch_array($true)) {

if($_KA['scriptData'] == 'y') {
 $_id = $getCat[$_KA[listingsID]];
 $_sb = $getCat[$_KA[listingsSb]];
} else {
 $_id = $getCat['fID'];
 $_sb = $getCat['fSubject'];
}

echo '<option value="' . $_id . '">' . $_sb . "</option>\n"; 
}
?>
</select></p>
</fieldset>

<fieldset>
<legend>Submit</legend>
<p class="tc"><input name="action" class="input2" type="submit" value="Add Member"></p>
</fieldset>
</form>
<?php
}

elseif (isset($_POST['action']) && $_POST['action'] == 'Add Member') {
$name = cleanMys($_POST['name']);
 if(empty($name)) { 
 displayError('Script Error', 'Your <samp>name</samp> field is empty.', false);
 } elseif (!preg_match("/^[A-Za-z]/D", $name)) { 
 displayError('Script Error', 'There are invalid characters in the <samp>name</samp> field. Go back and try again.', false);
 } elseif (strlen($name) > 20) {
 displayError('Script Error', 'Your <samp>name</samp> is too long. Go back and shorten it.</p>', false);
 }
$email = cleanMys($_POST['email']);
 if(empty($email)) { 
 displayError('Script Error', 'Your <samp>email</samp> field is empty.', false);
 } 
 # From Jem of jemjabella.co.uk (http://www.jemjabella.co.uk/scripts/free-php-mail-form)
 elseif (!ereg("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,6})$", $email)) {
 displayError('Script Error', 'The characters specified in the <samp>email</samp> field are not allowed.', false); 
 } elseif (filter_var($email, FILTER_VALIDATE_EMAIL) == false) {
 displayError('Script Error', 'Your <samp>e-mail</samp> appears to be invalid.', false);
 }
$url = cleanMys($_POST['url']);
 if(!empty($url)) {
  if(!strstr($url, 'http://')) {
  displayError('Script Error', 'Your <samp>site url</samp> does not start with http:// and therefore' . 
	' is not valid. Try again.', false);
  } elseif (filter_var($url, FILTER_VALIDATE_URL) == false) {
  displayError('Script Error', 'Your <samp>site URL</samp> appears to be invalid.', false);
  }
 }
$visible = cleanMys($_POST['visible']);
 if(!ctype_digit($visible) || $visible > 1) { 
 displayError('Script Error', 'Your <samp>visible</samp> field is not valid.', false);
 }
$previous = cleanMys((int)$_POST['previous']);
 if(!ctype_digit($previous) || $previous > 1) { 
 displayError('Script Error', 'Your <samp>previous</samp> field is not valid.', false);
 }
$password = cleanMys($_POST['password']);
$generate = cleanMys($_POST['generate']);
 if($generate == 'yes') {
 $pass = substr(md5(mt_rand(50, 500)), 0, 6) . substr(md5(date("YmdHis")), 0, 6);
 } else {
 $pass = $password;
 }
$listing = cleanMys((int)$_POST['listing']);
$listingArray = listingsList();
 if(empty($listing) || !ctype_digit($listing) || !in_array($listing, $listingArray)) {
 displayError('Script Error', 'In order to be added to the KIM list, you need to choose a listing.', false);
 } 

$insert = "INSERT INTO `$_KA[mainTable]`" . 
" (`mEmail`, `fNiq`, `mName`, `mURL`, `mPassword`, `mVisible`, `mPending`, `mPrevious`, `mAdd`)" . 
" VALUES ('$email', '$listing', '$name', '$url', MD5('$pass'), '$visible', 0, '$previous', CURDATE())";
@mysql_query("SET NAMES 'utf8';");
$true = mysql_query($insert);
 if($true == false) {
  displayError('Database Error', 'Could not insert you as a member.', true, $insert);
 } else {
  echo "<p class=\"successButton\"><span class=\"success\">Success!</span> The member was added!</p>\n";
  echo backLink('mem');
 }
}

# -- Edit ----------------------------------------------------------------------

elseif (isset($_GET['get']) && $_GET['get'] == 'old') {
if(empty($_GET['id']) || !isset($_GET['id'])) {
?>
<form action="members.php" method="get">
<input name="get" type="hidden" value="old">
<fieldset> 
<legend>Choose Member</legend>
<p><label>Member:</label> <select name="id" class="input1" size="6">
<?php 
$select = "SELECT * FROM `$_KA[mainTable]` ORDER BY `mName` ASC";
$true = mysql_query($select);
if($true == false) { 
 displayError('Database Error', 'Could not select the members.|Make sure your members table exists.');
}

else {
 while($getItem = mysql_fetch_array($true)) {
  echo('<option value="' . $getItem['mID'] . '">' . $getItem['mName'] . " (" . getSubject($getItem['fNiq']) . ")</option>\n");
 }
}
?>
</select></p>
<p class="tc"><input class="input2" type="submit" value="Edit Member"></p>
</fieldset>
</form>
<?php
}

if(!empty($_GET['id'])) {
$id = cleanMys((int)$_GET['id'], 'all');

$select = "SELECT * FROM `$_KA[mainTable]` WHERE `mID` = '$id' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the specified member from the database.|Make sure the ID is not empty and the' . 
 ' KIM members table exists.');
}
$getItem = mysql_fetch_array($true);
?>
<form action="members.php" enctype="multipart/form-data" method="post">
<input name="id" type="hidden" value="<?php echo $getItem['mID']; ?>">
<fieldset>
<legend>Intermiate Changes</legend>
<p><label>Edit Now?<br>
'Edit Now' decides whether you want that member updated. 
</label> <input name="edit_now" checked="checked" class="input3" type="radio" value="no"> No
<input name="edit_now" class="input3" type="radio" value="yes"> Yes</p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label>E-Mail Recipient?<br>
'E-Mail Recipient' decides if you want to e-mail a member of their update.
</label> <input name="email_now" checked="checked" class="input3" type="radio" value="no"> No
<input name="email_now" class="input3" type="radio" value="yes"> Yes</p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label>Previous Owner?</label> 
<?php
$v = $getItem['mPrevious'];
if($v == 0) {
echo '<input name="previous" checked="checked" type="radio" value="0"> Leave (No)' . "\n";
echo '<input name="previous" type="radio" value="1"> Yes' . "\n";
} elseif($v == 1) {
echo '<input name="previous" checked="checked" type="radio" value="1"> Leave (Yes)' . "\n";
echo '<input name="previous" type="radio" value="0"> No' . "\n";
}
?></p>
</fieldset>

<fieldset>
<legend>Member Details</legend>
<p><label>Name:</label> <input name="name" class="input1" type="text" value="<?php echo $getItem['mName']; ?>"></p>
<p><label>E-Mail:</label> <input name="email" class="input1" type="text" value="<?php echo $getItem['mEmail']; ?>"></p>
<p><label>URI:</label> <input name="url" class="input1" type="text" value="<?php echo $getItem['mURL']; ?>"></p>
<p><label>Show E-Mail:</label> 
<?php
$status = $getItem['mVisible'];
if($status == 0) {
echo '<input name="visible" checked="checked" type="radio" value="0"> Leave (Show)' . "\n";
echo '<input name="visible" type="radio" value="1"> Hide' . "\n";
} elseif($status == 1) {
echo '<input name="visible" checked="checked" type="radio" value="1"> Leave (Hide)' . "\n";
echo '<input name="visible" type="radio" value="0"> Show' . "\n";
}
?></p>
</fieldset>

<fieldset>
<legend>Listing</legend>
<p><label>Listing:</label> <select name="listing" class="input1" size="4">
<?php 
if($_KA['scriptData'] == 'y') {
 $select = "SELECT * FROM `$_KA[otherTable]` ORDER BY `$_KA[listingsSb]` ASC";
} else {
 $select = "SELECT * FROM `$_KA[valuesTable]` ORDER BY `fSubject` ASC";
}
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Could not select the listings.|Make sure your listings table exists.');
}

while($getCat = mysql_fetch_array($true)) {
$cats = explode('!', $getItem['fNiq']);

if($_KA['scriptData'] == 'y') {
 $_id = $getCat[$_KA[listingsID]];
 $_sb = $getCat[$_KA[listingsSb]];
} else {
 $_id = $getCat['fID'];
 $_sb = $getCat['fSubject'];
}

echo '<option value="' . $_id . '"'; if(in_array($_id, $cats)) echo ' selected="selected"'; 
echo '>' . $_sb . "</option>\n"; 
}
?>
</select></p>
</fieldset>

<fieldset>
<legend>Submit</legend>
<p class="tc"><input name="action" class="input2" type="submit" value="Edit Member"></p>
</fieldset>
</form>
<?php
}
}

elseif (isset($_POST['action']) && $_POST['action'] == 'Edit Member') {
$id = cleanMys((int)$_POST['id']);
 if(empty($id) || !ctype_digit($id)) {
 displayError('Script Error', 'Your ID is empty. This means you selected an incorrect KIM member or' . 
 ' you\'re trying to access something that doesn\'t exist. Go back and try again.', false);
 } 
$members = getMember($id);
$edit_now = cleanUpt($_POST['edit_now']);
$email_now = cleanUpt($_POST['email_now']);
$previous = cleanMys((int)$_POST['previous']);
 if(!ctype_digit($previous) || $previous > 1) { 
 displayError('Script Error', 'Your <samp>previous</samp> field is not valid.', false);
 }
$name = cleanMys($_POST['name']);
 if(empty($name)) { 
 displayError('Script Error', 'Your <samp>name</samp> field is empty.', false);
 } elseif (!preg_match("/^[A-Za-z]/D", $name)) { 
 displayError('Script Error', 'There are invalid characters in the <samp>name</samp> field. Go back and try again.', false);
 } elseif (strlen($name) > 20) {
 displayError('Script Error', 'Your <samp>name</samp> is too long. Go back and shorten it.</p>', false);
 }
$email = cleanMys($_POST['email']);
 if(empty($email)) { 
 displayError('Script Error', 'Your <samp>email</samp> field is empty.', false);
 } 
 # From Jem of jemjabella.co.uk (http://www.jemjabella.co.uk/scripts/free-php-mail-form)
 elseif (!ereg("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,6})$", $email)) {
 displayError('Script Error', 'The characters specified in the <samp>email</samp> field are not allowed.', false); 
 } elseif (filter_var($email, FILTER_VALIDATE_EMAIL) == false) {
 displayError('Script Error', 'Your <samp>e-mail</samp> appears to be invalid.', false);
 }
$url = cleanMys($_POST['url']);
$visible = cleanMys($_POST['visible']);
 if(!ctype_digit($visible)) { 
 displayError('Script Error', 'Your <samp>visible</samp> field is not a number.', false);
 }
$listing = cleanMys((int)$_POST['listing']);

$update = "UPDATE `$_KA[mainTable]` SET `mEmail` = '$email', `fNiq` = '$listing', `mName` = '$name', `mURL` = '$url', " . 
"`mVisible` = '$visible', `mPrevious` = '$previous'"; 
 if($edit_now == 'yes') 
  $update .= ", `mAdd` = CURDATE()";
$update .= " WHERE `mID` = '$id' LIMIT 1";
@mysql_query("SET NAMES 'utf8';");
$true = mysql_query($update);

if($true == false) {
 displayError('Database Error', 'Unable to update the member.|Make sure your ID is not empty and your table exists.');
} 

elseif ($true == true) {
if($email_now == 'yes') {
 $listing = getListings($members['fNiq']);
 
 $subject = $websiteName . " KIM: Updated";

 $message = "Hello " . $members['mName'] . ",\n\n";
 $message .= "This is a notice to let you know that you have been removed from the pending list at the {$websiteName} KIM list" . 
 " and your information has been updated at your request. Your information is below:\n\n";
 $message .= "Name: " . $members['mName'] . "\n";
 $message .= "E-Mail Address: " . $members['mEmail'] . "\n";
 if(!empty($members['mURL']))
  $message .= "Site URL: <" . $members['mURL'] . ">\n\n";
 $message .= "If this has been an error, or the information listed is wrong, feel more than free to reply to this message and let me know.\n\n";
 $message .= "Thank you for keeping your information up to date! :D\n\n";
 $message .= "--\n{$my_name}\n{$websiteName} KIM <{$websiteKIM}>";

 $headers = "From: {$my_name} <$my_email>\n";
 $headers .= "Reply-To: <$my_email>";

 $mail = mail($members['mEmail'], $subject, $message, $headers);
}

 echo "<p class=\"successButton\"><span class=\"success\">Success!</span> The member was updated! :D</p>\n";
 if($mail) {
  echo "<p class=\"successButton\"><span class=\"success\">Success!</span> The member was notified of their update!</p>\n";
 }
 echo backLink('mem');
 }
}

/* -- Delete ------------------------------------------------------------------- */

elseif (isset($_GET['get']) && $_GET['get'] == 'erase') {
if(empty($_GET['id']) || !isset($_GET['id'])) {
?>
<form action="members.php" method="get">
<input name="get" type="hidden" value="erase">
<fieldset> 
<legend>Choose Member</legend>
<p><label>Member:</label> <select name="id" class="input1" size="6">
<?php 
$select = "SELECT * FROM `$_KA[mainTable]` ORDER BY `mName` ASC";
$true = mysql_query($select);
if($true == false) { 
 displayError('Database Error', 'Could not select the listings.|Make sure your values table exists.');
}

else {
 while($getItem = mysql_fetch_array($true)) {
  echo('<option value="' . $getItem['mID'] . '">' . $getItem['mName'] . " (" . getSubject($getItem['fNiq']) . ")</option>\n");
 }
}
?>
</select></p>
<p class="tc"><input class="input2" type="submit" value="Delete Member"></p>
</fieldset>
</form>
<?php
}

if(!empty($_GET['id'])) {
$id = cleanMys((int)$_GET['id'], 'all');

$select = "SELECT * FROM `$_KA[mainTable]` WHERE `mID` = '$id' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the specified member.|Make sure your ID is not empty and your table exists.');
}
$getItem = mysql_fetch_array($true);
?>
<p>You are about to delete the member <strong><?php echo $getItem['mName']; ?></strong> (of 
<strong><?php echo getSubject($getItem['fNiq']); ?></strong>); please be aware that once you delete 
a member, they are gone forever. <em>This cannot be undone!</em> To proceed, click the "Delete Member" button. :)</p>

<form action="members.php" method="post">
<input name="id" type="hidden" value="<?php echo $getItem['mID']; ?>">

<fieldset>
<legend>Delete Member</legend>
<p class="tc">Deleting <strong><?php echo $getItem['mName'] ?></strong> (of <?php echo getSubject($getItem['fNiq']); ?>)</p>
<p class="tc"><input name="action" class="input2" type="submit" value="Delete Member"></p>
</fieldset>
</form>
<?php
}
}

elseif (isset($_POST['action']) && $_POST['action'] == 'Delete Member') {
$id = cleanMys((int)$_POST['id'], 'all');
 if(empty($id)) {
 displayError('Script Error', 'Your ID is empty. This means you selected an incorrect member or' . 
 ' you\'re trying to access something that doesn\'t exist. Go back and try again.', false);
 } elseif (!ctype_digit($id)) {
 displayError('Script Error', 'Your ID is not a number. Go back and try again.', false);
 }

$delete = "DELETE FROM `$_KA[mainTable]` WHERE `mID` = '$id' LIMIT 1";
$true = mysql_query($delete);

if($true == false) {
 displayError('Database Error', 'Unable to delete the member.', true, $delete);
} elseif ($true == true) {
  echo "<p class=\"successButton\"><span class=\"success\">Success!</span> Your member was deleted!</p>";
  echo backLink('mem');
 }
}

/* -- Mass-Approve Members ----------------------------------------------------- */
elseif (isset($_POST['action']) && $_POST['action'] == 'Approve') {
 if(empty($_POST['member'])) {
 displayError('Script Error', 'You need to select a member (or two, etc.) in order to approve them.', false);
 }
 
 foreach($_POST['member'] as $pm) {
  $members = getMember($pm);
  $update = "UPDATE `$_KA[mainTable]` SET `mPending` = '0', `mAdd` = CURDATE() WHERE `mID` = '$pm' LIMIT 1";
  @mysql_query("SET NAMES 'utf8';");
	$true = @mysql_query($update);
	if($true == true) {
	 echo '<p class="successButton"><span class="success">SUCCESS!</span> The <samp>' . memberName($pm) . '</samp>' . 
	 ' member (from the <strong>' . getSubject($members['fNiq']) . "</strong> listing) has been approved! :D</p>\n";
	} 
	$mailNow = @mailMembers('s', $members['fNiq'], 'apr_temp', 'n', 'n', $members['mEmail'], $pm);
	if($mailNow) {
	 echo "<p class=\"successButton\"><span class=\"success\">SUCCESS!</span> The member was notified of their approval!</p>\n";
	}
 }
 echo backLink('mem');
}

/* -- Mass-Delete Members ------------------------------------------------------*/
elseif (isset($_POST['action']) && $_POST['action'] == 'Delete') {
 if(empty($_POST['member'])) {
 displayError('Script Error', 'You need to select a member (or two, etc.) in order to approve them.', false);
 }
 
 foreach($_POST['member'] as $pm) {
  $members = getMember($pm);
  $delete = "DELETE FROM `$_KA[mainTable]` WHERE `mID` = '$pm' LIMIT 1";
	$true = @mysql_query($delete);
	if($true == true) {
	 echo "<p class=\"successButton\"><span class=\"success\">SUCCESS!</span> The member was deleted! :D</p>\n";
	} 
 }
 echo backLink('mem');
}

/* -- Mass-Update Members ------------------------------------------------------*/
elseif (isset($_POST['action']) && $_POST['action'] == 'Update') {
 if(empty($_POST['member'])) {
 displayError('Script Error', 'You need to select a member (or two, etc.) in order to approve them.', false);
 }
 
 foreach($_POST['member'] as $pm) {
  $members = getMember($pm);
  $update = "UPDATE `$_KA[mainTable]` SET `mPending` = '0', `mUpdate` = 'n', `mAdd` = CURDATE() WHERE `mID` = '$pm' LIMIT 1";
  @mysql_query("SET NAMES 'utf8';");
	$true = @mysql_query($update);
	if($true == true) {
	 echo '<p class="successButton"><span class="success">SUCCESS!</span> The <samp>' . memberName($pm) . '</samp>' . 
	 ' member (from the <strong>' . getSubject($members['fNiq']) . "</strong> listing) has been updated! :D</p>\n";
	} 
	$mailNow = @mailMembers('s', $members['fNiq'], 'upd_temp', 'n', 'n', $members['mEmail'], $pm);
	if($mailNow) {
	 echo "<p class=\"successButton\"><span class=\"success\">SUCCESS!</span> The member was notified of their update!</p>\n";
	}
 }
 echo backLink('mem');
}

/* -- Index -------------------------------------------------------------------- */

else {
?>
<p>Welcome to <samp>members.php</samp>, the page to edit or delete current <abbr title="Keep In Mind">KIM</abbr> members! Below is the list of 
your members. To edit or delete, click "Edit" or "Delete" by the appropriate member.</p>
<p>If you'd like to e-mail an individual member, click "E-Mail" by the appropriate member (under "Action"). To e-mail
all members from a specific listing, go to <a href="values.php">&raquo; Values</a> and click "E-Mail" by the 
appropriate listing.</p>
<p class="explode"><a href="members.php?get=new">Add a Member</a></p>

<div class="height">
<form action="members.php" method="get">
<input name="get" type="hidden" value="searchEmails">
<fieldset class="lap-two">
<legend>Search E-Mails</legend>
<p class="tc"><label>E-Mail:</label> <select name="email" class="input1">
<?php
$select = "SELECT DISTINCT `mEmail` FROM `$_KA[mainTable]` ORDER BY `mEmail` ASC";
$true = @mysql_query($select);

while($getTion = mysql_fetch_array($true)) {
$cleanEmail = str_replace('@', 'AT', $getTion['mEmail']);
$cleanEmail = str_replace('.', 'DOT', $cleanEmail);
$cleanEmail = str_replace('-', 'DASH', $cleanEmail);
$cleanEmail = str_replace('_', 'SCORE', $cleanEmail);

 echo '<option value="' . $cleanEmail . '">' . $getTion['mEmail'] . '</option>' . "\n";
}
?>
</select></p>
<p class="tc"><input class="input2" type="submit" value="Search E-Mails"></p>
</fieldset>
</form>

<form action="members.php" method="get">
<input name="get" type="hidden" value="searchListings">
<fieldset class="lap-two">
<legend>Search Listings</legend>
<p class="tc"><label>Listing:</label> <select name="listing_id" class="input1">
<?php
if($_KA['scriptData'] == 'y') {
 $select = "SELECT * FROM `$_KA[otherTable]` ORDER BY `$_KA[listingsSb]` ASC";
} else {
 $select = "SELECT * FROM `$_KA[valuesTable]` ORDER BY `fSubject` ASC";
}
$true = @mysql_query($select);

while($getTion = mysql_fetch_array($true)) {
 if($_KA['scriptData'] == 'y') {
  $_id = $getTion["$_KA[listingsID]"];
  $_sb = $getTion["$_KA[listingsSb]"];
 } else {
  $_id = $getTion['fID'];
  $_sb = $getTion['fSubject'];
 }
 echo '<option value="' . $_id . '">' . $_sb . '</option>' . "\n";
}
?>
</select></p>
<p class="tc"><input class="input2" type="submit" value="Search Listings"></p>
</fieldset>
</form>
<div style="clear: both; margin: 0 0 1% 0;"></div>
</div>
<?php
if(isset($_GET['get']) && $_GET['get'] == 'searchEmails') {
$em_id = cleanMys($_GET['email']);
$redoEmail = str_replace('AT', '@', $em_id);
$redoEmail = str_replace('DOT', '.', $redoEmail);
$redoEmail = str_replace('DASH', '-', $redoEmail);
$redoEmail = str_replace('SCORE', '_', $redoEmail);

$select = "SELECT * FROM `$_KA[mainTable]` WHERE `mEmail` = '$redoEmail' ORDER BY `mAdd` DESC LIMIT $start, $per_page";
$true = @mysql_query($select);
 if($true == false) {
 displayError('Database Error', 'Unable to select the members from the specified e-mail.', true, $select);
 }
$count = @mysql_num_rows($true);
}

elseif (isset($_GET['get']) && $_GET['get'] == 'searchListings') {
$fl_id = cleanMys($_GET['listing_id']);

$select = "SELECT * FROM `$_KA[mainTable]` WHERE `fNiq` = '$fl_id' ORDER BY `mAdd` DESC LIMIT $start, $per_page";
$true = @mysql_query($select);
 if($true == false) {
 displayError('Database Error', 'Unable to select the members from the specified listing.', true, $select);
 }
$count = @mysql_num_rows($true);
}

else {
$select = "SELECT * FROM `$_KA[mainTable]` ORDER BY `mAdd` DESC LIMIT $start, $per_page";
$true = @mysql_query($select);
 if($true == false) {
 displayError('Database Error', 'Unable to select the members from the specified listing.', true, $select);
 }
$count = @mysql_num_rows($true);
}

if($count > 0) {
?>
<form action="members.php" method="post">
<table class="index" width="100%"><thead>
<tr><th>&nbsp;</th>
<th>Listing</th>
<th>Name</th>
<th>E-Mail</th>
<th>Action</th></tr>
</thead>
<?php
while($getItem = mysql_fetch_array($true)) {
$ip = $getItem['mUpdate'] == 'y' ? " class=\"update\"" : " class=\"approve\"";
$cd = $getItem['mPending'] == '1' ? $ip : "";
?>
<tbody<?php echo $cd; ?>><tr>
<td class="tc"><input name="member[]" type="checkbox" value="<?php echo $getItem['mID']; ?>"></td>
<td class="tc"><?php echo getSubject($getItem['fNiq']); ?></td>
<td class="tc"><?php echo $getItem['mName']; ?></td>
<td class="tc"><?php echo $getItem['mEmail']; ?></td>
<td class="tc">(<a href="members.php?get=old&amp;id=<?php echo $getItem['mID']; ?>">Edit</a>) |
(<a href="emails.php?type=single&amp;id=<?php echo $getItem['fNiq']; ?>&amp;mid=<?php echo $getItem['mID']; ?>">E-Mail</a>) | 
(<a href="members.php?get=erase&amp;id=<?php echo $getItem['mID']; ?>">Delete</a>)</td>
</tr></tbody>
<?php
} 
?>
<tfoot><tr>
<td class="tc" colspan="6">With Checked: <input name="action" class="input2" type="submit" value="Approve">
<input name="action" class="input2" type="submit" value="Update">
<input name="action" class="input2" type="submit" value="Delete"></td>
</tr></tfoot>
</table>
</form>
<?php
echo "\n<p id=\"pagination\">";
$fl = cleanUpt((int)$_GET['listing_id']);
$em = cleanUpt($_GET['email']);
 $do = str_replace('AT', '@', $em);
 $do = str_replace('DOT', '.', $do);
 $do = str_replace('DASH', '-', $do);
 $do = str_replace('SCORE', '_', $do);

$select = "SELECT * FROM `$_KA[mainTable]`";
if(isset($_GET['get']) && $_GET['get'] == 'searchEmails')
 $select .= " WHERE `mEmail` = '$do'";
elseif (isset($_GET['get']) && $_GET['get'] == 'searchListings')
 $select .= " WHERE `fNiq` = '$fl'";
$true = mysql_query($select);
$total = mysql_num_rows($true);
$pages = ceil($total/$per_page);

$prev = ($page - 1);
if($page > 1) {
echo '<a href="members.php?page=' . $prev . '">&laquo; Previous</a> ';
} elseif ($page > 1 && isset($_GET['get']) && $_GET['get'] == 'searchEmails') {
echo '<a href="members.php?get=searchEmails&amp;email=' . $em . '&amp;page=' . $prev . '">&laquo; Previous</a> ';
} elseif ($page > 1 && isset($_GET['get']) && $_GET['get'] == 'searchListings') {
echo '<a href="members.php?get=searchListings&amp;listing_id=' . $fl . '&amp;page=' . $prev . '">&laquo; Previous</a> ';
} else {
echo '&laquo; Previous ';
}

for($i = 1; $i <= $pages; $i++) {
 if($page == $i) {
  echo $i . " ";
 } elseif (isset($_GET['get']) && $_GET['get'] == 'searchEmails') {
  echo '<a href="members.php?get=searchEmails&amp;email=' . $em . '&amp;page=' . $i . '">' . $i . '</a>';
 } elseif (isset($_GET['get']) && $_GET['get'] == 'searchListings') {
  echo '<a href="members.php?get=searchListings&amp;listing_id=' . $fl . '&amp;page=' . $i . '">' . $i . '</a>';
 } else { 
  echo '<a href="members.php?page=' . $i . '">' . $i . '</a> ';
 }
}

$next = ($page + 1);
if($page < $pages) {
echo '<a href="members.php?page=' . $next . '">Next &raquo;</a>';
} elseif ($page < $pages && isset($_GET['get']) && $_GET['get'] == 'searchEmails') {
echo '<a href="members.php?get=searchEmails&amp;email=' . $em . '&amp;page=' . $next . '">Next &raquo;</a>';
} elseif ($page < $pages && isset($_GET['get']) && $_GET['get'] == 'searchListings') {
echo '<a href="members.php?get=searchListings&amp;listing_id=' . $fl . '&amp;page=' . $next . '">Next &raquo;</a>';
} else {
echo 'Next &raquo;';
}

echo "</p>\n";
} 

else {
 echo "<p class=\"tc\">Currently no members!</p>\n";
}

}

require("footer.php");
?>
