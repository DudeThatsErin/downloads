<?php
# 'UPGRADE' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin 
------------------------------------------------------------- */
require("rats.inc.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
 "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title> <?php echo $_KA['version']; ?> &#8212; Upgrade </title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="install">
<h2>Upgrade Script</h2>
<?php
if(isset($_POST['action']) && $_POST['action'] == 'Upgrade Script') {
$bots = "/(Indy|Blaiz|Java|libwww-perl|Python|OutfoxBot|User-Agent|PycURL|" . 
"AlphaServer|T8Abot|Syntryx|WinHttp|WebBandit|nicebot|Jakarta|curl|Snoopy|" . 
"PHPcrawl|id-search)/i";
if(preg_match($bots, $_SERVER['HTTP_USER_AGENT']) || empty($_SERVER['HTTP_USER_AGENT'])) {
 exit('<p class="error">Known SPAM bots aren\'t allowed.</p>');
}

# -- Add 	Member Template: --
$member = '&lt;li&gt;&lt;strong&gt;{name}&lt;/strong&gt;&lt;br /&gt;
{email} &amp;middot; {url}&lt;br /&gt;
&lt;em&gt;Listing:&lt;/em&gt; {listing}&lt;br /&gt;
{previous_owner}
&lt;/li&gt;';
$member_head = '&lt;ol&gt;';
$member_foot = '&lt;/ol&gt;';
$approve = mysql_real_escape_string("Hello {fan-name},

This is a notice to let you know that you have been removed from the pending list at the {site-name} KIM list and added to the members list. You can now see your information here: <{site-list}>

If you need to change your information, you can do so here: <{site-update}>. :D

--
{site-owner}
{site-name} KIM <{site-url}>");
$update = mysql_real_escape_string("Hello {fan-name},

This is a notice to let you know that you have been removed from the pending list at the {site-name} KIM list and your information has been updated at your request. Your information is below: 

Name: {fan-name}
E-Mail Address: {fan-email}
URL: {fan-url}
Country: {fan-country}

If this has been an error, or the information listed is wrong, feel more than free to reply to this message and let me know. Thank you for keeping your information up to date! :D

--
{site-owner}
{site-name} KIM <{site-url}>");

$insert = "INSERT INTO `$_KA[optionsTable]` VALUES ('mem_temp', '$member'),
('mem_head', '$member_head'),
('mem_foot', '$member_foot'),
('apr_temp', '$approve'),
('upd_temp', '$update')";
@mysql_query("SET NAMES 'utf8';");
$true = mysql_query($insert);
if($true == false) {
 exit('<p><span class="mysql">Error:</span> ' . mysql_error() . "<br />\n<em>" . $insert . '</em></p>');
}

$alter = "ALTER TABLE `$_KA[mainTable]` ADD `mUpdate` ENUM('y', 'n') NOT NULL DEFAULT 'n' AFTER `mPrevious`";
$true = mysql_query($alter);
if($true == false) {
 exit('<p><span class="mysql">Error:</span> ' . mysql_error() . ' <em>' . $alter . '</em></p>');
}
?>
<p class="successButton"><span class="success">Success!</span> The upgrading process has ended and you have upgraded 
your script! For security purposes, please remember to delete this file from your server. Have fun and 
<a href="index.php">log in</a>! :D</p>
<?php
}

else {
?>
<p>Welcome to <samp>upgrade.php</samp>, the tool to upgrading your KIM script. There is only one
step, which is reviewing your information and editing the essentials.</p>
<p>Please be aware that you must have installed <samp>KIM Admin 1.0</samp> prior; this is <em>only</em> for
upgrading your script to the latest release, <strong>1.1</strong>. After running the installation, delete this 
file from your webserver <em>as soon as you finish</em>. Consult the <samp>readme.txt</samp> file for further 
instructions.</p>

<form action="upgrade.php" method="post">
<fieldset>
<legend>Database Changes</legend>
<p>There is <em>one</em> database change, which includes adding a members template to the options table. <em>Please</em>, read 
through this file carefully!</p>
</fieldset>

<fieldset>
<legend>Submit</legend>
<p class="tc"><input name="action" class="input2" type="submit" value="Upgrade Script"></p>
</fieldset>
</form>
<?php
}
?>
</div>

</body>
</html>
