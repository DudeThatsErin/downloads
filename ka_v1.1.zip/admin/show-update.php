<div id="show-update">
<?php
# 'SHOW-UPDATE' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin 
------------------------------------------------------------- */
require("rats.inc.php");
require_once("func.inc.php");
require("vars.inc.php");
if($_KA['akismet_opt'] == 'y') {
 require_once("func.microakismet.inc.php");
}

# -- Get Variables ------------------------------------------
$nots = array("alert", "ass", "bcc:", "beastial", "bestial", "billiard", 
"billiard type", "billiards", "blowjob", "buy", "cc:", "clit", 
"content-type", "cum", "cock", "cum", "cunilingus", "cunillingus", "cunnilingus", 
"cunt", "dick", "document.cookie", "ejaculate", "fag", "felatio", "fellatio", 
"ffxi", "fuk", "fuks", "gangbang", "gangbanged", "gil", "grumpies", "javascript", 
"jism", "lxfrlvnqdedq", "maple", "mesos", "onclick", "onload", "poker", 
"porn", "purchasing", "pussies", "pussy", "runescape", "sex", "shuffleboard", 
"silicone", "silkroad", "snooker", "spunk", "sro", "vdgcrzdyduup", "viagra", 
"warcraft", "weapons", "wow gold");
$hots = array('[b]', '[/b]', '[b', '/b]', '[i]', '[i', '[link]', '[/link]', 
'[link', '[link=', '/link]', '[url]', '[/url]', '[url', '[url=', '/url]');
$bots = "/(Indy|Blaiz|Java|libwww-perl|Python|OutfoxBot|User-Agent|PycURL|" . 
"AlphaServer|T8Abot|Syntryx|WinHttp|WebBandit|nicebot|Jakarta|curl|Snoopy|" . 
"PHPcrawl|id-search|WebAlta Crawler|Baiduspider+|Gaisbot|KaloogaBot|Gigabot|" . 
"Gaisbot|ia_archiver)/i";

# -- Get POST -----------------------------------------------
if(isset($_POST['action']) && $_POST['action'] == 'Update Info') {

# -- Get variables, check 'em -------------------------------
$name = cleanMys($_POST['name']);
 if(empty($name)) { 
 displayError('Script Error', 'You have not filled out the <samp>name</samp> field.', false);
 } elseif (!preg_match("/^[A-Za-z]+$/", $name)) { 
 displayError('Script Error', 'There are invalid characters in the <samp>name</samp> field. Go back and try again.', false);
 } elseif (strlen($name) > 20) {
 displayError('Script Error', 'Your <samp>name</samp> is too long. Go back and shorten it.</p>', false);
 }
$email = cleanMys(strtolower($_POST['email']));
$new_email = cleanMys(strtolower($_POST['new_email']));
 # Email ereg()'s from Jem of jemjabella.co.uk (http://www.jemjabella.co.uk/scripts/free-php-mail-form)
 if(empty($email)) {
 displayError('Script Error', 'You have not filled out the <samp>email</samp> field.</p>', false);
 } elseif (!ereg("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,6})$", $email)) {
 displayError('Script Error', 'The characters specified in the <samp>email</samp> field are not allowed.', false); 
 } elseif (filter_var($email, FILTER_VALIDATE_EMAIL) == false) {
 displayError('Script Error', 'Your <samp>e-mail</samp> appears to be invalid.', false);
 } 
 if(!empty($new_email)) {
  if(!ereg("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,6})$", $new_email)) {
  displayError('Script Error', 'The characters specified in the <samp>email</samp> field are not allowed.', false); 
  } elseif (filter_var($new_email, FILTER_VALIDATE_EMAIL) == false) {
  displayError('Script Error', 'Your <samp>new e-mail</samp> appears to be invalid.', false);
  } 
 }
$new_url = cleanMys($_POST['new_url']);
 if(!empty($new_url)) {
  if(!strstr($new_url, 'http://')) {
  displayError('Script Error', 'Your <samp>new url</samp> field appears to be invalid, though this might be due to the lack of' . 
	' <samp>http://</samp> at the beginning of your URL. Go back and apply one.', false);
  } elseif (filter_var($new_url, FILTER_VALIDATE_URL) == false) {
  displayError('Script Error', 'Your <samp>new URL</samp> appears to be invalid.', false);
  }
 }
$listing = cleanMys((int)$_POST['listing']);
$listingArray = listingsList();
 if(empty($listing) || !ctype_digit($listing) || !in_array($listing, $listingArray)) {
 displayError('Script Error', 'In order to be added to the KIM list, you need to choose a listing.', false);
 } 
# -- Check password AFTER $listing is applied, kthx: 
# -- Passwords: new, old and verify ----------------
$passwordo = cleanMys($_POST['passwordo']);
$passwordn = cleanMys($_POST['passwordn']);
$passwordv = cleanMys($_POST['passwordv']);
 if(checkPassword($email, $passwordo, $listing) == false) {
 displayError('Script Error', 'Oops! It appears the <samp>password</samp> you entered is incorrect. Go back' . 
 ' and supply a correct one. If you have forgotten your old password, you can reset one ' . 
 '<a href="' . getOption('website_reset') . '">&raquo; at the lost password page</a>!', false);
 } elseif ($passwordn !== $passwordv) {
 displayError('Script Error', 'Your <samp>new password</samp> fields do not match. Go back and try again.', false);
 }
 if(!empty($passwordn)) {
  if(empty($passwordv)) {
	displayError('Script Error', 'In order to update your password, you need to fill out both new password fields.', false);
	}
 }
$visible = cleanMys($_POST['visible']);
 if(!ctype_digit($visible)) {
 displayError('Script Error', 'Your <samp>show email</samp> field needs to be a number.', false);
 } elseif ($visible > 3) {
 displayError('Script Error', 'Your <samp>show email</samp> field only has three options: leave, yes and no.', false);
 }
 
# -- Check for SPAM words, mhmm? ----------------------------
foreach($nots as $b) {
 if(strpos($comments, $b) === true) {
  displayError('SPAM Error', 'SPAM language is not allowed.', false);
 }
}

# -- Check for bbCode ---------------------------------------
foreach($hots as $h) {
 if(strpos($_POST['comments'], $h) !== false) {
	displayError('SPAM Error', 'bbCode language is not allowed.', false);
 }
}

# -- Check for SPAM bots ------------------------------------
if(preg_match($bots, $_SERVER['HTTP_USER_AGENT']) || empty($_SERVER['HTTP_USER_AGENT'])) {
 displayError('SPAM Error', 'SPAM bots are not allowed.', false);
}

# -- Get (somewhat) expensive JavaScript Cheat --------------
if($_KA['jscheat_opt'] == 'y') {
 if(!isset($_POST['cheaycheatCheater']) || $_POST['cheatcheatCheater'] != md5($_KA['jscheat_key'])) {
  displayError('Script Error', 'It appears you have JavaScript turned off. As it is required to have JavaScript' . 
  ' enabled, I suggest you go back and enable it.', false);
 }
}

# -- (Almost) Last Check, m'dears ---------------------------
if($_KA['akismet_opt'] == 'y') {
$vars = array();
$vars['user_ip'] = $_SERVER['REMOTE_ADDR'];
$vars['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
$vars['referer'] = $_SERVER['HTTP_REFERER'];
$vars['comment_type'] = 'update';
$vars['comment_author'] = $name;
$vars['comment_author_email'] = $email;
$vars['comment_author_url'] = $url;
$vars['comment_content'] = $new_email . ' (' . $listing . ')';
 
$check = akismet_check($vars);
 if($check == true) {
	displayError('SPAM Error', 'It appears Akismet thinks you\'re SPAM.|While this isn\'t a <em>huge</em> issue' . 
	' it\'s keeping you from updating your information. If you believe you\'re not SPAM, feel free to' . 
	' update your information ' . $hide_address . '.', false);
 }
}
 
# -- Get "new" variables ------------------------------------
if(empty($new_email)) { 
 $e = $email;
} else 
 $e = $new_email;

# -- Now we will mail zee member ----------------------------
$update = "UPDATE `$_KA[mainTable]` SET `mEmail` = '$e',";
if(!empty($new_url)) 
 $update .= " `mURL` = '$url',";
if(!empty($passwordn) && !empty($passwordv)) 
 $update .= " `mPassword` = MD5('$passwordn'),";
if($visible != 3)
 $update .= " `mVisible` = '$visible',";
$update .= " `mPending` = '1', `mUpdate` = 'y' WHERE `mEmail` = '$email' and `fNiq` = '$listing' LIMIT 1";
$true = mysql_query($update);
if($true == false) {
 displayError('Database Error', 'Unable to update your information.', false);
} 
 
elseif ($true == true) {
 if(empty($new_email)) {
  $mail = $email;
 } else 
  $mail = $new_email;

 $subject = $websiteName . " KIM: Update Member";
 $message = "You have a received a update form from a member for your KIM list:\n\n";
 $message .= "Name: {$name}\n";
 $message .= "Old E-Mail: {$email}\n";
 $message .= "New E-Mail: {$new_email}\n";
 if(!empty($new_url)) 
  $message .= "New URL: <{$new_url}>\n";
 if($visible != 3) {
  if($visible == 1) {
   $message .= "Show E-Mail: Yes (0)\n\n";
  } else {
   $message .= "Show E-Mail: No (1)\n\n";
  }
 } else {
  $message .= "\n\n";
 }
 $message .= "IP Address: {$_SERVER['REMOTE_ADDR']}\n"; 
 $message .= "Browser: {$_SERVER['HTTP_USER_AGENT']}\n\n";
 $message .= "To moderate (or delete) this member update, go here: <{$adminH}>";

 $headers = "From: KIM Admin <$my_email>" . "\n";
 $headers .= "Reply-To: <{$mail}>";

 $mmail = @mail($my_email, $subject, $message, $headers);

 echo '<p><span class="success">Success!</span> Your update form was processed and you are now listed under the ' . 
 "pending list for approval. When you have been approved of your update, an approval email will be sent to you. :)</p>\n";
 }
}

else {
if($_KA['markup'] == 'xhtml') {
 $mark = " /";
} else
 $mark = "";
?>
<p>Please use the form below for updating your information only. If you would like
to join the list, you can <a href="<?php echo $formJoin; ?>">&raquo; do so here</a>. Hit 
the submit button only once, as your update form is entered into the database, and 
ready for approval. If you have any problems, feel more than free to contact me 
<?php echo $hide_address; ?>. Required fields are marked with the asterisk symbol (*).</p>

<form action="<?php echo getOption('website_update'); ?>" method="post">
<?php 
if($_KA['jscheat_opt'] == 'y') {
 echo javascriptCheat(md5($_KA['jscheat_key'])); 
} 
?>
<fieldset>
<legend>Details</legend>
<p><label>* Name:</label> <input name="name" class="input1" type="text"<?php echo $mark; ?>></p>
<p><label>New URL:</label> <input name="new_url" class="input1" type="text"<?php echo $mark; ?>></p>
</fieldset>

<fieldset>
<legend>Password</legend>
<p><label>* Old Password:</label> <input name="passwordo" class="input1" type="password"<?php echo $mark; ?>></p>
<p><label style="float: left; padding: 0 1%; width: 48%;"><strong>New Password</strong><br<?php echo $mark; ?>>
Type in your new password (if desired) twice for verification:</label> 
<input name="passwordn" class="input1" style="width: 48%;" type="password"<?php echo $mark; ?>><br<?php echo $mark; ?>>
<input name="passwordv" class="input1" style="width: 48%;" type="password"<?php echo $mark; ?>></p>
</fieldset>

<fieldset>
<legend>E-Mail Settings</legend>
<p><label>* Old E-Mail:</label> <input name="email" class="input1" type="text"<?php echo $mark; ?>></p>
<p><label>New E-Mail:</label> <input name="new_email" class="input1" type="text"<?php echo $mark; ?>></p>
<p><label>Show E-Mail:</label> <input name="visible" checked="checked" class="input3" type="radio" value="3"<?php echo $mark; ?>> Leave
<input name="visible" class="input3" type="radio" value="0"<?php echo $mark; ?>> Yes 
<input name="visible" class="input3" type="radio" value="1"<?php echo $mark; ?>> No</p>
</fieldset>

<fieldset>
<legend>Listing</legend>
<p><label>* Listing:</label> <select name="listing" class="input1">
<?php 
if($_KA['scriptData'] == 'y') {
 $select = "SELECT * FROM `$_KA[otherTable]` WHERE `status` = '2' ORDER BY `$_KA[listingsSb]` ASC";
} else {
 $select = "SELECT * FROM `$_KA[valuesTable]` ORDER BY `fSubject` ASC";
}
$true = @mysql_query($select);
if($true == false) {
 echo "<option>No Listings Available</option>\n";
}

else {
 while($getItem = mysql_fetch_array($true)) {
  if($_KA['scriptData'] == 'y') {
	 $_id = $getItem[$_KA[listingsID]];
	 $_sb = $getItem[$_KA[listingsSb]];
	} else {
	 $_id = $getItem['fID']; 
	 $_sb = $getItem['fSubject'];
	}
  echo '<option value="' . $_id . '">' . $_sb . "</option>\n";
 }
}  
?>
</select></p>
</fieldset>

<fieldset>
<legend>Submit</legend>
<?php
# -- Edit the following, and the KA world will drop on you: ---- 
# -- (i.e. Editing the values will make the script break.) -----
?>
<p class="tc"><input name="action" class="input2" type="submit" value="Update Info"<?php echo $mark; ?>> 
<input class="input2" type="reset" value="Reset"<?php echo $mark; ?>></p>
</fieldset>
</form>

<p style="text-align: center;">
Powered by <a href="<?php echo $_KA['scriptURI']; ?>"><?php echo $_KA['version']; ?></a>
</p>
<?php
}
?>
</div>
