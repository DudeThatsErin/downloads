<?php
# 'VARS.INC' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin 
------------------------------------------------------------- */

# -- Pagination ---------------------------------------------
$per_page = getOption('per_page');

# -- My Details ---------------------------------------------
$my_name = getOption('your_name');

# -- Statistics and Sorting ---------------------------------
$memsort = getOption('mem_sort');
$memtemp = getOption('mem_temp');
$memhead = getOption('mem_head');
$memfoot = getOption('mem_foot');

# -- Website Details ---------------------------------------- 
$adminH = getOption('adm_http');
$adminP = getOption('adm_path');

$websiteName = getOption('website_name');
$websiteURL = getOption('website_url');
$websiteKIM = getOption('website_kim');

$formJoin = getOption('website_join');
$formUpdt = getOption('website_update');
$formList = getOption('website_list');
$formLost = getOption('website_reset');

# -- E-Mail (addresss and JS) -------------------------------
$my_email = getOption('your_email');
$hide_address = '<script language="JavaScript" type="text/javascript">' . 
"\n<!--\njmail = ('$my_email');\n" .
"document.write('<a href=\"mailto:' + jmail + '\">via email</' + " .
"'a>');\n//-->\n</script>";
?>
