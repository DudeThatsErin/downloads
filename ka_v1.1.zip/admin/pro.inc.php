<?php
# 'PRO.INC' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin 
------------------------------------------------------------- */
session_cache_limiter('private_no_expire, must-revalidate');
session_start();

require("rats.inc.php");
require("func.inc.php");

if(isset($_GET['get']) && $_GET['get'] == 'logout') {
 $u = basename($_SERVER['PHP_SELF']); 
 setcookie('kalog');
 header("Location: $u");
}

$loginForm = true;
$errors = array();

$hash1 = substr(md5(date("F")), 0, 5);
 $hash2 = substr(md5($_KA['hash_password']), 0, 5);
 
$alofUsername = $_KA['hide_username'];
 $alofPassword = $_KA['hide_password'];

if(isset($_POST['action']) && $_POST['action'] == 'Log In') {
$pbots = "/(Indy|Blaiz|Java|libwww-perl|Python|OutfoxBot|User-Agent|PycURL|" . 
"AlphaServer|T8Abot|Syntryx|WinHttp|WebBandit|nicebot|Jakarta|curl|Snoopy|" . 
"PHPcrawl|id-search|WebAlta Crawler|Baiduspider+|Gaisbot|KaloogaBot|Gigabot|" . 
"Gaisbot|ia_archiver)/i";

if(preg_match($pbots, $_SERVER['HTTP_USER_AGENT']) || empty($_SERVER['HTTP_USER_AGENT'])) {
 $errors['form'] = '<p class="errorButton tc"><span class="error">ERROR:</span> Known SPAM bots aren\'t allowed.</p>';
}
$fullUsername = cleanUpt($_POST['username']);
$fullPassword = md5(cleanMys($_POST['password']));

if($fullUsername != $alofUsername || $fullPassword != $alofPassword) {
 $errors['form'] = '<p class="errorButton tc"><span class="error">ERROR:</span> The username/password combination' . 
 ' you entered does not match the one on file. Try again.</p>';
} 

elseif ($fullUsername == $alofUsername && $fullPassword == $alofPassword) {
  $loginForm = false;
	if(isset($_POST['rememberMe']) && $_POST['rememberMe'] == 'yes') {
	 setcookie('kalog', md5($hash1 . $alofUsername . $alofPassword . $hash2), time()+60*60*24*30);
	} else
	 setcookie('kalog', md5($hash1 . $alofUsername . $alofPassword . $hash2));
 }
} 

else {
 if(isset($_COOKIE['kalog'])) {
 $loginForm = false;
  if($_COOKIE['kalog'] === md5($hash1 . $alofUsername . $alofPassword . $hash2)) {
   $loginForm = false;
  } else {
   $loginForm = true;
  }
 }
}

if($loginForm) {
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
 "http://www.w3.org/TR/html4/strict.dtd">

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title> <?php  echo $_KA['version']; ?> &#8212; Log In </title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="login">
<div id="logo">
<h2>Enter Your Password</h2>
<p>Fill in the username and password you filled out prior to installation.</p>
<?php
if(isset($errors['form'])) {
 echo "\n<h3>Errors</h3>\n";
 echo "{$errors['form']}\n";
}
?>
</div>

<div id="form">
<form action="<?php echo basename($_SERVER['PHP_SELF']); ?>" method="post">
<fieldset>
<legend>Login</legend>
<p><label>Username:</label> <input name="username" class="input1" type="text"></p>
<p><label>Password:</label> <input name="password" class="input1" type="password"></p>
<p class="tc">Remember? <input name="rememberMe" class="input3" type="checkbox" value="yes"></p>
<p class="tc"><input name="action" class="input2" type="submit" value="Log In"></p>
</fieldset>
</form>
</div>

<div id="clear-login"></div>
</div>

</body>
</html>
<?php
exit();
}
?>
