<?php
/* ----------------------------------------------------------
Tess Ally 2006-2008 � Pumpin'! Admin 
------------------------------------------------------------- */
$getTitle = "Control Panel";
require("pro.inc.php");
require("header.php");

echo "<h2>{$getTitle}</h2>\n";

if(file_exists('install.php') || file_exists('upgrade.php')) {
 displayError('Script Error', 'The <samp>install.php</samp> and/or <samp>upgade.php</smap> file' . 
 ' is on your server; delete them.', false);
 require("footer.php");
}

else {
?>
<p>Welcome to <samp><?php echo $_KA['version']; ?></samp>, the script to maintain your KIM members. The control panel of your 
script is where you'll be able to view statistics (of members) and use this as a refresh stop. Navigation is simple, and 
is to the left. Have fun creating and displaying your list of sites! :D</p>

<h3>Statistics</h3>
<?php
$current = getCount('current');
 $pending = getCount('pending');
$members = $current + $pending;
$listings = countListings();
?>
<p id="stats">You have <?php echo $current; ?> current members (with <?php echo $pending; ?> pending approval). This makes 
<?php echo $members; ?> members total (which are held in <?php echo $listings; ?> listings, of course). Your options that were 
installed prior are permanent, regardless of their use.</p>
<?php	 
}

require("footer.php");
?>
