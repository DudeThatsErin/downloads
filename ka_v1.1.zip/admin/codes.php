<?php
# 'CODES' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin 
------------------------------------------------------------- */
$getTitle = "Display Codes";
require("pro.inc.php");
require("header.php");

echo "<h2>{$getTitle}</h2>\n";
?>
<p>Below is the snippets to display on your site. Please be aware these <em>must</em> be used in conjunction with
the <samp>fic.inc.php</samp> file that came with your .zip of the script. For further instructions, consult the
<samp>readme.txt</samp> file.</p>

<h3>Join Form</h3>
<code>
&lt;?php<br>
# -----------------------------------------------------------<br>
require("fig.inc.php");<br>
# -----------------------------------------------------------<br>
require(KAPATH . &#039;show-join.php&#039;);<br>
# -----------------------------------------------------------<br>
?&gt;
</code>

<h3>Update Form</h3>
<code>
&lt;?php<br>
# -----------------------------------------------------------<br>
require("fig.inc.php");<br>
# -----------------------------------------------------------<br>
require(KAPATH . &#039;show-update.php&#039;);<br>
# -----------------------------------------------------------<br>
?&gt;
</code>

<h3>Members List</h3>
<p>Go to <a href="options.php">&raquo; Options</a> to edit your members templates.</p>
<code>
&lt;?php<br>
# -----------------------------------------------------------<br>
require("fig.inc.php");<br>
# -----------------------------------------------------------<br>
require(KAPATH . &#039;show-members.php&#039;);<br>
# -----------------------------------------------------------<br>
?&gt;
</code>

<h3>Lost Password Form</h3>
<code>
&lt;?php<br>
# -----------------------------------------------------------<br>
require("fig.inc.php");<br>
# -----------------------------------------------------------<br>
require(KAPATH . &#039;show-reset.php&#039;);<br>
# -----------------------------------------------------------<br>
?&gt;
</code>

<h3>Statistics</h3>
<p>Go to <a href="options.php">&raquo; Options</a> to edit your statistics template.</p>
<code>
&lt;?php<br>
# -----------------------------------------------------------<br>
require("fig.inc.php");<br>
# -----------------------------------------------------------<br>
require(KAPATH . &#039;show-stats.php&#039;);<br>
# -----------------------------------------------------------<br>
?&gt;
</code>
<?php
require("footer.php");
?>
