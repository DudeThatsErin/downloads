<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
 "http://www.w3.org/TR/html4/strict.dtd">

<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title> <?php echo $_KA['version']; ?> &#8212; <?php if(isset($getTitle)) echo $getTitle; else echo 'KIM Script'; ?> </title>
<meta name="Author" content="Tess Ally">
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="container">

<div id="header">
<h1><?php echo $_KA['version']; ?></h1>
</div>

<div id="navigation">
<ul>
<?php if(isPage() == 'index.php') { ?>
<li class="c"><a href="<?php echo getOption('adm_http'); ?>">Control Panel</a></li>
<?php } else { ?>
<li><a href="<?php echo getOption('adm_http'); ?>">Control Panel</a></li>
<?php } if(isPage() == 'members.php') { ?>
<li class="c"><a href="members.php">Members</a></li>
<?php } else { ?>
<li><a href="members.php">Members</a></li>
<?php } if(isPage() == 'listings.php') { ?>
<li class="c"><a href="listings.php">Listings</a></li>
<?php } else { ?>
<li><a href="listings.php">Listings</a></li>
<?php } if(isPage() == 'options.php') { ?>
<li class="c"><a href="options.php">Options</a></li>
<?php } else { ?>
<li><a href="options.php">Options</a></li>
<?php } if(isPage() == 'codes.php') { ?>
<li class="c"><a href="codes.php">Display Codes</a></li>
<?php } else { ?>
<li><a href="codes.php">Display Codes</a></li>
<?php } ?>
<li id="lg"><a href="<?php echo cleanUpt($_SERVER['PHP_SELF']); ?>?get=logout">&raquo; Logout</a></li>
</ul>
</div>

<div id="content">
