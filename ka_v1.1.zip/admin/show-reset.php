<div id="show-reset">
<?php
# 'SHOW-JOIN' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin 
------------------------------------------------------------- */
require("rats.inc.php");
require_once("func.inc.php");
require("vars.inc.php");

# -- Get POST -----------------------------------------------
if(isset($_POST['action']) && $_POST['action'] == 'Reset Password') {

# -- Get variables, check 'em -------------------------------
$email = cleanMys(strtolower($_POST['email']));
 if(empty($email)) {
 displayError('Script Error', 'You have not filled out the <samp>email</samp> field.</p>', false);
 } 
 # From Jem of jemjabella.co.uk (http://www.jemjabella.co.uk/scripts/free-php-mail-form)
 elseif (!ereg("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,6})$", $email)) {
 displayError('Script Error', 'The characters specified in the <samp>email</samp> field are not allowed.', false); 
 } elseif (filter_var($email, FILTER_VALIDATE_EMAIL) == false) {
 displayError('Script Error', 'Your <samp>e-mail</samp> appears to be invalid.', false);
 }
$listing = cleanMys((int)$_POST['listing']);
$listingArray = listingsList();
 if(empty($listing) || !ctype_digit($listing) || !in_array($listing, $listingArray)) {
 displayError('Script Error', 'In order to be added to the KIM list, you need to choose a listing.', false);
 }  
if(checkReset($email, $listing) == false) {
 displayError('Script Error', 'It appears your email is not listed in the specified listing. This might be' . 
 ' because you are not a member, or you chose the wrong listing.', false);
}
$password = substr(md5(mt_rand(90, 900)), 0, 6) . substr(md5(date("YmdHis")), 0, 6);

# -- Check for SPAM bots ------------------------------------
if(preg_match($bots, $_SERVER['HTTP_USER_AGENT']) || $_SERVER['HTTP_USER_AGENT'] == " ") {
 displayError('SPAM Error', 'SPAM bots are not allowed.', false);
}

# -- Get (somewhat) expensive JavaScript Cheat --------------
if($_KA['jscheat_opt'] == 'y') {
 if(!isset($_POST['cheatcheatCheater']) || $_POST['cheatcheatCheater'] != md5($_KA['jscheat_key'])) {
  displayError('Script Error', 'It appears you have JavaScript turned off. As it is required to have JavaScript' . 
  ' enabled, I suggest you go back and enable it.', false);
 }
}

# -- Now will we update zee member! -------------------------
$update = "UPDATE `$_KA[mainTable]` SET `mPassword` = MD5('$password')";
$update .= " WHERE `mEmail` = '$email' AND `fNiq` = '$listing' LIMIT 1";
$true = @mysql_query($update);

 if($true == false) {
  displayError('Script Error', 'Unable to reset your password. If you so wish it, you can email me ' . 
	$hide_address . ' to reset it.', false);
 } else {
  $member = pullMember($email, $listing);
  # Mail to THEM: 
  $subject = $websiteName . " KIM: Lost Password";

  $message = "Hello {$member['mName']},\n\n";
  $message .= "You have received this email because you (or someone else) used this email address " .
  "to request a lost password at {$websiteName}'s KIM list. If this is in error, " .
  "please reply to this email and tell me and I will rectify the situation as soon as possible.\n\n";
  $message .= "The information you requested to this list is shown below. Please keep this " .
  "information for future reference.\n\n";

  $message .= "Password: " . $password . "\n";
  $message .= "Listing: " . getSubject($listing) . "\n\n"; 

  $message .= "--\n{$my_name}\n{$websiteName} KIM List <{$websiteURL}>";

  $headers = "From: {$my_name} <$my_email>\n";
  $headers .= "Reply-To: <$my_email>";

  $mail = @mail($email, $subject, $message, $headers);
	
	if($mail) {
	 echo '<p><span class="success">Success!</span> Your lost password form was processed, and your' . 
	 ' password changed. It has been sent to your e-mail address. From there, I advise you to change' . 
	 ' your password as soon as you have the chance.</p>';
	} else {
	 echo '<p>Your form was processed and your password updated, however, I was unable to send you your' . 
	 ' password. I would recommend trying again, and if that fails, you are always free to e-mail me ' . 
	 $hide_address . ', and have me change your password for you.</p>';
	}
 }
}

else {
if($_KA['markup'] == 'xhtml') {
 $mark = " /";
} else
 $mark = "";
?>
<p>Please use the form below for requesting a lost password only. The e-mail and listing
you enter will supply you with a new password for that listing <em>only</em>. If your
e-mail is listed under multiple, you will need to send in a form for each listing. 
<em>All</em> fields are required.</p>
<p>If the form does not work for you, or you have lost access to your current e-mail
account, you can e-mail me <?php echo $hide_address; ?>. </p>

<form action="<?php echo basename(getOption('website_reset')); ?>" method="post">
<?php 
if($_KA['jscheat_opt'] == 'y') {
?>
<input name="imaCheater" type="hidden" value="r5ndomstringnumb3rnin3b3c5us3ich35t"<?php echo $mark; ?>>
<?php
 echo javascriptCheat(md5($_KA['jscheat_key'])); 
} 
?>
<fieldset>
<legend>Lost Password</legend>
<p><label>* E-Mail:</label> <input name="email" class="input1" type="text"<?php echo $mark; ?>></p>
<p><label>* Listing:</label> <select name="listing" class="input1">
<?php 
if($_KA['scriptData'] == 'y') {
 $select = "SELECT * FROM `$_KA[otherTable]` ORDER BY `$_KA[listingsSb]` ASC";
} else {
 $select = "SELECT * FROM `$_KA[valuesTable]` ORDER BY `fSubject` ASC";
}
$true = @mysql_query($select);
if($true == false) {

}

else {
 while($getItem = mysql_fetch_array($true)) {
  if($_KA['scriptData'] == 'y') {
	 $_id = $getItem[$_KA[listingsID]];
	 $_sb = $getItem[$_KA[listingsSb]];
	} else {
	 $_id = $getItem['fID']; 
	 $_sb = $getItem['fSubject'];
	}
  echo '<option value="' . $_id . '">' . $_sb . "</option>\n";
 }
} 
?>
</select></p>
<?php
# -- Edit the following, and the KA world will drop on you: ---- 
# -- (i.e. Editing the values will make the script break.) -----
?>
<p class="tc"><input name="action" class="input2" type="submit" value="Reset Password"<?php echo $mark; ?>> 
<input class="input2" type="reset" value="Reset"<?php echo $mark; ?>></p>
</fieldset>
</form>

<p style="text-align: center;">
Powered by <a href="<?php echo $_KA['scriptURI']; ?>"><?php echo $_KA['version']; ?></a>
</p>
<?php
}
?>
</div>
