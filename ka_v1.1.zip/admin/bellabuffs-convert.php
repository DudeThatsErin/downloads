<?php
# 'BELLABUFFS-CONVERT' FILE 
# -----------------------------------------------------------
require("rats.inc.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
 "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title> <?php echo $_KA['version']; ?> &#8212; Convert Script </title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="install">
<h2>Convert BellaBuffs to KIM Admin</h2>
<?php
if(isset($_POST['action']) && $_POST['action'] == 'Convert') {
$bots = "/(Indy|Blaiz|Java|libwww-perl|Python|OutfoxBot|User-Agent|PycURL|AlphaServer|T8Abot|" . 
"Syntryx|WinHttp|WebBandit|nicebot|Jakarta|curl|Snoopy|PHPcrawl|id-search)/i";
if(preg_match($bots, $_SERVER['HTTP_USER_AGENT']) || $_SERVER['HTTP_USER_AGENT'] == " ") {
 exit('<p class="error">Known SPAM bots aren\'t allowed.</p>');
}

$txt = trim(strip_tags($_POST['txtfile']));
if(empty($txt)) {
 exit('<p><span class="error">ERROR:</span> In order to convert, you need to enter a <samp>.txt</samp> file.</p>');
}
 
function breakEmail($email) {
 $email = str_replace('ATTIE', '@', $email);
 $email = str_replace('DOTTY', '.', $email);
 $email = str_replace('DASHY', '-', $email);
 $email = str_replace('SCORE', '_', $email);
 return $email;
}

$file = file($txt);
if(count($file) == 0) {
 exit('<p><span class="error">ERROR:</span> No members to convert.</p>');
}

echo('<div style="margin: 15px 0 0 0;">' . "\n");
?>
<p>Copy the following text into a .sql file and import in into your database. This'll differ depending on your server.</p>
<p style="color: #202020; font-family: Lucida Console;">
<?php
echo 'INSERT INTO `' . $_KA[mainTable] . '`' . 
' (`mEmail`, `fNiq`, `mName`, `mURL`, `mPassword`, `mVisible`, `mPending`, `mPrevious`, `mAdd`) VALUES' . "<br>\n";
$i = 0;

$mem = '';
foreach($file as $f) {
list($name, $email, $show, $url, $listing) = explode(',', $f);

if($show == 'yes') {
 $s = 0;
} else
 $s = 1;
 
if($url == '') {
 $u = '';
} else
 $u = $url;

$mem .= "('" . breakEmail($email) . "', '{$listing}', '{$name}', '{$u}', '', {$s}, 0, 0, '0000-00-00'),<br>";

$i++;
}
$mem = rtrim($mem, ',<br>');
echo $mem . ';';
echo "</p>\n</div>\n";
}

else {
?>
<p>Below is the confirmation to convert your BellaBuffs script to KIM Admin. Please be aware
that your BellaBuffs script must have been used for KIM list purposes, and not as a fanlisting.</p>
<p><span class="error">NOTE:</span> Because of the way BellaBuffs and KIM Admin differ, you will be
given a list of members, which you will need to edit. The Listings (displayed as a subject and not a number)
needs to be changed to its appropriate ID before you import it into the database.</p>
<p><span class="error">ONCE AGAIN:</span> This is <em>not</em> a definite alternative to converting
members from BellaBuffs to KIM Admin. You are a given a raw version of a .sql file, which you will need to
copy and then paste in a .sql file, before importing it into the database. If you feel this is
your preferred way and would like help, do not hesitate to contact me via e-mail: 
<strong>theirrenegadexxx@gmail.com</strong></p>

<form action="bellabuffs-convert.php" method="post">
<fieldset>
<legend>Convert</legend>
<p><label>Text File:</label> <input name="txtfile" class="input1" type="text" value="members.txt"></p>
<p class="tc"><input name="action" style="padding: 2px;" type="submit" value="Convert"></p>
</fieldset>
</form>
<?php
}
?>
</div>

</body>
</html>
