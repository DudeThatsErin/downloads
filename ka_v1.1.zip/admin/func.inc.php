<?php
# 'FUNC.INC' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin 
------------------------------------------------------------- */

# -- Get Cleaning Functions ---------------------------------
# -----------------------------------------------------------
function cleanMys($post, $type = 'all', $symb = 'all') {
 if($type == 'all') {
  $post = strip_tags($post);
 }
 
 if($symb == 'all') {
  $post = trim(htmlentities($post, ENT_QUOTES, 'UTF-8'));
 } elseif ($symb == 'nom') {
  $post = trim($post);
 } else 
  $post = trim(htmlentities($post, ENT_NOQUOTES, 'UTF-8'));
	
 if(get_magic_quotes_gpc())
  $post = stripslashes($post);
	
 $post = mysql_real_escape_string($post);
 return $post;
}

function cleanUpt($post) {
 $post = strip_tags($post);
 $post = trim(htmlentities($post, ENT_QUOTES, 'UTF-8'));
 return $post;
}

# -- Get 'displayError' Function ----------------------------
# -----------------------------------------------------------
# -- Get 'displayError' Function ----------------------------
# -----------------------------------------------------------
function displayError($title, $body, $admin = true, $query = 'nom') {
global $connect;

echo "<h3>" . $title . "</h3>\n";

if($title == 'Database Error') {
 $class = "mysql";
} elseif ($title == 'Script Error') {
 $class = "php";
} else
 $class = "error";
 
if($title == 'Database Error') {
 $p = "mysqlButton";
} elseif ($title == 'Script Error') {
 $p = "errorButton";
} else
 $p = "errorButton";

$bodies = explode('|', $body);
foreach($bodies as $b) {
 echo "<p class=\"{$p} tb\">" . $b . "</p>\n";
}

if(isset($_COOKIE['kalog']) && $admin) {
 echo "<h3>Debug Mode</h3>\n<p>There seems to be a few (hopefully minor) issues with the script:</p>\n"; 
 echo "<p class=\"$p\"><span class=\"$class\">MySQL Errors:</span> ";
 if($query != 'nom') {
  echo mysql_error($connect);
  echo "\n<br><em>" . $query . "</em></p>\n";
 } else {
  echo "</p>\n";
 }
}
 
exit();
}

# -- Get 'backLink' Function --------------------------------
# -----------------------------------------------------------
function backLink($type, $id = 'n') {
global $adminH;

if($type == 'emails')
 $link = "\n" . '<p class="backLink">&laquo; <a href="' . $adminH . '">Back to Control Panel</a>' . "</p>\n";
elseif ($type == 'list') {
 if($id != 'n') {
  $link = "\n" . '<p class="backLink">&laquo; <a href="listings.php?get=old&amp;id=' . $id . '">Back to Listing</a>' . "</p>\n";
 } else {
  $link = "\n" . '<p class="backLink">&laquo; <a href="listings.php">Back to Listings</a>' . "</p>\n";
 }
} elseif ($type == 'mem') {
 if($id != 'n') {
  $link = "\n" . '<p class="backLink">&laquo; <a href="members.php?get=old&amp;id=' . $id . '">Back to Member</a>' . "</p>\n";
 } else {
  $link = "\n" . '<p class="backLink">&laquo; <a href="members.php">Back to Members</a>' . "</p>\n";
 }
} elseif ($type == 'opt')
 $link = "\n" . '<p class="backLink">&laquo; <a href="options.php">Back to Options</a>' . "</p>\n";
 
return $link;
}

# -- Is Page Function ---------------------------------------
# -----------------------------------------------------------
function isPage() {
 return basename($_SERVER['PHP_SELF']);
}

# -- Is Year Function ---------------------------------------
# -----------------------------------------------------------
function isYear($o) {
 $y = date("Y");
 if($o == $y) {
  return $o;
 } else {
  return $o . "-" . $y;
 }
}

# -- Edit Option Function -----------------------------------
# -----------------------------------------------------------
function editOption($option, $value) {
global $_KA;

if(get_magic_quotes_gpc())
 $value = stripslashes($value);
 
$value = mysql_real_escape_string($value);

$update = "UPDATE `$_KA[optionsTable]` SET `text` = '$value' WHERE `name` = '$option' LIMIT 1";
@mysql_query("SET NAMES 'utf8';");
$true = mysql_query($update);
 if($true == false) {
  displayError('Database Error', 'Unable to update the specified option.', true, $update);
 } 
 
 else {
  echo '<p class="successButton"><span class="success">SUCCESS!</span> Your <samp>' . $option . 
	"</samp> option has been edited! :D</p>\n";
 }
}

# -- Get Option Function ------------------------------------
# -----------------------------------------------------------
function getOption($option) {
global $_KA;

$select = "SELECT `text` FROM `$_KA[optionsTable]` WHERE `name` = '$option' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Cannot select option from the database.|Make sure your options table exists.');
}
$getItem = mysql_fetch_array($true);

return $getItem['text'];
} 

# -- Count Function -----------------------------------------
# -----------------------------------------------------------
function getCount($cat) {
global $_KA;

$select = "SELECT * FROM";
if($cat == 'current')
 $select .= " `$_KA[mainTable]` WHERE `mPending` = '0'";
elseif ($cat == 'pending')
 $select .= " `$_KA[mainTable]` WHERE `mPending` = '1'";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the specific table.|Make sure your table(s) exist.');
}
$count = mysql_num_rows($true);

return $count;
}

# -- Count Function (listings) ------------------------------
# -----------------------------------------------------------
function countListings() {
global $_KA;

if($_KA['scriptData'] == 'y') {
 $select = "SELECT * FROM `$_KA[otherTable]`";
} else 
 $select = "SELECT * FROM `$_KA[valuesTable]`";

$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the listings from the specified table.|Make sure your table(s) exist.', false);
}
$count = mysql_num_rows($true);

return $count;
}

# -- get Subject Function -----------------------------------
# -----------------------------------------------------------
function getSubject($id) {
global $_KA;

 if($_KA['scriptData'] == 'y') {
  $select = "SELECT `$_KA[listingsSb]` FROM `$_KA[otherTable]` WHERE `$_KA[listingsID]` = '$id'";
	$true = mysql_query($select);
	if($true == false) {
   displayError('Database Error', 'Unable to select the subject from the specified listing ID.|' . 
	 'Make sure your table(s) exist.', false);
  }
  $count = mysql_num_rows($true);
	$getItem = mysql_fetch_array($true);
	return $getItem["$_KA[listingsSb]"];
 }
 
 elseif ($_KA['scriptData'] == 'n') {
  $select = "SELECT `fSubject` FROM `$_KA[valuesTable]` WHERE `fID` = '$id'";
	$true = mysql_query($select);
	if($true == false) {
   displayError('Database Error', 'Unable to select the subject from the specified listing ID.|' . 
	 'Make sure your table(s) exist.', false);
  }
  $getItem = mysql_fetch_array($true);
	return $getItem['fSubject'];
 }
}

# -- Get Members ID -----------------------------------------
# -----------------------------------------------------------
function getMember($id) {
global $_KA;

$select = "SELECT * FROM `$_KA[mainTable]` WHERE `mID` = '$id' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the specified member.', false);
}
$getItem = mysql_fetch_array($true);

return $getItem;
}

# -- get_members_from_listing Function ----------------------
# -----------------------------------------------------------
function pullMembers($id) {
global $_KA;

$select = "SELECT * FROM `$_KA[mainTable]` WHERE `fNiq` = '$id' AND `mPending` = '0'";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the members from the specified listing.|' . 
 'Make sure your member table exists.', false);
}

$all = array();
while($getItem = mysql_fetch_array($true)) {
 $all[] = $getItem;
}

return $all;
}

# -- get_members_from_listing Function (2) ------------------
# -----------------------------------------------------------
function pullEmails($id) {
global $_KA;

$select = "SELECT * FROM `$_KA[mainTable]` WHERE `fNiq` = '$id' AND `mPending` = '0'";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the members from the specified listing.|' . 
 'Make sure your member table exists.', false);
}

$all = array();
while($getItem = mysql_fetch_array($true)) {
 $all[] = $getItem['mEmail'];
}

return $all;
}

# -- Get Member Name Function -------------------------------
# -----------------------------------------------------------
function memberName($id) {
global $_KA;

$select = "SELECT `mName` FROM `$_KA[mainTable]` WHERE `mID` = '$id' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Could not select the title from the database.', false);
}
$getItem = mysql_fetch_array($true);

return $getItem['mName']; 
}

# -- Get Listings Function ----------------------------------
# -----------------------------------------------------------
function getListings($id) {
global $_KA;

if($_KA['scriptData'] == 'y') {
 $select = "SELECT * FROM `$_KA[otherTable]` WHERE `$_KA[listingsID]` = '$id' LIMIT 1";
} else {
 $select = "SELECT * FROM `$_KA[valuesTable]` WHERE `fID` = '$id' LIMIT 1";
}
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the specified listing.', false);
}
$getItem = mysql_fetch_array($true);

return $getItem;
}

# -- Get Mail Function --------------------------------------
#  $type = Type of e-mail, depends on whether we're e-mailing 
#  one person or several. Will be 'm' for multiple or 's' 
#  for single. 
#  $id   = ID of the listing 
#  $t    = Template 
#  $s    = Subject (optional) 
#  $b    = Body (optional) 
#  $e    = E-Mail (optional)
#  $mid  = Member's ID (optional) 
# -----------------------------------------------------------
function mailMembers($type, $id, $t, $s = 'n', $b = 'n', $e = 'n', $mid = 'n') {
global $_KA, $my_name, $my_email;

if($t != 'none') {
$select = "SELECT `text` FROM `$_KA[optionsTable]` WHERE `name` = '$t' LIMIT 1";
$true = mysql_query($select);
 if($true == false) {
	displayError('Database Error', 'Unable to select the specified e-mail template.', false);
 }
$getTemplate = mysql_fetch_array($true);
$template = $getTemplate['text'];
} else 
 $template = trim($b);

$members = pullMembers($id);
if($mid != 'n') {
 $all = getMember($mid);
}

$format = $template;
if($type == 'm') {
 foreach($members as $m) {
  $u = !empty($m['mURL']) ? "<" . $m['mName'] . ">" : "";
  $format = str_replace('{fan-email}', $m['mEmail'], $format);
	$format = str_replace('{fan-name}', $m['mName'], $format);
	$format = str_replace('{fan-url}', $u, $format);
  $format = str_replace('{listing}', getSubject($m['fNiq']), $format);
 }
} elseif ($type == 's') {
 $u = !empty($all['mURL']) ? "<" . $all['mName'] . ">" : "";
 $format = str_replace('{fan-email}', $all['mEmail'], $format);
 $format = str_replace('{fan-name}', $all['mName'], $format);
 $format = str_replace('{fan-url}', $u, $format);
 $format = str_replace('{listing}', getSubject($all['fNiq']), $format);
}
$format = str_replace('{site-name}', getOption('website_name'), $format);
$format = str_replace('{site-join}', getOption('website_join'), $format);
$format = str_replace('{site-kim}', getOption('website_kim'), $format);
$format = str_replace('{site-list}', getOption('website_list'), $format);
$format = str_replace('{site-owner}', getOption('your_name'), $format);
$format = str_replace('{site-update}', getOption('website_update'), $format);
$format = str_replace('{site-url}', getOption('website_url'), $format);

if($type == 's') {
 $email = $e;
} elseif ($type == 'm') {
 $all = pullEmails($id);
 $email = '';
 foreach($all as $a) {
  $email .= $a . ', ';
 }
 $email = trim($email, ', ');
}
if($t == 'adp_temp') {
 $subject = getOption('website_name') . ": Adopting Out";
} elseif ($t == 'apr_temp') {
 $subject = getOption('website_name') . ": Added";
} elseif ($t == 'cls_temp') {
 $subject = getOption('website_name') . ": Closing";
} elseif ($t == 'upd_temp') {
 $subject = getOption('website_name') . ": Update";
} elseif ($t == 'none') {
 $subject = $s;
}
$body = $format;

$headers = "From: $my_name <$my_email>\n";
$headers .= "Reply-To: <$my_email>";

if(mail($email, $subject, $body, $headers)) {
 $r = true;
}
 
else {
 $r = false;
}
 
return $r;
}

# -- Get Member Count ---------------------------------------
# -----------------------------------------------------------
function countMemNumber($s) {
global $_KA;

$select = "SELECT * FROM `$_KA[mainTable]`";
if($s == 0) {
 $select .= " WHERE `mPending` = '0'";
} elseif ($s == 1) 
 $select .= " WHERE `mPending` = '1'";
 
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Cannot select the specified listing from the database.', false);
}
$count = mysql_num_rows($true);

return $count;
}

# -- Get List Updated ---------------------------------------
# -----------------------------------------------------------
function countMemUpdate() {
global $_KA;

$select = "SELECT `mAdd` FROM `$_KA[mainTable]` WHERE `mPending` = '0' ORDER BY `mAdd` DESC LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Cannot select the specified listing from the database.', false);
}
$getItem = mysql_fetch_object($true);

$r = empty($getItem->mAdd) ? 'Date Unavailable' : date('F j, Y', strtotime($getItem->mAdd));

return $r;
}

# -- Check Password -----------------------------------------
# -----------------------------------------------------------
function checkPassword($email, $password, $listing) {
global $_KA;

# -- First, we find out if the member exists in which case --
# -- we'll take it from my hand-dandy fanlisting script, ----
# -- STFU T-Rex! Admin --------------------------------------
$select = "SELECT * FROM `$_KA[mainTable]` WHERE `mEmail` = '$email' AND `fNiq` = '$listing'";
$true = @mysql_query($select);

if(mysql_num_rows($true) == 1) {
 $valid = true;
} else
 $valid = false;

# -- Now let's see if the member exists ---------------------
# -- We HAVE to include $listing, as the same email might ---
# -- appear several times throughout the database -----------
# -----------------------------------------------------------
$select = "SELECT * FROM `$_KA[mainTable]` WHERE `mEmail` = '$email' AND `fNiq` = '$listing'";
$select .= " AND `mPassword` = MD5('$password')";
$true = @mysql_query($select);

if(mysql_num_rows($true) == 1) {
 $valid = true;
} else
 $valid = false;
	
return $valid;
}

# -- Check Passsword (Reset) --------------------------------
# -----------------------------------------------------------
function checkReset($email, $listing) {
global $_KA;

$select = "SELECT * FROM `$_KA[mainTable]` WHERE `mEmail` = '$email' AND `fNiq` = '$listing'";
$true = @mysql_query($select);

if(mysql_num_rows($true) == 1) {
 $valid = true;
} else
 $valid = false;
	
return $valid;
}

# -- reset Password Function --------------------------------
# -----------------------------------------------------------
function resetPassword($password, $email, $listing) {
global $_KA;

$update = "UPDATE `$_KA[mainTable]` SET `mPassword` = '$password' WHERE `mEmail` = '$email'" . 
" AND `fNiq` = '$listing' LIMIT 1";
@mysql_query("SET NAMES 'utf8';");
$true = @mysql_query($update);
}

# -- Get Short URL Function ---------------------------------
# -----------------------------------------------------------
function shortURL($u) {
 $u = str_replace('http://', '', $u);
 $u = str_replace('www.', '', $u);
 $e = explode('/', $u);
 $n = str_replace('/', '', $e[0]);
 return $n;
}

# -- Get JavaScript E-Mail ----------------------------------
# -----------------------------------------------------------
function javascriptEmail($e) {
 $string = "<script language=\"JavaScript\" type=\"text/javascript\">\n<!--\n" . 
 "jmail = ('$e');\ndocument.write('<a href=\"mailto:' + jmail + '\">E-Mail</' + 'a>');\n" . 
 "//-->\n</script>\n";
 return $string;
}

# -- Get JavaScript Cheat -----------------------------------
# -----------------------------------------------------------
function javascriptCheat($p) {
global $_KA;

# -- We should never get here, but just in case -------------
if($_KA['jscheat_opt'] == 'n') {
 return "";
}

if($_KA['markup'] == 'xhtml') {
 $mark = " /"; 
} else 
 $mark = "";
 
 $string = "<script language=\"JavaScript\" type=\"text/javascript\">\n<!--\n" .
 "document.write('<input name=\"cheatcheatCheater\" type=\"hidden\" value=\"" . $p . "\"" . $mark . ">');\n" .
 "//-->\n</script>\n";
 return $string;
}

# -- pullMember Function ------------------------------------
# -----------------------------------------------------------
function pullMember($email, $listing) {
global $_KA;

$select = "SELECT * FROM `$_KA[mainTable]` WHERE `mEmail` = '$email' AND `fNiq` = '$listing' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the specified member.', false);
}
$getItem = mysql_fetch_array($true);

return $getItem;
}

# -- Check Categories ---------------------------------------
# -----------------------------------------------------------
function checkListings($id) {
global $_KA;

$select = "SELECT * FROM `$_KA[mainTable]` WHERE `fNiq` = '$id' AND `mPending` = '0'";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Could not select the listings from the database.', false);
}

if(mysql_num_rows($true) == 0) {
 $valid = false;
} else 
 $valid = true;
 
return $valid;
}

# -- Categories List ----------------------------------------
# -----------------------------------------------------------
function listingsList() {
global $_KA;

if($_KA['scriptData'] == 'y') {
 $select = "SELECT * FROM `$_KA[otherTable]` ORDER BY `$_KA[listingsSb]` ASC";
} else {
 $select = "SELECT * FROM `$_KA[valuesTable]` ORDER BY `fSubject` ASC";
}
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Could not select the categories from the database.', false);
}

$all = array();
while($getItem = mysql_fetch_array($true)) {
 if($_KA['scriptData'] == 'y') {
  $_id = $getItem[$_KA[listingsID]];
 } else {
  $_id = $getItem['fID'];
 }
 $all[] = $_id;
}

return $all;
}

# -- Get Format Template Function ---------------------------
# -----------------------------------------------------------
function format($t, $m = 'n', $e = '', $l = '') {
global $_KA;

$select = "SELECT `text` FROM `$_KA[optionsTable]` WHERE `name` = '$t' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the specified template.', false);
}
$getItem = mysql_fetch_array($true);

if($m == 'y') {
 $member = pullMember($e, $l);
 if($member['mVisible'] == 0) {
  $email = javascriptEmail($member['mEmail']);
 } else
  $email = "<del>E-Mail</del>";
 
 if(!empty($member['mURL'])) {
  $url = "<a href=\"" . $member['mURL'] . "\" title=\"External Link: " . shortURL($member['mURL']) . "\">URL &raquo;</a>";
 } else
  $url = "<del>URL</del>";
	
 if($member['mPrevious'] == 1) {
  $p = "<em>Previous Owner</em>";
 } else
  $p = "";
}

$format = str_replace('{approved}', countMemNumber('0'), str_replace('&amp;', '&', html_entity_decode($getItem['text'])));
if($m == 'y') {
 $format = str_replace('{email}', $email, $format);
 $format = str_replace('{listing}', getSubject($member['fNiq']), $format);
 $format = str_replace('{name}', $member['mName'], $format);
 $format = str_replace('{previous_owner}', $p, $format);
 $format = str_replace('{url}', $url, $format);
}
$format = str_replace('{pending}', countMemNumber('1'), $format);
$format = str_replace('{updated}', countMemUpdate(), $format);

echo $format;
}

# -- show Default Function ----------------------------------
# -----------------------------------------------------------
function showDefault($type) {
global $_KA, $memfoot, $memhead, $per_page, $start;

$query = $_SERVER['QUERY_STRING'];
if(isset($query) && !empty($query)) {
 $_URL = '?' . str_replace('&', '&amp;', $query) . '&amp;';
} else 
 $_URL = '?';


if($type == 'list') {
 $_ALL = listingsList();
 
 echo "<ol>\n";
 foreach($_ALL as $a) {
  if(checkListings($a) == true) {
	 echo '<li><a href="' . $_URL . 'sort=byListing&amp;id=' . $a . '">' . getSubject($a) . "</a></li>\n";
  }
 } 
 echo '<li style="list-style-type: none;"><a href="' . $_URL . 'sort=byListing&amp;id=all' . '">All Listings</a>' . "</li>\n";
 echo "</ol>\n";
}

elseif ($type == 'drop') {
 $_ALL = listingsList();

 if($_KA['markup']) {
  $mark = " /";
 } else
  $mark = "";
 
 echo '<form action="' . $_URL . "\" method=\"get\">\n";
 echo '<input name="sort" type="hidden" value="byListing"' . $mark .">\n\n";
 echo "<p><select name=\"id\" class=\"input1\">\n";
 foreach($_ALL as $a) {
  if(checkListings($a) == true) {
	 echo '<option value="' . $a . '">' . getSubject($a) . "</option>\n";
  }
 } 
 echo "</select>" . ' <input class="input2" type="submit" value="Search"' . $mark . "></p>\n";
 echo "</form>\n";
}

elseif ($type == 'all') {
 $select = "SELECT * FROM `$_KA[mainTable]` WHERE `mPending` = '0' ORDER BY `mName` ASC LIMIT $start, $per_page";
 $true = mysql_query($select);
 if($true == false) {
  displayError('Script Error', 'Unable to select the members from the specified listing.', false);
 }

 if(!empty($memhead)) {
  echo format('mem_head', 'y', $getItem['mEmail'], $getItem['fNiq']);
 }
 while($getItem = mysql_fetch_array($true)) {
  echo format('mem_temp', 'y', $getItem['mEmail'], $getItem['fNiq']);
 }
 if(!empty($memfoot)) {
  echo format('mem_foot', 'y', $getItem['mEmail'], $getItem['fNiq']);
 }
}

}
?>
