<?php
# 'UPGRADE' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin 
------------------------------------------------------------- */
require("rats.inc.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
 "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title> <?php echo $_KA['version']; ?> &#8212; Upgrade </title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>

<div id="install">
<h2>Upgrade Script</h2>
<?php
if(isset($_POST['action']) && $_POST['action'] == 'Upgrade Script') {
$bots = "/(Indy|Blaiz|Java|libwww-perl|Python|OutfoxBot|User-Agent|PycURL|" . 
"AlphaServer|T8Abot|Syntryx|WinHttp|WebBandit|nicebot|Jakarta|curl|Snoopy|" . 
"PHPcrawl|id-search)/i";
if(preg_match($bots, $_SERVER['HTTP_USER_AGENT']) || empty($_SERVER['HTTP_USER_AGENT'])) {
 exit('<p class="error">Known SPAM bots aren\'t allowed.</p>');
}

# Validate and Such:
function cleanInput($post, $type = 'all') {
 if($type == 'all') {
  $post = strip_tags($post);
 }
 $post = htmlentities($post, ENT_QUOTES, 'UTF-8');
 return mysql_real_escape_string($post);
}  

# -- Check for "password change"; even so, we're doing it FIRST --
$check = cleanInput($_POST['password']);
if($check == 'yes') {
 $alter = "ALTER TABLE `$_KA[mainTable]` ADD `mPassword` varchar(255) NOT NULL AFTER `mURL`";
 $true = mysql_query($alter);
 if($true == false) {
  exit('<p><span class="mysql">Error:</span> ' . mysql_error() . ' <em>' . $alter . '</em></p>');
 }
}

# -- Add 'previous owner': --
$alter = "ALTER TABLE `$_KA[mainTable]` ADD `mPrevious` tinyint(1) NOT NULL DEFAULT '0' AFTER `mPending`";
$true = mysql_query($alter);
if($true == false) {
 exit('<p><span class="mysql">Error:</span> ' . mysql_error() . ' <em>' . $alter . '</em></p>');
}

# -- Add E-Mail Templates: --
$adopting = mysql_real_escape_string("Hello {fan-name},

You are receiving this e-mail because you (or someone else) used this email address to sign up as a member of {site-name}'s KIM list. If this is in error, please reply to this email and tell me and I will remove you from the list as soon as possible.

The {listing} listing has been put up for adoption, and you are currently listed as a new potentional owner of this listing. If you are interested in adopting this listing, reply to this e-mail or use this form <{site-url}/adopt>. I look forward to hearing from you! :)

--
{site-owner}
{site-name} KIM List
<{site-url}>");
$closing = mysql_real_escape_string("Hello {fan-name},

You are receiving this e-mail because you (or someone else) used this email address to sign up as a member of {site-name}'s KIM list. If this is in error, please reply to this email and tell me and I will remove you from the list as soon as possible.

The {listing} listing has closed, and you are currently listed as a new potentional owner of this listing. If you are interested in opening this listing and receiving the members list, reply to this e-mail. I look forward to hearing from you! :)

--
{site-owner}
{site-name} KIM List
<{site-url}>");

$insert = "INSERT INTO `$_KA[optionsTable]` VALUES ('adp_temp', '$adopting'), 
('cls_temp', '$closing')";
@mysql_query("SET NAMES 'utf8';");
$true = mysql_query($insert);
if($true == false) {
 exit('<p><span class="mysql">Error:</span> ' . mysql_error() . "<br />\n<em>" . $insert . '</em></p>');
}
?>
<p class="successButton"><span class="success">Success!</span> The upgrading process has ended and you have upgraded your script! 
For security purposes, please remember to delete this file from your server. Have fun and <a href="index.php">log in</a>! :D</p>
<?php
}

else {
?>
<p>Welcome to <samp>upgrade.php</samp>, the tool to upgrading your KIM script. There is only one
step, which is reviewing your information and editing the essentials.</p>
<p>Please be aware that you must have installed <samp>KIM Admin 1.0 Beta</samp> prior; this is <em>only</em> for
upgrade your script. After running the installation, delete this file from your webserver <em>as soon as you finish</em>. 
Consult the <samp>readme.txt</samp> file for further instructions.</p>

<form action="upgrade.php" method="post">
<fieldset>
<legend>Database Changes</legend>
<p>There are <em>four</em> database changes, which includes adding a password field in the members table (a bug
that was in the beta version), a previous owner field and two e-mail templates. The last three are required, while
the first is not. This is due to a bugfix being released before. <em>Please</em>, read through this file
carefully!</p>
</fieldset>

<fieldset>
<legend>Optionanl</legend>
<p><label><strong>Password Field:</strong><br>
Optional due to a previous bugfix being released. If you have no fixed this bug, tick 'yes'.
</label> <input name="password" class="input3" type="checkbox" value="yes"> Yes</p>
</fieldset>

<fieldset>
<legend>Submit</legend>
<p class="tc"><input name="action" class="input2" type="submit" value="Upgrade Script"></p>
</fieldset>
</form>
<?php
}
?>
</div>

</body>
</html>
