<?php
# 'EMAILS' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin 
------------------------------------------------------------- */
$getTitle = "E-Mails";
require("pro.inc.php");
require("vars.inc.php");
require("header.php");

echo "<h2>{$getTitle}</h2>\n";

if(isset($_GET['type']) && !empty($_GET['type'])) {
 if(isset($_GET['type']) && $_GET['type'] == 'single') {
 $id = cleanMys((int)$_GET['id']);
  if(empty($id) || !ctype_digit($id)) {
  displayError('Script Error', 'Your ID is empty. This means you selected an incorrect member or' . 
  ' you\'re trying to access something that doesn\'t exist. Go back and try again.', false);
  }
 $mid = cleanMys((int)$_GET['mid']);
  if(empty($mid) || !ctype_digit($mid)) {
  displayError('Script Error', 'Your ID is empty. This means you selected an incorrect member or' . 
  ' you\'re trying to access something that doesn\'t exist. Go back and try again.', false);
  }
 # -- Continue, correct ID -- 
 $all = getMember($mid);
 ?>
<form action="emails.php" method="post">
<input name="listingid" type="hidden" value="<?php echo $id; ?>">
<input name="memberid" type="hidden" value="<?php echo $mid; ?>">
<fieldset>
<legend>E-Mail Member</legend>
<p>You are choosing to e-mail the <strong><?php echo $all['mName']; ?></strong> member from the
<strong><?php echo getSubject($all['fNiq']); ?></strong> listing. Below are two options: a e-mail template 
(which can edit through <a href="options.php">&raquo; Options</a>) and a
subject and body field for a more personalized e-mail. For templates, visit the <a href="readme.txt">readme.txt</a>
file.</p>
<p><em>As of the current version, there is only two e-mail templates: adoption or closing.</em></p>
<p><label>Template:</label> <select name="template" class="input1">
<option value="none">None</option>
<option value="adp_temp">Adoption: Adopting</option>
<option value="cls_temp">Adoption: Closing</option>
</select></p>
<p><label>Subject:</label> <input name="subject" class="input1" type="text"></p>
<p><label>E-Mail:</label><br><textarea name="email" cols="50" rows="8" style="width: 100%;"></textarea></p>
<p class="tc"><input name="action" type="submit" value="E-Mail Member"></p>
</fieldset>
</form>
 <?php
 }
 
 elseif (isset($_GET['type']) && $_GET['type'] == 'multiple') {
 $id = cleanMys((int)$_GET['id']);
  if(empty($id) || !ctype_digit($id)) {
  displayError('Script Error', '<p class="error">Your ID is empty. This means you selected an incorrect member or' . 
  ' you\'re trying to access something that doesn\'t exist. Go back and try again.</p>', false);
  }
 # -- Continue, correct ID -- 
 # -- Check if listing actually has members:
 $select = "SELECT * FROM `$_KA[mainTable]` WHERE `fNiq` = '$id'";
 $true = @mysql_query($select);
 if(mysql_num_rows($true) == 0) {
	displayError('Script Error', 'It appears there are no members in the listing you would like to e-mail.', false);
 }
	
 else {
 ?>
<form action="emails.php" method="post">
<input name="listingid" type="hidden" value="<?php echo $id; ?>">
<fieldset>
<legend>E-Mail Members</legend>
<p>You are choosing to e-mail all members from the <strong><?php echo getSubject($id); ?></strong> listing. 
Below are two options: a e-mail template (which can edit through <a href="options.php">&raquo; Options</a>) and a
subject and body field for a more personalized e-mail. For templates, visit the <a href="readme.txt">readme.txt</a>
file.</p>
<p><em>As of the current version, there is only two e-mail templates: adoption or closing.</em></p>
<p><label>Template:</label> <select name="template" class="input1">
<option value="none">None</option>
<option value="adp_temp">Adoption: Adopting</option>
<option value="cls_temp">Adoption: Closing</option>
</select></p>
<p><label>Subject:</label> <input name="subject" class="input1" type="text"></p>
<p><label>E-Mail:</label><br><textarea name="email" cols="50" rows="8" style="width: 100%;"></textarea></p>
<p class="tc"><input name="action" type="submit" value="E-Mail Members"></p>
</fieldset>
</form>
 <?php
 }
 }
}

elseif (isset($_POST['action']) && $_POST['action'] == 'E-Mail Member') {
$listingid = cleanMys((int)$_POST['listingid']);
if(empty($listingid) || !ctype_digit($listingid)) {
 displayError('Script Error', 'Your <samp>listing</samp> field is invalid.', false);
} 
$memberid = cleanMys((int)$_POST['memberid']);
if(empty($memberid) || !ctype_digit($memberid)) {
 displayError('Script Error', 'Your <samp>member ID</samp> field is invalid.', false);
} 
$template = cleanMys($_POST['template']);
$subject = cleanMys($_POST['subject']);
$email = trim($_POST['email']);
$members = getMember($memberid);
 
$mail = mailMembers('s', $listingid, $template, $subject, $email, $members['mEmail'], $memberid);
	
if($mail) {
 echo "<p class=\"successButton\"><span class=\"success\">Success!</span> Your email has been sent!</p\n";
}
echo backLink('emails');
}

elseif (isset($_POST['action']) && $_POST['action'] == 'E-Mail Members') {
$listingid = cleanMys((int)$_POST['listingid']);
if(empty($listingid) || !ctype_digit($listingid)) {
 displayError('Script Error', 'Your <samp>listing</samp> field is invalid.', false);
} 
$template = cleanMys($_POST['template']);
$subject = cleanMys($_POST['subject']);
$email = trim($_POST['email']);
 
$mail = mailMembers('m', $listingid, $template, $subject, $email);
	
if($mail) {
 echo "<p class=\"successButton\"><span class=\"success\">Success!</span> Your email has been sent!</p\n";
}
echo backLink('emails');
}

else {
?>
<p>Use the form below to e-mail members from a particular listing. To e-mail a member individually, go to the
<a href="members.php">&raquo; Members</a> page.</p>

<h3>E-Mail Members from a Listing</h3>
<form action="emails.php" method="get">
<input name="type" type="hidden" value="multiple">
<fieldset>
<legend>Listings</legend>
<p><label>Listings:</label> <select name="id" class="input1">
<?php
if($_KA['scriptData'] == 'y') {
 $select = "SELECT * FROM `$_KA[otherTable]` ORDER BY `$_KA[listingsSb]` ASC";
} else {
 $select = "SELECT * FROM `$_KA[valuesTable]` ORDER BY `fSubject` ASC";
}
$true = @mysql_query($select);

while($getTion = mysql_fetch_array($true)) {
 if($_KA['scriptData'] == 'y') {
  $_id = $getTion["$_KA[listingsID]"];
  $_sb = $getTion["$_KA[listingsSb]"];
 } else {
  $_id = $getTion['fID'];
  $_sb = $getTion['fSubject'];
 }
 echo '<option value="' . $_id . '">' . $_sb . '</option>' . "\n";
}
?>
</select></p>
<p class="tc"><input class="input2" type="submit" value="E-Mail Members"></p>
</fieldset>
</form>
<?php
}

require("footer.php");
?>
