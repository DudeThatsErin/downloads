</div>

<div id="footer">
<p><strong><?php echo $_KA['version']; ?></strong> &copy; <?php echo isYear('2008'); ?> (<em>Tess Ally</em>)</p>
</div>

</div>

</body>
</html>
