<div id="show-members">
<?php
# 'SHOW-MEMBERS' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin  
------------------------------------------------------------- */
require("rats.inc.php");
require_once("func.inc.php");
require("vars.inc.php");

# -- Get Variables, yo' -------------------------------------
if(!isset($_GET['page']) || empty($_GET['page']) || !ctype_digit($_GET['page'])) {
 $page = 1;
} else 
 $page = cleanMys((int)$_GET['page']);
$start = mysql_real_escape_string((($page * $per_page) - $per_page));

$query = $_SERVER['QUERY_STRING'];
if(isset($query) && !empty($query)) {
 if(isset($_GET['page'])) {
	$_URL = '?';
	$query = str_replace($_GET['page'], '', $query);
	$query = str_replace('&amp;page=', '', $query);
	$query = str_replace('&page=', '', $query);
	$query = str_replace('page=', '', $query);
	$query = str_replace('&', '&amp;', $query);
	$_URL .= $query;
 } else {
  $_URL = '?' . str_replace('&', '&amp;', $query) . '&amp;';
 }
} else 
 $_URL = '?';

# -- Get SQL queries ----------------------------------------
$select = "SELECT * FROM `$_KA[mainTable]` WHERE `mPending` = '0'";
$true = mysql_query($select);
if($true == false) {
 displayError('Script Error', 'Unable to select the members.', false);
}
$count = mysql_num_rows($true);

if($count > 0) {
 if(isset($_GET['sort']) && $_GET['sort'] == 'byListing') {
 if(ctype_digit($_GET['id']) && $_GET['id'] != 'all') {
 $id = cleanMys((int)$_GET['id']);
 $idArray = listingsList();
  if(empty($id) || !in_array($id, $idArray)) {
	displayError('Script Error', 'In order to search members by the listing, you need to ' . 
	'<a href="' . $formList . '">&raquo; select a listing</a>.', false);
	}
 # -- Continue, no empty ID: 
 $select = "SELECT * FROM `$_KA[mainTable]` WHERE `mPending` = 0 AND `fNiq` = '$id'"; 
 $select .= " ORDER BY `mName` LIMIT $start, $per_page";
 $true = mysql_query($select);
  if($true == false) {
	displayError('Script Error', 'Unable to select the member(s) from the specified listing.', false);
	}
 # -- Continue, no bad query: 
 echo '<p class="tc">You are currently viewing members in the <strong>' . getSubject($id) . "</strong> listing.</p>\n";
	
  if(!empty($memhead)) {
   echo format('mem_head', 'y', $getItem['mEmail'], $getItem['fNiq']);
  }
  while($getItem = mysql_fetch_array($true)) {
   echo format('mem_temp', 'y', $getItem['mEmail'], $getItem['fNiq']);
  } 
	if(!empty($memfoot)) {
   echo format('mem_foot', 'y', $getItem['mEmail'], $getItem['fNiq']);
  }
 }
 
 elseif (!ctype_digit($_GET['id']) && $_GET['id'] == 'all') {
 # -- Continue, no empty ID: 
 $select = "SELECT * FROM `$_KA[mainTable]` WHERE `mPending` = '0'"; 
 $select .= " ORDER BY `mName` LIMIT $start, $per_page";
 $true = mysql_query($select);
  if($true == false) {
	displayError('Script Error', 'Unable to select the members from the specified listing.', false);
	}
 # -- Continue, no bad query: 
 echo "<p class=\"tc\">You are currently viewing <strong>all</strong> members.</p>\n";
 
  if(!empty($memhead)) {
   echo format('mem_head', 'y', $getItem['mEmail'], $getItem['fNiq']);
  }
  while($getItem = mysql_fetch_array($true)) {
   echo format('mem_temp', 'y', $getItem['mEmail'], $getItem['fNiq']);
  } 
	if(!empty($memfoot)) {
   echo format('mem_foot', 'y', $getItem['mEmail'], $getItem['fNiq']);
  }
 }

 
 echo "\n<p id='back'><a href=\"javascript:history.go(-1)\">&laquo; Go Back</a></p>\n";
 echo "\n<p id='pagination'>\n";
 $gid = cleanMys((int)$_GET['id']);
 $gidArray = listingsList();
 $select = "SELECT * FROM `$_KA[mainTable]` WHERE `mPending` = '0'";
  if($_GET['id'] != 'all' && ctype_digit($_GET['id']) && in_array($gid, $gidArray))
   $select .= " AND `fNiq` = '$gid'";
 $true = @mysql_query($select);
 $total = @mysql_num_rows($true);
 $pages = ceil($total/$per_page);
 
 $prev = ($page - 1);
 if($page > 1) {
  echo '<a href="' . $_URL . 'page=' . $prev . '">&laquo; Previous</a> ';
 } else {
  echo '&laquo; Previous ';
 }

 for($i = 1; $i <= $pages; $i++) {
  if($page == $i) {
   echo $i . " ";
  } else {
   echo '<a href="' . $_URL . 'page=' . $i . '">' . $i . '</a> ';
  }
 }
		
 $next = ($page + 1);
 if($page < $pages) {
  echo '<a href="' . $_URL . 'page=' . $next . '">Next &raquo;</a>';
 } else {
  echo 'Next &raquo;';
 }
 echo "</p>\n";
 }

 else {
  if($memsort == 'list') {
	 echo showDefault('list');
	} elseif ($memsort == 'drop') {
	 echo showDefault('drop');
	} elseif ($memsort == 'all') {
	 echo showDefault('all');
	} else {
	 echo showDefault('list');
	}
	
	if($memsort == 'all') {
	echo "<p id='pagination'>\n";
	$select = "SELECT * FROM `$_KA[mainTable]` WHERE `mPending` = '0'";
    $true = @mysql_query($select);
     $total = @mysql_num_rows($true);
  $pages = ceil($total/$per_page);
 
  $prev = ($page - 1);
  if($page > 1) {
   echo '<a href="' . $_URL . 'page=' . $prev . '">&laquo; Previous</a> ';
  } else {
   echo '&laquo; Previous ';
  }

  for($i = 1; $i <= $pages; $i++) {
   if($page == $i) {
    echo $i . " ";
   } else {
    echo '<a href="' . $_URL . 'page=' . $i . '">' . $i . '</a> ';
   }
  }
		
	$next = ($page + 1);
  if($page < $pages) {
   echo '<a href="' . $_URL . 'page=' . $next . '">Next &raquo;</a>';
  } else {
   echo 'Next &raquo;';
  }
	echo "</p>\n";
	}
 }
?>

<p style="text-align: center;">
Powered by <a href="<?php echo $_KA['scriptURI']; ?>"><?php echo $_KA['version']; ?></a>
</p>
<?php
}

else {
echo('<p class="tc">Currently no members!</p>' . "\n");
}
?>
</div>
