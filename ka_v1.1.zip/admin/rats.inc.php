<?php
# 'RATS' FILE 
/* ----------------------------------------------------------
Tess Ally 2008 � KIM Admin 
------------------------------------------------------------- */
if('rats.inc.php' === basename($_SERVER['PHP_SELF'])) {
 die('ERROR: You cannot access this file directly!');
}

# -- Database Variables -------------------------------------
#  $database_host - MySQL Host (usually localhost)
#  $database_user - MySQL username 
#  $database_pass - MySQL password 
#  $database_name - MySQL database name (if you're pulling 
#  your listings from Enthusiast or a personal script, be 
#  sure this database is the same database your Enthusiast
#  tables are held in!) 
# -----------------------------------------------------------
$database_host = "localhost";
$database_user = "";
$database_pass = "";
$database_name = "";

# -- Table Variables ----------------------------------------
#  $_KA['mainTable']    - Main table (where members are held)
#  $_KA['optionsTable'] - Options table 
#  $_KA['valuesTable']  - Values table (this is to be used if 
#  you are NOT pulling from Enthusiast).
# -----------------------------------------------------------
$_KA['mainTable'] = "ka_main";
$_KA['optionsTable'] = "ka_options";
$_KA['valuesTable'] = "ka_values";

# -- Enthusiast Table ---------------------------------------
#  If you run Enthusiast 3+, you can pull your listings from 
#  the "owned" table. Please be aware you must have your 
#  tables in the same database as your Enthusiast table, and 
#  you must set $_KA['scriptData'] to "y" below.
# 
#  NOTE: If you run your own fanlisting collective script in  
#  the same way Enthusiast 3+ runs, you can enter your own 
#  table. 
# -----------------------------------------------------------
$_KA['otherTable'] = "owned";

# -- Pull Listings from Enthusiast --------------------------
#  The option, $_KA['scriptData'], decides if you'd like the 
#  fanlistings pulled from Enthusiast. This should be set to 
#  off ('n') if you are NOT pulling listings from Enthusiast. 
# 
#  To set this on, enter 'y' and to set it off, enter 'n'.
# -----------------------------------------------------------
$_KA['scriptData'] = 'n';

# -- Listing Database Variables -----------------------------
#  * This option only needs to be edited if you're pulling 
#  your listings from a second table.
# 
#  $_KA['listingsID'] - name of the ID field to each listing 
#  $_KA['listingsSb'] - name of the subject field for each 
#  listing.
# ----------------------------------------------------------- 
$_KA['listingsID'] = 'listingid';
$_KA['listingsSb'] = 'subject';

# -- HTML Mark Up Choice ------------------------------------
#  Some users (like myself) like having valid HTML, but
#  sometimes users want one (X/HTML) over the other. This
#  will affect only the forms and members list (such as 
#  line breaks (<br>).
#
#  You can choose from using XHTML (for instance: <br />, 
#  <img src="" />) or HTML (<br>, <img src="">). By default, it 
#  is set to XHTML.
#
#  For XHTML: $_KA['markup'] = 'xhtml';
#  For HTML:  $_KA['markup'] = 'html';
# 
# -----------------------------------------------------------
$_KA['markup'] = 'xhtml';

# -- Anti-SPAM Options --------------------------------------
#  There two options for anti-SPAM options: Akismet, a plugin 
#  to fight off SPAM, and JavaScript cheat, which sets two  
#  random strings to check against. Both options are optional
#  will be used only on all forms.
#  
#  If you do decide to use Akismet, you need only one thing,
#  which would be your WordPress API key. If you do not have 
#  one, you can obtain one by creating an account at 
#  <http://wordpress.org> To turn Akismet off:
#  
#  $_KA['askimet_opt'] = 'n';
# 
#  To turn on, simply use y instead of n. $_KA['akismet_key']
#  should be your API key.
# 
#  $_KA['jscheat_opt'] should be set to 'n' to turn off, and 
#  'y' to turn on. 
# 
#  $_KA['jscheat_key'] should be a random string, including 
#  letters, numbers and symbols. Example:
# 
#  $_KA['jscheat_key'] = 'hjelodnfdhj-37437bz328@@fr^^&0';
# -----------------------------------------------------------
$_KA['akismet_opt'] = 'n';
$_KA['akismet_key'] = '';

$_KA['jscheat_opt'] = 'y';
$_KA['jscheat_key'] = '859003nfndj9547bfdk583408247ansfh58';

# -- Password -----------------------------------------------
# -----------------------------------------------------------
#  Password to log into your admin. Please remember 
#  to keep it long (no less than 8 characters, no 
#  more than 40 characters) and hard to guess. The 
#  only symbols accepted are: !, - and _ Use the 
#  following examples for reference: 
# 
#  $_KA['hide_password'] = md5('!ilovebluecolors89!');
#  $_KA['hide_password'] = md5('iamgodofmyhouse2008!');
# -----------------------------------------------------------
$_KA['hide_username'] = "admin";
$_KA['hide_password'] = md5('p5ssw0rdn0wplz');

# -- Password Hash ------------------------------------------
# 
#  Password hash is your "salt" for better security. It needs
#  to be random and long, with any type of characters. Here
#  are some examples:
# 
#  $_KA['hash_password'] = '!2006!_t3ssisagoddontyaknow_!2004!';
#  $_KA['hash_password'] = '!4565!dnfdjbhbtessisthebest584mfdd!';
# 
# -----------------------------------------------------------
$_KA['hash_password'] = '90w78sdgj869578nrwny49$6yn4jgn4793(rneu)5je';

# -- STOP EDITING HERE! -------------------------------------
# -----------------------------------------------------------
# 
#  Below this line are sensitive lines that should NOT be 
#  messed with unless you know exactly what you're doing.
# 
# -----------------------------------------------------------
# -----------------------------------------------------------

# -- Script Name and Version --------------------------------
# -----------------------------------------------------------
$_KA['version'] = 'KIM Admin 1.1';
$_KA['scriptURI'] = 'http://keepitpumpin.net/scripts/kimadmin/';

# -- Get MySQL ----------------------------------------------
# -----------------------------------------------------------
$connect = mysql_connect($database_host, $database_user, $database_pass)
 or die('<p><span class="error">ERROR:</span> You cannot currently connect to MySQL.' . 
 ' Make sure all variables are correct in <samp>rats.inc.php</samp>; if it is a random' . 
 ' error, wait it out and see if it\'ll magically disappear.</p>');
$database = mysql_select_db($database_name)
 or die('<p><span class="error">ERROR:</span> You cannot currently connect to your database.' . 
 ' Make sure all variables are correct in <samp>rats.inc.php</samp>; if it is a random' . 
 ' error, wait it out and see if it\'ll magically disappear.</p>');
?>
