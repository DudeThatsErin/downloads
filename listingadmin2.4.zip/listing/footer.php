</section>

<footer>
 <p><strong>Example</strong> &#169; <?php echo $fanlisting->isYear('2007'); ?></p>
</footer>

</div>

</body>
</html>
