
<div id="feeds">
 <div id="lafeeds">
  <h4>Listing Admin Feed at Pumpin'!</h4>
<?php  
 $startnumero = 0;
 $feedurl = "http://scripts.wyngs.net/feed/?c=19";

 require_once('inc/fetch/rss_fetch.inc');
 $catchme = fetch_rss($feedurl);
 echo "  <menu>\n";
 $items = array_reverse($catchme->items);
 foreach($items as $item) {  
  $n = $startnumero == 2 ? " id=\"last\"" : '';
  $unotitle = strripos($item['title'], LAVERSION) != false ? 
  "Listing Admin " . LAVERSION : $item['title'];
	echo "   <li class=\"block\"$n><strong>" . $unotitle . "</strong><br>\n";
	// echo "   <p>" . substr($item['description'], 0, 200) . "</p>\n";
	echo "   <a href=\"" . $item['guid'] . "\" title=\"External Link: scripts.wyngs.net\">Read More &#187;</a></li>\n";
	if($startnumero == 2) {
	 break;
	}
  $startnumero++;
 }
 echo "  </menu>\n";
?>
 </div>

 <div id="bugfixfeeds">
  <h4 class="tr"><ins><?php echo $laoptions->version; ?></ins> Bugfix Feed</h4>
  <p>This feed is only here for checks of bugfixes of the current version. Bugfixes
  will only be listed here if there is bugfix(es) for the current version of Listing 
  Admin and you will be taken to the <strong>Downloads</strong> page at 
  <a href="http://scripts.wyngs.net/" title="External Link: scripts.wyngs.net">Pumpin'! &#187;</a>
  to download the bugfix .zip file.</p>
<?php 
 $startdigit = 0;
 $bugfixurl = "http://scripts.wyngs.net/listingadmin/";
 $imp       = explode('Listing Admin ', $laoptions->version);

 require_once('inc/fetch/rss_fetch.inc');
 $ifyoucan = fetch_rss($bugfixurl);
 $object   = $ifyoucan->items;
 if(count($object) == 0) {
  echo "  <p class=\"tc\">Currently no bugfixes for the current version!</p>\n";
 } 
 
 else {
  echo "  <menu>\n";
  foreach($object as $obc) {  
	 echo "   <li><a href=\"http://scripts.wyngs.net/downloads/\" title=\"External Link:" . 
	 " Downloads\">" . str_replace($imp[1], '', $obc['description']) . "</a></li>\n";
   $startdigit++;
	}
	echo "  </menu>\n";
 }
?>
 </div>
 <section class="clear"></section>
</div>
</section>

</div>

<footer>
 <p><strong><?php echo $laoptions->version; ?></strong> &#169; <?php echo $leopards->isYear('2007'); ?> <em>Tess</em></p>
</footer>

</div>

<script src="js.js" type="text/javascript"></script>
<script src="jquery.js" type="text/javascript"></script>
<script src="jquery-custom.js" type="text/javascript"></script>

</body>
</html>
