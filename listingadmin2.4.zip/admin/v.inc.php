<?php 
/* 
 /////////////////////////////////////////////////////////////
 Listing Admin (c) 2007 
 ///////////////////////////////////////////////////////////// 
*/ 
/** 
 *  @copyright   2007 
 *  @license     GPL Version 3; BSD Modified 
 *  @author      Tess <theirrenegadexxx@gmail.com> 
 *  @file        <rats.inc.php> 
 *  @since       September 2nd, 2011 
 *  @version     2.1.9 
 */ 
$_ST = array();

if(!defined('LAVERSION')) {
 define('LAVERSION', '2.4');
}

/**  
 * Grab login object! 
 */  
$loginInfo = (object) array(
 'logBots' => "/(Indy|Blaiz|Java|libwww-perl|Python|OutfoxBot|User-Agent|PycURL|" . 
 "AlphaServer|T8Abot|Syntryx|WinHttp|WebBandit|nicebot|Jakarta|curl|Snoopy|" . 
 "PHPcrawl|id-search)/i",
 'logInfo' => "|" . $_SERVER['REMOTE_ADDR'] . "|" . $_SERVER['HTTP_USER_AGENT'] . "|",
 'logNots' => array("alert", "bcc:", "content-type", "document.cookie", 
 "javascript", "onclick", "onload")
);
?>
