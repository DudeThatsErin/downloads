<?php  
# 'B.INC.PHP' FILE 
/* ----------------------------------------------------------
Tess Ally 2007 � Listing Admin 
------------------------------------------------------------- */
if(defined('MAINDIR') == false) {
 define('MAINDIR', str_replace('inc', '', dirname(__FILE__)));
}
?>
