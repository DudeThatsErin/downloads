<?php
	/* This part of PHP is required for the page to work. */
	$site_sub_title = 'Update';
	include_once('includes/header.inc.php');
	include_once(PHPFANLIST_INCLUDES . 'update.inc.php');
?>
<h1>Update</h1>
<?php if ($update_success !== true) { ?>
<p>Fill in only those field that have changed. If you're not sure about what you filled in, you can also fill in all fields. Only the member number is mandatory.</p>
<?php if ($message != '') { ?><p class="message"><?php echo $message; ?></p><?php } ?>
<form method="post" action="<?php $_SERVER['PHP_SELF']; ?>" accept-charset="utf-8"> 
<p>
	<label for="mid">Your member number:</label><br />
	<input name="mid" type="text" id="mid" size="6" maxlength="9"<?php defaultValue('mid'); ?> />
</p>
<p>
	<label for="name">Your new name:</label><br />
	<input id="name" name="name" type="text" size="30"<?php defaultValue('name'); ?> />
</p>
<p>
	<label for="mail">Your new e-mail address:</label><br />
	<input id="mail" name="mail" type="text" size="30"<?php defaultValue('mail'); ?> /><br />
	<span class="smaller">All e-mail addresses will be protected against spam.</span>
	<?php if ($fanlisting->settings['show_mail'] == 3) {?><br /><input id="showmail" name="showmail" type="checkbox" value="1" <?php defaultValue('showmail', 'checked', true); ?> />&nbsp;
	<label for="showmail">Show my new e-mail address.</label><?php } ?>
</p>
<?php if ($fanlisting->settings['ask_url']) { ?>
<p>
	<label for="url">Your new website:</label><br />
	<input id="url" name="url" type="text" size="30"<?php defaultValue('url'); ?> />
	<?php if (!$fanlisting->CheckRequired('url')) {?><br /><input id="deleteurl" name="deleteurl" type="checkbox" value="1" <?php defaultValue('deleteurl', 'checked'); ?> />&nbsp;<label for="deleteurl">Remove my URL from the list.</label><?php } ?>
</p>
	<?php } ?>
	<?php if ($fanlisting->settings['ask_country']) { ?>
<p>
	<label for="country">Your new country:</label><br />
	<select name="country" id="country">
		<?php include(PHPFANLIST_INCLUDES . 'countrylist.inc.php'); ?>
	</select>
</p><?php } ?>
	<?php if ($fanlisting->settings['ask_custom']) { ?>
<p>
	<label for="custom"><?php echo $fanlisting->settings['custom_field_name']; ?>:</label><br />
	<input id="custom" name="custom" type="text" size="30"<?php defaultValue('custom'); ?> />
</p><?php } ?>
<p><label for="comment">Any comments?</label><br />
	<textarea id="comment" name="comment" cols="30" rows="5"><?php defaultValue('comment', 'textarea'); ?></textarea>
</p>
	<?php if ($fanlisting->settings['allow_memberdelete']) { ?><p><input id="delme" name="delme" type="checkbox" value="1"<?php defaultValue('delme', 'checked'); ?> />&nbsp;<label for="delme">Delete me from the list</label>
	</p><?php } ?>
<p><input name="doupdate" type="submit" id="doupdate" value="Update" /></p>
</form>
<?php } else { ?><p class="message"><?php echo $message; ?></p><?php } ?>
<p class="powered">Powered by <a href="http://www.phpfanlist.com" target="_blank">phpFanList</a> <?php echo PHPFANLIST_VERSION; ?></p>
<?php include_once('includes/footer.inc.php'); ?>
