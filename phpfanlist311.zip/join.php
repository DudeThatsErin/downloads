<?php 
	/* This part of PHP is required for the page to work. */
	$site_sub_title = 'Join';
	include_once('includes/header.inc.php');
	include_once(PHPFANLIST_INCLUDES . 'join.inc.php');
?>
<h1>Join</h1>
<?php if ($join_success !== true) { ?>
<p>Fill out the form below to join the <?php echo htmlentities($fanlisting->settings['site_name'], ENT_QUOTES, 'UTF-8'); ?>. Please make sure you've read the rules and if you have a website, that you put a link back up to <a href="<?php echo htmlentities(handle_site($fanlisting->settings['site_url']), ENT_QUOTES, 'UTF-8'); ?>" title="<?php echo htmlentities($fanlisting->settings['site_name'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlentities(handle_site($fanlisting->settings['site_url']), ENT_QUOTES, 'UTF-8'); ?></a> before applying!</p>
<p>If you are already listed and want to update your data, you can do this <a href="update.php">here</a>.</p>
<?php if ($message != '') { ?><p class="message"><?php echo $message; ?></p><?php } ?>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" accept-charset="utf-8">
<p>
	<label for="name">Your name:</label><br />
	<input id="name" name="name" type="text" size="30"<?php defaultValue('name'); ?> /><?php is_required('*', 'name'); ?>
</p>
<p>
	<label for="mail">Your e-mail address:</label><br />
	<input id="mail" name="mail" type="text" size="30"<?php defaultValue('mail'); ?> /><?php is_required('*', 'mail'); ?><br />
	<span class="smaller">All e-mail addresses will be protected against spam.</span>
	<?php if ($fanlisting->settings['show_mail'] == 3) {?><br /><input id="showmail" name="showmail" type="checkbox" value="1"<?php defaultValue('showmail', 'checked', true); ?> /><label for="showmail">Show my e-mail address</label><?php } ?>
</p>
<?php if ($fanlisting->settings['ask_url']) { ?>
<p>
	<label for="url">Your website:</label><br />
	<input id="url" name="url" type="text" size="30"<?php defaultValue('url'); ?> /><?php is_required('*', 'url'); ?>
</p>
<?php } ?>
<?php if ($fanlisting->settings['ask_country']) { ?>
<p>
	<label for="country">Your country:</label><br />
	<select name="country" id="country">
		<?php include(PHPFANLIST_INCLUDES . 'countrylist.inc.php'); ?>
	</select><?php is_required('*', 'country'); ?>
</p>
<?php } if ($fanlisting->settings['ask_rules']) { ?>
<p>
	<label for="rules"><?php echo  htmlentities($fanlisting->settings['rules_question'], ENT_QUOTES, 'UTF-8'); ?></label><br />
	<input id="rules" name="rules" type="text" size="30"<?php defaultValue('rules'); ?> /><?php is_required('*', 'rules'); ?>
</p>
<?php } if ($fanlisting->settings['ask_custom']) { ?>
<p>
	<label for="custom"><?php echo  htmlentities($fanlisting->settings['custom_field_name'], ENT_QUOTES, 'UTF-8'); ?>:</label><br />
	<input id="custom" name="custom" type="text" size="30"<?php defaultValue('custom'); ?> /><?php is_required('*', 'custom'); ?>
</p><?php } ?>
<p>
	<label for="comment">Any comments?</label><br />
	<textarea id="comment" name="comment" cols="30" rows="5"><?php defaultValue('comment', 'textarea'); ?></textarea>
</p>
<p><input name="dojoin" type="submit" id="dojoin" value="Join" /></p>
<p>* Required</p>
</form>
<?php } else { ?><p class="message"><?php echo $message; ?></p><?php } ?>
<p class="powered">Powered by <a href="http://www.phpfanlist.com" target="_blank">phpFanList</a> <?php echo PHPFANLIST_VERSION; ?></p>
<?php include_once('includes/footer.inc.php'); ?>
