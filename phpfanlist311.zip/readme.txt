 =============================================================================
                               phpFanList 3
 =============================================================================
 
 Introduction
 ------------
 phpFanList is a FREE listing script, for managing (approved) fanlistings,
 anime fanlistings, namelistings, cliques, etc. It is designed to help organize
 fans or members and make the life of the fanlist or clique owner much
 easier. It also allows you to manage your affiliates and post simple news 
 updates, all with 1 easy interface. You need PHP on your webserver and a
 MySQL database to store the data.
 
 Installation
 ------------
 1. Unpack this .zip file to a local directory.
 2. Open 'config.inc.php' file (located in the includes directory). Set the 
    settings to right values.
	(More info on: http://www.phpfanlist.com/configuration.html)
 3. Upload all files to a folder on your webserver, except version.txt,
    license.txt and readme.txt. These files are there for information only.
 4. Open the install directory you uploaded in your browser. A database 
    connection will be established with the given settings in point 3. 
    If the database connection was successfull, click on install.
    If you have a previous version installed, click update and the database
    will be updated. (back up your database before upgrading!)
 5. The install creates the tables for phpFanList and inserts the default
    settings.
 6. If the install was successful, delete the install directory from the 
    server. (You don't need them anymore and removing it is more secure.)
 7. Open the admin.php file. Default username is "admin", with no password.
 8. You are now ready to use phpFanList.
 
 x. If you do need help with the installation or phpFanList can't be 
    installed, don't hesitate to contact us.
	(http://www.phpfanlist.com/contact.php)
 
 Upgrading 2.1.0 or higher (full update)
 ----------------------------------------
 1. There are 3 different scenarios when you are planning to update:
	a. you have only 1 or more fanlisting/clique and you have your
	   g_includes folder inside your fanlisting/clique folder.
	b. you have 1 or more fanlistings/cliques and you have your g_includes
	   folder in your root folder. You are planning to update all your
	   fanlistings/cliques the same day.
	c. you have 1 or more fanlistings/cliques and you have your g_includes
	   folder in your root folder. You won't be able to update all your
	   fanlistings/cliques in a short timespan.

 Scenario a and b
 ----------------
 1. Delete the old g_includes folder upload the new g_includes (use
    phpfanlist3xx.zip, not phpfanlist3xx_quick.zip).
 2. Upload the web_includes.
 3. Replace all fanlisting/clique files (join.php, update.php, admin.php, etc.).
 4. foot.inc.php and head.inc.php have been replaced by footer.inc.php and
    header.inc.php, you might have to change this in your files (e.g. rules.php,
    codes.php)
 5. Don't forget to change the config.inc.php, settings need to be exactly the
    same as for the old version.
 6. When everything is installed, go to fanlisting.yoursite.com/install/. If you
    did everything as described, the install will ask you to update.
 7. After upgrading, delete the install directory.
 8. Go to the admin and change your settings if necessary. Login and password are
    unchanged.

 Scenario c
 ----------
 1. Keep the old g_includes folder.
 2. Upload the new g_includes into g_includes_new (use phpfanlist3xx.zip, not
    phpfanlist3xx_quick.zip).
 3. Upload the web_includes.
 4. IMPORTANT STEP: go to the admin of the fanlisting you wish to update and
    change the g_includes path to g_includes_new! Otherwise your admin will be
    blank after upgrading!
 5. Replace all fanlisting/clique files (join.php, update.php, admin.php, etc.).
 6. foot.inc.php and head.inc.php have been replaced by footer.inc.php and
    header.inc.php, you might have to change this in your files (e.g. rules.php,
    codes.php)
 7. Don't forget to change the config.inc.php, settings need to be exactly the
    same as for the old version.
 8. When everything is installed, go to fanlisting.yoursite.com/install/. If you
    did everything as described, the install will ask you to update.
 9. After upgrading, delete the install directory.
 10.Go to the admin and change your settings if necessary. Login and password are
    unchanged.

 Upgrading 3.0.0 or higher (quickupdate)
 ----------------------------------------
 0. Make sure there is a quick update available for your version.
    (A quick update only contains the changed files)
 1. Upload and overwrite all files from phpfanlist3xx_quick.zip.
 2. Go to the admin, your login and password are unchanged.
 3. phpFanList will automatically update.
 ----------------------------------------------------------------------------
 
 For more information see the phpFanList website (http://www.phpfanlist.com).
 
 ============================================================================
       phpFanList � 2003 - 2007 Sitemakers.be. Some rights reserved.