<?php include_once('includes/header.inc.php'); ?>
<p>Welcome to the <?php if ($fanlisting->settings['approved']) { ?><a href="<?php echo $fanlisting->settings['approved_link']; ?>">approved</a> <?php } echo htmlentities($fanlisting->settings['site_name'], ENT_QUOTES, 'UTF-8'); ?> (open since <?php echo PHPFANLIST_STARTDATE; ?>).</p>
<p>We have a total of <strong><?php echo PHPFANLIST_MEMBERCOUNT;?></strong> members.</p>
<p>
	<strong><?php echo PHPFANLIST_NUMJOIN; ?></strong> member(s) pending.<br />
	<strong><?php echo PHPFANLIST_NUMUPDATE; ?></strong> member(s) wanting an update.<br />
	<strong><?php echo PHPFANLIST_NUMDELETE; ?></strong> member(s) wanting to be deleted.
</p>
<p>Last updated on: <strong><?php echo PHPFANLIST_LASTUPDATE; ?></strong><br />
Last checked on: <strong><?php echo PHPFANLIST_LASTCHECKED; ?></strong></p>
<p>Last members updated on: <strong><?php echo PHPFANLIST_LASTMEMUPDATE; ?></strong>.<br />
Last members added on: <strong><?php echo PHPFANLIST_LASTMEMNEW; ?></strong>.</p>
<p>Last updated members: <?php echo PHPFANLIST_LASTX; ?></p>
<p>Last added members: <?php echo PHPFANLIST_LASTNEWX; ?></p>
<p>Latest News</p>
<?php showNews(1); ?>
<p>Affiliates<br />
<?php ShowAffiliates(2); ?>
</p>
<?php include_once('includes/footer.inc.php'); ?>