<?php
	header('Location: ../');
	exit;
?>