<?php
	header('Location: ../../');
	exit;
?>