<?php
$err_setting = error_reporting(0); 

// Password protect it \\
session_start();
header("Cache-control: private"); // IE fix!!!
if (isset($_GET['action']) && ($_GET['action'] == 'logout')) {
	$_SESSION = array();
	}
if ((!isset($_SESSION['loggedin'])) || ($_SESSION['loggedin'] != 1)) {
	$_SESSION['previous_url'] = $_SERVER['REQUEST_URI'];
	if (isset($_GET['action']) && ($_GET['action'] == 'logout')) {
		unset($_SESSION['previous_url']);
	}
	header('Location: login.php');
	exit;
	}
/***********************/
	
require_once('includes/inc.php');
require_once(realpath(PHPFANLIST_INCLUDES . 'admin.inc.php'));
		
error_reporting($err_setting); 
?>