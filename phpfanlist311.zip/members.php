<?php
	/* This part of PHP is required for the page to work. */

	$site_sub_title = 'Members';
	include_once('includes/header.inc.php');
?>
<h1>Members</h1>
<?php include(PHPFANLIST_INCLUDES . 'members.inc.php'); ?>
<p class="powered">Powered by <a href="http://www.phpfanlist.com" target="_blank">phpFanList</a> <?php echo PHPFANLIST_VERSION; ?></p>
<?php include_once('includes/footer.inc.php'); ?>