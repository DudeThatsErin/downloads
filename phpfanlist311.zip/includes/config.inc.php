<?php 
// Database data
$db_host    = 'localhost';	// Host where database is located, often 'localhost'
$db_name    = '';			// Name of the database, you can share a database with different versions op phpFanList
$db_user    = '';			// Database User
$db_pass    = '';			// Password for Database User
$table_name = 'phpfanlist';	// Name of the table where the members will be stored, cannot be shared
?>