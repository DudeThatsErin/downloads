</body>
</html>
<?php error_reporting($err_setting); ?>