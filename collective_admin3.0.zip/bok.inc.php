<?php
# 'FIG.INC' FILE 
/* ----------------------------------------------------------
Tess Ally 2006 � Collective Admin 
------------------------------------------------------------- */
if('fig.inc.php' === basename($_SERVER['PHP_SELF'])) {
 die('ERROR: Should you not be doing something else? D:');
}

# -- Database Variables -------------------------------------
#  $database_host - MySQL Host (usually localhost)
#  $database_user - MySQL username 
#  $database_pass - MySQL password 
#  $database_name - MySQL name
# -----------------------------------------------------------
$database_host = "localhost";
$database_user = "";
$database_pass = "";
$database_name = "";

# -- Table Prefix -------------------------------------------
#  Table prefix before your table names. 
# -----------------------------------------------------------
$_CA['prefix'] = "ca_";

# -- STOP EDITING HERE! -------------------------------------
# -----------------------------------------------------------
# 
#  Below this line are sensitive lines that should NOT be 
#  messed with unless you know exactly what you're doing.
# 
# -----------------------------------------------------------
# -----------------------------------------------------------
if((!isset($_CA['prefix']) || empty($_CA['prefix'])) 
|| (strpos($_CA['prefix'], '_') === false)) {
 $prefix = "ca_";
} else {
 $prefix = $_CA['prefix'];
}

# -- Table Names --------------------------------------------
# ----------------------------------------------------------- 
$_CA['options'] = $prefix . "options";

# -- Get MySQL ----------------------------------------------
# -----------------------------------------------------------
$connect = mysql_connect($database_host, $database_user, $database_pass)
 or die('<p><span class="error">Error:</span> You cannot currently connect to MySQL.' . 
 ' Make sure all variables are correct in <samp>rats.inc.php</samp>; if it is a random' . 
 ' error, wait it out and see if it\'ll magically disappear.</p>');
$database = mysql_select_db($database_name)
 or die('<p><span class="error">Error:</span> You cannot currently connect to your database.' . 
 ' Make sure all variables are correct in <samp>rats.inc.php</samp>; if it is a random' . 
 ' error, wait it out and see if it\'ll magically disappear.</p>');
 
# -- Run Query ----------------------------------------------
# -----------------------------------------------------------
$select = "SELECT `optText` FROM `$_CA[options]` WHERE `optName` = 'admPath' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 exit('Unable to select the specified option.');
}
$getItem = mysql_fetch_array($true);
define('CAPATH', $getItem['optText']); 
?>
