<?php
# 'CODES' FILE 
/* ----------------------------------------------------------
Tess Ally 2006 � Collective Admin 
------------------------------------------------------------- */
$getTitle = "Display Codes";
require("pro.inc.php");
require("header.php");

echo "<h2>{$getTitle}</h2>\n";
?>
<p>Below is the snippet to display the list of sites on your site.</p>

<h3>Display Code</h3>
<p>Below is the snippet to display the list of categories/status lists on your site. Please be aware the file 
<samp>bok.inc.php</samp> (which was included in the .zip file) <em>must</em> be uploaded on your server in order 
for the following path to work.</p>
<p class="noteButton"><span class="note">Note:</span> "All" was added to the default list option in 
<a href="options.php">&raquo; Options</a>; you can now choose to have your default list as categories, status (or both)
or have all sites displayed (without choosing a category or status). If you do choose to display all sites, you can 
choose how to sort them in your <a href="options.php">&raquo; Options</a>.</p>
<code>
&lt;?php<br />
# -----------------------------------------------------------<br />
require("bok.inc.php");<br />
# -----------------------------------------------------------<br />
require(CAPATH . &#039;show_sites.php&#039;);<br />
# -----------------------------------------------------------<br />
?&gt;
</code>
<?php
require("footer.php");
?>