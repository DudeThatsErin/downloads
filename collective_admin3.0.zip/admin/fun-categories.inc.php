<?php 
# 'FUN-CATEGORIES.INC' FILE 
/* ----------------------------------------------------------
Tess Ally 2006 � Collective Admin 
------------------------------------------------------------- */

if(!class_exists('categoryfunc')) {
 class categoryfunc {
  # -- Categories List ----------------------------------------
  # -----------------------------------------------------------
  function categoryList($b = 'id', $i = '') {
   global $_CA;

   $select = "SELECT * FROM `$_CA[categories]`";
	 if($b == 'parent') {
	  $select .= " WHERE `catParent` = '$i'";
	 }
	 $select .= " ORDER BY `catName` ASC";
   $true = mysql_query($select);
   if($true == false) {
    displayError('Database Error', 'Could not select the categories from the database.', true, $select);
   }

   $all = array();
   while($getItem = mysql_fetch_array($true)) {
	  switch($b) {
		 case 'name':
      $all[] = $getItem['catName'];
		 break;
		 case 'id':
		 case 'parent':
		  $all[] = $getItem['catID'];
		 break;
		}
   }

   return $all;
  }
	
	# -- Get Category Function ----------------------------------
  # -----------------------------------------------------------
  function getCategory($i) {
   global $_CA;

   $select = "SELECT * FROM `$_CA[categories]` WHERE `catID` = '$i' LIMIT 1";
   $true = @mysql_query($select);
   if($true == false) {
    displayError('Script Error', 'The script was unable to pull the category you specified.', false);
   } 
   $getItem = mysql_fetch_array($true);

   return $getItem;
  }

  # -- Get Category Name Function -----------------------------
  # -----------------------------------------------------------
  function getCatName($id) {
   global $_CA;

   $select = "SELECT `catName` FROM `$_CA[categories]` WHERE `catID` = '$id' LIMIT 1";
   $true = mysql_query($select);
   if($true == false) {
    displayError('Database Error', 'Could not select the category name from the database.', false);
   }
   $getItem = mysql_fetch_array($true);

   return $getItem['catName']; 
  }

  # -- Get Category ID Function -------------------------------
  # -----------------------------------------------------------
  function getCatID($n) {
   global $_CA;

   $select = "SELECT `catID` FROM `$_CA[categories]` WHERE `catName` = '$n' LIMIT 1";
   $true = mysql_query($select);
   if($true == false) {
    displayError('Database Error', 'Could not select the category name from the database.');
   }
   $getItem = mysql_fetch_array($true);

   return $getItem['catID']; 
  }

  # -- Pull Category Name(s) ----------------------------------
  # -----------------------------------------------------------
  function pullCatNames($i, $s) {

   $categories = explode($s, $i);
   $cat = '';
   foreach($categories as $category) {
    $c = $this->getCategory($category);
    if($c['catParent'] == 0) {
	   $cat .= $this->getCatName($category) . ', ';
    } else {
	   $cat .= $this->getCatName($c['catParent']) . " &raquo; " . $this->getCatName($category) . ', ';
    }
   }
   $cat = trim($cat, ', ');

   return $cat;
  }

  # -- Check Categories ---------------------------------------
  # -----------------------------------------------------------
  function checkCategory($c) {
   global $_CA, $eastroad;

   $select = "SELECT * FROM `$_CA[main]` WHERE `listCategory` LIKE '%!$c!%'";
   $true = mysql_query($select);
   if($true == false) {
    $eastroad->displayError('Database Error', 'Could not select the category from the database.', true, $select);
   }

   if(mysql_num_rows($true) == 0) {
    return 0;
   } else {
    return 1;
	 }
  }
 }
}

$categoryfunc = new categoryfunc();
?>
