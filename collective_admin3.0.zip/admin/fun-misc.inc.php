<?php
# 'FUN-MISC.INC' FILE 
/* ----------------------------------------------------------
Tess Ally 2006 � Pumpin'! Admin 
------------------------------------------------------------- */

if(!class_exists('optionsfunc')) {
 class optionsfunc {
  # -- Edit Option Function -----------------------------------
  # -----------------------------------------------------------
  function editOption($option, $value) {
   global $_CA;

   if(get_magic_quotes_gpc()) {
    $value = stripslashes($value);
	 }
 
   $value = mysql_real_escape_string($value);

   $update = "UPDATE `$_CA[options]` SET `optText` = '$value' WHERE `optName` = '$option' LIMIT 1";
   mysql_query("SET NAMES 'utf8';");
   $true = mysql_query($update);
   if($true == false) {
    displayError('Database Error', 'Unable to update the specified option.|' . 
		'Make sure your table exists.', false);
   } 
 
   else {
    echo '<p class="successButton"><span class="success">SUCCESS!</span> Your ' . 
		"<samp>$option</samp> option has been edited! :D</p>\n";
   }
  }

  # -- Get Option Function ------------------------------------
  # -----------------------------------------------------------
  function getOption($option) {
   global $_CA;

   $select = "SELECT `optText` FROM `$_CA[options]` WHERE `optName` = '$option'";
   $true = mysql_query($select);
   if($true == false) {
    displayError('Database Error', 'Cannot select option from the database.|' . 
		'Make sure your options table exists.', false);
   }
   $getItem = mysql_fetch_array($true);

   return $getItem['optText'];
  } 

  # -- Get Template Function ----------------------------------
  # -----------------------------------------------------------
  function getTemplate($template) {
   global $_CA;

   $select = "SELECT `tempBody` FROM `$_CA[templates]` WHERE `tempName` = '$template'";
   $true = mysql_query($select);
   if($true == false) {
    displayError('Database Error', 'Could not select the specified template' . 
		' from the database.', false);
   }
   $getItem = mysql_fetch_array($true);

   return $getItem['tempBody'];
  }

  # -- Count Function -----------------------------------------
  # -----------------------------------------------------------
  function getCount($c) {
   global $_CA, $eastroad;

   $select = "SELECT * FROM";
	 switch($c) {
    case 'cat':
		 $select .= " `$_CA[categories]`";
		break;
    case 'current':
     $select .= " `$_CA[main]` WHERE `listStatus` = '0'";
		break;
    case 'upcoming':
     $select .= " `$_CA[main]` WHERE `listStatus` = '1'";
		break;
    case 'pending':
     $select .= " `$_CA[main]` WHERE `listStatus` = '2'";
		break;
    case 'closed':
     $select .= " `$_CA[main]` WHERE `listStatus` = '3'";
		break;
	 }
   $true = mysql_query($select);
   if($true == false) {
    $eastroad->displayError('Database Error', 'Unable to select the specific table.|' . 
		'Make sure your table(s) exist.', true, $select);
   }
   $count = mysql_num_rows($true);

   return $count;
	}
	
	# -- Get Short URL Function ---------------------------------
	# -----------------------------------------------------------
	function shortURL($u) {
   $u = str_replace('http://', '', $u);
   $u = str_replace('www.', '', $u);
   $e = explode('/', $u);
   $n = str_replace('/', '', $e[0]);
   return $n;
  }
 }
}

$optionsfunc = new optionsfunc();
?>
