<?php 
# 'CATEGORIES' FILE 
/* ----------------------------------------------------------
Tess Ally 2006 � Collective Admin 
------------------------------------------------------------- */ 
$getTitle = "Categories";
require("pro.inc.php");
require("vars.inc.php");
require("header.php");

echo "<h2>{$getTitle}</h2>\n";

if(!isset($_GET['page']) || empty($_GET['page']) || !ctype_digit($_GET['page'])) { 
 $page = 1;
} else {
 $page = $eastroad->cleanMys((int)$_GET['page']);
}
$start = mysql_real_escape_string((($page * $per_page) - $per_page));

if(isset($_GET['g']) && $_GET['g'] == 'new') {
?>
<form action="categories.php" method="post">
<fieldset>
<legend>Add Category</legend>
<p><label>Category:</label> <input name="category" class="input1" type="text" /></p>
<p><label>Parent Category:</label> <select name="parent" class="input1" size="10">
<?php 
$select = "SELECT * FROM `$_CA[categories]` WHERE `catParent` = '0' ORDER BY `catName` ASC";
$true = mysql_query($select);
if($true == false) { 
 echo "<option value=\"0\">No Categories Available</option>\n";
}

else {
 while($getItem = mysql_fetch_array($true)) {
  echo '<option value="' . $getItem['catID'] . '">' . $getItem['catName'] . "</option>\n";
 }
}
?>
</select></p>
<p class="tc"><strong>Description</strong><br />
<textarea name="desc" cols="50" rows="7" style="height: 150px; margin: 0 1% 0 0; width: 99%;"></textarea></p>
<p class="tc"><input name="action" class="input2" type="submit" value="Add Category" /> 
<input class="input2" type="reset" value="Reset" /></p>
</fieldset>
</form>
<?php
}

elseif (isset($_POST['action']) && $_POST['action'] == 'Add Category') {
$name = $eastroad->cleanMys($_POST['category']);
 if(empty($name)) {
  $eastroad->displayError('Script Error', 'In order to create a category, you must enter a name first. :P', false);
 }
$parent = $eastroad->cleanMys($_POST['parent']);
if(!isset($parent) || empty($parent) || !ctype_digit($parent)) {
 $par = 0;
} else {
 $par = $parent;
}
$desc = $eastroad->cleanMys($_POST['desc']);

$insert = "INSERT INTO `$_CA[categories]` (`catName`, `catParent`, `catDesc`) VALUES ('$name', '$par', '$desc')";
@mysql_query("SET NAMES 'utf8';");
$true = mysql_query($insert);

if($true == false) {
 $eastroad->displayError('Database Error', 'Unable to add the category to the database.', true, $insert);
} elseif ($true == true) {
  echo '<p class="successButton"><span class="success">SUCCESS!</span> Your category was added to the database!</p>';
  echo $eastroad->backLink('cat');
 }
}

/* -- Edit --------------------------------------------------------------------- */

elseif (isset($_GET['g']) && $_GET['g'] == 'old') {
if(empty($_GET['id']) || !isset($_GET['id'])) {
?>
<form action="categories.php" method="get">
<p class="noBottom"><input name="g" type="hidden" value="old" /></p>
<fieldset> 
<legend>Choose Category</legend>
<p><label>Category:</label> <select name="id" class="input1" size="6">
<?php 
$select = "SELECT * FROM `$_CA[categories]` ORDER BY `catName` ASC";
$true = mysql_query($select);
if($true == false) { 
 echo "<option>No Categories Available</option>\n";
}

else {
 while($getItem = mysql_fetch_array($true)) {
  echo '<option value="' . $getItem['catID'] . '">' . $getItem['catName'] . "</option>\n";
 }
}
?>
</select></p>
<p class="tc"><input class="input2" type="submit" value="Edit Category" /></p>
</fieldset>
</form>
<?php
}

if(!empty($_GET['id'])) {
$id = $eastroad->cleanMys((int)$_GET['id']);
 if(!ctype_digit($id)) {
  $eastroad->displayError('Script Error', 'Your ID is not a number. Go back and try again.', false);
 }

$select = "SELECT * FROM `$_CA[categories]` WHERE `catID` = '$id' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 $eastroad->displayError('Database Error', 'Unable to select that specific category.|' . 
 'Make sure the ID is not empty and the category table exists.', true, $select);
}
$getItem = mysql_fetch_array($true);
?>
<form action="categories.php" method="post">
<p class="noBottom"><input name="id" type="hidden" value="<?php echo $getItem['catID']; ?>" /></p>

<fieldset>
<legend>Edit Category</legend>
<p><label>Category</label> <input name="category" class="input1" type="text" value="<?php echo $getItem['catName']; ?>" /></p>
<p><label>Parent:</label> <select name="parent" class="input1" size="7">
<?php 
$select = "SELECT * FROM `$_CA[categories]` WHERE `catParent` = '0' ORDER BY `catName` ASC";
$true = mysql_query($select);
if($true == false) { 
 echo "<option value=\"0\">No Categories Available</option>\n";
}

else {
 while($getCat = mysql_fetch_array($true)) {
  $cats = explode('!', $getItem['catParent']);
  echo "<option value=\"" . $getCat['catID'] . "\""; 
	if(in_array($getCat['catID'], $cats)) {
	 echo ' selected="selected"'; 
	}
	echo ">";
	if($getCat['catParent'] != 0) {
	 echo "&raquo; ";
	}
	echo $getCat['catName'] . "</option>\n";
 }
}
?>
</select></p>
<p class="tc"><strong>Description</strong><br />
<textarea name="desc" cols="50" rows="7" style="height: 150px; margin: 0 1% 0 0; width: 99%;">
<?php echo $getItem['catDesc']; ?></textarea></p>
<p class="tc"><input name="action" class="input2" type="submit" value="Edit Category" /></p>
</fieldset>
</form>
<?php
 }
}

elseif (isset($_POST['action']) && $_POST['action'] == 'Edit Category') {
$id = $eastroad->cleanMys((int)$_POST['id']);
 if(empty($id) || !ctype_digit($id)) {
  $eastroad->displayError('Script Error', 'Your ID is empty. This means you selected an incorrect category or' . 
  ' you\'re trying to access something that doesn\'t exist. Go back and try again.', false);
 }
$name = $eastroad->cleanMys($_POST['category']);
 if(empty($name)) {
  $eastroad->displayError('Script Error', 'In order to edit a category, you must enter a name first. :P', false);
 }
$parent = $eastroad->cleanMys($_POST['parent']);
if(!isset($parent) || empty($parent) || !ctype_digit($parent)) {
 $par = 0;
} else {
 $par = $parent;
}
$desc = $eastroad->cleanMys($_POST['desc']);

$update = "UPDATE `$_CA[categories]` SET `catName` = '$name', `catParent` = '$par'," . 
" `catDesc` = '$desc' WHERE `catID` = '$id' LIMIT 1";
mysql_query("SET NAMES 'utf8';");
$true = mysql_query($update);
if($true == false) {
 $eastroad->displayError('Database Error', 'Unable to edit the category.|Make sure your category table exists.');
} elseif ($true == true) {
  echo '<p class="successButton"><span class="success">SUCCESS!</span> Your category was edited!</p>';
  echo $eastroad->backLink('cat');
 }
}

/* -- Delete ------------------------------------------------------------------- */

elseif (isset($_GET['g']) && $_GET['g'] == 'erase') {
if(empty($_GET['id']) || !isset($_GET['id'])) {
?>
<form action="categories.php" method="get">
<p class="noBottom"><input name="g" type="hidden" value="erase" /></p>
<fieldset> 
<legend>Choose Category</legend>
<p><label>Category:</label> <select name="id" class="input1" size="6">
<?php 
$select = "SELECT * FROM `$_CA[categories]` ORDER BY `catName` ASC";
$true = mysql_query($select);
if($true == false) { 
 echo "<option>No Categories Found</option>\n";
}

else {
 while($getItem = mysql_fetch_array($true)) {
  echo '<option value="' . $getItem['catID'] . '">' . $getItem['catName'] . "</option>\n";
 }
}
?>
</select></p>
<p class="tc"><input class="input2" type="submit" value="Delete Category" /></p>
</fieldset>
</form>
<?php
}

if(!empty($_GET['id'])) {
$id = $eastroad->cleanMys((int)$_GET['id']);
 if(!ctype_digit($id)) {
  $eastroad->displayError('Script Error', 'Your ID is not a number. Go back and try again.', false);
 }
 
$select = "SELECT * FROM `$_CA[categories]` WHERE `catID` = '$id' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select that specific category.|' . 
 'Make sure the ID is not empty and the listings table exists.', true, $select);
}
$getItem = mysql_fetch_array($true);
?>
<p>You are about to delete the <strong><?php echo $getItem['catName']; ?></strong> category; please be aware that once you 
delete a category, it is gone forever. <em>This cannot be undone!</em> To proceed, click the "Delete Category" button. :)</p>

<form action="categories.php" method="post">
<p class="noBottom"><input name="id" type="hidden" value="<?php echo $getItem['catID']; ?>" /></p>

<fieldset>
<legend>Delete Category</legend>
<p class="tc">Deleting <strong><?php echo $getItem['catName'] ?></strong></p>
<p class="tc"><input name="action" class="input2" type="submit" value="Delete Category" /></p>
</fieldset>
</form>
<?php
}
}

elseif (isset($_POST['action']) && $_POST['action'] == 'Delete Category') {
$id = $eastroad->cleanMys((int)$_POST['id']);

$delete = "DELETE FROM `$_CA[categories]` WHERE `catID` = '$id' LIMIT 1";
$true = mysql_query($delete);

if($true == false) {
 $eastroad->displayError('Database Error', 'Unable to delete the category.', true, $delete);
} elseif ($true == true) {
  echo '<p class="successButton"><span class="success">SUCCESS!</span> Your category was deleted!</p>';
  echo $eastroad->backLink('cat');
 }
}

/* -- Index -------------------------------------------------------------------- */

else {
?>
<p>Welcome to <samp>categories.php</samp>, the page to add categories and edit or delete your current ones! Below
is your list of categories. To edit or delete a current one, click "Edit" or "Delete" by the appropriate category.</p>
<p class="explode"><a href="categories.php?g=new">Add a Category</a></p>
<?php
$select = "SELECT * FROM `$_CA[categories]` ORDER BY `catName` ASC LIMIT $start, $per_page";
$true = mysql_query($select);
$count = mysql_num_rows($true);

if($count > 0) {
?>
<table class="index" width="100%"><thead><tr>
<th>Category ID</th>
<th>Category Name</th>
<th>Action</th>
</tr></thead>
<?php
while($getItem = mysql_fetch_array($true)) {
if(!empty($getItem['catParent'])) {
 $c = $categoryfunc->getCatName($getItem['catParent']) . " &raquo; " . $getItem['catName'];
}

else {
 $c = $getItem['catName'];
}
?>
<tbody><tr>
<td class="tc" width="10%"><?php echo $getItem['catID']; ?></td>
<td class="tc"><?php echo $c; ?></td>
<td class="tc" width="30%">(<a href="categories.php?g=old&amp;id=<?php echo $getItem['catID']; ?>">Edit</a>) |
 (<a href="categories.php?g=erase&amp;id=<?php echo $getItem['catID']; ?>">Delete</a>)</td>
</tr></tbody>
<?php
} 
echo "</table>\n";

echo '<p id="pagination">';

$select = "SELECT * FROM `$_CA[categories]`";
 $true = mysql_query($select);
  $total = mysql_num_rows($true);
$pages = ceil($total/$per_page);

$prev = ($page - 1);
if($page > 1) {
 echo '<a href="categories.php?page=' . $prev . '">&laquo; Previous</a> ';
} else {
 echo '&laquo; Previous ';
}

for($i = 1; $i <= $pages; $i++) {
 if($page == $i) {
  echo $i . " ";
 } else { 
  echo '<a href="categories.php?page=' . $i . '">' . $i . '</a> ';
 }
}

$next = ($page + 1);
if($page < $pages) {
 echo '<a href="categories.php?page=' . $next . '">Next &raquo;</a>';
} else {
 echo 'Next &raquo;';
}

echo "</p>\n";
} 

 else {
  echo "<p class=\"tc\">Currently no categories!</p>\n";
 }
}

require("footer.php");
?>
