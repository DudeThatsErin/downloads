<?php 
# 'FUN-SITES.INC' FILE 
/* ---------------------------------------------------------- 
Tess Ally 2006 � Collective Admin 
------------------------------------------------------------- */ 

if(!class_exists('collectivefunc')) {
 class collectivefunc {
  # -- Pull Image (direct) ------------------------------------
  # -----------------------------------------------------------
  function pullImage($i) {
   global $_CA, $eastroad;

   $select = "SELECT `listImage` FROM `$_CA[main]` WHERE `listID` = '$i' LIMIT 1";
   $true = mysql_query($select);
   if($true == false) {
    $eastroad->displayError('Database Error', 'Unable to select the image from the specific site.|' . 
    'Make sure your table(s) exist.', true, $select);
   }
   $getItem = mysql_fetch_array($true);

   return $getItem['listImage'];
  }

  # -- Get Status Name Function -------------------------------
	#  NOTES: Get's the status names from the fake IDs.
  # -----------------------------------------------------------
  function getStatusName($i) {
   if($i == 1) {
    return "Current";
   } elseif ($i == 2) {
    return "Upcoming";
   } elseif ($i == 3) {
    return "Pending";
   } elseif ($i == 4) {
    return "Closed";
   } 
  }

	# -- Get Status Name Function -------------------------------
	#  NOTES: Get's the status names from the real IDs (commmonly
	#  listed in the database).
  # -----------------------------------------------------------
  function returnReal($i) {
   if($i == 0) {
    return "Current";
   } elseif ($i == 1) {
    return "Upcoming";
   } elseif ($i == 2) {
    return "Pending";
   } elseif ($i == 3) {
    return "Closed";
   }
  }

  # -- Get Listings by Status ---------------------------------
  # -----------------------------------------------------------
  function getListings($b = 'id', $p = 'category', $i = 'nom') {
   global $_CA, $eastroad;

   if($p == 'status' && $i != 'nom') {
    $g = $i - 1;
   }

   $select = "SELECT * FROM `$_CA[main]`";
   if($p == 'status' && ($i != 'nom' && ctype_digit($i))) {
    $select .= " WHERE `listStatus` = '$g'";
   } elseif ($p == 'category' && ($i != 'nom' && ctype_digit($i))) {
	  $select .= " WHERE `listCategory` LIKE '%!$i!%'";
	 }
	 $select .= " ORDER BY `listTitle` ASC";
   $true = mysql_query($select);
   if($true == false) {
    $eastroad->displayError('Database Error', 'Could not select the status of the' . 
		' site(s) from the database.|Please make sure your status has been set for' . 
		' each site.', false);
   }

   $all = array();
   while($getItem = mysql_fetch_array($true)) {
	  if($b == 'id') {
     $all[] = $getItem['listID'];
		}
   }

   return $all;
  }

  # -- Get Clean Text -----------------------------------------
  #  From Matt <http://ma.tt/scripts/autop/> and WordPress 
  #  <http://wordpress.org> 
  #  w/ some light editing 
  # 
  #  NOTE: Some editing had to be done to completely satisfy 
  #  me, therefore, this function is no longer as useful as it 
  #  was most likely intended. If wanting to take, I'd 
  #  recommend getting it from the URL above. 
  # ----------------------------------------------------------- 
  function cleanText($p, $br = 1) {

   # -- CUSTOM-ADDED: Added to make sure entities appear as they are - mainly --
	 # -- fixes the &raquo; entity problem. D: /displeased -----------------------
   $p = str_replace('&lt;', '<', $p);
   $p = str_replace('&gt;', '>', $p);
   $p = str_replace('&quot;', '"', $p);
   $p = str_replace('&39;', "'", $p);

   $p = $p . "\n"; // just to make things a little easier, pad the end 
   $allblocks = '(?:table|thead|tfoot|caption|colgroup|tbody|tr|td|th|div|dl|dd|dt|' . 
   'ul|ol|li|pre|select|form|map|area|blockquote|address|math|style|input|code|p|h[1-6]|hr)';
   $p = preg_replace('!(<' . $allblocks . '[^>]*>)!', "\n$1", $p);
   $p = preg_replace('!(</' . $allblocks . '>)!', "$1\n\n", $p);
   $p = str_replace(array("\r\n", "\r"), "\n", $p); // cross-platform newlines
   if(strpos($p, '<object') !== false) {
    $p = preg_replace('|\s*<param([^>]*)>\s*|', "<param$1>", $p); // no pee inside object/embed 
    $p = preg_replace('|\s*</embed>\s*|', '</embed>', $p);
   }
   $p = preg_replace("/\n\n+/", "\n\n", $p); // take care of duplicates
   $p = preg_replace('/\n?(.+?)(?:\n\s*\n|\z)/s', "<p>$1</p>\n", $p); // make paragraphs, including one at the end 
   $p = preg_replace('|<p>\s*?</p>|', '', $p); // under certain strange conditions it could create a P of entirely whitespace 
   $p = preg_replace('!<p>([^<]+)\s*?(</(?:div|address|form)[^>]*>)!', "<p>$1</p>$2", $p);
   $p = preg_replace('|<p>|', "$1<p>", $p);
   $p = preg_replace('!<p>\s*(</?' . $allblocks . '[^>]*>)\s*</p>!', "$1", $p); // don't pee all over a tag 
   $p = preg_replace("|<p>(<li.+?)</p>|", "$1", $p); // problem with nested lists 
   $p = preg_replace('|<p><blockquote([^>]*)>|i', "<blockquote$1><p>", $p);
   $p = str_replace('</blockquote></p>', '</p></blockquote>', $p);
   $p = preg_replace('!<p>\s*(</?' . $allblocks . '[^>]*>)!', "$1", $p);
   $p = preg_replace('!(</?' . $allblocks . '[^>]*>)\s*</p>!', "$1", $p);
   $p = preg_replace('!(</?' . $allblocks . '[^>]*>)\s*<br />!', "$1", $p);
   $p = preg_replace('!<br>(\s*</?(?:p|li|div|dl|dd|dt|th|pre|td|ul|ol)[^>]*>)!', '$1', $p);
   if(strpos($p, '<pre') !== false) {
    $p = preg_replace_callback('!(<pre.*?>)(.*?)</pre>!is', 'clean_pre', $p);
	 }
   $p = preg_replace("|\n</p>$|", '</p>', $p);   
    
	 # -- CUSTOM-ADDED: Transform - and -- to pre-defined HTML entity ------------ 
   $p = str_replace(' - ', '&#8211;', $p);
	 $p = str_replace(' -- ', '&#8212;', $p);

   # -- CUSTOM-ADDED: Fixed in 2009; makes sure <, >, ' and " show up in their - 
	 # -- proper syntax form. ---------------------------------------------------- 
   $p = str_replace('&amp;lt;', '&lt;', $p);
   $p = str_replace('&amp;gt;', '&gt;', $p);
   $p = str_replace('&amp;#034;', '&#034;', $p);
   $p = str_replace('&amp;#039;', '&#039;', $p);
	
	 # -- CUSTOM-ADDED: Added to make sure nd, th, st and rd show up properly. --- 
   $p = preg_replace('!([0-9]+)(st|nd|rd|th)!', '$1<sup>$2</sup>', $p);

   return $p;
  }

  # -- Template Function --------------------------------------
  # -----------------------------------------------------------
  function pullTemplates($i, $p) {
   global $_CA, $categoryfunc, $optionsfunc, $per_list, $per_page;

   $select = "SELECT * FROM `$_CA[main]` WHERE `listID` = '$i' LIMIT 1";
   $true = mysql_query($select);
   if($true == false) {
    displayError('Database Error', 'Cannot select sites from the database.', false);
   }
   $getItem = mysql_fetch_array($true);

   $select = "SELECT `tempBody` FROM `$_CA[templates]`"; 
   if($p == 'category') {
    $select .= " WHERE `tempName` = 'sitesTemplate'";
   } elseif ($p == 'status') {
    $select .= " WHERE `tempName` = 'statusTemplate'";
   }
	 $true = mysql_query($select);
   if($true == false) {
    $eastroad->displayError('Database Error', 'Cannot select the sites or status' . 
		' template from the database.|Make sure your templates have been created or' . 
		' are turned off if not in use.', false);
   }
   $template = mysql_fetch_array($true);

   if(mysql_num_rows($true) == 0) {
    $template['tempBody'] = '<p id="title"><a href="{url}" title="External Link: {title}">{title} &raquo;</a>
    <div class="details">{details}</div>';
   }

   $format = str_replace('{categories}', $categoryfunc->pullCatNames($getItem['listCategory'], '!'), $template['tempBody']);
   $format = str_replace('{details}', $this->cleanText(html_entity_decode($getItem['listDesc'])), $format);
   $format = str_replace('{image}', $optionsfunc->getOption('imgHttp') . $getItem['listImage'], $format);
   $format = str_replace('{since}', date($optionsfunc->getTemplate('dateTemplate'), strtotime($getItem['listSince'])), $format);
   $format = str_replace('{status}', $this->returnReal($getItem['listStatus']), $format);
   $format = str_replace('{subject}', $getItem['listSubject'], $format);
   $format = str_replace('{title}', $getItem['listTitle'], $format);
   $format = str_replace('{url}', $getItem['listURL'], $format);

   return html_entity_decode($format);
  }

  # -- Show Default Function ---------------------------------- 
  # -----------------------------------------------------------
  function showDefault($p) {
   global $_CA, $categoryfunc, $optionsfunc, $page, $per_list, $start, $sort_by;

   $server = basename(trim(strip_tags($_SERVER['PHP_SELF'])));
   $query = trim(strip_tags($_SERVER['QUERY_STRING']));
   if(isset($query) && !empty($query)) {
    if(!isset($_GET['p'])) {
     $_URL = '?' . urlencode($query) . '&amp;';
    } else {
     $_URL = '?';
    }
	 } else {
    $_URL = '?';
   }

   if($p == 'category') {
    $ids = $categoryfunc->categoryList();
 
    echo "<table class=\"indexListings\" width=\"100%\">\n";
		echo "<tfoot><tr><td class=\"tc\" colspan=\"2\">&raquo; <a href=\"" . $_URL . "c=all\">All Categories</a></td></tr></tfoot>\n";
    foreach($ids as $i) {
     if($categoryfunc->checkCategory($i) == 1) {
	    echo '<tbody><tr><td class="left"><a href="' . $_URL . 'c=' . $i . '">' . $categoryfunc->getCatName($i) . "</a></td>\n";
	    echo '<td class="center">' . count($this->getListings('id', 'category', $i)) . "</td></tr></tbody>\n";
	   }
    } 
    echo "</table>\n";
   } 
 
   elseif ($p == 'status') {
    $current = $optionsfunc->getCount('current');
    $upcoming = $optionsfunc->getCount('upcoming');
    $pending = $optionsfunc->getCount('pending');
    $closed = $optionsfunc->getCount('closed');
 
    echo "<table class=\"indexListings\" width=\"100%\">\n";
    if($current > 0) {
     echo '<tbody><tr><td class="left"><a href="' . $_URL . "s=1\">Current</a></td></tr></tbody>\n";
    } 
	
	  if($upcoming > 0) {
     echo '<tbody><tr><td class="left"><a href="' . $_URL . "s=2\">Upcoming</a></td></tr></tbody>\n";
    } 
	
	  if($pending > 0) {
     echo '<tbody><tr><td class="left"><a href="' . $_URL . "s=3\">Pending</a></td></tr></tbody>\n";
    } 
	
	  if($closed > 0) {
     echo '<tbody><tr><td class="left"><a href="' . $_URL . "s=4\">Closed</a></td></tr></tbody>\n";
    }
    echo "</table>\n";
   }
 
   elseif ($type == 'all') {
    $select = "SELECT * FROM `$_CA[main]`";
    if($sort_by == 'id') {
	   $select .= " ORDER BY `listID` DESC";
    } elseif ($sort_by == 'since') {
	   $select .= " ORDER BY `listSince` DESC";
    } elseif ($sort_by == 'subject') {
	   $select .= " ORDER BY `listSubject` ASC";
    }
    $select .= " LIMIT $start, $per_list";
    $true = @mysql_query($select);
 
    $query = "SELECT * FROM `$_CA[main]`";
    $result = @mysql_query($query);
    $total = @mysql_num_rows($result);
    $pages = @ceil($total/$per_list);
    $prev = ($page - 1);
    $next = ($page + 1);
		
		while($getItem = @mysql_fetch_array($true)) {
	   echo "<div id=\"separate\">\n" . $this->pullTemplates($getItem['listID'], 'category') . "\n</div>\n";
    }
 
    echo '<p id="pagination">';
    if($page > 1) {
     echo '<a href="' . $_URL . 'p=' . $prev . '">Previous &laquo;</a> ';
    } else {
     echo 'Previous &laquo; ';
    }
		
    if($page < $pages) {
     echo '<a href="' . $_URL . 'p=' . $next . '">Next &raquo;</a>';
    } else {
     echo 'Next &raquo;';
    }
    echo '</p>';
   }
  }
 }
}

$collectivefunc = new collectivefunc();
?>
