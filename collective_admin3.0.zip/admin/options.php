<?php 
# 'OPTIONS' FILE 
/* ----------------------------------------------------------
Tess Ally 2006 � Collective Admin 
------------------------------------------------------------- */
$getTitle = "Options";
require("pro.inc.php");
require("vars.inc.php");
require("header.php");

echo "<h2>{$getTitle}</h2>\n";

if(isset($_POST['action']) && $_POST['action'] == 'Edit Options') {
$adm_path = $eastroad->cleanMys($_POST['adm_path']);
$adm_http = $eastroad->cleanMys($_POST['adm_http']);
 if(!strrchr($adm_http, '/') || !strrchr($adm_path, '/')) {
  $eastroad->displayError('Script Error', 'One or more of your paths need trailing slashes. Add them.', false);
 } 
 if($optionsfunc->getOption('admPath') != $adm_path) {
  $optionsfunc->editOption('admPath', $adm_path);
 }
 if($optionsfunc->getOption('admHttp') != $adm_http) {
  $optionsfunc->editOption('admHttp', $adm_http);
 }
$img_path = $eastroad->cleanMys($_POST['img_path']);
$img_http = $eastroad->cleanMys($_POST['img_http']);
 if(!strrchr($img_http, '/') || !strrchr($img_path, '/')) {
  $eastroad->displayError('Script Error', 'One or more of your paths need trailing slashes. Add them.', false);
 } 
 if($optionsfunc->getOption('imgPath') != $img_path) {
  $optionsfunc->editOption('imgPath', $img_path);
 }
 if($optionsfunc->getOption('imgHttp') != $img_http) {
  $optionsfunc->editOption('imgHttp', $img_http);
 }
$per_page_opt = $eastroad->cleanMys((int)$_POST['per_page']);
 if(!ctype_digit($per_page_opt)) {
  $eastroad->displayError('Script Error', 'Your pagination field isn\'t a number. Go back and enter a <em>digit</em>.', false);
 } elseif (strlen($per_page_opt) > 2) {
  $eastroad->displayError('Script Error', 'The script does not allow pagination queries' . 
	' longer than 2 digits. Go back and enter a different number.', false);
 }
 if($optionsfunc->getOption('perPage') != $per_page_opt) {
  $optionsfunc->editOption('perPage', $per_page_opt);
 }
$per_list_opt = $eastroad->cleanMys((int)$_POST['per_list']);
 if(!ctype_digit($per_list_opt)) {
  $eastroad->displayError('Script Error', 'Your pagination field isn\'t a number. Go back' . 
	' and enter a <em>digit</em>.', false);
 } elseif (strlen($per_list_opt) > 2) {
  $eastroad->displayError('Script Error', 'The script does not allow pagination queries longer than 2 digits.' . 
  ' Go back and enter a different number.', false);
 }
 if($optionsfunc->getOption('perList') != $per_list_opt) {
  $optionsfunc->editOption('perList', $per_list_opt);
 }
$markup_opt = $eastroad->cleanMys($_POST['markup']);
$markup_opt_array = array('html', 'xhtml');
 if(empty($markup_opt) || !in_array($markup_opt, $markup_opt_array)) {
  $eastroad->displayError('Script Error', 'Your <samp>markup</samp> field is invalid.', false);
 }
 if($optionsfunc->getOption('markUp') != $markup_opt) {
  $optionsfunc->editOption('markUp', $markup_opt);
 }
$show_bth = $eastroad->cleanMys($_POST['show_bth']);
$show_def = $eastroad->cleanMys($_POST['show_def']);
$show_dar = array('all', 'category', 'status');
$show_bar = array('y', 'n');
 if(empty($show_bth) || empty($show_def)) {
  # Default values: 
  $show_bth = 'n';
  $show_def = 'cat';
 } elseif (!in_array($show_def, $show_dar)) {
  $eastroad->displayError('Script Error', 'You can have <samp>all</samp>,' . 
	' <samp>category</samp> or <samp>status</samp> as your default list.', false);
 } elseif (!in_array($show_bth, $show_bar)) {
  $eastroad->displayError('Script Error', 'You can have <samp>y</samp> or <samp>n</samp> in your "Both Lists" field.', false);
 }
 if($optionsfunc->getOption('showBoth') != $show_bth) {
  $optionsfunc->editOption('showBoth', $show_bth);
 }
 if($optionsfunc->getOption('showDefault') != $show_def) {
  $optionsfunc->editOption('showDefault', $show_def);
 }
$sort_by_opt = $eastroad->cleanMys($_POST['sort_by']);
$sort_by_opt_array = array('id', 'since', 'subject'); 
 if(empty($sort_by_opt) || !in_array($sort_by_opt, $sort_by_opt_array)) {
  $eastroad->displayError('Script Error', 'Your <samp>sort by</samp> field is invalid.', false);
 }
 if($optionsfunc->getOption('sortBy') != $sort_by_opt) {
  $optionsfunc->editOption('sortBy', $sort_by_opt);
 }

echo $eastroad->backLink('options');
}

else {
?>
<p>Below are the options you entered when you installed the script. All options can be edited, however, no options 
can be currently added (although this might change in future releases).</p>

<form action="options.php" method="post">
<fieldset>
<legend>Paths</legend>
<p><label><strong>Admin Paths:</strong><br />
Adm paths are for your admin panel.</label>
<input name="adm_path" class="input1" type="text" value="<?php echo $optionsfunc->getOption('admPath'); ?>" /><br />
<input name="adm_http" class="input1" type="text" value="<?php echo $optionsfunc->getOption('admHttp'); ?>" /></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>Image Paths:</strong><br />
Image paths are for your site images.</label>
<input name="img_path" class="input1" type="text" value="<?php echo $optionsfunc->getOption('imgPath'); ?>" /><br />
<input name="img_http" class="input1" type="text" value="<?php echo $optionsfunc->getOption('imgHttp'); ?>" /></p>
</fieldset>

<fieldset>
<legend>Pagination</legend>
<p><label><strong>Per Page:</strong><br />
Pagination for the admin panel.
</label> <input name="per_page" class="input1" type="text" value="<?php echo $optionsfunc->getOption('perPage'); ?>" /></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>Per List:</strong><br />
Pagination for displaying all sites (option for that below).
</label> <input name="per_list" class="input1" type="text" value="<?php echo $optionsfunc->getOption('perList'); ?>" /></p>
</fieldset>

<fieldset>
<legend>Mark-Up Choose</legend>
<p><label><strong>Mark-Up</strong><br />
Chooses whether you'd like HTML or XHTML as your markup.</label>
<?php 
if($optionsfunc->getOption('markUp') == 'xhtml') { 
?>
<input name="markup" class="input3" checked="checked" type="radio" value="xhtml" /> XHTML
<input name="markup" class="input3" type="radio" value="html" /> HTML</p>
<?php 
} else { 
?>
<input name="markup" class="input3" checked="checked" type="radio" value="html" /> HTML
<input name="markup" class="input3" type="radio" value="xhtml" /> XHTML</p>
<?php 
} 
?>
</fieldset>

<fieldset>
<legend>Lists</legend>
<p><label><strong>Default List:</strong><br />
Decides what your "default" list will be for <samp>show_sites.php</samp> 
(usually needed if <samp>Both Lists</samp> is set to 'n'). Options are <samp>all</samp>,
<samp>cat</samp> and <samp>sts</samp> (status).
</label> <input name="show_def" class="input1" type="text" value="<?php echo $optionsfunc->getOption('showDefault'); ?>" /></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>Both Lists:</strong><br />
Decides if you'd like both lists in <samp>show_sites.php</samp>; if yes, set
to 'y', if no, set to 'n'
</label> <input name="show_bth" class="input1" type="text" value="<?php echo $optionsfunc->getOption('showBoth'); ?>" /></p>
</fieldset>

<fieldset>
<legend>Lists: Sort by</legend>
<p>This option can only be used if <strong>Default List</strong> is set to 'all' (in which it displays all sites,
not by category or status). You can choose between sorting by <samp>id</samp>, <samp>since</samp> (date) and 
<samp>subject</samp>.</p>
<p><label><strong>Sort by:</strong></label> 
<input name="sort_by" class="input1" type="text" value="<?php echo $optionsfunc->getOption('sortBy'); ?>" /></p>
</fieldset>

<fieldset>
<legend>Submit</legend>
<p class="tc"><input name="action" class="input2" type="submit" value="Edit Options" /></p>
</fieldset>
</form>
<?php
}

require("footer.php");
?>
