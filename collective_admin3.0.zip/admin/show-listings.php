<div id="show-listings">
<?php 
# 'SHOW-LISTINGS' FILE 
/* ---------------------------------------------------------- 
Tess Ally 2006 � Collective Admin 
------------------------------------------------------------- */ 
require("rats.inc.php");
require_once("fun.inc.php");
require_once("fun-categories.inc.php");
require_once("fun-collective.inc.php");
require_once("fun-misc.inc.php");
require("vars.inc.php");

# -- Get Variables ------------------------------------------
if(!isset($_GET['p']) || empty($_GET['p']) || !ctype_digit($_GET['p'])) {
 $page = 1;
} else {
 $page = $eastroad->cleanMys((int)$_GET['p']);
}
$start = mysql_real_escape_string((($page * $per_list) - $per_list));
$sortByOpt = $optionsfunc->getOption('sortBy');

# -- Get by categories --------------------------------------
if(isset($_GET['c']) && !empty($_GET['c'])) {
 $cat = $eastroad->cleanMys($_GET['c']);
 $catArray = $categoryfunc->categoryList();
 if(empty($cat) || !in_array($cat, $catArray)) {
  $eastroad->displayError('Script Error', 'You have selected an incorrect category!', false);
 }
 
 $select = "SELECT * FROM `$_CA[main]`";
 if(isset($_GET['c']) && $_GET['c'] != 'all') {
  $select .= " WHERE `listCategory` LIKE '%!$cat!%'";
 }
 if($sortByOpt == 'id') {
  $select .= " ORDER BY `listID` ASC";
 } elseif ($sortByOpt == 'since') {
  $select .= " ORDER BY `listSince` DESC";
 } elseif ($sortByOpt == 'subject') {
  $select .= " ORDER BY `listSubject` ASC";
 } else {
  $select .= " ORDER BY `listSubject` ASC";
 }
 $true = mysql_query($select);
 if($true == false) {
  $eastroad->displayError('Script Error', 'Unable to select the specified sites.', false);
 }
 $count = mysql_num_rows($true);
 
 $name = $categoryfunc->getCatName($_GET['c']);

 if(isset($_GET['c']) && $_GET['c'] == 'all') {
  echo '<p>You are viewing all categories. There are currently <strong>' . $count . "</strong> sites listed.</p>\n";
  while($getAll = mysql_fetch_array($true)) {
   echo "<div class=\"separate\">\n" . $collectivefunc->pullTemplates($getAll['listID'], 'category') . "\n</div>\n";
  }
 } 
 
 elseif ((isset($_GET['c']) && ctype_digit($_GET['c'])) && ($_GET['c'] != 'all')) {
  echo '<p class="tc">You are viewing the <strong>' . $name . '</strong> category. There are currently <strong>' . 
  $count . "</strong> site(s) listed.</p>\n";
  while($getByCat = mysql_fetch_array($true)) {
   echo "<div class=\"separate\">\n" . $collectivefunc->pullTemplates($getByCat['listID'], 'category') . "\n</div>\n";
  }
 }
}

# -- Get by status ------------------------------------------
elseif (isset($_GET['s']) && !empty($_GET['s'])) {
 $raw = $eastroad->cleanMys($_GET['s']);
 $sta = $eastroad->cleanMys($_GET['s']) - 1;
 $staArray = array('0', '1', '2', '3');
 if(!in_array($sta, $staArray)) {
  $eastroad->displayError('Script Error', 'You have selected an incorrect status!', false);
 }

 $select = "SELECT * FROM `$_CA[main]`";
 if(isset($_GET['s']) && $_GET['s'] != 'all') {
  $select .= " WHERE `listStatus` = '$sta'";
 }
 if($sortByOpt == 'id') {
  $select .= " ORDER BY `listID` ASC";
 } elseif ($sortByOpt == 'since') {
  $select .= " ORDER BY `listSince` DESC";
 } elseif ($sortByOpt == 'subject') {
  $select .= " ORDER BY `listSubject` ASC";
 } else {
  $select .= " ORDER BY `listSubject` ASC";
 }
 $true = mysql_query($select);
 if($true == false) {
  $eastroad->displayError('Script Error', 'Unable to select the specified sites.', false);
 }
 $count = mysql_num_rows($true);
 
 $name = $collectivefunc->getStatusName($_GET['s']);
 
 if(isset($_GET['s']) && $_GET['s'] == 'all') {
  echo '<p>You are viewing all statuses. There are currently <strong>' . $count . "</strong> sites listed.</p>\n";
  while($getAll = mysql_fetch_array($true)) {
   echo "<div class=\"separate\">\n" . $collectivefunc->pullTemplates($getAll['listID'], 'status') . "\n</div>\n";
  }
 } 
 
 elseif ((isset($_GET['s']) && ctype_digit($_GET['s'])) && ($_GET['s'] != 'all')) {
  echo '<p class="tc">You are viewing the <strong>' . $name . '</strong> status. There are currently <strong>' . 
  $count . "</strong> listing(s) listed.</p>\n";
  while($getByCat = mysql_fetch_array($true)) {
   echo "<div class=\"separate\">\n" . $collectivefunc->pullTemplates($getByCat['listID'], 'status') . "\n</div>\n";
  }
 }
}

# -- Get Index ----------------------------------------------
else {
if(empty($showDefault)) {
 $default = 'category';
} else {
 $default = $optionsfunc->getOption('showDefault');
}

 if($optionsfunc->getOption('showBoth') == 'y') {
  echo $collectivefunc->showDefault('category');
  echo $collectivefunc->showDefault('status');
 } else {
  echo $collectivefunc->showDefault($default);
 }
}
?>
<p class="showCredit" style="text-align: center;">
 Powered by <a href="<?php echo $_CA['versionURI']; ?>" title="External Link: <?php echo $optionsfunc->shortURL($_CA['versionURI']); ?>">
 <?php echo $_CA['version']; ?> &raquo;</a>
</p>
</div>
