<?php 
# 'INDEX' FILE 
/* ---------------------------------------------------------- 
Tess Ally 2006 � Collective Admin 
------------------------------------------------------------- */ 
$getTitle = "Control Panel";
require("pro.inc.php");
require("vars.inc.php");
require("header.php");

echo "<h2>$getTitle</h2>\n";

if(is_dir($optionsfunc->getOption('admPath') . 'install/')) {
?>
<p class="mysqlButton"><span class="mysql">Error:</span> It appears you still 
have the <samp>/install/</samp> folder still on your server. The 
<samp>readme.txt</samp> file clearly states to delete this as soon as you are 
done installing the script, as it's a security hazard. <ins>DO NOT DISAPPOINT 
THE SERVER</ins>.</p>
<?php 
}

else {
?>
<p>Welcome to <samp><?php echo $_CA['version']; ?></samp>, the script built to 
manage your collective websites (or just a list of websites in general). Please 
note that this script is not used for creating sites, but for managing "links" 
of your existing, upcoming, pending and closed ones (a lot like the infamous 
scripts <samp>Flinx</samp> and <samp>Ninja Links</samp>).</p>
<p>The control panel of your script is where you'll be able to view statistics 
(of sites, categories, templates, the like) and use this as a refresh stop. 
Navigation is simple, and is to the left. Have fun creating and displaying your 
list of websites! :D</p>
<?php 
$con = 1;
$exp = explode('Collective Admin ', $_CA['version']);
$url = "http://keepitpumpin.net/versions/";

require_once('fetch/rss_fetch.inc');
$items = fetch_rss($url);
foreach($items->items as $item) { 
 if($con > 0) {
  if($item['title'] === 'Collective Admin' && $item['description'] !== $exp[1]) {
	 echo "<p class=\"errorButton\"><span class=\"error\">Error!</span> It appears you do not have the latest" . 
	 " version of Collective Admin! Please visit the" . 
	 " <a href=\"http://keepitpumpin.net/downloads/\" title=\"External Link: Pumpin'!\">downloads page at Pumpin'! &raquo;</a> to" . 
	 " download the latest version.</p>\n";
	}
 }
 $con--;
}
?>
<h3>Statistics</h3>
<?php 
$categories = $optionsfunc->getCount('cat');
$current = $optionsfunc->getCount('current');
$upcoming = $optionsfunc->getCount('upcoming');
$pending = $optionsfunc->getCount('pending');
$closed = $optionsfunc->getCount('closed');
$sites = $current + $upcoming + $pending + $closed;
?>
<p id="stats">You have <?php echo $current; ?> current sites (with 
<?php echo $upcoming; ?> upcoming, <?php echo $pending; ?> pending and 
<?php echo $closed; ?> closed). This makes <?php echo $sites; ?> sites total. 
Your category number boasts a whopping <?php echo $categories; ?>. Your two 
templates and options that were installed prior are permanent, regardless of 
their use.</p>
<?php	 
}

require("footer.php");
?>
