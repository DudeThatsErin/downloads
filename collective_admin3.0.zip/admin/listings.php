<?php 
# 'SITES' FILE 
/* ---------------------------------------------------------- 
Tess Ally 2006 � Collective Admin 
------------------------------------------------------------- */ 
$getTitle = "Listings";
require("pro.inc.php");
require("vars.inc.php");
require("header.php");

echo "<h2>{$getTitle}</h2>\n";

if(!isset($_GET['page']) || empty($_GET['page']) || !ctype_digit($_GET['page'])) { 
 $page = 1;
} else {
 $page = $eastroad->cleanMys((int)$_GET['page']);
}
$start = mysql_real_escape_string((($page * $per_page) - $per_page));

if(isset($_GET['g']) && $_GET['g'] == 'new') {
?>
<form action="listings.php" enctype="multipart/form-data" method="post">
<fieldset>
<legend>Details</legend>
<p><label>Title:</label> <input name="title" class="input1" type="text" /></p>
<p><label>Subject:</label> <input name="subject" class="input1" type="text" /></p>
<p><label>URL:</label> <input name="url" class="input1" type="text" /></p>
<p><label>Status:</label> <select name="status" class="input1">
<option value="0">Current</option>
<option value="1">Upcoming</option>
<option value="2">Pending</option>
<option value="3">Closed</option>
</select></p>
</fieldset>

<fieldset>
<legend>Image</legend>
<p><label>Image:</label> <input name="image" class="input1" type="file" /></p>
</fieldset>

<fieldset>
<legend>Description</legend>
<p class="tr"><textarea name="desc" cols="70" rows="15" style="height: 150px; margin: 0 1% 0 0; width: 99%;"></textarea></p>
</fieldset>

<fieldset>
<legend>Categor(y|ies)</legend>
<p class="tc"><label>Categor(y|ies):</label> <select name="category[]" class="input1" multiple="multiple" size="5">
<?php 
$select = "SELECT * FROM `$_CA[categories]` ORDER BY `catName` ASC";
$true = mysql_query($select);
if($true == false) { 
 echo "<option>No Categories Found</option>\n";
}

else {
 while($getItem = mysql_fetch_array($true)) {
 $catid = $getItem['catID'];
  echo('<option value="' . $getItem['catID'] . '">' . $getItem['catName'] . "</option>\n"); 
	$q2 = mysql_query("SELECT * FROM `$_CAT[categories]` WHERE `catParent` = '$catid' ORDER BY `catName` ASC");
	while($getItem2 = mysql_fetch_array($q2)) {
   echo '<option value="' . $getItem2['catID'] . '">' . 
	 $categoryfunc->getCatName($getItem2['catParent']) . " &raquo; " . $getItem2['catName'] . "</option>\n";
	}
 }
}
?>
</select></p>
</fieldset>

<fieldset>
<legend>Date Opened</legend>
<p class="tc"><label>Month:</label> <select name="month" class="input1" size="4">
<?php
$dateArray = $get_date_array;
$currMonth = @date("F");
$currMonth2 = explode('!', $currMonth);
foreach($dateArray as $dA => $dA2) {
 echo '<option value="' . $dA . '"';
 if(in_array($dA, $currMonth2)) { 
  echo ' selected="selected"';
 }
 echo '>' . $dA2 . "</option>\n";
}
?>
</select></p>
<p class="tc"><label>Day:</label> <input name="day" class="input1" type="text" value="<?php echo date('d'); ?>" /></p>
<p class="tc"><label>Year:</label> <input name="year" class="input1" type="text" value="<?php echo date('Y'); ?>" /></p>
</fieldset>

<fieldset>
<legend>Submit</legend>
<p class="tc"><input name="action" class="input2" type="submit" value="Add Listing" /> 
<input class="input2" type="reset" value="Reset" /></p>
</fieldset>
</form>
<?php
}

elseif (isset($_POST['action']) && $_POST['action'] == 'Add Listing') {
$title = $eastroad->cleanMys($_POST['title']);
$subject = $eastroad->cleanMys($_POST['subject']);
 if(empty($subject)) {
  $eastroad->displayError('Script Error', 'Your subject is empty.', false);
 } 
$url = $eastroad->cleanMys($_POST['url']);
 if(!empty($url)) {
  if(!strstr($url, 'http://')) {
   $eastroad->displayError('Script Error', 'Your <samp>site URL</samp> does not start with http:// and therefore' . 
	 ' is not valid. Try again.', false);
  } elseif (filter_var($url, FILTER_VALIDATE_URL) == false) {
   $eastroad->displayError('Script Error', 'Your <samp>site URL</samp> appears to be invalid.', false);
  }
 }
$image = $_FILES['image'];
$image_tag = substr(md5(mt_rand(70, 120)), 0, 10);
 if(isset($_FILES['image']) && !empty($image['name']))
 if($image['type'] != 'image/jpeg' && $image['type'] != 'image/png' && $image['type'] != 'image/gif') {
  $eastroad->displayError('Script Error', 'Only <samp>.gif</samp>, <samp>.jpg</samp> and <samp>.png</samp> extensions' . 
	' allowed.', false);
 }
$desc = $eastroad->cleanMys($_POST['desc'], 'nom');
$status = $eastroad->cleanMys((int)$_POST['status']);
 if(!ctype_digit($status)) {
  $eastroad->displayError('Script Error', 'Your <samp>status</samp> is not a number.', false);
 } elseif (strlen($status) > 1) {
  $eastroad->displayError('Script Error', 'Your <samp>status</samp> should not go over 3. Go back and try again.', false);
 } elseif ($status > 3) {
  $eastroad->displayError('Script Error', 'Your <samp>status</samp> needs to be between the numbers of 0 and 3.', false);
 }
$category = array();
 $category = $_POST['category'];
 $category = $eastroad->cleanArray($category, 'all', 'nom');
 if(empty($category)) {
  $category = 0;
 }
$year = $eastroad->cleanMys((int)$_POST['year'], 'n');
 if(empty($year)) {
  $eastroad->displayError('Script Error', 'Your <samp>year</samp> field is empty.', false);
 } elseif (!ctype_digit($year)) {
  $eastroad->displayError('Script Error', 'Your <samp>year</samp> field is not a number.', false);
 } elseif (strlen($year) > 4) {
  $eastroad->displayError('Script Error', 'Your <samp>year</samp> field needs to be the length of 4 digits.', false);
 }
$month = $eastroad->cleanMys((int)$_POST['month'], 'n');
 if(empty($month)) {
  $eastroad->displayError('Script Error', 'Your <samp>month</samp> field is empty.', false);
 } elseif (!ctype_digit($month)) {
  $eastroad->displayError('Script Error', 'Your <samp>month</samp> field is not a number.', false);
 } elseif (strlen($month) > 2) {
  $eastroad->displayError('Script Error', 'Your <samp>month</samp> field needs to be the length of 2 digits.', false);
 }
$day = $eastroad->cleanMys((int)$_POST['day'], 'n');
 if(empty($day)) {
  $eastroad->displayError('Script Error', 'Your <samp>day</samp> field is empty.', false);
 } elseif (!ctype_digit($day)) {
  $eastroad->displayError('Script Error', 'Your <samp>day</samp> field is not a number.', false);
 } elseif (strlen($day) > 2) {
  $eastroad->displayError('Script Error', 'Your <samp>day</samp> field needs to be the length of 2 digits.', false);
 }
$date = $eastroad->cleanMys($year . '-' . $month . '-' . $day);

# Get "path": 
$img_path = $optionsfunc->getOption('imgPath');
if(!empty($img_path) || is_dir($img_path)) {
 $path = $optionsfunc->getOption('imgPath');
} else {
 $path = $_SERVER['SCRIPT_FILENAME'];
 $path = str_replace('listings.php', '', $path);
}

if(file_exists($path . $image['name'])) {
 $before = $image_tag . '_';
} else {
 $before = "";
}
 
if(!empty($image['name'])) {
 $file = mysql_real_escape_string('PmpA_' . $before . $image['name']);
 $success = @move_uploaded_file($_FILES['image']['tmp_name'], $path . $file);
} else {
 $file = '';
}

$cat = implode('!', $category);
$cat = '!' . trim($cat, '!') . '!';
 
$insert = "INSERT INTO `$_CA[main]` (`listTitle`, `listSubject`, `listURL`, `listImage`," . 
" `listDesc`, `listStatus`, `listCategory`, `listSince`) VALUES ('$title', '$subject'," . 
" '$url', '$file', '$desc', '$status', '$cat', '$date')";
mysql_query("SET NAMES 'utf8';");
$true = mysql_query($insert);

if($true == false) {
 $eastroad->displayError('Database Error', 'Unable to add the site.', true, $insert);
} elseif ($true == true) {
 echo '<p class="successButton"><span class="success">SUCCESS!</span> Your site was added! :D</p>';
  if(isset($success)) { 
   if($success) {
	  echo '<p class="successButton"><span class="success">SUCCESS!</span> Your image was uploaded!</p>';
   }
  }
  echo $eastroad->backLink('listings');
 }
}

/* -- Edit --------------------------------------------------------------------- */

elseif (isset($_GET['g']) && $_GET['g'] == 'old') {
if(empty($_GET['id']) || !isset($_GET['id'])) {
?>
<form action="listings.php" method="get">
<p class="noBottom"><input name="g" type="hidden" value="old" /></p>
<fieldset> 
<legend>Choose Listing</legend>
<p><label>Listing:</label> <select name="id" class="input1" size="6">
<?php 
$select = "SELECT * FROM `$_CA[main]` ORDER BY `listSubject` ASC";
$true = mysql_query($select);
if($true == false) { 
 echo "<option>No Listings Available</option>\n";
}

else {
 while($getItem = mysql_fetch_array($true)) {
  echo '<option value="' . $getItem['listID'] . '">' . $getItem['listSubject'] . "</option>\n";
 }
}
?>
</select></p>
<p class="tc"><input class="input2" type="submit" value="Edit Listing" /></p>
</fieldset>
</form>
<?php
}

if(!empty($_GET['id'])) {
$id = $eastroad->cleanMys((int)$_GET['id']);
 if(empty($id) || !ctype_digit($id)) {
  $eastroad->displayError('Script Error', 'Your ID is empty. This means you selected an incorrect category or' . 
  ' you\'re trying to access something that doesn\'t exist. Go back and try again.', false);
 }

$select = "SELECT * FROM `$_CA[main]` WHERE `listID` = '$id' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the site.|Make sure the ID of the site actually exists.', true, $select);
}
$getItem = mysql_fetch_array($true);
?>
<form action="listings.php" enctype="multipart/form-data" method="post">
<p class="noBottom"><input name="id" type="hidden" value="<?php echo $getItem['listID']; ?>" /></p>

<fieldset>
<legend>Details</legend>
<p><label>Title:</label> <input name="title" class="input1" type="text" value="<?php echo $getItem['listTitle']; ?>" /></p>
<p><label>Subject:</label> <input name="subject" class="input1" type="text" value="<?php echo $getItem['listSubject']; ?>" /></p>
<p><label>URL:</label> <input name="url" class="input1" type="text" value="<?php echo $getItem['listURL']; ?>" /></p>
<p><label>Status:</label> 
<?php 
$statusArray = $get_status_array;
$statusNow1 = $getItem['listStatus']; 
$statusNow2 = explode('!', $statusNow1);
foreach($statusArray as $sA => $sA2) {
 echo '<option value="' . $sA . '"';
 if(in_array($sA, $statusNow2)) { 
  echo ' selected="selected"';
 }
 echo '>' . $sA2 . "</option>\n";
}
?></p>
</fieldset>

<fieldset>
<legend>Image</legend>
<?php 
$img = $optionsfunc->getOption('imgPath') . $getItem['listImage'];
if(!empty($getItem['listImage']) && file_exists($img)) { 
?>
<p class="tc"><img src="<?php echo $optionsfunc->getOption('imgHttp') . $getItem['listImage']; ?>" alt=""></p>
<?php } ?>
<p><label>Changes:</label> <input name="change" class="input3" type="radio" value="add" /> Add
<input name="change" class="input3" type="radio" value="edit" /> Edit
<input name="change" class="input3" type="radio" value="delete" /> Delete
<input name="change" checked="checked" class="input3" type="radio" value="none" /> No Change</p>
<p><label>New Image:</label> <input name="image" class="input1" type="file" /></p>
</fieldset>

<fieldset>
<legend>Description</legend>
<p><strong>Description:</strong><br><textarea name="desc" cols="50" rows="8" style="width: 100%;">
<?php echo $getItem['listDesc']; ?></textarea></p>
</fieldset>

<fieldset>
<legend>Categor(y|ies)</legend>
<p><label>Categor(y|ies):</label> <select name="category[]" class="input1" multiple="multiple" size="7">
<?php 
$select = "SELECT * FROM `$_CA[categories]` ORDER BY `catName` ASC";
$true = mysql_query($select);
if($true == false) { 
 echo "<option>No Categories Available</option>\n";
}

else {
 while($getCat = mysql_fetch_array($true)) {
  $catid = $getCat['catID'];
  $cats = explode('!', $getItem['listCategory']);
  echo '<option value="' . $getCat['catID'] . '"'; 
	if(in_array($getCat['catID'], $cats)) {
	 echo ' selected="selected"'; 
  }
	echo '>' . $getCat['catName'] . "</option>\n";
	$q2 = mysql_query("SELECT * FROM `$_CA[categories]` WHERE `catParent` = '$catid' ORDER BY `catName` ASC");
	while($getCat2 = mysql_fetch_array($q2)) {
   echo '<option value="' . $getCat2['catID'] . '"'; 
	 if(in_array($getCat2['catID'], $cats)) {
	  echo ' selected="selected"'; 
   }
	 echo '>' . $categoryfunc->getCatName($getCat2['catParent']) . " &raquo; " . $getCat2['catName'] . "</option>\n";
	}
 }
}
?>
</select></p>
</fieldset>

<fieldset>
<legend>Date Opened</legend>
<p class="tc"><label>Month:</label> <select name="month" class="input1" size="4">
<?php
$dateArray = $get_date_array;
$dateNow1 = date("m", strtotime($getItem['listSince'])); 
$dateNow2 = explode('!', $dateNow1);
foreach($dateArray as $dA => $dA2) {
 echo '<option value="' . $dA . '"';
 if(in_array($dA, $dateNow2)) { 
  echo ' selected="selected"';
 }
 echo '>' . $dA2 . "</option>\n";
}
?>
</select></p>
<p class="tc"><label>Day:</label> 
<input name="day" class="input1" type="text" value="<?php echo date('d', strtotime($getItem['listSince'])); ?>" /></p>
<p class="tc"><label>Year:</label> 
<input name="year" class="input1" type="text" value="<?php echo date('Y', strtotime($getItem['listSince'])); ?>" /></p>
</fieldset>

<fieldset>
<legend>Submit</legend>
<p class="tc"><input name="action" class="input2" type="submit" value="Edit Listing" /></p>
</fieldset>
</form>
<?php
}
}

elseif (isset($_POST['action']) && $_POST['action'] == 'Edit Listing') {
$id = $eastroad->cleanMys((int)$_POST['id']);
 if(empty($id) || !ctype_digit($id)) {
  $eastroad->displayError('Script Error', 'Your ID is empty. This means you selected an incorrect site or' . 
  ' you\'re trying to access something that doesn\'t exist. Go back and try again.', false);
 } 
$title = $eastroad->cleanMys($_POST['title']);
$subject = $eastroad->cleanMys($_POST['subject']);
 if(empty($subject)) {
  $eastroad->displayError('Script Error', 'Your subject is empty.', false);
 } 
$url = $eastroad->cleanMys($_POST['url']);
$change = $eastroad->cleanMys($_POST['change'], 'n');
$changeArray = array('add', 'edit', 'delete', 'none');
 if(!in_array($change, $changeArray)) {
  $eastroad->displayError('Script Error', 'You can only add, edit and delete an image.', false);
 }
$image = $_FILES['image'];
$image_tag = substr(md5(mt_rand(999, 9220)), 0, 10);
 if($change == 'add' || $change == 'edit') {
  if($image['type'] != 'image/jpeg' && $image['type'] != 'image/png' && $image['type'] != 'image/gif') {
   $eastroad->displayError('Script Error', 'Only <samp>.gif</samp>, <samp>.jpg</samp> and <samp>.png</samp> extensions' . 
	 ' allowed.', false);
  }
 }
$desc = $eastroad->cleanMys($_POST['desc'], 'nom');
$status = $eastroad->cleanMys((int)$_POST['status']);
 if(!ctype_digit($status)) {
  $eastroad->displayError('Script Error', 'Your <samp>status</samp> is not a number.', false);
 } elseif (strlen($status) > 1) {
  $eastroad->displayError('Script Error', 'Your <samp>status</samp> should not go over 3. Go back and try again.', false);
 } elseif ($status > 3) {
  $eastroad->displayError('Script Error', 'Your <samp>status</samp> needs to be between the numbers of 0 and 3.', false);
 }
$category = array();
 $category = $_POST['category'];
 $category = $eastroad->cleanArray($category, 'all', 'nom');
 if(empty($category)) {
  $category = 0;
 }
$year = $eastroad->cleanMys((int)$_POST['year'], 'n');
 if(empty($year)) {
  $eastroad->displayError('Script Error', 'Your <samp>year</samp> field is empty.', false);
 } elseif (!ctype_digit($year)) {
  $eastroad->displayError('Script Error', 'Your <samp>year</samp> field is not a number.', false);
 } elseif (strlen($year) > 4) {
  $eastroad->displayError('Script Error', 'Your <samp>year</samp> field needs to be the length of 4 digits.', false);
 }
$month = $eastroad->cleanMys((int)$_POST['month'], 'n');
 if(empty($month)) {
  $eastroad->displayError('Script Error', 'Your <samp>month</samp> field is empty.', false);
 } elseif (!ctype_digit($month)) {
  $eastroad->displayError('Script Error', 'Your <samp>month</samp> field is not a number.', false);
 } elseif (strlen($month) > 2) {
  $eastroad->displayError('Script Error', 'Your <samp>month</samp> field needs to be the length of 2 digits.', false);
 }
$day = cleanUpt((int)$_POST['day'], 'n');
 if(empty($day)) {
  $eastroad->displayError('Script Error', 'Your <samp>day</samp> field is empty.', false);
 } elseif (!ctype_digit($day)) {
  $eastroad->displayError('Script Error', 'Your <samp>day</samp> field is not a number.', false);
 } elseif (strlen($day) > 2) {
  $eastroad->displayError('Script Error', 'Your <samp>day</samp> field needs to be the length of 2 digits.', false);
 }
$date = $eastroad->cleanMys($year . '-' . $month . '-' . $day);
 
if($change != 'none' && $change != 'add') {
$sImage = $listingsfunc->pullImage($id);
$dImage = $optionsfunc->getOption('imgPath') . $sImage;

 if($change == 'edit') {
  # Get image checks: 
  if(!file_exists($dImage)) {
	 $eastroad->displayError('Script Image', 'The file you chose to edit doesn\'t exist.|' . 
	 'Make sure your image path is and the file exists.', false);
  } elseif ($dImage == $image['name']) {
	 $eastroad->displayError('Script Image', 'The current version of the script does not' . 
	 ' allow uploads for files with the same name. Go back and edit the name of the file.', false);
  }
	# Andddd, we're safe: 
  if(file_exists($dImage)) {
	$delete = @unlink($dImage);
   if($delete == false) {
	  $eastroad->displayError('Script Error', 'Unable to delete <samp>' . $sImage . '</samp>.|' . 
		'Make sure your table exists and the file is in the appropriate folder.', false);
   } 
	}
 } elseif ($change == 'delete') {
  # Perform the checks needed to delete: 
  if(!file_exists($dImage)) {
	 displayError('Script Image', 'The file you chose to edit doesn\'t exist.|' . 
	 'Make sure your image path is and the file exists.', false);
  } 
	# We're OK: 
	if(file_exists($dImage)) {
	$delete = @unlink($dImage);
   if($delete == false) {
	  $eastroad->displayError('Script Error', 'Unable to delete <samp>' . $sImage . '</samp>.|' . 
		'Make sure your table exists and the file is in the appropriate folder.', false);
   }
	}
 }
}

# Get "path": 
$img_path = $optionsfunc->getOption('imgPath');
if(!empty($img_path) || is_dir($img_path)) {
 $path = $optionsfunc->getOption('imgPath');
} else {
 $path = $_SERVER['SCRIPT_FILENAME'];
 $path = str_replace('listings.php', '', $path);
} 

if(file_exists($path . $image['name'])) {
 $before = $image_tag . '_';
} else {
 $before = "";
}

if($change == 'add' || $change == 'edit') {
 if($change != 'delete' && $change != 'none') {
  $file = mysql_real_escape_string('PmpA_' . $image['name']);
  $success = @move_uploaded_file($_FILES['image']['tmp_name'], $path . $file);
 }
}
$cat = implode('!', $category);
$cat = '!' . trim($cat, '!') . '!';
 
$update = "UPDATE `$_CA[main]` SET `listTitle` = '$title', `listSubject` = '$subject', `listURL` = '$url',";
if($change == 'add' || $change == 'edit') { 
 $update .= " `listImage` = '$file',";
}
$update .= " `listDesc` = '$desc', `listStatus` = '$status', `listCategory` = '$cat', `listSince` = '$date'";
$update .= " WHERE `id` = '$id' LIMIT 1";
mysql_query("SET NAMES 'utf8';");
$true = mysql_query($update);

if($true == false) {
 $eastroad->displayError('Database Error', 'Unable to edit the site.|' . 
 'Make sure the ID of the site exists.', true, $update);
} else if($true == true) {
 echo '<p class="successButton"><span class="success">SUCCESS!</span> Your site was edited! :D</p>';
 if(isset($delete) && isset($success)) { 
	if($delete && $success) {
	 echo '<p class="successButton"><span class="success">SUCCESS!</span>' . 
	 ' Your old image was deleted and replaced with a new one!</p>';
	 }
	} 
	elseif (isset($delete) && !isset($success)) {
	 if($delete) {
    echo '<p class="successButton"><span class="success">SUCCESS!</span> Your old image was deleted!</p>';
	 }
	} 
	elseif (!isset($delete) && isset($success)) { 
	 if($success) {
	  echo '<p class="successButton"><span class="success">SUCCESS!</span> Your image was uploaded!</p>';
   }
	}
  echo $eastroad->backLink('listings');
 }
}

/* -- Delete ------------------------------------------------------------------- */

elseif (isset($_GET['g']) && $_GET['g'] == 'erase') {
if(empty($_GET['id']) || !isset($_GET['id'])) {
?>
<form action="listings.php" method="get">
<p class="noBottom"><input name="g" type="hidden" value="erase" /></p>
<fieldset> 
<legend>Choose Listing</legend>
<p><label>Listing:</label> <select name="id" class="input1" size="6">
<?php 
$select = "SELECT * FROM `$_CA[main]` ORDER BY `listSubject` ASC";
$true = mysql_query($select);
if($true == false) { 
 echo "<option>No Listings Found</option>\n";
}

else {
 while($getItem = mysql_fetch_array($true)) {
  echo '<option value="' . $getItem['listID'] . '">' . $getItem['listSubject'] . "</option>\n";
 }
}
?>
</select></p>
<p class="tc"><input class="input2" type="submit" value="Delete Listing" /></p>
</fieldset>
</form>
<?php
}

if(!empty($_GET['id'])) {
$id = $eastroad->cleanMys((int)$_GET['id']);
 if(empty($id) || !ctype_digit($id)) {
  $eastroad->displayError('Script Error', 'Your ID is empty. This means you selected an incorrect site or' . 
  ' you\'re trying to access something that doesn\'t exist. Go back and try again.', false);
 }

$select = "SELECT * FROM `$_CA[main]` WHERE `listID` = '$id' LIMIT 1";
$true = mysql_query($select);
if($true == false) {
 displayError('Database Error', 'Unable to select the site.|Make sure the ID of the site actually exists.', true, $select);
}
$getItem = mysql_fetch_array($true);
?>
<p>You are about to delete the <strong><?php echo $getItem['listSubject']; ?></strong> site; please be aware that once you delete 
a site, it is gone forever. <em>This cannot be undone!</em> To proceed, click the "Delete Site" button.</p>

<form action="sites.php" method="post">
<input name="id" type="hidden" value="<?php echo $getItem['listID']; ?>" />

<fieldset>
<legend>Delete Site</legend>
<p class="tc">Deleting <strong><?php echo $getItem['listSubject'] ?></strong></p>
<p class="tc"><input name="action" class="input2" type="submit" value="Delete Site"></p>
</fieldset>
</form>
<?php
}
}

elseif (isset($_POST['action']) && $_POST['action'] == 'Delete Listing') {
$id = $eastroad->cleanMys((int)$_POST['id']);
 if(empty($id) || !ctype_digit($id)) {
  $eastroad->displayError('Script Error', 'Your ID is empty. This means you selected an incorrect site or' . 
  ' you\'re trying to access something that doesn\'t exist. Go back and try again.', false);
 }
 
$sImage = $listingsfunc->pullImage($id);
$dImage = $optionsfunc->getOption('imgPath') . $sImage;
if(file_exists($dImage)) {
 $delete = @unlink($dImage);
}
 
$delete = "DELETE FROM `$_CA[main]` WHERE `listID` = '$id' LIMIT 1";
$true = mysql_query($delete);

if($true == false) {
 $eastroad->displayError('Database Error', 'Unable to delete the site.|Make sure your site ID exists.', true, $delete);
} elseif ($true == true) {
  echo "<p class=\"successButton\"><span class=\"success\">SUCCESS!</span> Your site was deleted! :D</p>\n";
  $eastroad->backLink('listings');
 } 
} 

/* -- Index -------------------------------------------------------------------- */

else {
?>
<p>Welcome to <samp>sites.php</samp>, the outlet to adding sites and editing or deleting your current ones! 
Below is your list of sites. To edit or delete a category, click "Edit" or "Delete" by the appropriate site.</p>
<p class="explode"><a href="listings.php?g=new">Add a Site</a></p>

<div class="height">
<form action="listings.php" method="get">
<p class="noBottom"><input name="g" type="hidden" value="searchCats" /></p>
<fieldset class="lap-two">
<legend>Search Categories</legend>
<p class="tc"><select name="cat_id" class="input1">
<?php
$select = "SELECT * FROM `$_CA[categories]` ORDER BY `catName` ASC";
$true = mysql_query($select);
if($true == false) {
 echo "<option>No Categories Available</option>\n";
}

else {
 while($getItem = mysql_fetch_array($true)) {
  $catid = $getItem['catID'];
  echo '<option value="' . $getItem['catID'] . '">' . $getItem['catName'] . "</option>\n"; 
	$q2 = mysql_query("SELECT * FROM `$_CA[categories]` WHERE `catParent` = '$catid' ORDER BY `catName` ASC");
	while($getItem2 = mysql_fetch_array($q2)) {
   echo '<option value="' . $getItem2['catID'] . '">' . 
	 $categoryfunc->getCatName($getItem2['catParent']) . " &raquo; " . $getItem2['catName'] . "</option>\n";
	}
 }
}
?>
</select></p>
<p class="tc"><input class="input2" type="submit" value="Search Categories" /></p>
</fieldset>
</form>

<form action="listings.php" method="get">
<p class="noBottom"><input name="g" type="hidden" value="searchStatus" /></p>
<fieldset class="lap-two">
<legend>Search Status</legend>
<p class="tc"><select name="status_id" class="input1">
<option value="1">Current</option>
<option value="2">Upcoming</option>
<option value="3">Pending</option>
<option value="4">Closed</option>
</select></p>
<p class="tc"><input class="input2" type="submit" value="Search Status" /></p>
</fieldset>
</form>
<div style="clear: both; margin: 0 0 1% 0;"></div>
</div>
<?php
if(isset($_GET['g']) && $_GET['g'] == 'searchCats') {
 $cat_id = $eastroad->cleanMys((int)$_GET['cat_id']);

 $select = "SELECT * FROM `$_CA[main]` WHERE `listCategory` LIKE '%!$cat_id!%' ORDER BY `listTitle` ASC LIMIT $start, $per_page";
 $true = mysql_query($select);
 if($true == false) {
  $eastroad->displayError('Database Error', 'Unable to select the sites from the' . 
	' database.|Make sure your table exists.', true, $select);
 }
 $count = mysql_num_rows($true);
}

elseif (isset($_GET['g']) && $_GET['g'] == 'searchStatus') {
 $status_id = $eastroad->cleanMys((int)$_GET['status_id']) - 1;

 $select = "SELECT * FROM `$_CA[main]` WHERE `listStatus` = '$status_id' ORDER BY `listTitle` ASC LIMIT $start, $per_page";
 $true = mysql_query($select);
 if($true == false) {
  $eastroad->displayError('Database Error', 'Unable to select the sites from the database.| ' . 
	'Make sure your table exists.', true, $select);
 }
 $count = mysql_num_rows($true);
}

else {
 $select = "SELECT * FROM `$_CA[main]` ORDER BY `listTitle` ASC LIMIT $start, $per_page";
 $true = mysql_query($select);
 if($true == false) {
  $eastroad->displayError('Database Error', 'Unable to select the sites from the' . 
	' database.|Make sure your table exists.', true, $select);
 }
 $count = mysql_num_rows($true);
}

if($count > 0) {
?>
<table class="index" width="100%"><thead><tr>
<th>ID</th>
<th>Subject</th>
<th>Category</th>
<th>Action</th>
</tr></thead>
<?php
while($getItem = mysql_fetch_array($true)) {
?>
<tbody><tr>
<td class="tc"><?php echo $getItem['listID']; ?></td>
<td class="tc"><?php echo $getItem['listSubject']; ?></td>
<td class="tc"><?php echo $categoryfunc->pullCatNames($getItem['listCategory'], '!'); ?></td>
<td class="tc" width="30%">(<a href="listings.php?g=old&amp;id=<?php echo $getItem['listID']; ?>">Edit</a>) |
 (<a href="listings.php?g=erase&amp;id=<?php echo $getItem['listID']; ?>">Delete</a>)</td>
</tr></tbody>
<?php
}
echo "</table>\n";

echo '<p id="pagination">';

$select = "SELECT * FROM `$_CA[main]`";
if(isset($_GET['g']) && $_GET['g'] == 'searchCats') {
 $select .= " WHERE `listCategory` LIKE '%!$cat_id!%'";
} elseif (isset($_GET['g']) && $_GET['g'] == 'searchCats') {
 $select .= " WHERE `listStatus` = '$status_id'";
}
$true = mysql_query($select);
$total = mysql_num_rows($true);
$pages = ceil($total/$per_page);

$prev = ($page - 1);
if($page > 1) {
echo '<a href="listings.php?page=' . $prev . '">&laquo; Previous</a> ';
} elseif (isset($_GET['g']) && $_GET['g'] == 'searchCats' && $page > 1) {
echo '<a href="listings.php?g=searchCats&amp;cat_id=' . $cat_id . '&amp;page=' . $prev . '">&laquo; Previous</a> ';
} elseif (isset($_GET['g']) && $_GET['g'] == 'searchStatus' && $page > 1) {
echo '<a href="listings.php?g=searchStatus&amp;status_id=' . $status_id . '&amp;page=' . $prev . '">&laquo; Previous</a> ';
} else {
echo '&laquo; Previous ';
}

for($i = 1; $i <= $pages; $i++) {
 if($page == $i) {
  echo $i . " ";
 } elseif (isset($_GET['g']) && $_GET['g'] == 'searchCats') {
  echo '<a href="listings.php?g=searchCats&amp;cat_id=' . $cat_id . '&amp;page=' . $i . '">' . $i . '</a> ';
 } elseif (isset($_GET['g']) && $_GET['g'] == 'searchStatus') {
  echo '<a href="listings.php?g=searchStatus&amp;status_id=' . $status_id . '&amp;page=' . $i . '">' . $i . '</a> ';
 } else { 
  echo '<a href="listings.php?page=' . $i . '">' . $i . '</a> ';
 }
}

$next = ($page + 1);
if(!isset($_GET['get']) && $page < $pages) {
 echo '<a href="listings.php?page=' . $next . '">Next &raquo;</a>';
} elseif (isset($_GET['g']) && $_GET['g'] == 'searchCats' && $page < $pages) {
 echo '<a href="listings.php?g=searchCats&amp;cat_id=' . $cat_id . '&amp;page=' . $next . '">Next &raquo;</a> ';
} elseif (isset($_GET['g']) && $_GET['g'] == 'searchStatus' && $page < $pages) {
 echo '<a href="listings.php?g=searchStatus&amp;status_id=' . $status_id . '&amp;page=' . $next . '">Nexy &raquo;</a> ';
} else {
 echo 'Next &raquo;';
}

echo "</p>\n";
} 

 else {
  echo '<p class="tc">Currently no sites!</p>' . "\n";
 }
}
 
require("footer.php");
?>
