<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> <?php echo $_CA['version']; ?> &#8212; <?php echo $adminfunc->isTitle($getTitle); ?> </title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script src="js.js" type="text/javascript"></script>
</head>
<body>

<div id="container">

<div id="header"><h1><?php echo $_CA['version']; ?></h1></div>

<div id="sidebar">
<ul>
<li<?php echo $adminfunc->currently('listings'); ?>><a href="listings.php">Listings</a></li>
<?php
if($adminfunc->isPage() == 'listings.php') {
?>
<li>
 <ul>
 <li><a href="listings.php?g=new">New Site</a></li>
 <li><a href="listings.php?g=old">Edit Site</a></li>
 <li><a href="listings.php?g=erase">Delete Site</a></li>
 <li>&bull;</li>
 </ul>
</li>
<?php 
} 
?>
<li<?php echo $adminfunc->currently('categories'); ?>><a href="categories.php">Categories</a></li>
<?php
if($adminfunc->isPage() == 'categories.php') {
?>
<li>
 <ul>
 <li><a href="categories.php?g=new">New Category</a></li>
 <li><a href="categories.php?g=old">Edit Caterory</a></li>
 <li><a href="categories.php?g=erase">Delete Category</a></li>
 <li>&bull;</li>
 </ul>
</li>
<?php 
} 
?>
<li<?php echo $adminfunc->currently('templates'); ?>><a href="templates.php">Templates</a></li>
</ul>

<ul>
<li<?php echo $adminfunc->currently('codes'); ?>><a href="codes.php">Display Codes</a></li>
<li<?php echo $adminfunc->currently('options'); ?>><a href="options.php">Options</a></li>
<li<?php echo $adminfunc->currently('index'); ?>><a href="<?php echo $optionsfunc->getOption('admHttp'); ?>">Control Panel</a></li>
</ul>

<ul>
<li id="lg"><a href="<?php echo basename($_SERVER['PHP_SELF']); ?>?g=logout">&raquo; Logout</a></li>
</ul>
</div>

<div id="content">
