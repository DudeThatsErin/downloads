<?php
# 'FUN.INC' FILE 
/* ----------------------------------------------------------
Tess Ally 2006 � Collective Admin 
------------------------------------------------------------- 
*/

if(!class_exists('eastroad')) {
 class eastroad {
  # -- Get Cleaning Functions ---------------------------------
  # -----------------------------------------------------------
  function cleanMys($p, $e = 'y', $y = 'y', $s = 'y') {
	 if($e == 'y') {
	  if(get_magic_quotes_gpc()) {
     $p = stripslashes($p);
    }
    $p = mysql_real_escape_string($p);
	 }
	 
   if($y == 'y') {
    $p = strip_tags($p);
   }
 
   if($s == 'all') {
    $p = trim(htmlentities($p, ENT_QUOTES, 'UTF-8'));
   } elseif ($s == 'nom') {
    $p = trim($p);
   } else { 
    $p = trim(htmlentities($p, ENT_NOQUOTES, 'UTF-8'));
   }
	
   $p = trim($p);
   return $p;
  }
	
	# -- Clean Arrays! -----------------------------------------
	# ----------------------------------------------------------
	function cleanArray($a, $y = 'all', $s = 'all') {
	 $n = array();
	 $a = $this->emptyarray($a);
	 foreach($a as $b) {
	  $n[] = $this->cleanMys($b, $y, $s);
	 }
   return $n;
	}
	
	# -- Empties arrays of empty values -------------------------
	# -----------------------------------------------------------
	function emptyarray($a) {
   $n = array();
   $e = array();

   foreach($a as $k) {
    $k = trim($k);
    $e[] = '0';

    if(!in_array($k, $e) && $k != "") {
     $n[] = $k;
    }
   }
	 
	 return $n;
	}

  # -- Get 'displayError' Function ----------------------------
  # -----------------------------------------------------------
  function displayError($title, $body, $admin = true, $query = 'nom') {
   global $connect;

   echo "<h3>" . $title . "</h3>\n";

   if($title == 'Database Error') {
    $class = "mysql";
   } elseif ($title == 'Script Error') {
    $class = "php";
   } else {
    $class = "error";
	 }
 
   if($title == 'Database Error') {
    $p = "mysqlButton";
   } elseif ($title == 'Script Error') {
    $p = "errorButton";
   } else {
    $p = "errorButton";
   }
	 
   $bodies = explode('|', $body);
   foreach($bodies as $b) {
    echo "<p class=\"{$p} tb\">" . $b . "</p>\n";
   }

   if(isset($_COOKIE['calog']) && $admin) {
    echo "<h3>Debug Mode</h3>\n<p>There seems to be a few (hopefully minor) issues with the script:</p>\n"; 
    echo "<p class=\"$p\"><span class=\"$class\">MySQL Errors:</span> ";
    if($query != 'nom') {
     echo mysql_error($connect);
     echo "\n<br><em>" . $query . "</em></p>\n";
    } else {
     echo "</p>\n";
    }
   }
 
   exit();
  }

  # -- Get 'backLink' Function --------------------------------
  # -----------------------------------------------------------
  function backLink($p, $i = 'n') {

   if($p == 'cat') {
    $k = "\n" . '<p class="backLink"><a href="categories.php">&laquo; Back to Categories</a>' . "</p>\n";
   } elseif ($p == 'listings') {
    if($i != 'n') {
     $k = "\n" . '<p class="backLink"><a href="listings.php?get=old&amp;id=' . $i . '">&laquo; Back to Listings</a>' . "</p>\n";
    } else {
     $k = "\n" . '<p class="backLink"><a href="listings.php">&laquo; Back to Listings</a>' . "</p>\n";
    }
   } elseif ($p == 'options') {
    $k = "\n" . '<p class="backLink"><a href="options.php">&laquo; Back to Options</a>' . "</p>\n";
   } elseif ($p == 'temp') {
    $k = "\n" . '<p class="backLink"><a href="templates.php">&laquo; Back to Templates</a>' . "</p>\n";
   }
   return $k;
  }
 }
}

$eastroad = new eastroad();
?>
