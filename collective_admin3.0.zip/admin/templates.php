<?php 
# 'TEMPLATES' FILE 
/* ----------------------------------------------------------
Tess Ally 2006 � Collective Admin 
------------------------------------------------------------- */
$getTitle = "Templates";
require("pro.inc.php");
require("vars.inc.php");
require("header.php");

echo "<h2>{$getTitle}</h2>\n";

if(isset($_GET['g']) && $_GET['g'] == 'dateTemplate') {
?>
<p>Below if your template for the variable <samp>{since}</samp> for any current or future 
template that holds <samp>{since}</samp>. This template displays the way your date is displayed. 
The default template is <samp>F jS, Y</samp>, although this can be changed. For more ways to display 
the date, be sure to visit the 
<a href="http://php.net/date" title="External Link: 'date' at PHP.net">PHP manual &raquo;</a></p>

<form action="templates.php" method="post">
<fieldset>
<legend>Sites Template</legend>
<p class="tc"><textarea name="date" cols="50" rows="7" style="height: 150px; margin: 0 1% 0 0; width: 99%;">
<?php echo $optionsfunc->getTemplate('dateTemplate'); ?></textarea></p>
<p class="tc"><input name="action" class="input1" type="submit" value="Edit Date Template" /></p>
</fieldset>
</form>
<?php
}

elseif (isset($_POST['action']) && $_POST['action'] == 'Edit Date Template') {
 $date = $eastroad->cleanMys($_POST['date']);
 if(empty($date)) {
  $eastroad->displayError('Script Error', 'Your template is empty!', false);
 } 
 
 $update = "UPDATE `$_CA[templates]` SET `tempBody` = '$date' WHERE `tempName` = 'dateTemplate' LIMIT 1";
 mysql_query("SET NAMES 'utf8';");
 $true = mysql_query($update);

 if($true == false) {
  $eastroad->displayError('Database Error', 'Cannot update your date template.', true, $update);
 } elseif ($true == true) {
  echo '<p class="successButton"><span class="success">SUCCESS!</span> Your template was updated! :D</p>';
  echo $eastroad->backLink('temp');
 }
}

elseif (isset($_GET['g']) && $_GET['g'] == 'sitesTemplate') {
?>
<p>Below if your template for your sites in <samp>show_sites.php</samp>; this template is not displayed through the main
list, but through the categories of that list. You can use the following variables for aspects of the script:</p>
<table class="stats" width="100%"><tbody>
 <tr>
  <td class="right">{categories}</td>
  <td class="left">Categories the website is listed under</td>
 </tr>
 <tr>
  <td class="right">{details}</td>
  <td class="left">Description of the website</td>
 </tr>
 <tr>
  <td class="right">{image}</td>
	<td class="left">Image of the listing</td>
 </tr>
 <tr>
  <td class="right">{since}</td>
	<td class="left">Date the website opened</td>
 </tr>
 <tr>
  <td class="right">{status}</td>
  <td class="left">Status of the website</td>
 </tr>
 <tr>
  <td class="right">{subject}</td>
	<td class="left">Subject of the website</td>
 </tr>
 <tr>
  <td class="right">{title}</td>
  <td class="left">Title of website</td>
 </tr>
 <tr>
  <td class="right">{url}</td>
  <td class="left"><abbr title="Uniform Resource Indentifier">URI</abbr> of the website</td>
 </tr>
</tbody></table>

<form action="templates.php" method="post">
<fieldset>
<legend>Websites Template: Category</legend>
<p class="tc">
<textarea name="sites" cols="50" rows="7" style="height: 150px; margin: 0 1% 0 0; width: 99%;">
<?php echo $optionsfunc->getTemplate('sitesTemplate'); ?>
</textarea>
</p>
</fieldset>

<fieldset>
<legend>Websites Template: Status</legend>
<div class="infoTemp"><p>There are two sorting options on 
<samp>show-listings.php</samp>: categories or status, and you can display both, 
or one or the other. By default, the "category" template (above) is the same as the 
status template. If you'd like a different template for the status sorting 
option, click "Toggle Status Template" and unclick "Same as Websites Template?".</p>
<p class="noteButton"><strong>Please note</strong> that this is not the template
for the showing the categories and/or status', but the template that is shown
after you click a category or status.</p>
<p class="tc"><input name="status_temp_opt" checked="checked" class="input3" type="checkbox" value="yes" /> Same as Websites Template?</p>
</div>
<p class="tc" id="statusTemp" style="display: none;">
<textarea name="status" cols="50" rows="7" style="height: 150px; margin: 0 1% 0 0; width: 99%;">
<?php echo $optionsfunc->getTemplate('sitesTemplate'); ?>
</textarea>
</p>
<p class="tc"><a href="javascript:;" onclick="showWebsites('statusTemp');">Toggle Status Template?</a></p>
</fieldset>

<fieldset>
<legend>Submit</legend>
<p class="tc"><input name="action" class="input1" type="submit" value="Edit Listing Templates" /></p>
</fieldset>
</form>
<?php 
}

elseif (isset($_POST['action']) && $_POST['action'] == 'Edit Listing Templates') {
 $sites = $eastroad->cleanMys($_POST['sites'], 'y', 'n');
 if(empty($sites)) {
  $eastroad->displayError('Script Error', 'Your template is empty!', false);
 } 
 if(isset($_POST['status_temp_opt']) && $_POST['status_temp_opt'] == 'yes') {
  $status = $sites;
 } else {
  $status = $eastroad->cleanMys($_POST['status'], 'y', 'n');
 }
 
 $update = "UPDATE `$_CA[templates]` SET `tempBody` = '$sites' WHERE `tempName` = 'sitesTemplate' LIMIT 1";
 mysql_query("SET NAMES 'utf8';");
 $true = mysql_query($update);
 
 if(isset($_POST['status_temp_opt']) && $_POST['status_temp_opt'] == 'yes') {
  if($optionsfunc->getOption('tempBoth') != 'y') {
   $optionsfunc->editOption('tempBoth', 'y');
	}
 } else {
  if($optionsfunc->getOption('tempBoth') != 'n') {
   $optionsfunc->editOption('tempBoth', 'n');
	}
 }
 $updateUpdate = "UPDATE `$_CA[templates]` SET `tempBody` = '$status' WHERE `tempName` = 'statusTemplate' LIMIT 1";
 mysql_query("SET NAMES 'utf8';");
 $trueUpdate = mysql_query($updateUpdate);

 if($true == false) {
  $eastroad->displayError('Database Error', 'Cannot update your sites template.', true, $update);
 } elseif ($true == true) {
  echo '<p class="successButton"><span class="success">SUCCESS!</span> Your template was updated! :D</p>';
  echo $eastroad->backLink('temp');
 }
}

/* -- Index -------------------------------------------------------------------- */

else {
?>
<p>Welcome to <samp>templates.php</samp>, the very outlet to editing your templates for the 
displaying of your blog. Currently, you are only able to edit the two existing the templates. 
If you would like to turn them on or off, consult your <samp>rats.inc.php</samp> file. :D</p>

<h3>Default Templates</h3>
<table class="index" width="100%">
<thead><tr><th>Title</th>
<th>Action</th></tr></thead>
<tbody><tr>
<td class="tc" style="width: 50%;">Date Template</td>
<td class="tc">(<a href="templates.php?g=dateTemplate">Edit</a>)</td>
</tr></tbody>
<tbody><tr>
<td class="tc" style="width: 50%;">Sorting Template(s)</td>
<td class="tc">(<a href="templates.php?g=sitesTemplate">Edit</a>)</td>
</tr></tbody>
</table>
<?php 
}

require("footer.php");
?>
