<?php 
# 'VARS.INC' FILE 
/* ---------------------------------------------------------- 
Tess Ally 2006 � Collective Admin 
------------------------------------------------------------- */ 

# -- Date Array ---------------------------------------------
$get_date_array = array(
 '1' => 'January',
 '2' => 'February',
 '3' => 'March',
 '4' => 'April',
 '5' => 'May',
 '6' => 'June',
 '7' => 'July',
 '8' => 'August',
 '9' => 'September',
 '10' => 'October',
 '11' => 'November',
 '12' => 'December'
);

# -- Get Status Array ---------------------------------------
$get_status_array = array(
 '0' => 'Current',
 '1' => 'Upcoming',
 '2' => 'Pending',
 '3' => 'Closed'
);

# -- Paths --------------------------------------------------
$adminH = $optionsfunc->getOption('admHttp');
$adminP = $optionsfunc->getOption('admPath');
$imageH = $optionsfunc->getOption('imgHttp');
$imageP = $optionsfunc->getOption('imgPath');

# -- Mark-Up ------------------------------------------------
$mup = $optionsfunc->getOption('markup');
if(empty($mup)) {
 $markup = 'xhtml';
} else {
 $markup = $optionsfunc->getOption('markup');
}

# -- Lists --------------------------------------------------
$showDefault = $optionsfunc->getOption('showDefault');
$sort_by = $optionsfunc->getOption('sortBy');

# -- Pagination ---------------------------------------------
$per_list = $optionsfunc->getOption('perList');
$per_page = $optionsfunc->getOption('perPage');
?>
