<?php
# 'FUNCTIONS.INC' FILE 
/* ----------------------------------------------------------
Tess Ally 2006 � Pumpin'! Admin 
------------------------------------------------------------- */

if(!class_exists('installfunc')) {
 class installfunc {
  # -- Show Welcome Function ----------------------------------
  # -----------------------------------------------------------
	function showWelcome() {
	 global $_CA;
?>
<h2 class="tr">Install <?php echo $_CA['version']; ?></h2>
<p>Welcome to the installation of <strong><?php echo $_CA['version']; ?></strong>!
There is four steps in total to installing the script, and the script will guide 
you through each step. <strong>Each step is required</strong>, so be sure to read 
through each page!</p>
<p class="nextStep"><a href="?step=1">Start Installation &raquo;</a></p>
<?php
	}
	
	function installCategories() {
?>
<h2 class="tr">Step 1: Categories</h2>
<p>Once you hit "Install Categories" the script will install your categories. Below
is the default category that will be installed with the category table. If left
blank, <samp>General</samp> will be inserted.</p>
<form action="<?php echo 'http://' . $_SERVER['SERVER_NAME'] . str_replace('index.php', '', $_SERVER['PHP_SELF']); ?>" method="post">
<fieldset>
<legend>Install Categories</legend>
<p><label><strong>Default Category:</strong></label> 
<input name="default_category" class="input1" type="text" value="General" /></p>
<p class="tc"><input name="action" class="nextStep" type="submit" value="Install Categories" /></p>
</fieldset>
</form>
<?php
	}
	
	function installOptions() {
?>
<h2 class="tr">Step 2: Options</h2>
<p>The only thing that's required to fill out is your username and password, and 
paths. The rest of your options will be created, and can be edited after the complete 
installation.</p>
<form action="<?php echo 'http://' . $_SERVER['SERVER_NAME'] . str_replace('index.php', '', $_SERVER['PHP_SELF']); ?>" method="post">
<fieldset>
<legend>Install Options</legend>
<p><label><strong>Username:</strong></label> <input name="username" class="input1" type="text" /></p>
<p><label><strong>Password:</strong><br />
Your password should not contain any dictionary (of any language) words,
should have a mixture of numbers and symbols and be no shorter than
ten characters in length.</label> <input name="password" class="input1" type="password" /></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<?php 
$adminPath = $_SERVER['SCRIPT_FILENAME'];
$adminPath = str_replace('install/index.php', '', $adminPath);
$adminURI = 'http://' . $_SERVER['SERVER_NAME'] . str_replace('install/index.php', '', $_SERVER['PHP_SELF']);
?>
<p><label><strong>Admin Paths:</strong><br>
Admin paths are the path and <abbr title="Uniform Resource Identifier">URI</abbr> to your admin
panel. All paths and URLs are already set for you, although they can be changed to the desired path.
</label> <input name="adm_path" class="input1" type="text" value="<?php echo $adminPath; ?>"><br>
         <input name="adm_http" class="input1" type="text" value="<?php echo $adminURI; ?>"></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p><label><strong>Image Paths:</strong><br />
Image paths are for your owned images. Paths are set for you, although they can changed
to the desired path(s).</label>
<input name="img_path" class="input1" type="text" value="<?php echo $adminPath . 'images/'; ?>"><br>
<input name="img_http" class="input1" type="text" value="<?php echo $adminURI . 'images/'; ?>"></p>
<p style="clear: both; margin: 0 0 2% 0;"></p>
<p class="tc"><input name="action" class="nextStep" type="submit" value="Install Options" /></p>
</fieldset>
</form>
<?php
	}
	
	function installTemplates() {
?>
<h2 class="tr">Step 3: Options</h2>
<p>Two other templates will be created with this one; this one has a default template,
so it can be left as is.</p>
<form action="<?php echo 'http://' . $_SERVER['SERVER_NAME'] . str_replace('index.php', '', $_SERVER['PHP_SELF']); ?>" method="post">
<fieldset>
<legend>Install Options</legend>
<?php
$adminPath = $_SERVER['SCRIPT_FILENAME'];
$adminPath = str_replace('install/index.php', '', $adminPath);
$adminURI = 'http://' . $_SERVER['SERVER_NAME'] . str_replace('install/index.php', '', $_SERVER['PHP_SELF']);
?>
<p><label><strong>Template:</strong><br />
<textarea name="template" cols="50" rows="7" style="height: 150px; margin: 0 1% 0 0; width: 99%;">
&lt;p class=&quot;image&quot;&gt;&lt;img src=&quot;{image}&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;{subject}&lt;/strong&gt;&lt;br /&gt;
{details}&lt;/p&gt;
</textarea></p>
<p class="tc"><input name="action" class="nextStep" type="submit" value="Install Templates" /></p>
</fieldset>
</form>
<?php
	}
	
	function showFinished() {
?>
<h2 class="tr">Step 4: Finish Install</h2>
<p>Click "submit" to create your listing table and finish the installation! :D</p>
<form action="<?php echo 'http://' . $_SERVER['SERVER_NAME'] . str_replace('index.php', '', $_SERVER['PHP_SELF']); ?>" method="post">
<fieldset>
<legend>Finish Installation</legend>
<p class="tc"><input name="action" class="nextStep" type="submit" value="Finish Installation" /></p>
</fieldset>
</form>
<?php
	}
	
	function showExit() {
?>
<h2 class="tr">Step 5: Installation Complete!</h2>
<p class="successButton"><span class="success">Huzzah!</span> You have finished 
the installation. You can now login to your 
<a href="<?php echo 'http://' . $_SERVER['SERVER_NAME'] . str_replace('install/index.php', '', $_SERVER['PHP_SELF']); ?>">&laquo; admin panel</a>!</p>
<?php
	}
 }
}

$installfunc = new installfunc();
?>
