<?php 
# 'INSTALL' FILE 
/* ----------------------------------------------------------
Tess Ally 2006 � Collective Admin 
------------------------------------------------------------- */
require("../rats.inc.php");
require_once("../fun.inc.php");
require_once("functions.inc.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> <?php echo $_CA['version']; ?> &#8212; Install </title>
<link href="../style.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div id="install">
<?php 
$steps = $eastroad->cleanMys($_GET['step']);
switch($steps) {
 case 1:
  echo $installfunc->installCategories();
 break;
 case 2: 
  echo $installfunc->installOptions();
 break;
 case 3:
  echo $installfunc->installTemplates();
 break;
 case 4:
  echo $installfunc->showFinished();
 break;
 case 5:
  echo $installfunc->showExit();
 break;
 default: 
  if(isset($_POST['action'])) {
   if(isset($_POST['action']) && $_POST['action'] == 'Install Categories') {
    $defaultCat = $eastroad->cleanMys($_POST['default_category']);
    # Create Categories Table: 
    $create = "CREATE TABLE `$_CA[categories]` (
     `catID` smallint(4) NOT NULL AUTO_INCREMENT,
     `catName` varchar(255) NOT NULL,
     `catParent` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
     `catDesc` text NOT NULL,
     PRIMARY KEY (`catID`),
     UNIQUE KEY `catName` (`catName`, `catParent`)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
    $true = mysql_query($create);
    if($true == false) {
     exit('<p><span class="mysql">Error:</span> ' . mysql_error() . "<br />\n<em>" . $create . '</em></p>');
    } else {
	   $insert = "INSERT INTO `$_CA[categories]` (`catName`, `catParent`, `catDesc`) VALUES ('$defaultCat', '0', '');";
		 mysql_query("SET NAMES 'utf8';");
	   $true = mysql_query($insert);
	   echo "<p class=\"successButton\"><span class=\"success\">SUCCESS!</span> Your default category was created.</p>\n";
	   echo "<p class=\"nextStep\"><a href=\"?step=2\">Next Step</a></p>\n";
	  }
	 } elseif (isset($_POST['action']) && $_POST['action'] == 'Install Options') {
	  $username = $eastroad->cleanMys($_POST['username']);
		$password = $eastroad->cleanMys($_POST['password']);
		$passwordmd5 = md5(trim($password));
		$hashpassword = md5(date("YmdHis"));
		$adm_path = $eastroad->cleanMys($_POST['adm_path']);
    $adm_http = $eastroad->cleanMys($_POST['adm_http']);
    $img_path = $eastroad->cleanMys($_POST['img_path']);
    $img_http = $eastroad->cleanMys($_POST['img_http']);
    if(!strrchr($adm_path, '/') || !strrchr($img_path, '/')) {
     exit('<p class="error">One or more of your paths need trailing slashes. Add them.</p>');
    } elseif (empty($adm_path) || empty($adm_http) || empty($img_path) || empty($img_http)) {
     exit('<p class="error">Your admin and image paths are empty. Enter the proper path.</p>');
    } elseif ((empty($username) || empty($password)) || (strlen($password) < 12)) {
		 exit('<p class="error">Make sure your username and password are not empty, and your' . 
		 ' password is not shorter than 12 characters.</p>');
		}
    # Create Categories Table: 
    $create = "CREATE TABLE `$_CA[options]` (
     `optName` varchar(255) NOT NULL,
     `optText` text NOT NULL,
     UNIQUE KEY `optName` (`optName`)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
    $true = mysql_query($create);
    if($true == false) {
     exit('<p><span class="mysql">Error:</span> ' . mysql_error() . "<br />\n<em>" . $create . '</em></p>');
    } else {
	   $insert = "INSERT INTO `$_CA[options]` (`optName`, `optText`) VALUES
		 ('hashUsername', '$username'),
		 ('hashPassword', '$passwordmd5'),
		 ('hashSecreths', '$hashpassword'),
     ('admHttp', '$adm_http'), 
     ('admPath', '$adm_path'), 
     ('imgHttp', '$img_http'), 
     ('imgPath', '$img_path'),
		 ('perPage', '12'),
		 ('perList', '1'),
		 ('sortBy', 'since'),
		 ('showDef', 'cat'),
		 ('showBoth', 'n'),
		 ('markUp', 'xhtml'),
		 ('tempBoth', 'n')";
		 mysql_query("SET NAMES 'utf8';");
	   $true = mysql_query($insert);
	   echo "<p class=\"successButton\"><span class=\"success\">SUCCESS!</span> Your paths were" . 
		 " inserted, as well as your options for future editing.</p>\n";
	   echo "<p class=\"nextStep\"><a href=\"?step=3\">Next Step</a></p>\n";
	  }
	 } elseif (isset($_POST['action']) && $_POST['action'] == 'Install Templates') {
		$template = $eastroad->cleanMys($_POST['template']);
    if(empty($template)) {
		 $template = trim("
		  &lt;p class=&quot;image&quot;&gt;&lt;img src=&quot;{image}&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;
			&lt;p&gt;&lt;strong&gt;{subject}&lt;/strong&gt;&lt;br /&gt;
			{details}&lt;/p&gt;
		 ");
		}
    # Create Templates Table: 
    $create = "CREATE TABLE `$_CA[templates]` (
     `tempName` varchar(255) NOT NULL,
     `tempTitle` varchar(255) NOT NULL,
     `tempBody` text NOT NULL,
     UNIQUE KEY (`tempName`)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
    $true = mysql_query($create);
    if($true == false) {
     exit('<p><span class="mysql">Error:</span> ' . mysql_error() . "<br />\n<em>" . $create . '</em></p>');
    } else {
	   $insert = "INSERT INTO `$_CA[templates]` (`tempName`, `tempTitle`, `tempBody`) VALUES
     ('dateTemplate', 'Date', 'F jS, Y'), 
     ('sitesTemplate', 'Category', '$template'), 
     ('statusTemplate', 'Status', '')";
		 mysql_query("SET NAMES 'utf8';");
	   $true = mysql_query($insert);
	   echo "<p class=\"successButton\"><span class=\"success\">SUCCESS!</span> Your templates were created!</p>\n";
	   echo "<p class=\"nextStep\"><a href=\"?step=4\">Next Step</a></p>\n";
	  }
	 } elseif (isset($_POST['action']) && $_POST['action'] == 'Finish Installation') {
    # Create Templates Table: 
    $create = "CREATE TABLE `$_CA[main]` (
     `listID` mediumint(6) NOT NULL auto_increment,
     `listTitle` varchar(255) NOT NULL,
     `listSubject` varchar(255) NOT NULL,
     `listURL` varchar(255) NOT NULL,
     `listImage` varchar(200) NOT NULL,
     `listDesc` longtext NOT NULL,
     `listStatus` tinyint(1) NOT NULL DEFAULT '0',
     `listCategory` varchar(50) NOT NULL,
     `listSince` date NOT NULL,
     PRIMARY KEY (`listID`),
     UNIQUE KEY `listSubject` (`listSubject`)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
    $true = mysql_query($create);
    if($true == false) {
     exit('<p><span class="mysql">Error:</span> ' . mysql_error() . "<br />\n<em>" . $create . '</em></p>');
    } else {
	   echo "<p class=\"successButton\"><span class=\"success\">SUCCESS!</span> Your installation has finished!</p>\n";
	   echo "<p class=\"nextStep\"><a href=\"?step=5\">Next Step</a></p>\n";
	  }
	 }
  } else { 
   echo $installfunc->showWelcome();
  }
 break;
}
?>
</div>

</body>
</html>
