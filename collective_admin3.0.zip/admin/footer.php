</div>

<div id="footer">
 <p><strong><?php echo $_CA['version']; ?></strong> &copy; <?php echo $adminfunc->isYear('2006'); ?> (<em>Tess Ally</em>)</p>
</div>

</div>

</body>
</html>
