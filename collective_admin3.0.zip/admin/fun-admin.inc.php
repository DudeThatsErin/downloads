<?php
# 'FUN-ADMIN.INC' FILE 
/* ---------------------------------------------------------- 
Tess Ally 2006 � Collective Admin 
------------------------------------------------------------- */ 

if(!class_exists('adminfunc')) {
 class adminfunc {
  # -- isTitle() Function -------------------------------------
  # -----------------------------------------------------------
  function isTitle($getTitle) {
   if(!empty($getTitle)) {
    return $getTitle;
   } else {
    return 'A Listing Management Script';
   }
  }

  # -- isPage() Function --------------------------------------
  # -----------------------------------------------------------
  function isPage() {
   return basename($_SERVER['PHP_SELF']);
  } 

  # -- isYear() Function --------------------------------------
  # -----------------------------------------------------------
  function isYear($o) {
   $y = date("Y");
   if($o == $y) {
    return $o;
   } else {
    return $o . "-" . $y;
   }
  }

  # -- Get Navigation Function --------------------------------
  # -----------------------------------------------------------
  function currently($n) {
   if(basename($_SERVER['PHP_SELF']) == $n . '.php') {
    return ' class="c"';
   } else {
    return "";
   }
  }
	
	# -- Get User -----------------------------------------------
  # -----------------------------------------------------------
	function checkUser($u, $p) {
	 global $optionsfunc;
	 
	 if($optionsfunc->getOption('hashUsername') == $u && $optionsfunc->getOption('hashPassword') == $p) {
	  return 0;
	 } else {
	  return 1;
	 }
	}
 }
}

$adminfunc = new adminfunc(); 
?>
