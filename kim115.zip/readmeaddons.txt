#
# phpFan - Add-Ons (for phpFan v3.3.0)
# Copyright 2004-2008 Gabrielle - All Rights Reserved.
#
# phpFan may be used and modified free of charge by anyone so long as this copyright notice and 
# the comments above remain intact. There also must be a link back to http://scripts.ishallnotcare.org, the 
# script is linkware. By using this code you agree to indemnify Gabrielle from any liability that might arise 
# from its use.
#
# Selling the code for this program without prior written consent is expressly forbidden. In other words, 
# please ask first before you try and make money off of my program.
#
# Obtain permission before redistributing this software over the Internet or in any other medium. In all cases 
# copyright and header must remain intact.
#

OVERVIEW:
	AFFILIATES:
		An add-on script that allows you to add affiliates, e-mail that affiliate individually, or mass e-mail
		affiliats for your site/collective. *Must* be used in conjunction with the LISTING add-on.
	KEEP-IN-MIND:
		An add-on script that allows individuals to add themselves to a keep-in-mind list for your listings,
		*must* be used in conjunction with the LISTING add-on. Updates are done through an automatic updates
		form (which allows keep-in-minders to 'retrieve' a password) or a form that allows the keep-in-minder
		to send an update e-mail.
	LISTING:
		An add-on script that allows you to add all your listings with a description, image (optional), categories
		and lists them by category.
	WISHLIST:
		An add-on script that allows you to add wishlisters and lists them by image (with the why, rejection number, category),
		by category, and allows for gained wishlisters (with URL) to be listed on the bottom

REQUIREMENTS:

PHP4 (version 4.3.11 or higher) 
MySQL (version 4.1 or higher) 

FEATURES:
- passworded (through salting) admin panel
- 'remember me' option for admin panel
- templates (updated through the admin control panel)
- optional caching of templates
- settings set in the admin control panel
- stylesheets
- can use php and includes in templates
- language stored in file for easy editing
- pagination for easy navigation
- use of EZ SQL for database abstraction
- friendly image names (not numbers)
- ability to add/edit multiple keep-in-minders, listing, affiliates, and wishlisters at the same time
- ability to mass-email keep-in-minders (by list) and affiliates
- keep track of updates through 'addons' section in phpFan
- integration with Wordpress

INSTALLATION:

1. Unzip the package (whether it's wishlist10.zip, kim10.zip, listing10.zip, affiliates10.zip) into an empty directory.
2. Upload all the files to your server.
3. Login to your phpFan control panel and check 'addons'. Links to the addons you've added should be there, click on
   the link(s) and the addon(s) should be installed once you click the link, 'Install?'.

UPGRADE WISHLIST/KEEP-IN-MIND/JOINED/LISTING/AFFILIATES:

1. Unzip the package.
2. Upload the /admin and /includes folders.
3. In the admin control panel go to each separate Addon page and run 'Upgrade?'
   
USE/INCLUDES:

Using includes is not necessary if using the included phpFan Addons in conjunction with permalinks and the .htaccess file.
In that case phpFan Addons would go roughly like this: phpFan Addons - Keep-In-Mind 
(http://yoursite.com/yourphpfanfolder/keep-in-mind/), phpFan Addons - Listing (http://yoursite.com/yourphpfanfolder/lists/),
phpFan Addons - Wishlist (http://yoursite.com/yourphpfanfolder/wishlist/), phpFan Addons - Affiliates
(http://yoursite.com/yourphpfanfolder/affiliates/).

If you want to include an Addon into a file and don't use permalinks use the following examples. You can replace ./includes/ with your full path if you are calling it outside of the main phpFan folder.

	AFFILIATES:
	
		<?php

			include_once './includes/conf.inc.php';
			$type = 'affiliates';
			include_once INCLUDEPATH .'/init.php';

		?>
	KEEP-IN-MIND:
	
		<?php

			include_once './includes/conf.inc.php';
			$type = 'keepinmind';
			include_once INCLUDEPATH .'/init.php';

		?>
	LISTING:
	
		<?php

			include_once './includes/conf.inc.php';
			$type = 'list';
			include_once INCLUDEPATH .'/init.php';

		?>
	WISHLIST:
	
		<?php

			include_once './includes/conf.inc.php';
			$type = 'wishlist';
			include_once INCLUDEPATH .'/init.php';

		?>
		
WORDPRESS 2.1 INTEGRATION:

1. Uncomment the following in your conf.inc.php file and remember to change the path to *your* site:

//	require_once('/path/to/your/wp-config.php');

2. In the templates section in your admin control panel add this in the header (remember to change the path
   to *your* site):

<?php

define('WP_USE_THEMES', false);
require('/path/to/your/wp-blog-header.php'); 
get_header();

?>

3. In the templates section in your admin control panel add this in the footer:

<?php

get_footer();

?>

4. That's basically it.

SUPER-DUPER WORDPRESS INTEGRATION:

The following lets you add phpFan add-ons directly into Wordpress instead of the other way around. Say, you want to add a phpFan add-on
into a Wordpress page (if you've allowed php includes in your pages). The following can be included into Wordpress.
	AFFILIATES:
	
		<?php

			include_once '/path/to/your/phpfan/includes/conf.inc.php';
			$type = 'affiliates';
			include_once INCLUDEPATH .'/init.php';

		?>
	KEEP-IN-MIND:
	
		<?php

			include_once '/path/to/your/phpfan/includes/conf.inc.php';
			$type = 'keepinmind';
			include_once INCLUDEPATH .'/init.php';

		?>
	LISTING:
	
		<?php

			include_once '/path/to/your/phpfan/includes/conf.inc.php';
			$type = 'list';
			include_once INCLUDEPATH .'/init.php';

		?>
	WISHLIST:
	
		<?php

			include_once '/path/to/your/phpfan/includes/conf.inc.php';
			$type = 'wishlist';
			include_once INCLUDEPATH .'/init.php';

		?>

SEPARATE FILE-BASED HEADERS/FOOTERS

You can use separate file-based headers/footers for each Addon. 

1. Upgrade to the latest version.
2. Use the exampleheader.php/examplefooter.php (rename!) in includes/cache as a template for your header. You may even opt to put
   the coding for your skinning in there (as phpFan Addon - Keep-In-Mind will *not* work if you put any code before the
   Keep-In-Mind include.
3. Upload the custom header/footer files to /includes/cache.
4. Go to 'Settings' and then 'Addon Settings'. Change the name the header/footer to the name of your own header/footer.

Credits:

Gabrielle from ishallnotcare.org created phpFan.