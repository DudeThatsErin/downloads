<?php

	if(strcmp(basename(urldecode($_SERVER['PHP_SELF'])),basename(__FILE__)) === 0)
	{
		exit('Forbidden!');
	}

	include_once INCLUDEPATH .'/init.php';

if (!class_exists('keepinmindphp')) 
{
	class keepinmindphp extends mainfunctions
	{
		var $emailnotify;
		var $action;
		var $header;
		var $footer;
		var $body;

		function keepinmindphp($everything)
		{
			parent::mainfunctions($everything);

			$this->action		= parent::allinput('action');
			$this->emailnotify  = parent::settings('emailnotify');

			$this->body		= parent::fetchtemplate(27);

			$this->body	= str_replace('%%kimupdateurl%%', parent::phpfanlink('keepinmind', '', '', 'choose'), $this->body);
			$this->body = str_replace('%%kimjoinurl%%', parent::phpfanlink('keepinmind', '', '', 'join'), $this->body);		

			$this->enthfileexists = 0;
			
			if (file_exists(ENTHUSIASTTI))
			{
				$this->enthfileexists = 1;
			}
			
			$x				= 0;
			$this->wherenum	= 0;
			$this->totalnum	= count($this->ruri);

			foreach ($this->ruri AS $string)
			{
				if (($string == 'choose') || ($string == 'retrievepw') || ($string == 'retrievepwnow') || ($string == 'updatenow') || ($string == 'updateinfonow') || ($string == 'update') || ($string == 'all') || ($string == 'join') || ($string== 'updateinfo') || ($string == 'sent')  || ($string == 'listshow'))
				{
					$this->action	= $string;
				} elseif ($string == 'number') {
					$this->wherenum	= $x;
				}

				$x++;
			}
			
			$allowedActions = array('choose', 'retrievepwnow', 'updateinfonow', 'updateinfo', 'listshow', 'all', 'sent', 'retrievepw', 'updatenow', 'update', 'join');
			
			$allowedForms 	= array();

			if (in_array($this->action, $allowedActions))
			{
				$temp	= call_user_func(array($this, $this->action));
			} else {
				$temp	= call_user_func(array($this, 'def'));
			}

			$temp	= str_replace('%%lang_menu_main_show_listings_with_no_kimers%%', '', $temp);
			
			$temp	= preg_replace_callback('/(<\?php?)(.*)(\?>)/is', array( &$this, 'phpintemplate'), $temp);

			parent::dositecache($this->cachename, $temp, $this->group, $this->lang['lang_titlekim']);
		}

		function choose()
		{
			$template	= parent::fetchtemplate(49);

			$body	= str_replace('%%kimbody%%', $template, $this->body);
			$body	= str_replace('%%lang_kimheader%%', $this->lang['lang_kimheaderchoose'], $body);
			$body 	= str_replace('%%lang_navigation%%', '', $body);
			$body	= str_replace('%%keepinmindautoupdateurl%%', $this->phpfanlink('keepinmind', '', '', 'updatenow'), $body);
			$body	= str_replace('%%keepinmindupdateurl%%', $this->phpfanlink('keepinmind', '', '', 'update'), $body);

			return $body;
		}

		function updateinfonow()
		{
			$this->body	= str_replace('%%lang_navigation%%', '', $this->body);
			$this->body	= str_replace('%%lang_kimheader%%', $this->lang['lang_kimheaderupdateinfonow'], $this->body);

			$spambody	= str_replace('%%menu_main_show_listings_with_no_kimers%%', '', $this->body);
			$template	= parent::antispamprocedures($spambody, 0);

			$klid	  	= parent::getemailpost('checkbox');
			$kshowemail	= parent::getemailpost('kimshowemail');

			$kurl		= parent::getdirtypost('kimurl');
			$kurl		= parent::cleanurl($kurl);

			$kname    	= parent::getemailpost('kimname');
			$kemail   	= parent::getemailpost('kimemail');
			$sendinfo	= parent::getemailpost('sendinfo');
			$oldemail	= parent::getemailpost('oldkimemail');
			$pw			= parent::getemailpost('pw');

			$errors		= 0;
			$error		= '';

			if (empty($kname)) 
			{
				$errors = 1;
				$error .= $this->lang['lang_errorname'];
			}

			if (empty($kemail))
			{
				$errors = 1;
				$error .= $this->lang['lang_erroremail'];
			} elseif (!parent::is_valid_email_address($kemail)) {
				$errors = 1;
				$error .= $this->lang['lang_errorinvalidemail'];
			} else {
				list($userName, $mailDomain) = split("@", $kemail);

				if (checkdnsrr($mailDomain, "MX"))
				{
				} else {
					$errors = 1;
					$error .= $this->lang['lang_errorinvalidemail'];
				}
			}

			if (!is_array($klid)) 
			{
				$error .= $this->lang['lang_errorlid'];
				$errors = 1;
			}

			$bodyjoin 		= '';

			if ($errors == 1)
			{
				$bodyjoin	.= $error;
				$template	= str_replace('%%lang_headergeneric%%', $this->lang['lang_kimheaderupdateinfonowerror'], $template);
			} else {
				$isinkim      	= $this->db->get_row('SELECT `kimid`, `kimpw`, `kimvalidated`, `salt` FROM `'. PREFIX .'_kim` WHERE `kimemail`='. parent::addthoseslashes($oldemail));

				$emailinkim	= $this->db->num_rows;

				if ($oldemail != $kemail)
				{
					$emailresults	= $this->db->get_var('SELECT COUNT(DISTINCT `kimid`) FROM `'. PREFIX .'_kim` WHERE `kimemail`='. parent::addthoseslashes($kemail));
				} else {
					$emailresults	= 0;
				}

				if ($emailinkim > 0)
				{
					if ($emailresults == 0)
					{
						$id		= $isinkim->kimid;
						$db_pw	= $isinkim->kimpw;
						$salt	= $isinkim->salt;
						$val	= $isinkim->kimvalidated;
						
						$passwordsalt		= parent::passwordhash($pw, $oldemail, $salt);
						$password_e			= $passwordsalt['password'];

						if ($db_pw == $password_e)
						{
							$autocapitalizenames = parent::settings('autocapitalizenames');

							if ($autocapitalizenames == 'Y')
							{
								$kname = strtolower($kname);
								$kname = ucwords($kname);
							}

							if (empty($kurl))
							{
								$kurl = '';
							} else {
								$web = substr($kurl,0,7);

								if ($web == 'http://')
								{
									if ($kurl != 'http://')
									{
										$kurl = $kurl;
									}
								} elseif ($web != 'http://') {
									if($kurl != 'http://')
									{
										$kurl = 'http://'. $kurl;
									}
								}
							}

							$sql = "UPDATE `". PREFIX ."_kim` SET ".
								"`kimname`=". parent::addthoseslashes($kname) .", ".
								"`kimemail`=". parent::addthoseslashes($kemail) .", ".
								"`kimshowemail`=". parent::addthoseslashes($kshowemail) .", ".
								"`kimurl`=". parent::addthoseslashes($kurl) .", ".
								"`kimvalidated`=0". 
								" WHERE `kimid`=". $id;

							$dokim			= $this->db->query($sql);

							$checkbox		= parent::getemailpost('checkbox');

							$lookupkim 		= $this->db->get_results('SELECT `lid` FROM `'. PREFIX .'_lookupkim` WHERE `kim`='. $id .' AND `lid` != 0 GROUP BY `lid`');
							$numlkim		= $this->db->num_rows;

							if ($numlkim > 0)
							{
								foreach ($lookupkim AS $lkim) 
								{
									$lid          = $lkim->lid;

									if ($val == 1)
									{
										parent::updatelinknumbers($lid, 'minus', 1, 'kim');
									}
								}
							}

							$delete = $this->db->query('DELETE FROM `'. PREFIX .'_lookupkim` WHERE `kim`='. $id);

							for ($i=0; $i<count($checkbox); $i++)
							{
								$squery   = $this->db->query('INSERT IGNORE INTO `'. PREFIX .'_lookupkim` SET `kim`='. $id .', `lid`='. $checkbox[$i]);
							}

							if ((TIEINON == 'enth') && ($this->enthfileexists == 1))
							{
								include ENTHUSIASTTI;

								$catlist 		= $this->db->get_results('SELECT `subject` FROM `'. PREFIX .'_lookupkim` y LEFT JOIN `'. $db_owned .'` z ON (z.listingid = y.lid) WHERE `listingid` != 0 AND `kim`='. $id .' GROUP BY `lid`');
							} else {
								$catlist 		= $this->db->get_results('SELECT `listname` FROM `'. PREFIX .'_lookupkim` y LEFT JOIN `'. PREFIX .'_list` z ON (z.listid = y.lid) WHERE `listid` != 0 AND `kim`='. $id .' GROUP BY `lid`');
							}

							$catlistsubtotal	= $this->db->num_rows;

							$p				= 1;
							$quickcats			= '';

							if ($catlistsubtotal > 0)
							{
								foreach ($catlist AS $list) 
								{
									if ((TIEINON == 'enth') && ($this->enthfileexists == 1))
									{
										$quickcats	.= $list->subject;
									} else {
										$quickcats	.= $list->listname;
									}

									if ($p < $catlistsubtotal)
									{
										$quickcats	.= ', ';
									}

									$p++;
								}
							}

							$catlist = $this->db->query("UPDATE `". PREFIX ."_kim` SET `quicklists`=". parent::addthoseslashes($quickcats) ." WHERE `kimid`=". $id);							

							if ($dokim || $catlist || $squery) 
							{
								$kname			= parent::stripthoseslashes($kname);
								$this->lang['lang_kimupdatenow'] 	= str_replace('%%kimname%%', $kname, $this->lang['lang_kimupdatenow']);

								$bodyjoin 		.= $this->lang['lang_kimupdatenow'];

					  			if ($this->emailnotify == 'Y')
								{
									$emailsubject	= 'Update Keep-in-Minder:'. SITENAME;

									$etemplate 	= parent::emailtemplatekim($id, 38, '', '', '');
									$etemplate	= str_replace('%%oldemail%%', $oldemail, $etemplate);

									$to['email']	= ADMINEMAIL;
									$to['name']		= ADMINNAME;

									$froma['email']	= $kemail;
									$froma['name']	= $kname;

									parent::dosendmail($to, $froma, $emailsubject, $etemplate);
								}

								if ($sendinfo == 1)
								{

									$emailsubject 	= 'Update Keep-In-Minder: '. SITENAME;

									$etempnotify  	= parent::emailtemplatekim($id, 43, '', '', '');
									$etempnotify	= str_replace('%%oldemail%%', $oldemail, $etempnotify);

									$to['email']	= $kemail;
									$to['name']		= $kname;

									$froma['email']	= ADMINEMAIL;
									$froma['name']	= ADMINNAME;

									parent::dosendmail($to, $froma, $emailsubject, $etempnotify);
								}
							}
						} else {
							$bodyjoin	.= $this->lang['lang_kimnotpw'];
							$template	= str_replace('%%lang_headergeneric%%', $this->lang['lang_kimheaderupdateinfonowerror'], $template);
						}
					} else {
						list($userName, $mailDomain) = split("@", ADMINEMAIL);

						$finalemail				= '<script type="text/javascript">mail2("'. $mailDomain .'", "", "'. $this->lang['lang_showemail'] .'", "'. $userName .'")</script>';
						$this->lang['lang_kimemailexists']	= str_replace('%%email%%', $finalemail, $this->lang['lang_kimemailexists']);
						$bodyjoin				.= $this->lang['lang_kimemailexists'];
						$template				= str_replace('%%lang_headergeneric%%', $this->lang['lang_kimheaderupdateinfonowerror'], $template);
					}
				} else { 
					list($userName, $mailDomain) = split("@", ADMINEMAIL);

					$finalemail				= '<script type="text/javascript">mail2("'. $mailDomain .'", "", "'. $this->lang['lang_showemail'] .'", "'. $userName .'")</script>';
					$this->lang['lang_emailoldnotinkim']	= str_replace('%%email%%', $finalemail, $this->lang['lang_emailoldnotinkim']);
					$bodyjoin				.= $this->lang['lang_emailoldnotinkim'];
					$template				= str_replace('%%lang_headergeneric%%', $this->lang['lang_kimheaderupdateinfonowerror'], $template);
				}
			}
			
			$bodyjoin	= str_replace('%%kimupdateurl%%', parent::phpfanlink('keepinmind', '', '', 'choose'), $bodyjoin);

			$template	= str_replace('%%body%%', $this->lang['lang_genericbegin'] . $bodyjoin . $this->lang['lang_genericend'], $template);
			$template	= str_replace('%%lang_headergeneric%%', $this->lang['lang_kimheaderupdateinfonowsent'], $template);
			$body		= str_replace('%%kimbody%%', $template, $this->body);
			$body		= str_replace('%%lang_kimheader%%', $this->lang['lang_kimheadermain'], $body);

			return $body;
		}

		function sent()
		{
			$this->body	= str_replace('%%lang_navigation%%', '', $this->body);
			$this->body	= str_replace('%%lang_kimheader%%', $this->lang['lang_kimheaderjoin'], $this->body);

			$spambody	= str_replace('%%menu_main_show_listings_with_no_kimers%%', '', $this->body);
			$template	= parent::antispamprocedures($spambody, 1);

			$klid	  	= parent::getemailpost('checkbox');
			$kshowemail	= parent::getemailpost('kimshowemail');

			$kurl		= parent::getdirtypost('kimurl');
			$kurl		= parent::cleanurl($kurl);

			$kname    	= parent::getemailpost('kimname');
			$kemail   	= parent::getemailpost('kimemail');
			$sendinfo	= parent::getemailpost('sendinfo');

			$errors		= 0;
			$error		= '';

			if (empty($kname)) 
			{
				$errors = 1;
				$error .= $this->lang['lang_errorname'];
			}

			if (empty($kemail))
			{
				$errors = 1;
				$error .= $this->lang['lang_erroremail'];
			} elseif (!parent::is_valid_email_address($kemail)) {
				$errors = 1;
				$error .= $this->lang['lang_errorinvalidemail'];
			} else {
				list($userName, $mailDomain) = split("@", $kemail);

				if (checkdnsrr($mailDomain, "MX"))
				{
				} else {
					$errors = 1;
					$error .= $this->lang['lang_errorinvalidemail'];
				}
			}

			if (!is_array($klid)) 
			{
				$error .= $this->lang['lang_errorlid'];
				$errors = 1;
			}

			$bodyjoin = '';

			if ($errors == 1)
			{
				$bodyjoin 	.= $error;
				$template	= str_replace('%%lang_headergeneric%%', $this->lang['lang_kimheaderjoinerror'], $template);
			} else {
				$result       = $this->db->get_results('SELECT `kimid` FROM `'. PREFIX .'_kim` WHERE `kimemail`='. parent::addthoseslashes($kemail));

				$emailresults = $this->db->num_rows;

				if ($emailresults == 0)
				{
					$autocapitalizenames = parent::settings('autocapitalizenames');

					if ($autocapitalizenames == 'Y')
					{
						$kname = strtolower($kname);
						$kname = ucwords($kname);
					}

					if (empty($kurl))
					{
						$kurl = '';
					} else {
						$web = substr($kurl,0,7);

						if ($web == 'http://')
						{
							if ($kurl != 'http://')
							{
								$kurl = $kurl;
							}
						} elseif ($web != 'http://') {
							if($kurl != 'http://')
							{
								$kurl = 'http://'. $kurl;
							}
						}
					}

					$sql = "INSERT INTO `". PREFIX ."_kim` SET ".
						"`kimname`=". parent::addthoseslashes($kname) .", ".
						"`kimvalidated`=0, ".
						"`kimemail`=". parent::addthoseslashes($kemail) .", ".
						"`kimshowemail`=". parent::addthoseslashes($kshowemail) .", ".
						"`kimurl`=". parent::addthoseslashes($kurl);

					if ($this->db->query($sql)) 
					{
						$kname			= parent::stripthoseslashes($kname);
						$this->lang['lang_kimthanks'] = str_replace('%%kimname%%', $kname, $this->lang['lang_kimthanks']);

						$bodyjoin 		.= $this->lang['lang_kimthanks'];
						$new_id 		= $this->db->insert_id;
						$checkbox		= parent::getemailpost('checkbox');

						for ($i=0; $i<count($checkbox); $i++)
						{
							$squery   = $this->db->query('INSERT IGNORE INTO `'. PREFIX .'_lookupkim` SET `kim`='. $new_id .', `lid`='. $checkbox[$i]);
						}

						if ((TIEINON == 'enth') && ($this->enthfileexists == 1))
						{
							include ENTHUSIASTTI;

							$catlist 		= $this->db->get_results('SELECT `subject` FROM `'. PREFIX .'_lookupkim` y LEFT JOIN `'. $db_owned .'` z ON (z.listingid = y.lid) WHERE `listingid` != 0 AND `kim`='. $new_id .' GROUP BY `lid`');
						} else {
							$catlist 		= $this->db->get_results('SELECT `listname` FROM `'. PREFIX .'_lookupkim` y LEFT JOIN `'. PREFIX .'_list` z ON (z.listid = y.lid) WHERE `listid` != 0 AND `kim`='. $new_id .' GROUP BY `lid`');
						}

						$catlistsubtotal	= $this->db->num_rows;

						$p					= 1;
						$quickcats			= '';

						if ($catlistsubtotal > 0)
						{
							foreach ($catlist AS $list) 
							{
								if ((TIEINON == 'enth') && ($this->enthfileexists == 1))
								{
									$quickcats	.= $list->subject;
								} else {
									$quickcats	.= $list->listname;
								}

								if ($p < $catlistsubtotal)
								{
									$quickcats	.= ', ';
								}

								$p++;
							}
						}

						$catlist = $this->db->query("UPDATE `". PREFIX ."_kim` SET `quicklists`=". parent::addthoseslashes($quickcats) ." WHERE `kimid`=". $new_id);

			  			if ($this->emailnotify == 'Y')
						{
							$emailsubject 	= 'New Keep-in-Minder: '. SITENAME;
							$etemplate 		= parent::emailtemplatekim($new_id, 36, '', '', '');

							$to['email']	= ADMINEMAIL;
							$to['name']		= ADMINNAME;

							$froma['email']	= $kemail;
							$froma['name']	= $kname;

							parent::dosendmail($to, $froma, $emailsubject, $etemplate);
						}

						if ($sendinfo == 1)
						{
							$emailsubject = 'New Keep-In-Mind: '. SITENAME;

							$etempnotify  = parent::emailtemplatekim($new_id, 35, '', '', '');

							$to['email']	= $kemail;
							$to['name']		= $kname;

							$froma['email']	= ADMINEMAIL;
							$froma['name']	= ADMINNAME;

							parent::dosendmail($to, $froma, $emailsubject, $etempnotify);
						}
						
						$sql = "DELETE FROM `". PREFIX ."_form_protect` ".
						"WHERE `formid`=". $this->addthoseslashes($this->getemailpost('formcodeanti'));

						$dodelete = $this->db->query($sql);
					} else {
						list($userName, $mailDomain) = split("@", ADMINEMAIL);

						$finalemail		= '<script type="text/javascript">mail2("'. $mailDomain .'", "", "'. $this->lang['lang_showemail'] .'", "'. $userName .'")</script>';
						$this->lang['lang_notadded']	= str_replace('%%email%%', $finalemail, $this->lang['lang_notadded']);
						$bodyjoin		.= $this->lang['lang_notadded'];
						$template	= str_replace('%%lang_headergeneric%%', $this->lang['lang_kimheaderjoinerror'], $template);
					}
				} else { 
					list($userName, $mailDomain) = split("@", ADMINEMAIL);

					$finalemail		= '<script type="text/javascript">mail2("'. $mailDomain .'", "", "'. $this->lang['lang_showemail'] .'", "'. $userName .'")</script>';
					$this->lang['lang_emailsame']	= str_replace('%%email%%', $finalemail, $this->lang['lang_emailsame']);
					$bodyjoin		.= $this->lang['lang_emailsame'];
					$bodyjoin		= str_replace('%%kimupdateurl%%', parent::phpfanlink('keepinmind', '', '', 'join'), $bodyjoin);
					$template	= str_replace('%%lang_headergeneric%%', $this->lang['lang_kimheaderjoinerror'], $template);
				}
			}

			$template	= str_replace('%%body%%', $this->lang['lang_genericbegin'] . $bodyjoin . $this->lang['lang_genericend'], $template);
			$template	= str_replace('%%lang_headergeneric%%', $this->lang['lang_kimheaderjoinsent'], $template);
			$body		= str_replace('%%kimbody%%', $template, $this->body);
			$body		= str_replace('%%lang_kimheader%%', $this->lang['lang_kimheadermain'], $body);

			return $body;
		}

		function updateinfo()
		{
			$this->body	= str_replace('%%lang_navigation%%', '', $this->body);			
			$this->body	= str_replace('%%lang_kimheader%%', $this->lang['lang_kimheaderupdateinfo'], $this->body);

			$spambody	= str_replace('%%menu_main_show_listings_with_no_kimers%%', '', $this->body);
			$template	= parent::antispamprocedures($spambody, 1);

			$klid	  	= parent::getemailpost('checkbox');
			$kshowemail	= parent::getemailpost('kimshowemail');

			$kurl		= parent::getdirtypost('kimurl');
			$kurl		= parent::cleanurl($kurl);

			$kname    	= parent::getemailpost('kimname');
			$kemail   	= parent::getemailpost('kimemail');
			$sendinfo	= parent::getemailpost('sendinfo');
			$oldemail	= parent::getemailpost('oldkimemail');

			$errors		= 0;
			$error		= '';

			if (empty($kname)) 
			{
				$errors = 1;
				$error .= $this->lang['lang_errorname'];
			}

			if (empty($kemail))
			{
				$errors = 1;
				$error .= $this->lang['lang_erroremail'];
			} elseif (!parent::is_valid_email_address($kemail)) {
				$errors = 1;
				$error .= $this->lang['lang_errorinvalidemail'];
			} else {
				list($userName, $mailDomain) = split("@", $kemail);

				if (checkdnsrr($mailDomain, "MX"))
				{
				} else {
					$errors = 1;
					$error .= $this->lang['lang_errorinvalidemail'];
				}
			}

			if (!is_array($klid)) 
			{
				$error .= $this->lang['lang_errorlid'];
				$errors = 1;
			}

			$bodyjoin = '';

			if ($errors == 1)
			{
				$bodyjoin .= $error;
			} else {
				$isinkim      	= $this->db->get_row('SELECT `kimid` FROM `'. PREFIX .'_kim` WHERE `kimemail`='. parent::addthoseslashes($oldemail));

				$emailinkim	= $this->db->num_rows;

				if ($oldemail != $kemail)
				{
					$result       = $this->db->get_results('SELECT `kimid` FROM `'. PREFIX .'_kim` WHERE `kimemail`='. parent::addthoseslashes($kemail));

					$emailresults = $this->db->num_rows;
				} else {
					$emailresults = 0;
				}

				if ($emailinkim > 0)
				{
					if ($emailresults == 0)
					{
						$id	= $isinkim->kimid;

						$autocapitalizenames = parent::settings('autocapitalizenames');

						if ($autocapitalizenames == 'Y')
						{
							$kname = strtolower($kname);
							$kname = ucwords($kname);
						}

						if (empty($kurl))
						{
							$kurl = '';
						} else {
							$web = substr($kurl,0,7);

							if ($web == 'http://')
							{
								if ($kurl != 'http://')
								{
									$kurl = $kurl;
								}
							} elseif ($web != 'http://') {
								if($kurl != 'http://')
								{
									$kurl = 'http://'. $kurl;
								}
							}
						}

						$kname			= parent::stripthoseslashes($kname);
						$this->lang['lang_kimthanksupdate'] 	= str_replace('%%kimname%%', $kname, $this->lang['lang_kimthanksupdate']);

						$bodyjoin		.= $this->lang['lang_kimthanksupdate'];

						$listq		= $this->db->get_results('SELECT `listname` FROM `'. PREFIX .'_list` WHERE `listid` IN (\''. implode("','", $klid) .'\') GROUP BY `listid`');
						$numlist	= $this->db->num_rows;

						if ($numlist > 0)
						{
							$listsn	= '';
							foreach ($listq AS $list)
							{
								$listsn	.= $list->listname ."\n";
							}
						}

						if ($kshowemail == 1)
						{
							$kshowemail = 'Y';
						} else {
							$kshowemail	= 'N';
						}

						$ip 	= parent::realip();
						$ua 	= parent::getserver('HTTP_USER_AGENT');

						$emailsubject = 'Update Keep-in-Minder:'. SITENAME;
						$etemplate 	= parent::gettemplate(38, '');
						$etemplate 	= str_replace('%%ip%%', $ip, $etemplate);
						$etemplate 	= str_replace('%%ua%%', $ua, $etemplate);
						$etemplate 	= str_replace('%%oldemail%%', $oldemail, $etemplate);
						$etemplate 	= str_replace('%%name%%', $kname, $etemplate);
						$etemplate 	= str_replace('%%email%%', $kemail, $etemplate);
						$etemplate 	= str_replace('%%showemail%%', $kshowemail, $etemplate);
						$etemplate 	= str_replace('%%listsname%%', $listsn, $etemplate);
						$etemplate 	= str_replace('%%url%%', $kurl, $etemplate);
						$etemplate 	= str_replace('%%id%%', $id, $etemplate);

						$etemplate	= parent::emailtemplatekim($id, 38, '', $etemplate, '');

						$to['email']	= ADMINEMAIL;
						$to['name']		= ADMINNAME;

						$froma['email']	= $kemail;
						$froma['name']	= $kname;

						parent::dosendmail($to, $froma, $emailsubject, $etemplate);

						if ($sendinfo == 1)
						{
							$emailsubject 	= 'Update Keep-In-Mind: '. SITENAME;

							$etemplate 	= parent::gettemplate(39, '');
							$etemplate	= str_replace('%%oldemail%%', $oldemail, $etemplate);
							$etemplate 	= str_replace('%%ip%%', $ip, $etemplate);
							$etemplate 	= str_replace('%%ua%%', $ua, $etemplate);
							$etemplate 	= str_replace('%%oldemail%%', $oldemail, $etemplate);
							$etemplate 	= str_replace('%%name%%', $kname, $etemplate);
							$etemplate 	= str_replace('%%email%%', $kemail, $etemplate);
							$etemplate 	= str_replace('%%showemail%%', $kshowemail, $etemplate);
							$etemplate 	= str_replace('%%listsname%%', $listsn, $etemplate);
							$etemplate 	= str_replace('%%url%%', $kurl, $etemplate);
							$etemplate 	= str_replace('%%id%%', $id, $etemplate);

							$etemplate 	= parent::emailtemplatekim($id, 39, '', $etemplate, '');

							$to['email']	= $kemail;
							$to['name']		= $kname;

							$froma['email']	= ADMINEMAIL;
							$froma['name']	= ADMINNAME;

							parent::dosendmail($to, $froma, $emailsubject, $etemplate);
						}

						$sql = "DELETE FROM `". PREFIX ."_form_protect` ".
						"WHERE `formid`=". $this->addthoseslashes($this->getemailpost('formcodeanti'));

						$dodelete = $this->db->query($sql);
					} else { 
						list($userName, $mailDomain) = split("@", ADMINEMAIL);

						$finalemail		= '<script type="text/javascript">mail2("'. $mailDomain .'", "", "'. $this->lang['lang_showemail'] .'", "'. $userName .'")</script>';
						$this->lang['lang_emailsame']	= str_replace('%%email%%', $finalemail, $this->lang['lang_emailsame']);
						$bodyjoin		.= $this->lang['lang_emailsame'];
					}
				} else {
					list($userName, $mailDomain) = split("@", ADMINEMAIL);

					$finalemail		= '<script type="text/javascript">mail2("'. $mailDomain .'", "", "'. $this->lang['lang_showemail'] .'", "'. $userName .'")</script>';
					$this->lang['lang_emailoldnotinkim']	= str_replace('%%email%%', $finalemail, $this->lang['lang_emailoldnotinkim']);
					$bodyjoin		.= $this->lang['lang_emailoldnotinkim'];
				}
			}

			$bodyjoin	= str_replace('%%kimupdateurl%%', parent::phpfanlink('keepinmind', '', '', 'choose'), $bodyjoin);

			$template	= str_replace('%%body%%', $this->lang['lang_genericbegin'] . $bodyjoin . $this->lang['lang_genericend'], $template);
			$template	= str_replace('%%lang_headergeneric%%', $this->lang['lang_kimheaderupdateinfosent'], $template);
			$body		= str_replace('%%kimbody%%', $template, $this->body);
			$body		= str_replace('%%lang_kimheader%%', $this->lang['lang_kimheadermain'], $body);

			return $body;
		}

		function retrievepwnow()
		{
			$this->body	= str_replace('%%lang_navigation%%', '', $this->body);
			$this->body	= str_replace('%%lang_kimheader%%', $this->lang['lang_kimheaderretrievepw'], $this->body);
			
			$spambody	= str_replace('%%menu_main_show_listings_with_no_kimers%%', '', $this->body);
			$template	= parent::antispamprocedures($spambody, 0);

			$kemail   	= parent::getemailpost('kimemail');

			$errors		= 0;
			$error		= '';

			if (empty($kemail))
			{
				$errors = 1;
				$error .= $this->lang['lang_erroremail'];
			}

			$bodyjoin 		= '';

			if ($errors == 1)
			{
				$bodyjoin 	.= $error;
				$template	= str_replace('%%lang_headergeneric%%', $this->lang['lang_kimheaderretrievepwerror'], $template);
			} else {
				$result       = $this->db->get_row('SELECT `kimid` FROM `'. PREFIX .'_kim` WHERE `kimemail`='. parent::addthoseslashes($kemail));

				$emailresults = $this->db->num_rows;

				if ($emailresults > 0)
				{
					$id	= $result->kimid;

					$kname				= parent::stripthoseslashes($kname);
					$this->lang['lang_kimthankspw'] 	= str_replace('%%kimname%%', $kname, $this->lang['lang_kimthankspw']);

					$bodyjoin			.= $this->lang['lang_kimthankspw'];

					$emailsubject = 'Retrieve Password for Keep-In-Minder: '. SITENAME;

					$random_password 	= parent::makeRandomPassword();
					$passwordsalt		= parent::passwordhash($random_password, $kemail, '');
					$password_e			= $passwordsalt['password'];
					$salt				= $passwordsalt['salt'];

					$etempnotify  	= parent::emailtemplatekim($id, 42, '', '', $random_password);

					$pw				= $this->db->query('UPDATE `'. PREFIX .'_kim` SET `kimpw`='. parent::addthoseslashes($password_e) .', `salt`='. parent::addthoseslashes($salt) .' WHERE `kimid`='. $id);

					$to['email']	= $kemail;
					$to['name']		= $kname;

					$froma['email']	= ADMINEMAIL;
					$froma['name']	= ADMINNAME;

					parent::dosendmail($to, $froma, $emailsubject, $etempnotify);
				} else {
					$template	= str_replace('%%lang_headergeneric%%', $this->lang['lang_kimheaderretrievepwerror'], $template);
					list($userName, $mailDomain) = split("@", ADMINEMAIL);

					$finalemail		= '<script type="text/javascript">mail2("'. $mailDomain .'", "", "'. $this->lang['lang_showemail'] .'", "'. $userName .'")</script>';
					$this->lang['lang_emailoldnotinkim']	= str_replace('%%email%%', $finalemail, $this->lang['lang_emailoldnotinkim']);
					$bodyjoin		.= $this->lang['lang_emailoldnotinkim'];
				}
			}

			$template	= str_replace('%%body%%', $this->lang['lang_genericbegin'] . $bodyjoin . $this->lang['lang_genericend'], $template);
			$template	= str_replace('%%lang_headergeneric%%', $this->lang['lang_kimheaderretrievepwsent'], $template);

			$body		= str_replace('%%kimbody%%', $template, $this->body);
			$body		= str_replace('%%lang_kimheader%%', $this->lang['lang_kimheadermain'], $body);
			$body 		= str_replace('%%lang_navigation%%', '', $body);

			return $body;
		}

		function newkim_tree()
		{
			$bodyc	= '';

			$cats 		= $this->db->get_results('SELECT `listid` FROM `'. PREFIX .'_list`');  
			$cattotal	= $this->db->num_rows;

			$getcats 	= $this->db->get_results('SELECT `listid`, `listname` FROM `'. PREFIX .'_list` ORDER BY `listname`');

			$numcats	= $this->db->num_rows;		

			if ($numcats > 0)
			{
				foreach ($getcats AS $cat) 
				{
					$npid    	= $cat->listid;
					$listname 	= $cat->listname;

					$bodyc	.= '<label>';
					$bodyc .= '<input type="checkbox" name="checkbox[]" value="'. $npid .'" />'. $listname .'</label><br />';
				}
			}

			return $bodyc;
		}

		function newenthkim_tree()
		{
			$bodyc	= '';
			
			if ((TIEINON == 'enth') && ($this->enthfileexists == 1))
			{
				include ENTHUSIASTTI;
				$cats 		= $this->db->get_results('SELECT `listingid` FROM `'. $db_owned .'`');  
				$cattotal	= $this->db->num_rows;

				$getcats 	= $this->db->get_results('SELECT `listingid`, `subject` FROM `'. $db_owned .'` ORDER BY `subject`');

				$numcats	= $this->db->num_rows;		

				if ($numcats > 0)
				{
					foreach ($getcats AS $cat) 
					{
						$npid    	= $cat->listingid;
						$listname 	= $cat->subject;

						$bodyc	.= '<label>';
						$bodyc .= '<input type="checkbox" name="checkbox[]" value="'. $npid .'" />'. $listname .'</label><br />';
					}
				}
			}

			return $bodyc;
		}

		function join()
		{
			$antispam	= parent::antispam('Y');

			$template	= parent::fetchtemplate(34);

			$template 		= str_replace('%%form_url%%', parent::phpfanlink('keepinmind', '', '', 'sent'), $template);


			$template 		= str_replace('%%listname%%', SITENAME, $template);

			if ((TIEINON == 'enth') && ($this->enthfileexists == 1))
			{
				$lidtemplate	= $this->newenthkim_tree();

				$template 		= str_replace('%%list_dropdown%%', $lidtemplate, $template);
			} else {
				$lidtemplate	= $this->newkim_tree();

				$template 		= str_replace('%%list_dropdown%%', $lidtemplate, $template);
			}

			$template 		= str_replace('%%kimname_field%%', '<input type="text" name="kimname" id="kimname" size="20" maxlength="100" class="inputfield" value="" />', $template);

			$template		 = str_replace('%%kimemail_field%%', '<input type="text" name="kimemail" id="kimemail" size="20" class="inputfield" maxlength="100" value="" />', $template);

			$showemail_field = '<input type="radio" name="kimshowemail" id="kimshowemail" value="1" />'. $this->lang['lang_yes'] .'&nbsp;<input type="radio" name="kimshowemail" value="0" />'. $this->lang['lang_no'];

			$template 	= str_replace('%%kimshowemail_field%%', $showemail_field, $template);
			$template 	= str_replace('%%kimurl_field%%', '<input type="text" name="kimurl" id="kimurl" size="20" maxlength="100" class="inputfield" value="" />', $template);
			$template 	= str_replace('%%antispam%%', $antispam, $template);

			$body		= str_replace('%%kimbody%%', $template, $this->body);
			$body		= str_replace('%%lang_kimheader%%', $this->lang['lang_kimheaderjoin'], $body);
			$body 		= str_replace('%%lang_navigation%%', '', $body);

			return $body;
		}

		function retrievepw()
		{
			$antispam	= parent::antispam('N');

			$template	= parent::fetchtemplate(41);

			$template 		= str_replace('%%form_url%%', parent::phpfanlink('keepinmind', '', '', 'retrievepwnow'), $template);

			$template 		= str_replace('%%kimemail_field%%', $antispam .'<input type="text" name="kimemail" id="kimemail" size="20" class="inputfield" maxlength="100" value="" />', $template);

			$template 			= str_replace('%%antispam%%', '', $template);

			$template 			= str_replace('%%kimpw_link%%', parent::phpfanlink('keepinmind', '', '', 'retrievepw'), $template);

			$body				= str_replace('%%kimbody%%', $template, $this->body);
			$body				= str_replace('%%lang_kimheader%%', $this->lang['lang_kimheaderretrievepw'], $body);
			$body 				= str_replace('%%lang_navigation%%', '', $body);

			return $body;
		}

		function updatenow()
		{
			$antispam	= parent::antispam('N');

			$template	= parent::fetchtemplate(40);

			$template 	= str_replace('%%form_url%%', parent::phpfanlink('keepinmind', '', '', 'updateinfonow'), $template);

			$template 	= str_replace('%%listname%%', SITENAME, $template);

			if ((TIEINON == 'enth') && ($this->enthfileexists == 1))
			{
				$lidtemplate	= $this->newenthkim_tree();

				$template 		= str_replace('%%list_dropdown%%', $lidtemplate, $template);
			} else {
				$lidtemplate	= $this->newkim_tree();
			
				$template	= str_replace('%%list_dropdown%%', $lidtemplate, $template);
			}

			$template 	= str_replace('%%kimname_field%%', '<input type="text" name="kimname" id="kimname" size="20" maxlength="100" class="inputfield" value="" />', $template);

			$template 	= str_replace('%%kimemail_field%%', '<input type="text" name="kimemail" id="kimemail" size="20" class="inputfield" maxlength="100" value="" />', $template);

			$template 	= str_replace('%%oldkimemail_field%%', '<input type="text" name="oldkimemail" id="oldkimemail" size="20" class="inputfield" maxlength="100" value="" />', $template);

			$template 	= str_replace('%%kimpw_field%%', '<input type="password" name="pw" id="pw" size="20" class="inputfield" maxlength="100" value="" />', $template);

			$showemail_field	= '<input type="radio" name="kimshowemail" id="kimshowemail" value="1" />'. $this->lang['lang_yes'] .'&nbsp;<input type="radio" name="kimshowemail" value="0" />'. $this->lang['lang_no'];

			$template 			= str_replace('%%kimshowemail_field%%', $showemail_field, $template);
			$template 			= str_replace('%%kimurl_field%%', $antispam .'<input type="text" name="kimurl" id="kimurl" size="20" maxlength="100" class="inputfield" value="" />', $template);
			$template 			= str_replace('%%antispam%%', '', $template);

			$template 			= str_replace('%%kimpw_link%%', parent::phpfanlink('keepinmind', '', '', 'retrievepw'), $template);

			$body				= str_replace('%%kimbody%%', $template, $this->body);
			$body				= str_replace('%%lang_kimheader%%', $this->lang['lang_kimheaderupdateinfonow'], $body);
			$body 				= str_replace('%%lang_navigation%%', '', $body);

			return $body;
		}

		function update()
		{
			$antispam	= parent::antispam('Y');


			$template	= parent::fetchtemplate(37);

			$template		 = str_replace('%%form_url%%', parent::phpfanlink('keepinmind', '', '', 'updateinfo'), $template);


			$template 		= str_replace('%%listname%%', SITENAME, $template);

			if ((TIEINON == 'enth') && ($this->enthfileexists == 1))
			{
				$lidtemplate	= $this->newenthkim_tree();

				$template 		= str_replace('%%list_dropdown%%', $lidtemplate, $template);
			} else {
				$lidtemplate	= $this->newkim_tree();

				$template 		= str_replace('%%list_dropdown%%', $lidtemplate, $template);
			}

			$template 		= str_replace('%%kimname_field%%', '<input type="text" name="kimname" id="kimname" size="20" maxlength="100" class="inputfield" value="" />', $template);

			$template 		= str_replace('%%kimemail_field%%', '<input type="text" name="kimemail" id="kimemail" size="20" class="inputfield" maxlength="100" value="" />', $template);

			$template 		= str_replace('%%oldkimemail_field%%', '<input type="text" name="oldkimemail" id="oldkimemail" size="20" class="inputfield" maxlength="100" value="" />', $template);

			$showemail_field = '<input type="radio" name="kimshowemail" id="kimshowemail" value="1" />'. $this->lang['lang_yes'] .'&nbsp;<input type="radio" name="kimshowemail" value="0" />'. $this->lang['lang_no'];

			$template	= str_replace('%%kimshowemail_field%%', $showemail_field, $template);
			$template 	= str_replace('%%kimurl_field%%', '<input type="text" name="kimurl" id="kimurl" size="20" maxlength="100" class="inputfield" value="" />', $template);
			$template 	= str_replace('%%antispam%%', $antispam, $template);

			$body		= str_replace('%%kimbody%%', $template, $this->body);
			$body		= str_replace('%%lang_kimheader%%', $this->lang['lang_kimheaderupdateinfo'], $body);
			$body 		= str_replace('%%lang_navigation%%', '', $body);

			return $body;
		}

		function listshow()
		{
			$id			= parent::allinput('listname');
			$getnum		= (int)parent::allinput('number');

			$x				= 0;
			$wherecat		= 0;
			$clean	= '';

			if (PERMALINK == 1)
			{
				foreach ($this->ruri AS $string)
				{
					if ($string == 'keep-in-mind')
					{
						$wherecat	= $x;
					}

					$x++;
				}

				$y	= 0;

				if ($this->wherenum > 0)
				{
					$catnum	= $this->wherenum - $wherecat;
					$catnum	= $wherecat + $catnum;

					$wherecat	= $wherecat + 1;

					for ($i=$wherecat; $i<$catnum; $i++) 
					{
						$id		= $this->ruri[$i];
						$clean	= $this->ruri[$i] .'/';
					}	

					$this->wherenum	= $this->wherenum + 1;

					$getnum	= (int)$this->ruri[$this->wherenum];
				} else {
					$catnum	= $this->totalnum - $wherecat;
					$catnum	= $wherecat + $catnum;

					$wherecat	= $wherecat + 1;

					for ($i=$wherecat; $i<$catnum; $i++) 
					{
						$id			= $this->ruri[$i];

						$clean		= $this->ruri[$i] .'/';

						$y++;
					}
				}
			}

			if ((TIEINON == 'enth') && ($this->enthfileexists == 1))
			{
				$enthcatp	= explode('-', $id);

				if (isset($enthcatp[1]))
				{
					$id	= (int)$enthcatp[1];
				} else {
					$id	= 0;
				}

				$sql_code 	= '`listingid`='. $id;
			} else {
				$sql_code    	= '`CleanCatname`='. parent::addthoseslashes($id);
			}

			$kimlist	= parent::fetchtemplate(31);
			$kimlistend	= parent::fetchtemplate(32);
			$kimkimer	= parent::fetchtemplate(33);

			if ((TIEINON == 'enth') && ($this->enthfileexists == 1))
			{
				include ENTHUSIASTTI;

				$third 		= 'FROM `'. $db_owned .'` y WHERE '. $sql_code;
				$second 	= ' FROM `'. PREFIX .'_kim` LEFT JOIN `'. PREFIX .'_lookupkim` ON ('. PREFIX .'_kim.kimid = '. PREFIX .'_lookupkim.kim) LEFT JOIN `'. $db_owned .'` z ON (z.listingid = '. PREFIX .'_lookupkim.lid) WHERE `kimvalidated`=1 AND '. $sql_code;
			} else {
				$third		= 'FROM `'. PREFIX .'_list` WHERE '. $sql_code;
				$second 	= ' FROM `'. PREFIX .'_kim` LEFT JOIN `'. PREFIX .'_lookupkim` ON ('. PREFIX .'_kim.kimid = '. PREFIX .'_lookupkim.kim) LEFT JOIN `'. PREFIX .'_list` z ON (z.listid = '. PREFIX .'_lookupkim.lid) WHERE `kimvalidated`=1 AND '. $sql_code;
			}

			$total 		= $this->db->get_var('SELECT COUNT(DISTINCT `kimid`)'. $second);

			$second		.= ' GROUP BY `kimid` ORDER BY `kimid`';

			$second 	.= ' LIMIT '. $getnum .', '. NUMBER;

			$listname	= '';
			$kimkimers	= '';

			if ((TIEINON == 'enth') && ($this->enthfileexists == 1))
			{
				$kims 		= $this->db->get_results('SELECT `listingid`, `quicklists`, `kimid`, `kimemail`, `kimurl`, `kimname`, `kimshowemail`, `subject`, `url`'. $second);
			} else {
				$kims 		= $this->db->get_results('SELECT `listid`, `quicklists`, `kimid`, `kimemail`, `kimurl`, `kimname`, `kimshowemail`, `listname`, `listurl`'. $second);
			}

			$kimtotal	= $this->db->num_rows;

			$listurl	= '';

			if ($kimtotal > 0)
			{
				foreach ($kims AS $kim)
				{
					$kimid     	= $kim->kimid;
					$kemail  	= $kim->kimemail;
					$kurl 		= $kim->kimurl;
					$kname		= $kim->kimname;
					$kshowemail	= $kim->kimshowemail;
					
					if ((TIEINON == 'enth') && ($this->enthfileexists == 1))
					{
						$listname	= $kim->subject;
						$listurl	= $kim->url;
					} else {
						$listname	= $kim->listname;
						$listurl	= $kim->listurl;
					}

					$quick		= $kim->quicklists;

					$kimer		= '';

					$kimkimers	.= $kimkimer;

					if (empty($kurl)) 
					{
						if (empty($kemail)) 
						{
							$kimer .= $kname .'<br />';
						} else {
							if ($kshowemail == 1)
							{
								list($userName, $mailDomain) = split("@", $kemail);

								$kimer .= '<script type="text/javascript">mail2("'. $mailDomain .'", "", "'. $kname .'", "'. $userName .'")</script>';
							} else {
								$kimer .= $kname;
							}						
						}
					} else {
						$kimer .= '<a href="'. $kurl .'"'. OPEN .'>'. $kname .'</a>';
					}

					$kimkimers		= str_replace('%%kimer%%', $kimer, $kimkimers);			
					$kimkimers		= str_replace('%%kimcats%%', $quick, $kimkimers);
				}
			} else {
				if ((TIEINON == 'enth') && ($this->enthfileexists == 1))
				{
					$lists 		= $this->db->get_row('SELECT `subject`, `url`'. $third);
					$listtotal	= $this->db->num_rows;

					if ($listtotal > 0)
					{
						$listname	= $lists->subject;
						$listurl	= $lists->url;
					} else {
						$listname	= $this->lang['lang_kimnoexist'];
						$listurl	= BASIC;
					}
				} else {
					$lists 		= $this->db->get_row('SELECT `listname`, `listurl`'. $third);
					$listtotal	= $this->db->num_rows;

					if ($listtotal > 0)
					{
						$listname	= $lists->listname;
						$listurl	= $lists->listurl;
					} else {
						$listname	= $this->lang['lang_kimnoexist'];
						$listurl	= BASIC;
					}
				}
			}

			$body		= str_replace('%%lang_kimheader%%', $this->lang['lang_kimspecificheader'], $this->body);
			$body		= str_replace('%%kimlistname%%', $listname, $body);
			$body		= str_replace('%%kimlisturl%%', $listurl, $body);

			$nav		= parent::navigation($total, $getnum, 'keepinmind', $id, $clean);

			if (!empty($nav))
			{
				$body 	= str_replace('%%lang_navigation%%', $this->lang['lang_navigation'], $body);
				$body 	= str_replace('%%navigation%%', $nav, $body);
			} else {
				$body 	= str_replace('%%lang_navigation%%', '', $body);
			}

			$body		= str_replace('%%kimbody%%', $kimlist . $kimkimers . $kimlistend, $body);		
			$body		= str_replace('%%listname%%', $listname, $body);

			return $body;
		}

		function all()
		{
			$getnum		= (int)parent::allinput('number');

			$clean	= '';

			if (PERMALINK == 1)
			{
				if ($this->wherenum > 0)
				{
					$this->wherenum	= $this->wherenum + 1;

					$getnum	= (int)$this->ruri[$this->wherenum];
				}
			}

			$kimlist	= parent::fetchtemplate(56);
			$kimlistend	= parent::fetchtemplate(57);
			$kimkimert	= parent::fetchtemplate(58);

			if ((TIEINON == 'enth') && ($this->enthfileexists == 1))
			{
				include ENTHUSIASTTI;
				$total 		= $this->db->get_var('SELECT COUNT(DISTINCT `kim`) FROM `'. PREFIX .'_kim` LEFT JOIN `'. PREFIX .'_lookupkim` ON ('. PREFIX .'_kim.kimid = '. PREFIX .'_lookupkim.kim) LEFT JOIN `'. $db_owned .'` z ON (z.listingid = '. PREFIX .'_lookupkim.lid) WHERE `kimvalidated`=1 AND `listingid` > 0');
			} else {
				$total 		= $this->db->get_var('SELECT COUNT(DISTINCT `kim`) FROM `'. PREFIX .'_kim` LEFT JOIN `'. PREFIX .'_lookupkim` ON ('. PREFIX .'_kim.kimid = '. PREFIX .'_lookupkim.kim) LEFT JOIN `'. PREFIX .'_list` z ON (z.listid = '. PREFIX .'_lookupkim.lid) WHERE `kimvalidated`=1 AND `lid` != 0');
			}

			$x       	= 0;
			$listname	= '';
			$listurl	= '';
			$kimer		= '';

			if ((TIEINON == 'enth') && ($this->enthfileexists == 1))
			{
				$kims 		= $this->db->get_results('SELECT `quicklists`, `listingid`, `kimid`, `kimemail`, `kimurl`, `kimname`, `kimshowemail`, `subject`, `url` FROM `'. PREFIX .'_kim` LEFT JOIN `'. PREFIX .'_lookupkim` ON ('. PREFIX .'_kim.kimid = '. PREFIX .'_lookupkim.kim) LEFT JOIN `'. $db_owned .'` z ON (z.listingid = '. PREFIX .'_lookupkim.lid) WHERE `kimvalidated`=1 AND `listingid` > 0 ORDER BY `lid`, `kimid` LIMIT '. $getnum .', '. NUMBER);
			} else {
				$kims 		= $this->db->get_results('SELECT `quicklists`, `listid`, `kimid`, `kimemail`, `kimurl`, `kimname`, `kimshowemail`, `listname`, `listurl` FROM `'. PREFIX .'_kim` LEFT JOIN `'. PREFIX .'_lookupkim` ON ('. PREFIX .'_kim.kimid = '. PREFIX .'_lookupkim.kim) LEFT JOIN `'. PREFIX .'_list` ON ('. PREFIX .'_list.listid = '. PREFIX .'_lookupkim.lid) WHERE `kimvalidated`=1 AND `lid` != 0 ORDER BY `lid`, `kimid` LIMIT '. $getnum .', '. NUMBER);
			}

			$kimtotal	= $this->db->num_rows;

			$thekimer	= '';

			if ($kimtotal > 0)
			{
				foreach ($kims AS $kim)
				{
					$kimid     	= $kim->kimid;
					$kemail  	= $kim->kimemail;
					$kurl 		= $kim->kimurl;
					$kname		= $kim->kimname;
					$kshowemail	= $kim->kimshowemail;
					$quick		= $kim->quicklists;

					$thekimer	.= $kimkimert;

					if (empty($kurl)) 
					{
						if (empty($kemail)) 
						{
							$realkimer	.= $kname;
						} else {
							if ($kshowemail == 1)
							{
								list($userName, $mailDomain) = split("@", $kemail);

								$realkimer	= '<script type="text/javascript">mail2("'. $mailDomain .'", "", "'. $kname .'", "'. $userName .'")</script>';
							} else {
								$realkimer	= $kname;
							}						
						}
					} else {
						$realkimer	= '<a href="'. $kurl .'"'. OPEN .'>'. $kname .'</a>';
					}

					$thekimer		= str_replace('%%kimer%%', $realkimer, $thekimer);			
					$thekimer		= str_replace('%%kimcats%%', $quick, $thekimer);
				}
			}

			if (!empty($thekimer))
			{
				$kimer	= $kimlist;
				$kimer	.= $thekimer;
				$kimer	.= $kimlistend;
			}

			$body		= str_replace('%%lang_kimheader%%', $this->lang['lang_kimallheader'], $this->body);
			$nav		= parent::navigation($total, $getnum, 'keepinmindall', '', '');

			if (!empty($nav))
			{
				$body 	= str_replace('%%lang_navigation%%', $this->lang['lang_navigation'], $body);
				$body 	= str_replace('%%navigation%%', $nav, $body);
			} else {
				$body 	= str_replace('%%lang_navigation%%', '', $body);
			}

			$body		= str_replace('%%kimbody%%', $kimer, $body);		
			$body 		= str_replace('%%listname%%', '', $body);
			return $body;
		}

		function def()
		{
			$id	= parent::allinput('id');

			$template	= parent::fetchtemplate(28);
			$kimlistend	= parent::fetchtemplate(29);
			$kimkimer	= parent::fetchtemplate(30);

			$getnum		= (int)parent::allinput('number');
			$x			= 0;
			$wheretype	= '';
			$type		= parent::allinput('type');

			if (PERMALINK == 1)
			{
				foreach ($this->ruri AS $string)
				{
					if ($string == 'type')
					{
						$wheretype	= $x;
					}

					$x++;
				}
			
				$clean	= '';	

				if ($this->wherenum > 0)
				{
					$this->wherenum	= $this->wherenum + 1;

					$getnum	= (int)$this->ruri[$this->wherenum];
				}

				if ($wheretype > 0)
				{
					$wheretype	= $wheretype + 1;
					$type		= $this->ruri[$wheretype];
					$clean		.= 'type/'. $type;
				}
			}
			
			if ((TIEINON == 'enth') && ($this->enthfileexists == 1))
			{
				include ENTHUSIASTTI;
				$total 		= $this->db->get_var('SELECT COUNT(`listingid`) FROM `'. $db_owned .'`');

				$second 	= 'SELECT `subject`, `listingid` FROM `'. $db_owned .'` WHERE `listingid` > 0 GROUP BY `listingid`';

				$second 	.= ' ORDER BY `subject`';
			} else {
				$total 		= $this->db->get_var('SELECT COUNT(`listid`) FROM `'. PREFIX .'_list` WHERE `Numkim` > 0');

				if ($type == 'listall')
				{
					$sqltype	= '';
				} else {
					$sqltype	= ' WHERE `Numkim` > 0';
				}

				$second 	= 'SELECT `listname`, `listid`, `CleanCatname`, `Numkim` FROM `'. PREFIX .'_list` '. $sqltype .' GROUP BY `listid`';

				$second 	.= ' ORDER BY `listname`';
			}


			$imsizei	= '';

			$kims 		= $this->db->get_results($second .' LIMIT '. $getnum .', '. NUMBER);
			$kimtotal	= $this->db->num_rows;

			if ($kimtotal > 0)
			{
				foreach ($kims AS $kim)
				{
					if ((TIEINON == 'enth') && ($this->enthfileexists == 1))
					{
						$listname	= $kim->subject;
						$listid		= $kim->listingid;
						
						$numkim 	= $this->db->get_var('SELECT COUNT(DISTINCT `kim`) FROM `'. PREFIX .'_lookupkim` y LEFT JOIN `'. PREFIX .'_kim` z ON(y.kim = z.kimid) WHERE `kim` > 0 AND `lid`='. $listid .' AND `kimvalidated` > 0');
						$clean		= 'enth-'. $listid .'-'. strtolower(ereg_replace("[^a-z,A-Z,0-9,_]", '-', parent::removeentities(parent::remove_accents($listname))));
					} else {
						$listname	= $kim->listname;
						$listid		= $kim->listid;
						$numkim		= $kim->Numkim;
						$clean		= $kim->CleanCatname;
					}

					$imsizei	.= $kimkimer;

					$imsizei 	= str_replace('%%kimlisturl%%',parent::phpfanlink('enthkeepinmind', '', '', $clean), $imsizei);

					$imsizei	= str_replace('%%kimlistname%%', $listname, $imsizei);	
					$imsizei	= str_replace('%%kimnum%%', $numkim, $imsizei);
				}
			}

			$template	.= $imsizei . $kimlistend;
			
			$this->body	= str_replace('%%lang_menu_main_show_listings_with_no_kimers%%', $this->lang['lang_menu_main_show_listings_with_no_kimers'], $this->body);
			$this->body	= str_replace('%%showalllistingskimersurl%%', parent::phpfanlink('keepinmindtype', 'listall', '', ''), $this->body);
			$this->body	= str_replace('%%showlistingskimersurl%%', parent::phpfanlink('keepinmindtype', '', '', ''), $this->body);


			$body		= str_replace('%%kimbody%%', $template, $this->body);
			$nav		= parent::navigation($total, $getnum, 'keepinmind', '', '');

			$body		= str_replace('%%navigation%%', $nav, $body);
			$body		= str_replace('%%lang_kimheader%%', $this->lang['lang_kimheadermain'], $body);
			$body		= str_replace('%%lang_navigation%%', '', $body);
			$body 		= str_replace('%%allurl%%',parent::phpfanlink('keepinmindall', '', '', ''), $body);

			return $body;
		}
	}
}

$exist    = $func->db->query("SHOW TABLES LIKE '". $prefix ."_kim'");
$x        = $func->db->num_rows;

if ($x != 0)
{
	if ($type == 'keepinmind')
	{
		include LANG_FILE;

		$lang						= array_merge($main_lang, $kim_lang);

		$everything['lang']			= $lang;
		
		if ((CACHE != 1) || (!is_file(CACHEFILE)))
		{
			$everything['templates']	= $func->rettemplates('1,4');
		}

		$debug    					= new debug($everything);	
		$phpfan  					= new keepinmindphp($everything);

	}
} else {
	echo $func->defaultifnotinstalled('The keep-in-mind table does not exist. Have you installed the phpFan keep-in-mind addon? Consult the Readme on installation.');
}

?>