<?php

	include_once './includes/conf.inc.php';
	$type = 'keepinmind';
	include_once INCLUDEPATH .'/init.php';

?>