<?php
//-----------------------------------------------------------------------------
// BellaBuzz v1b Copyright � Jem Turner 2008 unless otherwise noted
// http://www.jemjabella.co.uk/
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License. See README.txt
// or LICENSE.txt for more information.
//-----------------------------------------------------------------------------

require('prefs.php');
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
"http://www.w3.org/TR/html4/strict.dtd">

<html>
<head>
	<title>BellaBuzz</title>
	<style type="text/css">
		* { font: 11px/15px Verdana, Sans-Serif; }
		.question { font-weight: bold; font-size: 12px; }
		.answer { font-style: italic; }
		.dates { display: block; text-align: right; font-size: 10px; }
	</style>
</head>
<body>

<p>There are currently <?php echo doCount("done"); ?> answered, and <?php echo doCount("open"); ?> unanswered questions.</p>

<?php doAskBox(); ?>

<?php
$count = doCount("done");
if ($count > 0) {
	if (isset($_GET['page']) && is_numeric($_GET['page'])) $pg = $_GET['page'];
	else $pg = 1;

	$questions = file(ANSWERED);
	$numpages = ceil($count/$perpage);

	if (isset($sortby) && $sortby == "oldest") {
		krsort($questions);
		$questions = array_values($questions);
	}

	echo '<p>';
	if ($perpage < $count) {
		if ($pg > 1 && $pg <= $numpages) echo '<a href="questions.php?page='.($pg - 1).'">Prev</a> &middot; ';
		else echo "Prev &middot; ";

		for ($x = 1; $x <= $numpages; $x++) {
			if ($x == $pg) echo '[<strong>'.$x.'</strong>] ';
			else echo '<a href="questions.php?page='.$x.'">'.$x.'</a> ';
		}
		
		if ($pg < $numpages) echo ' &middot; <a href="questions.php?page='.($pg + 1).'">Next</a>';
		else echo " &middot; Next";
	}
	echo  '</p>';

	$i = $perpage * ($pg - 1); 
	$end = $i + $perpage;

	if ($end > $count) $end = $count;
	
	while ($i<$end) {
		list($question,$dateask,$ip,$answer,$dateanswer) = preg_split("/,(?! )/", $questions[$i]);
		$question = trim(stripslashes($question), "\"\x00..\x1F");
		$answer = trim(stripslashes($answer), "\"\x00..\x1F");
?>
		<p>
			<span class="question"><?php echo $question; ?></span><br>
			<span class="answer"><?php echo nl2br($answer); ?></span><br>
			<span class="dates">Asked: <?php echo date($timestamp, strtotime($dateask)); ?> | Answered: <?php echo date($timestamp, strtotime($dateanswer)); ?></span>
		</p>
<?php
		$i++;
	}
} else {
	echo '<p>No answered questions.</p>';
}
?>

</body>
</html>