<?php
//-----------------------------------------------------------------------------
// BellaBuzz v1b Copyright � Jem Turner 2008 unless otherwise noted
// http://www.jemjabella.co.uk/
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License. See README.txt
// or LICENSE.txt for more information.
//-----------------------------------------------------------------------------

@require('prefs.php');

if (isset($_COOKIE['bellabuzz'])) {
	if ($_COOKIE['bellabuzz'] == md5($admin_pass.$secret)) {
		if (isset($_GET['page'])) $page = $_GET['page'];
		else $page = NULL;
		
		doAdminHeader();
		switch($page) {
		case "answer":
			if (!isset($_GET['ques']) || !is_numeric($_GET['ques']))
				exit("Invalid question.");
			
			doQuestionForm($_GET['ques'], UNANSWERED);
		break;
		case "edit":
			if (!isset($_GET['ques']) || !is_numeric($_GET['ques']))
				exit("Invalid question.");
			
			doQuestionForm($_GET['ques'], ANSWERED);
		break;
		case "editprocess":
			if ($_SERVER['REQUEST_METHOD'] != "POST")
				doError("This page must not be accessed directly.");

			if (doIpCheck($_SERVER['REMOTE_ADDR']) === false)
				doError("Invalid IP; no need to fiddle with the readonly form elements.");

			foreach ($_POST as $key => $val) {
				$$key = preg_replace("/,(?! )/", ", ", trim(strip_tags($val)));
			}

			$answer = str_replace("<br /><br /><br /><br />", "<br /><br />", preg_replace("([\r\n])", "<br />", $answer));
			$storeit = '"'.$question.'",'.$dateask.','.$ip.',"'.$answer.'",'.$dateanswer;

			if ($file == "answered.txt") {
				$questions = file(ANSWERED);
				$questions[$quesid] = $storeit;
				doWrite(ANSWERED, implode($questions), "w");
			} elseif ($file == "unanswered.txt") {
				$openquestions = file(UNANSWERED);
				unset($openquestions[$quesid]);
				doWrite(UNANSWERED, implode($openquestions), "w");
				
				$questions = file(ANSWERED);
				$questions[] = "\r\n".$storeit;
				doWrite(ANSWERED, implode($questions), "w");
			}
			
			echo '<p>Question answered. <a href="admin.php">Return to main?</a></p>';
		break;
		case "delete":
			if (!isset($_GET['ques']) || !is_numeric($_GET['ques']))
				exit("Invalid question.");
				
			if (!isset($_GET['file']) && ($_GET['file'] != "answered.txt" || $_GET['file'] != "unanswered.txt"))
				exit("Invalid file");
			
			$questions = file($_GET['file']);
			unset($questions[$_GET['ques']]);
			doWrite($_GET['file'], implode($questions), "w");
			
			echo '<p>Question deleted. <a href="admin.php">Return to main?</a></p>';
		break;
		case "viewall":
			if (!isset($_GET['file']) && ($_GET['file'] != "answered.txt" || $_GET['file'] != "unanswered.txt"))
				exit("Invalid file");
			
			if ($_GET['file'] == "unanswered.txt") {
				echo '<h1>Unanswered Questions</h1>';
				doDisplayQuesAdmin("answer", UNANSWERED, doCount("open"));
			} else {
				echo '<h1>Answered Questions</h1>';
				doDisplayQuesAdmin("edit", ANSWERED, doCount("done"));
			}
		break;
		default:
?>
			<h1>Latest Unanswered Questions</h1>
<?php
			if (doCount("open") > 0) doDisplayQuesAdmin("answer", UNANSWERED, $perpage);
			else echo '<p>No unanswered questions.</p>';
?>
			<p><a href="admin.php?page=viewall&amp;file=unanswered.txt">View all unanswered</a></p>
			
			<h1>Latest Answered Questions</h1>
<?php
			if (doCount("done") > 0) doDisplayQuesAdmin("edit", ANSWERED, $perpage);
			else echo '<p>No answered questions.</p>';
?>
			<p><a href="admin.php?page=viewall&amp;file=answered.txt">View all answered</a></p>
<?php
		break;
		}
		doAdminFooter();
		exit;
	} else {
		exit("<p>Bad cookie. Clear 'em out and start again.</p>");
	}
}

if (isset($_GET['p']) && $_GET['p'] == "login") {
	if ($_POST['name'] != $admin_name || $_POST['pass'] != $admin_pass) {
		doAdminHeader();
?>
			<p>Sorry, that username and password combination is not valid. Try again.</p>

		    <form method="post" action="admin.php">
		    Username:<br>
		    <input type="text" name="name"><br>
		    Password:<br>
		    <input type="password" name="pass"><br>
		    <input type="submit" name="submit" value="Login">
		    </form>
<?php
		doAdminFooter();
		exit;
	} else if ($_POST['name'] == $admin_name && $_POST['pass'] == $admin_pass) {
		setcookie('bellabuzz', md5($_POST['pass'].$secret), time()+(31*86400));
		header("Location: admin.php");
		exit;
	} else {
		setcookie('bellabuzz', NULL, NULL);
		header("Location: admin.php");
		exit;
	}
}
doAdminHeader();
?>
    <form method="post" action="admin.php?p=login">
    Username:<br>
    <input type="text" name="name"><br>
    Password:<br>
    <input type="password" name="pass"><br>
    <input type="submit" name="submit" value="Login">
    </form>
<?php
doAdminFooter();
?>