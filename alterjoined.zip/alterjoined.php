<?php  
 require("rats.inc.php");
 require("inc/fun.inc.php");
 $alter = "ALTER TABLE `$_ST[joined]` ADD `jStatus` TINYINT(1) NOT NULL" . 
 " DEFAULT '0' AFTER `jMade`";
 $true = $scorpions->query($alter);
 if($true == false) {
  exit('<p class="mysqlButton"><span class="mysql">Error:</span> ' . $scorpions->error() . 
  ' <em>' . $alter . '</em></p>');
 } elseif ($true == true) {
  exit('The modification to the joined table was successful! :D'); 
 }
?>
