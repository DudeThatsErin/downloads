<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<title>Icon Sort</title>
<style type="text/css">
body { background-color: #ffffff; }
body, select, option { color: #000000; font: 11px tahoma; }
a { color: #666666; text-decoration: none; }
a:hover { color: #333333; }
ul { list-style-type: square; list-style-position: inside; padding: 0px; margin-left: 0px; }
h1 { font-size: 12px; letter-spacing: 1px;}
.credit { font-size: 10px; }
</style>
</head>
<body>
<h1>My Icons</h1>
<!-- Edit the header above or replace it with your own. -->

<?php
/*

ICON SORT
------------------------------------------------
A Quick and Easy PHP Icon Management Script by Julie (http://new-place.org/)

This script is free for non-commercial use and may be modified for personal use.  Please do not distribute modified copies of this script without my permission.  You may not sell this script or modified versions of it under any circumstances.

As provided, this script is valid XHTML 1.0 transitional.  The only requirement is PHP support (no database needed)!


UPDATES
------------------------------------------------
February 7, 2005 - Fixed the pagination to work with register_globals off.  Added file setup example to the instructions and tidied up the code in general.

September 2, 2005 - Two new features added!  It is now possible to display the icon count per category on the menu, and/or to paginate the individual category pages.  There are three new config variables.


SETUP INSTRUCTIONS
------------------------------------------------
Icon Sort can be installed in a new directory created specifically for this script, or you can put it in an existing directory that holds other files.  You can safely rename this file to whatever you'd like it to be called!

1.) Create a folder named "categories" in the same directory where this file will go.  If you don't want to call it "categories," edit the $catdir config variable (below the instructions) to the name you choose.

2.) Inside the "categories" folder, create a folder for each category of icons you want.  If there are spaces in the category name, replace them with underscores.  For example, instead of "Veronica Mars" use "Veronica_Mars."  (Replacing spaces with underscores is optional, but recommended, as it creates cleaner, more compatible links.  The underscores will not show up on the page.)  Upload your icons into their respective category folders.

   An example of the setup:
   yoursite.com/icons.php  <- this file
   yoursite.com/categories/  <- the categories folder
   yoursite.com/categories/Veronica_Mars  <- the individual category folders go inside that folder

3.) If desired, change the "sort" config variable (below the instructions) from 'first' to 'last' if you prefer new icons to be added to the bottom of the page.  By default, the newest icons added to a category are shown first on the category page. 

4.) Edit the "getcount," "perpage," and "divider" variables as desired.  None of them has to be changed for the script to work, but they allow you to customize the setup.

5.)  Edit or replace the header and footer at the top and bottom of this file to fit your site.  Edit or remove the paragraph above the menu (scroll down and find "<!-- Content Above Menu -->").  Upload this file.  That's it!


CUSTOMIZATION AND SUPPORT
------------------------------------------------
There are a few built in CSS styles to help you style your page.  The menu <ul> is id="iconmenu", the category page menu <p> is class="pagemenu", the <p> that holds the icons is class="icons", and the <p> that holds the credit to my site is class="credit".

If you are having a problem, send in a contact form at my site (http://new-place.org/) or post at the CodeGrrl forums (http://codegrrl.com/) and I will try to help.
 

CONFIG VARIABLES
------------------------------------------------*/
$catdir = 'categories';  // the icon categories folder (see step 1)
$sort = 'first';         // set 'first' to show newest icons first, 'last' to show newest icons last
$getcount = true;        // true shows the icon count per category in the menu, and false turns it off
$perpage = 20;          // the number of icons shown on each page (set to a really high number to turn off pagination)
$divider = '&nbsp;';     // the divider between the numbers and front/back arrows in the page navigation


// DO NOT EDIT THE PHP BELOW THIS LINE.  Scroll down to edit the text above the menu, and to add your footer.
// ----------------------------------------------

// get category folders and sort
if (!file_exists($catdir)) {
	echo 'Error!  The folder named <strong>' . $catdir . '</strong>, as specified in the config, does not exist in this directory.  The value of the variable $catdir must match the name of the created folder (case-sensitive), and that folder must be in this directory for the script to work.  Create the folder and put the individual icon category folders inside it.';
	exit();
}
$getfolders = opendir($catdir);
while (($file = readdir($getfolders)) !== false) {
	if (($file != '.' && $file != '..') && (is_dir($catdir.'/'.$file))) {
		$cats[] = $file;
	}
}
if (!$cats) {
   echo 'No category folders were found inside the folder named <strong>' . $catdir . '</strong>.  Create your individual category folders inside that folder and the menu will appear.';
	exit();
}
natcasesort($cats);

// build main menu
if ((!$_GET['cat']) || (!in_array($_GET['cat'], $cats))) {
	?>

	<!-- Content Above Menu -->
	<p>If you'd like any content on your main icon page, above the menu, such as usage rules, resource credits, etc., place it here.  It will only show up if a category is not selected.  If you don't want anything here, delete this paragraph!  To add content that will show up at the top or bottom of every page, put it in the header or footer.  To wrap the script in a div, place the opening tag in the header and the closing tag in the footer.</p>
	<!-- End Content Above Menu -->

	<?php
	echo '<ul id="iconmenu">';
	foreach ($cats as $value) {
		$catname = str_replace('_', ' ', $value);
      echo '<li><a href="' . $_SERVER['PHP_SELF'] . '?cat=' . $value . '">' . $catname . '</a>';
      if ($getcount) {
         $icons = array();
			$getcount = opendir($catdir . '/' . $value);
			while (($icon = readdir($getcount)) !== false) {
				if (eregi(".jpg$|.jpeg$|.gif$|.png$|.bmp$", $icon)) {
					$icons[] = $value;
				}
			}
			$count = count($icons);
         if ($count == 1) {
				echo ' (' . $count . ' icon)';
			} else {
				echo ' (' . $count . ' icons)';
			}
      }
      echo '</li>';
	}
	echo '</ul>';
}

// get icons and sort
if (in_array($_GET['cat'], $cats)) {
	$icons = array();
	$geticons = opendir($catdir.'/'.$_GET['cat']);
	while (($icon = readdir($geticons)) !== false) {
		if (eregi(".jpg$|.jpeg$|.gif$|.png$|.bmp$", $icon)) {
			$icons[] = array("name" => $icon, "modified" => filemtime($catdir . '/' . $_GET['cat'] . '/' . $icon));
		}
	}
	$count = count($icons);
	if ($count > 0) {
		function modcmp($a, $b) {
			return strcmp($a['modified'], $b['modified']);
		}
		usort($icons, 'modcmp');
		if ($sort == 'first') {
			$icons = array_reverse($icons);
		}

      // show category name and total icon count
		$catname = str_replace('_', ' ', $_GET['cat']);
      echo '<p><strong>' . $catname . ': ' . $count;
		if ($count == 1) {
			echo ' icon';
		} else {
         echo ' icons';
		}
		echo '</strong></p>';

      // configure pagination
		if ((!$perpage) || ($perpage < 1) || (!is_numeric($perpage))) {
			$perpage = 20;
		}
		$pagecalc = ($count / $perpage);
		$pagecount = ceil($pagecalc);
      $page = $_GET['page'];
		if (($page > $pagecount) || ($page == '0')) {
			$start = 0;
		} elseif (!$page) {
			$start = 0;
			$page = 1;
		} elseif (!is_numeric($page)) {
			$start = 0;
			$page = 1;
		} else {
			$start = (($page * $perpage) - $perpage);
		}
		$pagearray = array_slice($icons, $start, $perpage);

		// if there is more than one page, show the page menu
		if ($pagecount > 1) {
			if (($page <= $pagecount) && ($page > 1)) {
				$backpagecalc = ($page - 1);
            $backpage = '<a href="?cat=' . $_GET['cat'] . '&amp;page=' . $backpagecalc . '">&laquo;</a> ' . $divider;
			}
			if ($page < $pagecount) {
				$nextpagecalc = ($page + 1);
				$nextpage = $divider . ' <a href="?cat=' . $_GET['cat'] . '&amp;page=' . $nextpagecalc . '">&raquo;</a>';
			}
			echo '<p class="pagemenu">Pages: &nbsp;' . $backpage . ' ';
			$i = 1;
			while ($i <= $pagecount) {
            $pagespanstart = ((($i * $perpage) - $perpage) + 1);
            $pagespanend = ($i * $perpage);
            if ($i == $pagecount) {
               if ( $i == $page) {
                  echo $i;
               } else {
                  echo '<a href="?cat=' . $_GET['cat'] . '&amp;page=' . $i . '">' . $i . '</a>';
               }
            } else {
               if ($i == $page) {
                  echo $i . ' ' . $divider . ' ';
               } else {
                  echo '<a href="?cat=' . $_GET['cat'] . '&amp;page=' . $i . '">' . $i . '</a> ' . $divider . ' ';
               }
            }
            $i++;
			}			
			echo ' ' . $nextpage . '</p>';
		}
		
		// show the icons
		echo '<p class="icons">';
			foreach ($pagearray as $value) {
				$iconsize = getimagesize($catdir . '/' . $_GET['cat'] . '/' . $value['name']);
				echo '<img src="' . $catdir . '/' . $_GET['cat'] . '/' . $value['name'] . '" ' . $iconsize[3] . ' alt="" /> ';
			}
	} else {
		echo '<p>There are no icons in this category.';
	}
	echo '</p><p>&laquo; <a href="' . $_SERVER['PHP_SELF'] . '">back</a></p>';
}
?>

<!-- You may remove this credit for stylistic purposes, but a link back on your credits page or elsewhere is appreciated. -->
<p class="credit">Powered by <a href="http://new-place.org/scripts/" target="_blank">Icon Sort</a></p>

<!-- Edit the footer below above or replace it with your own. -->
</body>
</html>