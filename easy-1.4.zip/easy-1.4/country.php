<?php
$countrySettings = array();
$countrySettings['en-us']['GEO_COUNTRY_TLD'] ='com';$countrySettings['en-us']['GEO_PLACEMENT_ID'] ='711-53200-19255-0';$countrySettings['en-us']['GEO_SITE_ID'] ='0';$countrySettings['en-us']['GEO_LANGUAGE'] ='en-US';
$countrySettings['en-us']['bin'] = "Buy It Now";
$countrySettings['en-us']['currentbid'] = "Current Bid";
$countrySettings['en-us']['bids'] = "Bids";
$countrySettings['en-us']['ends'] = "Ends";
$countrySettings['en-gb']['GEO_COUNTRY_TLD'] ='co.uk';$countrySettings['en-gb']['GEO_PLACEMENT_ID'] ='710-53481-19255-0';$countrySettings['en-gb']['GEO_SITE_ID'] ='3';$countrySettings['en-gb']['GEO_LANGUAGE'] ='en-GB';
$countrySettings['en-gb']['bin'] = "Buy It Now";
$countrySettings['en-gb']['currentbid'] = "Current Bid";
$countrySettings['en-gb']['bids'] = "Bids";
$countrySettings['en-gb']['ends'] = "Ends";

$countrySettings['en-au']['GEO_COUNTRY_TLD'] ='au';
$countrySettings['en-au']['GEO_PLACEMENT_ID'] ='705-53470-19255';
$countrySettings['en-au']['GEO_SITE_ID'] ='15';
$countrySettings['en-au']['GEO_LANGUAGE'] ='en-AU';
$countrySettings['en-au']['bin'] = "Buy It Now";
$countrySettings['en-au']['currentbid'] = "Current Bid";
$countrySettings['en-au']['bids'] = "Bids";
$countrySettings['en-au']['ends'] = "Ends";

$countrySettings['be-fr']['GEO_COUNTRY_TLD'] = 'be';
$countrySettings['be-fr']['GEO_PLACEMENT_ID'] = '1553-53471-19255-0';
$countrySettings['be-fr']['GEO_SITE_ID'] = '71';
$countrySettings['be-fr']['GEO_LANGUAGE'] ='fr-FR';
$countrySettings['be-fr']['bin'] = "Achat immédiat";
$countrySettings['be-fr']['currentbid'] = "Enchère Actuelle";
$countrySettings['be-fr']['bids'] = "Enchères";
$countrySettings['be-fr']['ends'] = "Fin";

$countrySettings['fr-fr']['GEO_COUNTRY_TLD'] = 'fr';
$countrySettings['fr-fr']['GEO_PLACEMENT_ID'] = '709-53476-19255-0';
$countrySettings['fr-fr']['GEO_SITE_ID'] = '71';
$countrySettings['fr-fr']['GEO_LANGUAGE'] ='fr-FR';
$countrySettings['fr-fr']['bin'] = "Achat immédiat";
$countrySettings['fr-fr']['currentbid'] = "Enchère Actuelle";
$countrySettings['fr-fr']['bids'] = "Enchères";
$countrySettings['fr-fr']['ends'] = "Fin";

$countrySettings['en-ca']['GEO_COUNTRY_TLD'] = 'ca';
$countrySettings['en-ca']['GEO_PLACEMENT_ID'] = '706-53473-19255-0';
$countrySettings['en-ca']['GEO_SITE_ID'] = '2';
$countrySettings['en-ca']['GEO_LANGUAGE'] ='en-CA';
$countrySettings['en-ca']['bin'] = "Buy It Now";
$countrySettings['en-ca']['currentbid'] = "Current Bid";
$countrySettings['en-ca']['bids'] = "Bids";
$countrySettings['en-ca']['ends'] = "Ends";


$countrySettings['es-es']['GEO_COUNTRY_TLD'] = 'es';
$countrySettings['es-es']['GEO_PLACEMENT_ID'] = '1185-53479-19255-0';
$countrySettings['es-es']['GEO_SITE_ID'] = '186';
$countrySettings['es-es']['GEO_LANGUAGE'] = 'es-ES';
$countrySettings['es-es']['bin'] = "¡Cómpralo ya!";
$countrySettings['es-es']['currentbid'] = "Oferta actual";
$countrySettings['es-es']['bids'] = "Puja";
$countrySettings['es-es']['ends'] = "Fecha de finalización";

$countrySettings['zh-hk']['GEO_COUNTRY_TLD'] = 'com.hk';
$countrySettings['zh-hk']['GEO_PLACEMENT_ID'] = '3422-53475-19255-0';
$countrySettings['zh-hk']['GEO_SITE_ID'] = '216'; // couldn't find proper id =  set to Singapore$countrySettings['zh-hk']['GEO_LANGUAGE'] ='zh-HK';
$countrySettings['zh-hk']['bin'] = "Buy It Now";
$countrySettings['zh-hk']['currentbid'] = "Current Bid";
$countrySettings['zh-hk']['bids'] = "Bids";
$countrySettings['zh-hk']['ends'] = "Ends";

$countrySettings['en-in']['GEO_COUNTRY_TLD'] = 'in';
$countrySettings['en-in']['GEO_PLACEMENT_ID'] = '4686-53472-19255-0';
$countrySettings['en-in']['GEO_SITE_ID'] = '203';
$countrySettings['en-in']['GEO_LANGUAGE'] ='en-IN';
$countrySettings['en-in']['bin'] = "Buy It Now";
$countrySettings['en-in']['currentbid'] = "Current Bid";
$countrySettings['en-in']['bids'] = "Bids";
$countrySettings['en-in']['ends'] = "Ends";

$countrySettings['it-it']['GEO_COUNTRY_TLD'] = 'it';
$countrySettings['it-it']['GEO_PLACEMENT_ID'] = '724-53478-19255-0';
$countrySettings['it-it']['GEO_SITE_ID'] = '101';
$countrySettings['it-it']['GEO_LANGUAGE'] ='it-IT';
$countrySettings['it-it']['bin'] = "Compralo Subito";
$countrySettings['it-it']['currentbid'] = "Offerta corrente";
$countrySettings['it-it']['bids'] = "Offerte";
$countrySettings['it-it']['ends'] = "Data di scadenza";

$countrySettings['nl-nl']['GEO_COUNTRY_TLD'] = 'nl';
$countrySettings['nl-nl']['GEO_PLACEMENT_ID'] = '1346-53482-19255-0';
$countrySettings['nl-nl']['GEO_SITE_ID'] = '146';
$countrySettings['nl-nl']['GEO_LANGUAGE'] ='nl-NL';
$countrySettings['nl-nl']['bin'] = "Nu kopen";
$countrySettings['nl-nl']['currentbid'] = "Huidig bod";
$countrySettings['nl-nl']['bids'] = "Biedingen";
$countrySettings['nl-nl']['ends'] = "Einddatum";

$countrySettings['zh-sg']['GEO_COUNTRY_TLD'] = 'com.sg';
$countrySettings['zh-sg']['GEO_PLACEMENT_ID'] = '3423-53474-19255-0';
$countrySettings['zh-sg']['GEO_SITE_ID'] = '216';
$countrySettings['zh-sg']['GEO_LANGUAGE'] = 'zh-sg';
$countrySettings['zh-sg']['bin'] = "Buy It Now";
$countrySettings['zh-sg']['currentbid'] = "Current Bid";
$countrySettings['zh-sg']['bids'] = "Bids";
$countrySettings['zh-sg']['ends'] = "Ends";

?>
