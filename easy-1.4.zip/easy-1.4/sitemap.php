<?php
//sitemap.php by ChuckMcB


// Define ROOT_DIR
if (!defined('ROOT_DIR')) define('ROOT_DIR', realpath(dirname(__FILE__)).'/');

//Prep xml output
header("Content-Type: text/xml;charset=iso-8859-1"); 
echo '<?xml version="1.0" encoding="UTF-8"?>
  <urlset xmlns="http://www.google.com/schemas/sitemap/0.84">';

// Prep the date
$displaydate = date('Y-m-d');

// load default config
require_once ROOT_DIR.'sites/default.php';
// Check for custom config
findSite($_SERVER['HTTP_HOST']);

// Once loaded split into array
$keywordArray = split(',',$site['mainkeywords']);
$keyword = $keywordArray[0];

//
while (list($key, $val) = each($keywordArray))
{
echo
'
   <url>
    <loc>http://' .$_SERVER['HTTP_HOST']. '/buy/' .urlencode($val). '</loc>
    <lastmod>'.$displaydate.'</lastmod>
    <changefreq>hourly</changefreq>
    <priority>0.5</priority>
   </url>
';
}

//close the XML attribute
echo
'</urlset>';


function findSite($domain) {
global $site;
if ($domain=="") {
return;
}

$a = split("\.",$domain);
if (count($a)>1) {
for ($i=count($a);$i>0; $i--) {
$newdomainA = array_slice($a, $i-1, count($a));
$newdomain = implode(".",$newdomainA);
if (file_exists(ROOT_DIR.'sites/'.$newdomain.'.php')) {
require_once ROOT_DIR.'sites/'.$newdomain.'.php';
}
}
}
}

?>
