McJiffy EASy 

McJiffy EASy automatically creates a storefront based upon
the eBay affiliate program. 

----------------------------------------------------------
INSTALLATION
----------------------------------------------------------

Place the EASy files into your website directory. In the 
same directory as the EASy files, create a directory called
cache and make it writable to the webserver.
	
	chmod 777 cache
	
You will now need to edit the default configuration file in 
the sites directory: sites/default.php You will need to add
your Ebay Developer Production Key and Ebay Affiliate Program
Campaign Id in the appropriate locations.

You can sign up for your Ebay Developers Production Key at
http://developer.ebay.com/

You can sign up for the Ebay Affiliate Program at
https://www.ebaypartnernetwork.com/

Full documentation on McJiffy EASy is available at
http://www.mcjiffy.com
