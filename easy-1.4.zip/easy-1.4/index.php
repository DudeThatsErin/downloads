<?php
// McJiffy EASy 1.4
// http://www.mcjiffy.com

$version = "1.4";

if (!defined('ROOT_DIR')) define('ROOT_DIR', realpath(dirname(__FILE__)).'/');
// load country settings
require_once 'country.php';

// load default config
require_once ROOT_DIR.'sites/default.php';

// load site specific config
findSite($_SERVER['HTTP_HOST']);
define('THEME_DIR',ROOT_DIR.'themes/'.$site['theme']);
define('AFFILID',$site['account']);

// get the base url from the current request
$baseUrl = str_replace("index.php","",$_SERVER['PHP_SELF']);
$themeUrl = $baseUrl."themes/";
$mainkeywords = split(',',$site['mainkeywords']);

$country = array();
if (empty($site['country'])) {
	$country = findCountry($_SERVER['HTTP_ACCEPT_LANGUAGE']);
}
else {
	$country = $countrySettings[strtolower($site['country'])];
}

define('GEO_COUNTRY_TLD',$country['GEO_COUNTRY_TLD']);
define('GEO_PLACEMENT_ID',$country['GEO_PLACEMENT_ID']);
define('GEO_SITE_ID',$country['GEO_SITE_ID']);
define('GEO_LANGUAGE',$country['GEO_LANGUAGE']);

// define cache lifetimes in seconds
if (empty($site["CACHE_KEYWORD_TIME"])) {
	$site["CACHE_KEYWORD_TIME"] = 604800; // 7 days in seconds
}
if (empty($site["CACHE_ITEMS_TIME"])) {
	$site["CACHE_ITEMS_TIME"] = 300; // 5 minutes in seconds
}
if (empty($site["CACHE_GUIDES_TIME"])) {
	$site["CACHE_GUIDES_TIME"] = 604800; // 7 days in seconds
}

if (array_key_exists("action",$_GET)) {
	$action = $_GET["action"]; 
}
else {
	$action = "buy";
}

// set url for this request
$url = "http://".$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];

$q = "";
$keyword =  "";
if (!empty($_GET["q"])) {
	$q = $_GET["q"];
	$q = str_replace('-',' ',$q);
	$keyword = $q;

}
else {
	$keywordArray = split(',',$site['mainkeywords']);
	$keyword = $keywordArray[0];
	$q= $keyword;
}

if ($action=="go") {
	$link = $_GET['link'];
	goLink($link, $keyword);
	exit();
}
if ($action=="guide") {
	$link = $_GET['link'];
	guideLink($link, $keyword);
	exit();
}

$page = 1;
if (!empty($_GET["page"])) {
	$page = $_GET["page"];
}

$pageSize = 21;
if (!empty($site['pagesize'])) {
	$pageSize = $site['pagesize'];
}

// look for text file for this keyword
if (empty($site["textdirectory"])) {
	$site["textdirectory"] = "text";
}
if (file_exists(ROOT_DIR.$site["textdirectory"].'/'.urlencode($q).'.txt')) {
	$keywordtext = file_get_contents(ROOT_DIR.$site["textdirectory"].'/'.urlencode($q).'.txt');
}
else {
	$keywordtext = null;
}

$keywordsXML = getEbayKeywords($q);

foreach($keywordsXML->PopularSearchResult as $item) {
	$topicsString = $item->AlternativeSearches;
   $relatedString = $item->RelatedSearches;
   if (!empty($topicsString)) {
		$topics =  split(";",$topicsString);
	}
	if (!empty($relatedString)) {
		$related = split(";",$relatedString);
	}

}

$node = array();
$node['keywords'] = $q;

// set sort by
if (!empty($site["sortby"])) {
	$node['sortby'] = $site["sortby"];
}

// set ebay category
if (!empty($site["ebaycat"])) {
	$node['ebaycat'] = $site["ebaycat"];
}

// set min price
if (!empty($site["minprice"])) {
	$node['minprice'] = $site["minprice"];
}

// set max price
if (!empty($site["maxprice"])) {
	$node['maxprice'] = $site["maxprice"];
}

// set auction type
if (!empty($site["auctiontype"])) {
	$node['auctiontype'] = $site["auctiontype"];
}
else {
	// default to all
	$node['auctiontype'] = 0;
}

$xml = ebay_rss($node);

$ebayItems = array();
$totalItems = count($xml->channel->item);

$totalPages = $totalItems / $pageSize;


$i = 0;
foreach  ($xml->channel->item as $item) {
	$ebayRss = $item->children('urn:ebay:apis:eBLBaseComponents');

	if ($i>=($pageSize*($page-1)) && $i<($pageSize*$page)) {
		$newItem = array();
		$newItem['title'] = $item->title;
		$newItem['link'] = buyLink($item->link, $q);
		$newItem['image'] = ebay_stripImage($item->description);
		$newItem['currentbid'] = ebay_convertPrice($item->description);
		$newItem['bidcount'] = $ebayRss->BidCount;
		$newItem['endtime'] = ebay_convertTime($ebayRss->EndTime);
		$newItem['type'] = $ebayRss->AuctionType;
		if (!empty($ebayRss->BuyItNowPrice)) {
			$newItem['bin'] = ebay_convertPrice($item->description);
		}
		array_push($ebayItems, $newItem);
	}
	$i++;
}


$pageNumbers = array();
for ($i=1; $i<=$totalPages; $i++) {
	array_push($pageNumbers, $i);
}


// get user guides
$guidesXML = getEbayGuides($q);
$guides = array();
foreach ($guidesXML->guide as $guideXML) {
	$guide = array();
	$guide['url'] = makeguideLink($guideXML->url, $q);
	$guide['title'] = $guideXML->title;
	$guide['desc'] = $guideXML->desc;
	array_push($guides,$guide);
}


$impressionPixel = makeImpressionPixelImg($keyword);

// write html output
include('themes/'.$site['theme'].'/index.php');



// END PAGE LOAD LOGIC
// The following are helper functions


function findSite($domain) {
	global $site;
	if ($domain=="") {
		return;
	}
	$a = split("\.",$domain);
	if (count($a)>0) {
		for ($i=count($a);$i>0; $i--) {
			$newdomainA = array_slice($a, $i-1, count($a));
			$newdomain = implode(".",$newdomainA);
			if (file_exists(ROOT_DIR.'sites/'.$newdomain.'.php')) {
				require_once ROOT_DIR.'sites/'.$newdomain.'.php';
			}
		}
	}
}


function writeNewFile($filename, $numberSeconds) {

	if (file_exists($filename)) {
		if (time()- filemtime($filename) > $numberSeconds)
			return true;
		else
			return false;

	}
	else  {
		return true;
	}


}


function saveUrl($dir, $url, $file, $age, $out=null) {

	// allow passing of content directly to the file writing code, bypassing the url grabbing
	if ($out==null) {

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_HEADER, false);
		$out = curl_exec ($ch);
		curl_close ($ch);
	}

		// Let's check the file perms before trying to write to the folder.
		if (fileperms(ROOT_DIR.'cache/') != '16895') {
			echo "<center><font size='28' color='red'>ERROR!</font><br>Cache folder not writeable<br>Make sure " .ROOT_DIR . "cache/ has writeable permissions (777)</center>";
			exit;
		}

		// create the cache directory if needed.
		if (!is_dir($dir)) {
			mkdir($dir,0777, true);
		}

		// make sure we can write to the cache file
		if (!$handle = fopen($file, 'w+')) {
			 echo "<center><font size='28' color='red'>ERROR!</font><br>Cannot save file: $file.<br>Make sure " .ROOT_DIR . "cache/ has writeable permissions (777)</center>";
			 exit;
		}

		// write the cache file
	   if (!fwrite($handle, $out)) {
			echo "<center><h2><font color='red'>ERROR: Cannot write to file ($query)<br>Make sure " .ROOT_DIR . "cache/ has writeable permissions (777)</font></h2></center>";
			exit;
		}

		fclose($handle);


	// delete old files from this directory
	if ($dh = opendir($dir)) {
		$deleteTime = time() - $age;
		while (($oldfile = readdir($dh)) !== false) {
			if (is_file($dir . $oldfile) && (filectime($dir . $oldfile)<$deleteTime)) {
				unlink($dir.$oldfile);			   
			}
		}
		closedir($dh);
	}
}

function getEbayGuides($query) {
	global $site;

	$dir = ROOT_DIR.'cache/guides/';
	$xmlFile = $dir.urlencode($query).'.xml';

	if (writeNewfile($xmlFile, $site["CACHE_GUIDES_TIME"])) {

		$SafeQuery = urlencode($query); // Make the query URL-friendly

		$url = "http://search.reviews.ebay.com/ws/UCSearch?satitle=$query&ucc=g&fts=2&ugat=2&ufm=1";

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_HEADER, false);
		$str = curl_exec ($ch);
		curl_close ($ch);


		$pattern = '/<li class="catalog"><a href="(.*?)">(.*?)<\/a>.*<li class="desc">(.*)/';

		$xml = "<guides>";
		if (preg_match_all($pattern, $str, $matches)>0) {
			array_shift($matches);
			for ($i=0;$i<count($matches[0]);$i++) {
				$xml .= "<guide>";	
				$xml .= "<url><![CDATA[". $matches[0][$i]."]]></url>";
				$xml .= "<title><![CDATA[". $matches[1][$i]."]]></title>";
				$xml .= "<desc><![CDATA[". $matches[2][$i]."]]></desc>";
				$xml .= "</guide>";
			}
		}
		$xml .= "</guides>";

		saveUrl($dir, $url, $xmlFile, $site["CACHE_GUIDES_TIME"],$xml);

	}

	$resp = simplexml_load_file($xmlFile);
	return $resp;
	
}


function getEbayKeywords($query, $cat=-1) {
	global $AppId, $site;

	$dir = ROOT_DIR.'cache/keywords/';
	$xmlFile = $dir.urlencode($query);
	if (!empty($site['ebaycat'])) {
        	$xmlFile .= '-'.$site['ebaycat'];
        }
	$xmlFile .= '.xml';

	// cache the keywords file for 7 days since they won't change much
	if (writeNewfile($xmlFile, $site["CACHE_KEYWORD_TIME"])) {

		$SafeQuery = urlencode($query); // Make the query URL-friendly

		$endpoint = 'http://open.api.ebay.com/shopping';  // URL to call
		$responseEncoding = 'XML';                                       // Type of response we want back
		$apicall = "$endpoint?callname=FindPopularSearches&version=571&appid=$AppId&QueryKeywords=$SafeQuery&responseencoding=$responseEncoding";

		if (!empty($site['ebaycat'])) {
                        $apicall .= '&CategoryID='.$site['ebaycat'];
                }


		saveUrl($dir, $apicall, $xmlFile, $site["CACHE_KEYWORD_TIME"]);


	}

	$resp = simplexml_load_file($xmlFile);

	return $resp;
}



function ebay_convertTime($str) {

	$endtime = $str;
	$endtime = substr($endtime, 0, 10);
	$endtime = date("M d, h:i a", $endtime);

	return $endtime;

}
function ebay_convertPrice($str) {
	$pattern = "/<strong>(.*?)>/";

	if (preg_match($pattern, $str, $matches)>0) {
		return $matches[0];
	}
	else {
		return null;
	}

}

function ebay_stripImage($str) {

	$pattern = "/<img(.*?)>/";

	if (preg_match($pattern, $str, $matches)>0) {
		return $matches[0];
	}
	else {
		return null;
	}

}


function buylink($url, $keyword) {
	global $baseUrl;
	return $baseUrl ."go/".urlencode($keyword)."/".base64_encode($url);
}

function makeguidelink($url, $keyword) {
	global $baseUrl;
	$i = strpos($url,"http://reviews.ebay.com/")+strlen("http://reviews.ebay.com/");
	$url = substr($url, $i, strlen($url));
	return $baseUrl ."guide/".urlencode($keyword)."/".$url;
}


function ebay_rss($node) {
	global $site;

	$dir = ROOT_DIR.'cache/'.AFFILID.'/';
	$xmlFile = $dir.urlencode($node['keywords']).'-'.GEO_SITE_ID;
	if (!empty($site['ebaycat'])) {
        	$xmlFile .= '-'.$site['ebaycat'];
        }
	$xmlFile .= '.xml';

	// cache the rss long enough for someone to page through the results
	if (writeNewfile($xmlFile, $site["CACHE_ITEMS_TIME"])) {

		$url = 'http://rss.api.ebay.com/ws/rssapi?FeedName=SearchResults&siteId='.GEO_SITE_ID.'&language='.GEO_LANGUAGE.'&output=RSS20&sacur=0&from=R6&sacqyop=ge&saslc=0&floc=1&saprclo=&saprchi=&fcl=3&nojspr=y&afmp=&saslop=1&fss=0&';
		$url .= 'saobfmts=insif&sacqy=&';

		if (!empty($node['keywords'])) {
			$url .= 'satitle='.urlencode($node['keywords']).'&';
		}
		if (!empty($node['ebaycat'])) {
			$url .= 'catref=C5&sacat='.$node['ebaycat'].'&';
		}
		if (!empty($node['searchfields'])) {
			$url .= 'fts=' . $node['searchfields'] .'&';
		}

		if (!empty($node['minprice']) && $node['minprice']>0) {
			$url .= 'saprclo='.$node['minprice'].'&';
		}

		if (!empty($node['maxprice']) && $node['maxprice']>0) {
			$url .= 'saprchi='.$node['maxprice'].'&';
		}

		$url .= '&sascs=' . $node['auctiontype'] .'&';
		$url .= 'fsop=' . $node['sortby'] . '&';


		$url .= 'saaff=afepn&customid=&afepn='.AFFILID.'&';


		saveUrl($dir, $url, $xmlFile, $site["CACHE_ITEMS_TIME"]);


	}

	$rss =  simplexml_load_file($xmlFile);
	if ($rss) {
		return $rss;
	}
	else {
		echo "error loading ebay items";
	}



	return null;
}


function goLink($str, $keyword) {
	header('Location: ' . base64_decode($str));
	exit();
}

function guideLink($str, $keyword) {
	$url = 'http://rover.ebay.com/rover/1/' .GEO_PLACEMENT_ID. '/1?type=4&campid='. AFFILID. '&customid=' . urlencode($keyword) . '&toolid=10001&mpre=http%3A%2F%2Freviews.ebay.com%2F'.urlencode($str);
	header('Location: ' . $url);
	exit();
}

function makeImpressionPixelImg($keyword) {

	$out = "<img style='text-decoration:none; border: 0; padding: 0; margin: 0;' src='http://rover.ebay.com/ar/1/";
	$out .= GEO_PLACEMENT_ID."/1?mpt=" . rand(0, 1000)."&adtype=1&size=1x1&type=3&campid=". AFFILID. "&toolid=10005&";
	$out .= "customid=".urlencode($keyword)."&ext=".urlencode($keyword)."&satitle=".urlencode($keyword)."'/>";

 	return $out;
}


function findCountry($lang) {
	global $countrySettings;
	$pattern = "/[a-zA-Z]{2}-[a-zA-Z]{2}/";


	preg_match_all($pattern, $lang, $matches);
	$langs = $matches[count($matches)-1];
	
	foreach ($langs as $l) {
		if (array_key_exists(strtolower($l), $countrySettings)) {
			return $countrySettings[strtolower($l)];
		}
	}

	return $countrySettings['en-us'];

}


?>
