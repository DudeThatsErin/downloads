<?php

// Ebay Developer Production Key
$AppId = 'your app id';

// Ebay Affiliate program Campaign Id
$site['account'] = 'your campaign id';


$site['title'] = 'EASy';
$site['theme'] = 'default';
$site['slogan'] = 'Simple, quick and easy ... oh, and you can buy stuff too';
$site['pagesize'] = 21;
$site['mainkeywords'] = 'wii,gameboy,ps3,sega,xbox 360';

//$site['ebaycat'] = 617; // ebay category number
//$site['auctiontype'] = 2; // ebay auction type, 0=auction & buy it now, 1=auction only, 2=buy it now only
//$site['minprice'] = 10; // minimum price of ebay items
//$site['maxprice'] = 50; // maximum price of ebay items

// sort by
// 1&fsoo=1     = Time: ending soonest
// 2&fsoo=2     = Time: newly listed
// 34&fsoo=1    = Price + Shipping: lowest first
// 34&fsoo=2    = Price + Shipping: highest first
// 32&fsoo=2    = Best Match
$site['sortby'] = "1&fsoo=1";

// cache lifetime of keyword lookup
$site["CACHE_KEYWORD_TIME"] = 604800; // 7 days in seconds

// cache lifetime of ebay items
$site["CACHE_ITEMS_TIME"] = 300; // 5 minutes in seconds

// cache lifetime of buyer guide links
$site["CACHE_GUIDES_TIME"] = 604800; // 7 days in seconds

// force using a specific country
// comment out this setting if you want the country to automatically be detected
// available countries, en-us, en-au, en-ca, en-gb, en-it, fr-fr, be-fr, nl-nl, zh-sg, zh-hk, it-it, es-es
//$site["country"] = "en-us";

$site["textdirectory"] = "text";

?>
