

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en">



<!--  Version: Multiflex-3 Update-2 / Overview             -->

<!--  Date:    November 29, 2006                           -->

<!--  Author:  G. Wolfgang                                 -->

<!--  License: Fully open source without restrictions.     -->

<!--           Please keep footer credits with a link to   -->

<!--           G. Wolfgang (www.1-2-3-4.info). Thank you!  -->



<head>

  <meta http-equiv="content-type" content="text/html; charset=utf-8" />

  <meta name="robots" content="index,follow" />

  <meta name="description" content="Buy <?php echo $keyword; ?> items and find other similar products" />

  <meta name="keywords" content="<?php echo $keyword; ?>" />

  <link rel="stylesheet" type="text/css" media="screen,projection,print" href="<?php echo $themeUrl . $site['theme'] ?>/css/layout2_setup.css" />

  <link rel="icon" type="image/x-icon" href="<?php echo $themeUrl . $site['theme'] ?>/img/favicon.ico" />

  <title><?php 
	echo $keyword;
	
		if ($page>1) {
	 
			echo " page $page";
		}
	
		echo " | " . $site['title'];
	
		?>
</title>

</head>



<!-- Global IE fix to avoid layout crash when single word size wider than column width -->

<!--[if IE]><style type="text/css"> body {word-wrap: break-word;}</style><![endif]-->



<body>

  <!-- Main Page Container -->

  <div class="page-container">



    <!-- A. HEADER -->      

        <div class="header">

          

          <!-- A.1 HEADER MIDDLE -->

          <div class="header-middle">    

       

            <!-- Sitelogo and sitename -->

            <a class="sitelogo" href="<?php echo $baseUrl ?>" title="<?php echo $site['title'] ?>"></a>

            <div class="sitename">

              <h2><a href="<?php echo $baseUrl ?>" title="<?php echo $site['title'] ?>"><?php echo $site['title'] ?></a></h2>

            </div>

            

            

            <div class="sitemessage">

	              <h2><?php echo $site['slogan'] ?></h2>

	        </div>     

                    

          </div>

          

          <!-- A.2 HEADER BOTTOM -->

          <div class="header-bottom">

          

            <!-- Navigation Level 2 (Drop-down menus) -->

            <div class="nav2">

    	

              <!-- Navigation item -->

              <ul>

                <li><a href="<?php echo $baseUrl ?>">Home</a></li>

              </ul>

              

              <!-- Navigation item -->

              <?php foreach ($mainkeywords as $mainkey) {?>

	      <ul>

	          <li><a href="<?php echo $baseUrl ?>buy/<?php echo urlencode($mainkey); ?>"><?php echo $mainkey; ?></a></li>              

	      </ul>


		<?php } ?>

                 

            </div>

    	  </div>

    

          <!-- A.3 HEADER BREADCRUMBS -->

    

          <!-- Breadcrumbs -->

          <div class="header-breadcrumbs">

	          <ul>

	            <li>Current Search: <a href="<?php echo $baseUrl ?>buy/<?php echo urlencode($keyword); ?>"><?php echo $keyword; ?></a></li>

	        </ul>

           

            <!-- Search form -->                  

            <div class="searchform">

              <form action="<?php echo $baseUrl ?>" method="get">

                <fieldset>

                  <input name="q" class="field"  value=" Search..." onfocus="this.value=''" />

                  <input type="submit" name="button" class="button" value="GO!" />

                </fieldset>

              </form>

            </div>

          </div>

        </div>





    <!-- B. MAIN -->

    <div class="main">

 

      <!-- B.1 MAIN NAVIGATION -->

      <div class="main-navigation">



        <!-- Navigation Level 3 -->

        <div class="round-border-topright"></div>

        

        <h2><?php echo $keyword; ?> Related Searches</h2>

        

		<?php if (count($related)>0) { ?>
		<p>If you like <i><?php echo $keyword; ?></i>, try these related items.</p>

        <ul class="nav3-grid">
        <?php foreach ($related as $relatedword) { ?>

			<li><a href="<?php echo $baseUrl ?>buy/<?php echo urlencode($relatedword); ?>"><?php echo $relatedword; ?></a></li>

		<?php } ?>
			</ul>
		<?php
		} else { ?>
			<p>There are no related searches for <i><?php echo $keyword; ?></i></p>
		<?php }	 ?>

	

	

	

        <h2><?php echo $keyword; ?> Similar Topics</h2>

		<?php if (count($topics)>0) { ?>
		
			<p>Customers looking for <i><?php echo $keyword; ?></i> also searched for:</p>

        <ul class="nav3-grid">
        <?php foreach ($topics as $topic) { ?>

			<li><a href="<?php echo $baseUrl ?>buy/<?php echo urlencode($topic); ?>"><?php echo $topic; ?></a></li>

		<?php } ?>
			
		</ul>
		
		<?php
		} else { ?>
			
		<p>There are no related topics for <i><?php echo $keyword; ?></i></p>
		
		<?php }	 ?>

	

	

	<h2>Sponsored Links</h2>

	<div class="adsense">

	<div class="googlesky">
	
	</div>

	</div>

	

	

	<h2>Share This Site</h2>

		<p>If you enjoyed using this site, share it with your friends</p>

		<ul class="social">

			<li><a href="http://digg.com/submit?phase=2&amp;url=<?php echo urlencode($url); ?>"><img src="<?php echo $themeUrl . $site['theme'] ?>/img/ico-digg.gif" width="16" height="16" alt="digg this page" class="absmiddle"/>digg this</a></li>

			<li><a href="http://www.stumbleupon.com/submit?url=<?php echo urlencode($url); ?>"><img src="<?php echo $themeUrl . $site['theme'] ?>/img/ico-stumbleupon.gif" width="16" height="16" alt="stumble this page" class="absmiddle"/>stumble this</a></li>

			<li><a href="http://del.icio.us/post?url=<?php echo urlencode($url); ?>"><img src="<?php echo $themeUrl . $site['theme'] ?>/img/ico-delicious.gif" width="16" height="16" alt="add to delicious" class="absmiddle"/>add to del.ico.us.</a></li>

			

	</ul>



      </div>

 

      <!-- B.1 MAIN CONTENT -->

      <div class="main-content">

        

        <!-- Pagetitle -->

        <h1 class="pagetitle"><?php 
		
			if (!empty($keyword)) { 
				echo $keyword; 
			
				if ($page>1) {
				
					echo " page $page";
			
				}
		
			}
		
			else {
		 
				echo $site['title'];

			} ?></h1>



<div class="column1-unit">
<?php if (!empty($keywordtext)) { 
	echo '<div class="keywordtext">' . $keywordtext. '</div>';

} ?>



<?php foreach ($ebayItems as $ebayItem) { ?>



<div class="mcjiffy_item">

<div class="mcjiffy_image"><a href="<?php echo $ebayItem['link']; ?>"><?php echo $ebayItem['image']; ?></a></div>

<div class="mcjiffy_title"><a href="<?php echo $ebayItem['link']; ?>"><?php echo $ebayItem['title']; ?></a></div>

		

		<?php 
			if ($ebayItem['type']=="Auction") { ?>

		<div class="mcjiffy_currprice"><?php echo $country['currentbid'] ?>: <b><?php echo $ebayItem['currentbid']; ?></b> (<?php echo $ebayItem['bidcount'].' '.$country['bids']; ?>)</div>

		<?php }


		if (!empty($ebayItem['bin'])) { ?>

			<div class="mcjiffy_binprice"><?php echo $country['bin'] ?>: <b><?php echo $ebayItem['bin']; ?></b></div>

		<?php } ?>

		<div class="mcjiffy_ends"><?php echo $country['ends'] ?>: <b><?php echo $ebayItem['endtime']; ?></b></div>

		</div>





<?php } ?>



</div>



<?php if ($totalPages>0) { ?>

<div class="pager">

jump to page: 
<?php foreach ($pageNumbers as $pageNumber) { ?>

	<a href="<?php echo $baseUrl ?>buy/<?php echo urlencode($keyword); ?>?page=<?php echo $pageNumber; ?>" <?php if ($page==$pageNumber) { echo 'class="currentpage"';} ?>><?php echo $pageNumber; ?></a>

<?php } ?>

</div>

<?php } ?>

       
<?php if (count($guides)>0) { ?>
<h2><?php echo $keyword;?> Buyer Guides</h2>

			<ul>

				<?php foreach ($guides as $guide) { ?>

				<li><a href="<?php echo $guide['url'];?>"><?php echo $guide['title'];?></a> - <?php echo $guide['desc'];?></li>
				<?php } ?>

			</ul>

				<?php } ?>


				<?php echo $impressionPixel; ?>


      </div>

    </div>

      

    <!-- C. FOOTER AREA -->      



    <div class="footer">

      <p class="credits">Original design by <a href="http://www.1-2-3-4.info" title="Designer Homepage">G. Wolfgang</a> | Powered by <a href="http://www.mcjiffy.com" title="Mcjiffy">McJiffy <?php echo $version;?></a></p>

    </div>      

  </div> 

  
 



</body>

</html>







