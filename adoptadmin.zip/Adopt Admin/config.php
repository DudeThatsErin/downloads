<?php
//Adopt Admin: Fanlistings Adoption Management Script
//script by Julie (http://new-place.org/)

/*
SETUP INSTRUCTIONS
--------------------

Installation
------------
1. Edit the config variables below.
2. Create a directory specifically for this script.  It can be named anything you want, for example, /apply.
3. Upload everything to that directory, and go to admin.php (you'll need to login).  Ignore the errors for now!
4. Click the "Table Setup" link in the menu to create the tables.  That's it, you're done!  Start adding sites.

Customization
------------
You can easily customize index.php (the application form) to fit with your site.  Open it up and you will see marked with comments where to edit the header and footer.  You can simply edit it or remove the header and footer code and include your own PHP header and footer.

Near the bottom of index.php, you will find the code for the form.  If you want to edit the look of the form fields, I strongly recommend using CSS instead of editing the actual code.  The input fields, select box, and textarea all have the CSS style class ".form" built in and the button has ".button" for use in your stylesheet.  If you do edit, edit with care as the script relies on the form field names (ex. name="email").

Troubleshooting
---------------
Errors such as "mysql_num_rows(): supplied argument is not a valid MySQL result resource" mean the script can't connect to your database.  Confirm your connection info with your host if you are unsure.

If you need basic help, you may contact me via my contact form at http://new-place.org/ or post in the "Other Scripts" forum at http://codegrrl.com/

*/


//Your database connection variables (ask your webhost if you aren't sure).
$dbhostname = "";    //database hostname (usually localhost)
$dbusername = "";    //database username
$dbpassword = "";    //database password
$dbname = "";    //database name

//Choose a username and password for the admin panel (it does not have to match the database login).
$setusername = "username";
$setpassword = "password";

//Show a list of the fanlistings up for adoption above the apply form?
$showflinfo = true;    //true or false

//Send notice when there is a new application?
$notify = true;    //true or false

//Your email address, to receive notifications and/or send emails to applicants (not displayed anywhere).
$admin_email = "you@example.com";    

//Your name or site name as show in the "From" field of emails sent to applicants
$sender = "Your Name";

//The full URL to your admin panel, so you can click it in the notification emails!
$admin_panel = "http://example.com/apply/admin.php";

//The tables that hold the fanlisting and application info.  No need to change unless you want to.
$fls_table = "adopt_fls";
$apps_table = "adopt_apps";


//DON'T EDIT BELOW THIS LINE!!!
$connect = mysql_connect( $dbhostname, $dbusername, $dbpassword )
	or die( 'Error connecting to the database!  Check your hostname, username, and password.' );
mysql_select_db( $dbname )
	or die( 'Error connecting to the database!  Check your database name.' );
?>