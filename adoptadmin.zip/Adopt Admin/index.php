<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<title>Adopt Admin: Fanlistings Adoption Management Script</title>
<style type="text/css">
body, input, textarea, select {font-family: verdana; font-size: 11px; background-color: white;}
a {color: #000000;}
p {margin: 0px 0px 10px 0px;}
.form {border: 1px solid #000000; width: 300px; margin-bottom: 5px;}
.button {border: 1px solid #000000;}
</style>
</head>
<body>
<!-- edit above or replace with a header include -->


<?php
// Do not edit below this line unless you know what you are doing!
//----------------------------------------------------------------
include ("config.php");

//if there are fanlistings up for adoption
$get_fls = mysql_query("SELECT * FROM $fls_table ORDER BY subject ASC");
$count_fls = mysql_num_rows($get_fls);
if ($count_fls > 0) {

	//and the apply form hasn't been submitted
	if ($_POST[showform] != "false") {

		//and it's set true in the config, show list of fanlistings up for adoption
		if ($showflinfo) {
			echo '<p><b>Up for Adoption</b></p>';
			while ($row = mysql_fetch_array($get_fls)) {
			echo '<p>';
			if ($row[url] != "") {
				echo '<a href="'.$row[url].'" target="_blank">'.$row[subject].'</a>';
			} else {
				echo $row[subject];
			}
			echo '<br />';
			if ($row[about] != "") {
				echo stripslashes($row[about]);
			}
				echo '</p>';
			}
		}
	}
	$showform = true;
	
	//process a submitted form
	if ($action == "process") {
		if (empty($_POST[name]) OR empty($_POST[email]) OR empty($_POST[url]) OR empty($_POST[why])) {
			echo '<p><b>Name, email address, URL(s), fanlisting you are applying for, and the reason you want to adopt the fanlisting are required fields.</b></p>';
		} elseif ($_POST[fanlisting] == "false") {
			echo '<p><b>You forgot to choose which fanlisting you are applying for!</b></p>';
		} else {		
			$showform = false;
			$add_app = "INSERT INTO $apps_table VALUES ('','$_POST[name]','$_POST[email]','$_POST[boardname]','$_POST[url]','$_POST[fanlisting]','$_POST[why]','none','0')";
			mysql_query($add_app);
			if ($add_app) {
				if ($notify) {
					$get_fl = mysql_query("SELECT * FROM $fls_table WHERE id='$_POST[fanlisting]'");
					while ($row = mysql_fetch_array($get_fl)) {
						$fanlisting = $row[subject];
					}
						
					//send email to site admin (not indented for email formatting purposes)
					$subject = "Application: $fanlisting";
$message = '
The following applicant has applied for: '.$fanlisting.'

Name: '.$_POST[name].'
Email Address: '.$_POST[email].'
TFL Board Username: '.$_POST[boardname].'
URL(s): '.$_POST[url].'
Comments: '.$_POST[why].'

Applicant\'s IP Address: '.$_SERVER[REMOTE_ADDR].'

Login to your admin panel: '.$admin_panel.'
';
					$headers = "From: $_POST[name] <$_POST[email]>\r\n";
					$mail = mail($admin_email, $subject, stripslashes($message), $headers);				
				}
				echo '<p>Thank you, '.$_POST[name].'!  Your application has been received.</p><p><a href="'.$_SERVER[PHP_SELF].'">&laquo; back to the form</a></p>';
			}
		}
	}

	
	//show the application form (if you edit the form, don't change the field names!)
	if ($showform == true) {
	echo '<p><b>Application Form</b></p>';
	?>

	<form method="post" action="<?php echo $_SERVER[PHP_SELF]; ?>">
	<input type="hidden" name="action" value="process" />
	<input type="hidden" name="showform" value="false" />

	*Name:<br />
	<input type="text" name="name" class="form" value="<?php echo $_POST[name]; ?>" /><br />

	*Email Address:<br />
	<input type="text" name="email" class="form" value="<?php echo $_POST[email]; ?>" /><br />

	TFL Board Username (if applicable):<br />
	<input type="text" name="boardname" class="form" value="<?php echo $_POST[boardname]; ?>" /><br />

	*URL(s):<br />
	<input type="text" name="url" class="form" value="<?php echo $_POST[url]; ?>" /><br />

	*Select the fanlisting you are applying for:<br />
	<select name="fanlisting" class="form">
	<option value="false">- choose one -</option>
	<?php
	$get_fls = mysql_query("SELECT * FROM $fls_table ORDER BY subject ASC");
	while ($row = mysql_fetch_array($get_fls)) {
		if ($_POST[fanlisting] == $row[id]) {
			echo '<option value="'.$row[id].'" selected>'.$row[subject].'</option>';
		} else {
			echo '<option value="'.$row[id].'">'.$row[subject].'</option>';
		}
	}
	?>
	</select><br />

	*Why do you want to adopt the fanlisting?<br />
	<textarea name="why" rows="10" cols="40" class="form" style="overflow: auto;"><?php echo stripslashes($_POST[why]); ?></textarea><br />

	<input type="submit" class="button" value="Submit Application" />

	</form>


	<?php
	}

//if there are no fanlistings up for adoption, show this message
} else {
	echo '<p><b>Up for Adoption</b></p><p>None at this time.</p>';
}

//----------------------------------------------------------------
// Do not edit above this line unless you know what you are doing!
?>


<!-- edit below or replace with a footer include -->
</body>
</html>