<?php
session_start();
header("Cache-control: private");

include ("config.php");

if ($_GET[action] == "logout") {
	$_SESSION = array();
	session_destroy();
}

if ($_POST[action] == "login") {
	
	if (($_POST[username] != $setusername) || ($_POST[password] != $setpassword)) {
		$showform = true;
		$errormsg = "Invalid login!  Try again.";
	} else {	
		$showform = false;
		$_SESSION[username] = $_POST[username];
		$_SESSION[password] = md5($_POST[password]);
	}

} else {
	
	if (($_SESSION[username] != $setusername) || ($_SESSION[password] != md5($setpassword))) {
		$showform = true;
	}

}

if ($showform) {
	include ("config.php");
?>


	<!-- login page -->

	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
		   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Style-Type" content="text/css" />
	<title>Adopt Admin: Admin Panel</title>
	<style type="text/css">
	body, input {	font-family: verdana; font-size: 11px; line-height: 15px;}
	body {background-color: #fff; color: #000;}
    h1 { font-size: 12px; margin: 5px 0px; }
	p {margin: 5px 0px; }
	input {background-color: transparent;border: 1px #000 solid;}
    .button {text-transform: uppercase;font-size: 10px; margin-top: 5px;}
	</style>
	</head>
	<body>

	<h1>Login Required</h1>
	<form method="post" action="<?php echo $_SERVER[PHP_SELF]; ?>">
	<input type="hidden" name="action" value="login" />

	<?php
	if ($errormsg) {
		echo '<p>'.$errormsg.'</p>';
	}
	?>

	<p>
	<label for="username">Username:</label><br />
	<input type="text" id="username" name="username" />
	</p>

	<p>
	<label for="password">Password:</label><br />
	<input type="password" id="password" name="password" />
	</p>

	<p>
	<input class="button" type="submit" value="submit" />
	</p>
	
	</form>

	</body>
	</html>

	<!-- login page ends -->


	<?php
	exit;
}
?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<title>Adopt Admin: Admin Panel</title>
<style type="text/css">
body, td, input, select, textarea {	font-family: arial; font-size: 12px; line-height: 15px; }
body {background-color: #fff; color: #000; text-align: center; margin: 5px;}
table {	width: 700px; margin: 10px auto; border: 1px solid black; }
td { vertical-align: top; text-align: left; padding: 5px;	}
#menu {width: 175px; line-height: 18px;}
#content { border-right: 1px solid black; padding-right: 10px; width: 525px;}
a {color: #000;}
.highlight {background-color: #FFFFE0;}
.fade {color: #999999;}
.fade a {color: #999999;}
form.fade .button {border-color: #B7B7B7; color: #999999;}
input, textarea {background-color: transparent;border: 1px #000 solid;}
.form, .emailform {width: 80%; margin: 0px 0px 5px 0px;}
.emailform {height: 200px;}
p {margin: 0px; padding: 2px;}
#menu p {margin: 0px 0px 15px 0px;}
form {margin: 0px 0px 20px 0px; padding: 2px;}
.msg, .errormsg {margin: 10px 0px 10px 0px; font-weight: bold;}
.errormsg {color: red;}
#title {border-bottom: 1px solid black;}
h1, h2, h3 {font-family: arial; font-weight: bold; padding-left: 2px;}
h1 {font-size: 16px; letter-spacing: 1px; margin: 0px; line-height: 22px;}
h2 {font-size: 14px; letter-spacing: 1px; margin: 0px 0px 10px 0px; line-height: 17px;}
#menu h2 {margin: 0px 0px 0px 0px;}
h3 {font-size: 12px; letter-spacing: 1px; margin: 0px; line-height: 17px;}
.asterisk {color:red; font-family: serif;}
</style>
</head>
<body>


<table cellpadding="0" cellspacing="0">
<tr><td colspan="2" id="title"><h1>Adopt Admin: Fanlistings Adoption Management Script</h1></td></tr>
<tr>



<td id="content">

<?php
if (!$_GET[id]) {

	//if setting up tables
	if ($_POST[action] == "Create Tables") {
		echo '<h3>Table Setup</h3>';

		//create fanlistings table
		$exists = mysql_query("SELECT 1 FROM $fls_table LIMIT 0");
		if (!$exists) {
			$fls_create = mysql_query("CREATE TABLE $fls_table (id int(6) NOT NULL auto_increment, subject text NOT NULL, url varchar(255) NOT NULL, about text NOT NULL, PRIMARY KEY (id))");
			if ($fls_create) {
				echo '<p class="msg">Success! The table <i>'.$fls_table.'</i> has been created.</p>';
			} else {
				echo '<p class="errormsg">Error!  The table <i>'.$fls_table.'</i> was not created.  Please double check all connection info in config.php and try again.</p>';
			}
		} else {
			echo '<p class="errormsg">Error!  The table <i>'.$fls_table.'</i> already exists in your database.</p>';
		}


		//create applications table
		$exists = mysql_query("SELECT 1 FROM $apps_table LIMIT 0");
		if (!$exists) {
			$apps_create = mysql_query("CREATE TABLE $apps_table (id int(6) NOT NULL auto_increment, name text NOT NULL, email text NOT NULL, boardname text NOT NULL, url text NOT NULL, fanlisting text NOT NULL, why text NOT NULL, status varchar(50) NOT NULL, emailed tinyint(1) NOT NULL default '0', PRIMARY KEY (id))");
			if ($apps_create) {
				echo '<p class="msg">Success! The table <i>'.$apps_table.'</i> has been created.</p>';
			} else {
				echo '<p class="errormsg">Error!  The table <i>'.$apps_table.'</i> was not created.  Please double check all connection info in config.php and try again.</p>';
			}
		} else {
			echo '<p class="errormsg">Error!  The table <i>'.$apps_table.'</i> already exists in your database.</p>';
		}


	//if showing table setup info
	} elseif ($_GET[action] == "setup") {
		echo '<h3>Table Setup</h3>';
		$fls_exists = mysql_query("SELECT 1 FROM $fls_table LIMIT 0");
		$apps_exists = mysql_query("SELECT 1 FROM $apps_table LIMIT 0");
		if ((!$fls_exists) || (!$apps_exists)) {
		?>
		<p>Adopt Admin creates two tables in your database.  Before creating the tables, you must put your database name, hostname, username, and password in the config.php file.  Ask your webhost if you don't know this information.</p>
		<p>This script will not overwrite existing tables, so don't worry about accidentally deleting any stored information.  If you need to start fresh, you must delete (with phpMyAdmin) any tables you'd like to recreate.  If you do not have access to delete existing tables, or if you want to run multiple installations of the script in one database, you can change the table names in config.php, which will allow the script to create and use new tables.</p>
		<form method="post" action="admin.php">
		<input type="submit" name="action" value="Create Tables"/>
		</form>
		<?php
		} else {
		?>
		<p>Your tables are already set up so you can't run the installation.  If you want to create new tables, you must first delete (with phpMyAdmin) any tables you'd like to recreate.  If you do not have access to delete existing tables, you can change the table names in config.php, which will allow the script to create and use new tables.</p>
		<?php
		}


	//show add a fanlisting form
	}else if ($_GET[action] == "add") {
		?>
		<h2>Add a Fanlisting for Adoption</h2>
		<form method="post" action="admin.php">
		<input type="hidden" name="action" value="added" />
		Fanlisting Subject:<br />
		<input type="text" name="subject" class="form" /><br />
		Fanlisting URL:<br />
		<input type="text" name="url" class="form" /><br />
		Fanlisting Description/Notes:<br />
		<textarea name="about" rows="10" class="form" style="overflow: auto;"></textarea><br />		
		<input type="submit" class="button" value="Add Fanlisting" />
		</form>
		<?php

	//show edit a fanlisting form
	} elseif ($_POST[action] == "Edit") {
		$get_fl = mysql_query("SELECT * FROM $fls_table WHERE id='$_POST[fl_id]'");
		while ($row = mysql_fetch_array($get_fl)) {
			?>
			<h2>Edit a Fanlisting for Adoption</h2>
			<form method="post" action="admin.php">
			<input type="hidden" name="action" value="edited" />
			<input type="hidden" name="fl_id" value="<?php echo $_POST[fl_id]; ?>" />
			Fanlisting Subject:<br />
			<input type="text" name="subject" class="form" value="<?php echo $row[subject]; ?>" /><br />
			Fanlisting URL:<br />
			<input type="text" name="url" class="form" value="<?php echo $row[url]; ?>" ><br />
			Fanlisting Description/Notes:<br />
			<textarea name="about" rows="10" class="form" style="overflow: auto;"><?php echo $row[about]; ?></textarea><br />
			<input type="submit" class="button" value="Save Changes" />
			</form>
			<?php
		}


	} else {

		echo '<h2>Manage Sites</h2>';

		$count_fls = mysql_num_rows(mysql_query("SELECT * FROM $fls_table ORDER BY subject ASC"));
		if ($count_fls != 1) {
			echo '<p class="msg" style="font-weight: normal;">You have '.$count_fls.' fanlistings up for adoption.';
		} else {
			echo '<p class="msg" style="font-weight: normal;">You have '.$count_fls.' fanlisting up for adoption.';
		}
		echo ' <a href="admin.php?action=add">Add one</a>?';

		//if a fanlisting has been added
		if ($_POST[action] == "added") {
			if (!empty($_POST[subject])) {
				$add_fl = "INSERT INTO $fls_table VALUES ('','$_POST[subject]','$_POST[url]','$_POST[about]')";
				mysql_query($add_fl);
				echo '<p class="msg">'.$_POST[subject].' added!</p>';
			} else {
				echo '<p class="errormsg">Error! You must fill in the subject field.  The fanlisting was not added.</p>';
			}
		}

		//if a fanlisting has been edited
		if ($_POST[action] == "edited") {			
			if (!empty($_POST[subject])) {
				$edit_fl="UPDATE $fls_table SET subject='$_POST[subject]', url='$_POST[url]', about='$_POST[about]' WHERE id='$_POST[fl_id]'";
				mysql_query($edit_fl);
				echo '<p class="msg">'.$_POST[subject].' edited!</p>';
			} else {
				echo '<p class="errormsg">Error! You must have a subject field.  The fanlisting was not edited.</p>';
			}
		}

		//confirm deletion of a fanlisting
		if ($_POST[action] == "Delete") {
			$get_fl = mysql_query("SELECT * FROM $fls_table WHERE id='$_POST[fl_id]'");
			while ($row = mysql_fetch_array($get_fl)) {
			echo '<p class="errormsg">Delete '.$row[subject].'?  This will also delete all applications for this fanlisting!</p>';
			?>
			<form method="post" action="admin.php">
			<input type="hidden" name="fl_id" value="<?php echo $row[id]; ?>" />
			<input class="button" type="submit" name="action" value="Confirm Delete" />
			<input class="button" type="submit" value="Never Mind" />
			</form>
			<?php
			}
		}

		//perform confirmed deletion of a fanlisting
		if ($_POST[action] == "Confirm Delete") {		
			//delete the fanlisting
			$query="DELETE FROM $fls_table WHERE id='$_POST[fl_id]'";
			mysql_query($query);
			//delete apps for it
			$query="DELETE FROM $apps_table WHERE fanlisting='$_POST[fl_id]'";
			mysql_query($query);
			echo '<p class="errormsg">Fanlisting deleted!</p>';
		}

		//list all fanlistings
		$get_fls = mysql_query("SELECT * FROM $fls_table ORDER BY subject ASC");
		while ($row = mysql_fetch_array($get_fls)) {
			?>
			<p>
			<b>ID:</b> <?php echo $row[id]; ?><br />
			<b>Subject:</b> <?php echo $row[subject]; ?><br />
			<?php if ($row[url] != "") { ?>
				<b>URL:</b> <a href="<?php echo $row[url]; ?>" target="_blank"><?php echo $row[url]; ?></a><br />
			<?php } ?>
			<?php if ($row[about] != "") { ?>
				<b>Comments:</b> <?php echo stripslashes($row[about]); ?><br />
			<?php } ?>
			</p>
			<form method="post" action="admin.php">
			<input type="hidden" name="fl_id" value="<?php echo $row[id]; ?>" />
			<input class="button" type="submit" name="action" value="Edit" />
			<input class="button" type="submit" name="action" value="Delete" />
			</form>
			<?php
		}

	}


} else {

	//show apps for a fanlisting
	$get_fls = mysql_query("SELECT * FROM $fls_table WHERE id='$_GET[id]' ORDER BY subject ASC");
	while ($row = mysql_fetch_array($get_fls)) {
	echo '<h2>Applications: '.$row[subject].'</h2>';
	}


	//if sending mass email
	if ($_POST[action] == "Send Mass Email") {
		$headers = "From: $sender <$admin_email>\r\n";
		echo '<p class="msg">Success!  Email sent to:</p><p class="msg">';
		$get_faded = mysql_query("SELECT * FROM $apps_table WHERE fanlisting='$_GET[id]' and status='fade' ORDER BY id ASC");
		while ($row = mysql_fetch_array($get_faded)) {
			$mail = mail($row[email], $_POST[subject], stripslashes($_POST[body]), $headers);
			if ($mail) {
				$query="UPDATE $apps_table SET emailed='1' WHERE id='$row[id]'";
				mysql_query($query);
				echo $row[name].' &lt;'.$row[email].'&gt;<br />';
			}
		}
		echo '</p>';
	}

	//if sending single email
	if ($_POST[action] == "Send Email") {
		$headers = "From: $sender <$admin_email>\r\n";
		echo '<p class="msg">Success!  Email sent to:</p><p class="msg">';
		$mail = mail($_POST[email], $_POST[subject], stripslashes($_POST[body]), $headers);
		if ($mail) {
			$query="UPDATE $apps_table SET emailed='1' WHERE id='$_POST[app_id]'";
			mysql_query($query);
			echo $_POST[name].' &lt;'.$_POST[email].'&gt;</p>';
		}
	}

	//if mass action is emailing all faded applicants
	if ($_POST[action] == "massemail") {
		?>
		<h3>Email All Faded Applicants</h3>
		<p class="msg">An individual email is sent to each recipient (not one CC'ed email).  No HTML.</p>
		<p><b>From:</b> <?php echo $sender; ?> &lt;<?php echo $admin_email; ?>&gt;</p>
		<p><b>To:</b> <?php
		$get_faded = mysql_query("SELECT * FROM $apps_table WHERE fanlisting='$_GET[id]' and status='fade' ORDER BY id ASC");
		$count_faded = mysql_num_rows($get_faded);
		while ($row = mysql_fetch_array($get_faded)) {
			$count_faded--;
			if (($count_faded) != 0) {
				echo $row[name].' &lt;'.$row[email].'&gt;, ';
			} else {
				echo $row[name].' &lt;'.$row[email].'&gt;';
			}
		}
		?>
		</p>
		<form method="post" action="admin.php?id=<?php echo $_GET[id]; ?>">
		<b>Subject:</b><br />
		<input class="form" type="text" name="subject" /><br />
		<b>Body:</b><br />
		<textarea class="emailform" name="body"></textarea><br />
		<input class="button" type="submit" name="action" value="Send Mass Email" />
		</form>
		<?php
	}


	//if action is emailing single applicant
	if ($_POST[action] == "Email Applicant") {
		?>
		<h3>Email Applicant</h3>
		<p><b>From:</b> <?php echo $sender; ?> &lt;<?php echo $admin_email; ?>&gt;</p>
		<p><b>To:</b> 
		<?php echo $_POST[name].' &lt;'.$_POST[email].'&gt;'; ?>
		</p>
		<form method="post" action="admin.php?id=<?php echo $_GET[id]; ?>">
		<input type="hidden" name="name" value="<?php echo $_POST[name]; ?>" />
		<input type="hidden" name="email" value="<?php echo $_POST[email]; ?>" />
		<input type="hidden" name="app_id" value="<?php echo $_POST[app_id]; ?>" />
		<b>Subject:</b><br />
		<input class="form" type="text" name="subject" /><br />
		<b>Body:</b><br />
		<textarea class="emailform" name="body"></textarea><br />
		<input class="button" type="submit" name="action" value="Send Email" />
		</form>
		<?php
	}


	
	//if confirming the mass deletion of all faded apps
	if ($_POST[action] == "massdelete") {
		echo '<p class="errormsg">Permanently delete the following applications for this fanlisting?</p><p class="msg">';
		$get_faded = mysql_query("SELECT * FROM $apps_table WHERE fanlisting='$_GET[id]' and status='fade' ORDER BY id ASC");
		while ($row = mysql_fetch_array($get_faded)) {
		echo $row[id].') '.$row[name].' (<a href="mailto:'.$row[email].'">'.$row[email].'</a>)<br />';
		}
		?>
		</p>
		<form method="post" action="admin.php?id=<?php echo $_GET[id]; ?>">
		<input class="button" type="submit" name="action" value="Confirm Mass Deletion" />
		<input class="button" type="submit" value="Never Mind" />
		</form>
		<?php
	}


	//if it's actually mass deleting all faded apps
	if ($_POST[action] == "Confirm Mass Deletion") {
		$get_faded = mysql_query("SELECT * FROM $apps_table WHERE fanlisting='$_GET[id]' and status='fade' ORDER BY id ASC");
		while ($row = mysql_fetch_array($get_faded)) {
			$query="DELETE FROM $apps_table WHERE fanlisting='$_GET[id]' AND status='fade'";
			mysql_query($query);
		}
	echo '<p class="errormsg">Applications deleted!</p>';
	}


	
	//if it's confirming the deletion of a single app
	if ($_POST[action] == "Delete Application") {
		echo '<p class="errormsg">Delete application from '.$_POST[name].' (<a href="mailto:'.$_POST[email].'">'.$_POST[email].'</a>)?';
		?>
		<form method="post" action="admin.php?id=<?php echo $_GET[id]; ?>">
		<input type="hidden" name="app_id" value="<?php echo $_POST[app_id]; ?>" />
		<input class="button" type="submit" name="action" value="Confirm Application Deletion" />
		<input class="button" type="submit" value="Never Mind" />
		</form>
		<?php
	}


	//if it's actually deleting a single app (after confirmation)
	if ($_POST[action] == "Confirm Application Deletion") {
		$query="DELETE FROM $apps_table WHERE fanlisting='$_GET[id]' AND id='$_POST[app_id]'";
		mysql_query($query);
		echo '<p class="errormsg">Application deleted!</p>';
	}
	

	//if it's changing the status of an app
	if ($_POST[action] == "Highlight") {
		$query="UPDATE $apps_table SET status='highlight' WHERE fanlisting='$_GET[id]' AND id='$_POST[app_id]'";
		mysql_query($query);
	}
	if ($_POST[action] == "Fade") {
		$query="UPDATE $apps_table SET status='fade' WHERE fanlisting='$_GET[id]' AND id='$_POST[app_id]'";
		mysql_query($query);
	}
	if (($_POST[action] == "Remove Highlight") || ($_POST[action] == "Remove Fade")) {
		$query="UPDATE $apps_table SET status='none' WHERE fanlisting='$_GET[id]' AND id='$_POST[app_id]'";
		mysql_query($query);
	}


	//get all apps for the fanlisting
	$get_apps = mysql_query("SELECT * FROM $apps_table WHERE fanlisting='$_GET[id]' ORDER BY id ASC");
	$app_count = mysql_num_rows($get_apps);

	//count them
	if ($app_count > 1) {
		echo '<p class="msg" style="font-weight: normal;">You have '.$app_count.' applications for this fanlisting.<br />';
	} else {
		echo '<p class="msg" style="font-weight: normal;">You have '.$app_count.' application for this fanlisting.<br />';
	}
	?>
	<span class="asterisk">*</span> = applicant has been emailed via form</p>
	<?php
	
	//display them
	while ($row = mysql_fetch_array($get_apps)) {

		//strip HTML from url field then link all URLs (damn this was complex)
		$url = strip_tags($row[url]);
		$url = preg_replace("/((http)+(s)?:(\/\/)([\w]+(.[\w]+))([\w\-\.,@?^=%&:;\/~\+#]*[\w\-\@?^=%&:;\/~\+#])?)/i", "<a href=\"\\0\" target=\"_blank\">\\0</a>", $url);

		//set highlight, fade, or normal style and print the app details
		if ($row[status] == "highlight") {
			echo '<p class="highlight">';
		} elseif ($row[status] == "fade") {
			echo '<p class="fade">';
		} else {
			echo '<p>';
		}
		
		if ($row[emailed] == 1) {
			echo '<span class="asterisk">*</span>';
		}
		?>

		<b>ID:</b> <?php echo $row[id]; ?><br />
		<b>Name:</b> <?php echo $row[name]; ?><br />
		<b>Email Address:</b> <a href="mailto:<?php echo $row[email]; ?>"><?php echo $row[email]; ?></a><br />
		<b>TFL Board Name:</b> <?php echo $row[boardname]; ?><br />
		<b>URL(s):</b> <?php echo $url; ?><br />
		<b>Comments:</b> <?php echo $row[why]; ?>
		</p>

		<?php
		//set highlight, fade, or normal style and print form buttons
		if ($row[status] == "highlight") {
			echo '<form class="highlight" method="post" action="admin.php?id='.$_GET[id].'">';
		} elseif ($row[status] == "fade") {
			echo '<form class="fade" method="post" action="admin.php?id='.$_GET[id].'">';
		} else {
			echo '<form method="post" action="admin.php?id='.$_GET[id].'">';
		}
		?>

		<input type="hidden" name="app_id" value="<?php echo $row[id]; ?>" />
		<input type="hidden" name="name" value="<?php echo $row[name]; ?>" />
		<input type="hidden" name="email" value="<?php echo $row[email]; ?>" />

		<?php
		if ($row[status] == "highlight") {
			echo '<input class="button" type="submit" name="action" value="Remove Highlight" />';
		} else {
			echo '<input class="button" type="submit" name="action" value="Highlight" />';
		}
		?>

		<?php
		if ($row[status] == "fade") {
			echo '<input class="button" type="submit" name="action" value="Remove Fade" />';
		} else {
			echo '<input class="button" type="submit" name="action" value="Fade" />';
		}
		?>

		<input class="button" type="submit" name="action" value="Delete Application" />
		<input class="button" type="submit" name="action" value="Email Applicant" />
		</form>
		
		<?php
	}

	?>
	<h3>Mass Actions</h3>
	<p>Handy to send mass rejection emails or delete rejected applicants.</p>
	<form method="post" action="admin.php?id=<?php echo $_GET[id]; ?>">
	<select class="form" name="action">
	<option value="massemail">Email All Faded Applications</option>
	<option value="massdelete">Delete All Faded Applications</option>
	</select><br />
	<?php
	//check for faded apps, if there are none, don't print the mass action submit button because it can't do anything
	$count_faded = mysql_num_rows(mysql_query("SELECT * FROM $apps_table WHERE fanlisting='$_GET[id]' and status='fade' ORDER BY id ASC"));
	if ($count_faded < 1) {
	?>
	<p>Mass actions can only be performed when at least one application is faded.</p>
	<?php
	} else {
	?>
	<input class="button" type="submit" value="Perform Action" /> (will be confirmed)
	<?php
	}
	?>
	
	</form>
	<?php

}
?>
</td>

<td id="menu">
<h2>Menu</h2>

<p>
<a href="admin.php">Manage Sites</a><br />
<a href="admin.php?action=add">Add a Site</a><br />
</p>

<p>
<a href="admin.php?action=setup">Table Setup</a><br />
<a href="admin.php?action=logout">Logout</a>
</p>


<h3>View Applications</h3>
<p>
<?php
$count_fls = mysql_num_rows(mysql_query("SELECT * FROM $fls_table ORDER BY subject ASC"));
if ($count_fls > 0) {

	$get_fls = mysql_query("SELECT * FROM $fls_table ORDER BY subject ASC");
	while ($row = mysql_fetch_array($get_fls)) {
		$app_count = mysql_num_rows(mysql_query("SELECT * FROM $apps_table WHERE fanlisting='$row[id]' ORDER BY id ASC"));
		printf("(%02d)&nbsp;&nbsp;", $app_count);
		echo '<a href="admin.php?id='.$row[id].'">'.$row[subject].'</a><br />';
	}

} else {
	echo 'None yet.';
}
?>
</p>

<p><b>Adopt Admin</b> was created by <a href="http://new-place.org/" target="_blank">Julie</a>.  Feel free to customize it for personal use as needed.</p>

</td>

</tr>
</table>

</body>
</html>