<?php
if (isset($_GET['p'])) { $page = $_GET['p']; } else { $page = ""; }
switch ($page) {
	case "process":
		require_once('prefs.php');
		if (isset($captcha) && $captcha == "yes") {
			session_start();
			if (isset($_SESSION['key'])) {
				if(md5($_POST['captcha']) != $_SESSION['key']) {
					setcookie(session_name(), '', time()-36000, '/');
					$_SESSION = array();
					session_destroy();

					echo "<p>The text you entered didn't match the image, please <a href='contact.php'>try again</a>.</p>";
					exit;
				}
				if (isset($_SESSION['key']) && isset($_COOKIE[session_name()])) {
					setcookie(session_name(), '', time()-36000, '/');
					$_SESSION = array();
					session_destroy();
				}
			} else {
				echo "<p>The text you entered didn't match the image, please <a href='contact.php'>try again</a>.</p>";
				exit;
			}
		}
		include_once('header.php');

		if (!isset($_POST['submit']) || $_SERVER['REQUEST_METHOD'] != "POST") {
			echo "<p>Accessing this page directly is not allowed.</p>\n\n";
			exit;
		}

		$exploits = "/(content-type|bcc:|cc:|document.cookie|onclick|onload)/i";
		foreach ($_POST as $key => $val) {
			$clean[$key] = cleanUp($val);


			if (filesize(SPAMWDS) > 0 && (checkTXTfile(SPAMWDS, $val, "spamword") === true)) {
				exit("<p>Your application contains words in the spam list, that means you're not allowed to use this form at this time. \n</p>");
			}
			if (preg_match($exploits, $val)) {
				exit("<p>No meta injection, please. \n</p>");
			}
		} 

		// let's do some security checks
		if (empty($clean['name']) || empty($clean['email']) || empty($clean['comments'])) {
			exit("<p>Name, e-mail and comments are required fields. Please <a href='javascript:history.back(1)'>go back</a> and try again.\n</p>");
		} elseif (!ereg("^[A-Za-z' -]",$clean['name']) || strlen($clean['name']) > 15) {
			exit("<p>That name is not valid. Your name must contain letters only, and must be less than 15 characters. Please <a href='javascript:history.back(1)'>go back</a> and try again.\n</p>");
		} elseif (!ereg("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,6})$", strtolower($clean['email']))) {
			exit("<p>That email is not valid. Please <a href='javascript:history.back(1)'>go back</a> and try again.\n</p>");
		}

		// let's clean up the input and get things looking tidy
		$clean['name'] = ucwords(strtolower($clean['name']));
		if (!empty($clean['url']) && !ereg("^http://",$clean['url'])) {
			$clean['url'] = "http://" . $clean['url'];
		}
		
		// send off the email
		$subject = "E-mail through $title";

		$message = "The following e-mail has been sent through your $FLsubject fanlisting: \n\n";
		$message .= "Name: {$clean['name']} \n";
		$message .= "Email: " . fixEmail($clean['email']) . " \n";
		$message .= "URL: {$clean['url']} \n";
		$message .= "Reason for contact: {$clean['reason']} \n";
		$message .= "Comments: {$clean['comments']} \n";

		if (strstr($_SERVER['SERVER_SOFTWARE'], "Win")) {
			$headers   = "From: $clean[email] \n";
			$headers  .= "Reply-To: $clean[email]";
		} else {
			$headers   = "From: $clean[name] <$clean[email]> \n";
			$headers  .= "Reply-To: <$clean[email]>";
		}

		if (mail($admin_email,$subject,$message,$headers)) {
			echo "<h1>Thank You</h1> \n <p>Thank you for your e-mail. It was successfully sent!</p>";
		} else {
			echo "<h1>Oh Dear!</h1> \n <p>Your e-mail could not be sent this time. Please contact the owner of the fanlisting, using an alternative method, for help.</p>";
		}



	break;
	default:
		require_once('prefs.php');
		include_once('header.php');
?>
<h1>Contact Admin</h1>
<p>This form is for contacting the fanlisting owner only -- it is not to be used to join the fanlisting unless you have been directed to do so. (Name, e-mail and comments are required fields.)</p>

<form action="contact.php?p=process" method="post"><p>
	<label for="name">Name *</label><br /> <input type="text" id="name" name="name" /> <br />
	<label for="email">E-mail *</label><br /> <input type="text" id="email" name="email" /> <br />
	<label for="url">Website</label><br /> <input type="text" id="url" name="url" value="http://" /> <br />
	<label for="reason">Reason for contact</label><br /> <select name="reason" id="reason">
								<option value="affiliate-request">Affiliate Request</option>
								<option value="couldnt-join">Joining Problem</option>
								<option value="button-donation">Button Donation</option>
								<option value="other">Other</option>
	</select> <br />
<?php
	if (isset($captcha) && $captcha == "yes") {
?>
	<img src="captcha.php" alt="" /><br />
	<label>Captcha</label><br /> <input type="text" name="captcha" id="captcha" /> <br />
<?php
	}
?>
	<label for="comments">Comments *</label><br /> <textarea name="comments" id="comments" rows="3" cols="25"></textarea><br />
	<input type="submit" name="submit" id="submit" value="Send" /> 
</p></form>

<?php
	break;
}
include('footer.php');
?>