###################################################################
###################################################################
Domainish 2.0 © 2009 to Hannah W of hannah.nu. All rights reserved.
This script is linkware, meaning that it may be used and modified
as long as credit is provided. The script may not be redistributed
without permission. I am not responsible for any damage done to
your website/server while running this script.
###################################################################
###################################################################

HOW TO INSTALL:

1. Create a database and attach a username and password to it.
   If you do not know how, see this tutorial:
   http://www.tutorialtastic.co.uk/tutorial/creating_a_mysql_database
2. Open config.php in a plain text editor and edit the values.
   Instructions are included within the file.
3. Upload all of the files to your web server.
4. Run the install.php file and delete when prompted to do so.
5. You're done!

###################################################################

UPGRADE FROM 1.1.1 to 2.0 OR 2.0.1:

1. Edit the new config.php file with your details. 
2. Upload and overwrite old Domainish files with 2.0 files.
3. Go to yourdomain.com/domainish/upgrade.php, and delete
   upgrade.php when prompted to do so.


###################################################################

CUSTOMIZATION

Customizing should be pretty easy. If you use the standard method
of using PHP includes for your header and footer, you're set! Just
replace the header and footer included with your own!

If you want to integrate Domainish into an existing website, install
it in a subfolder of that site (like yourdomain.com/domains) and
replace header and footer inclusions with your own. If your header
and footer files are just outside the subfolder, you can simply change
them to include('../header.php'); and include('../footer.php');

###################################################################

HELP, I BROKE IT!

If you need help, or would like to suggest a new feature, contact me
at girl@hannah.nu.