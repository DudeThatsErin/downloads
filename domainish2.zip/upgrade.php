<?php
/**************************************************************************************************
Domainish 2.0b © 2009 to Hannah W of hannah.nu. All rights reserved. This script is linkware,
meaning that it may be used and modified as long as credit is provided to me. The script may not be
redistributed without permission. I am not responsible for any damage done to your website/server
while running this script. For support, mail girl@hannah.nu or check out @scriptish on Twitter.
**************************************************************************************************/
require_once('config.php');
require_once('functions.php');
include('header.php');

if (empty($dishDBhostname) || empty($dishDBusername) || empty($dishDBdatabase) || empty($dishDBdomains))
	exit("You must fill out all of the database information in config.php.");

/**************************************************************************************************
   INSTALL CATEGORIES TABLE
**************************************************************************************************/
if(mysql_query("SELECT * FROM `$dishDBcategories`"))
	echo "<p class=\"error\">Table '$dishDBcategories' already installed!</p>";
else {
	$dishInstallCategoriesQ = "CREATE TABLE `$dishDBcategories` (
		`category_id` int(6) NOT NULL auto_increment,
		`category_name` varchar(255) NOT NULL,
		PRIMARY KEY  (`category_id`));";
	$dishInstallCategories = mysql_query($dishInstallCategoriesQ)
		or die("<p class=\"error\">Couldn't create script table, \"$dishDBcategories\"!<br />\n".mysql_error()."</p>");
	echo "<p class=\"success\">Categories table, `$dishDBcategories` succesfully added!</p>";
}

/**************************************************************************************************
   INSERT CATEGORIES IN CATEGORIES TABLE FROM A DISTINCT SELECTION OF CATEGORIES IN DOMAINS TABLE
**************************************************************************************************/
$categoriesQ = "SELECT DISTINCT `domain_purpose` FROM `$dishDBdomains`";
$categoriesR = mysql_query($categoriesQ) or die("<p class=\"error\">".mysql_error()."</p>");
while($categories = mysql_fetch_assoc($categoriesR)) {
	$category = $categories['domain_purpose'];
	mysql_query("INSERT INTO `$dishDBcategories` (`category_name`) VALUES ('$category')") or die("<p class=\"error\">".mysql_error()."</p>");
}
echo "<p class=\"success\">Purposes were converted into categories and succesfully inserted into `$dishDBcategories`!</p>";

/**************************************************************************************************
   REPLACE PURPOSES IN DOMAIN TABLE WITH CORRESPONDING IDs JUST INSERTED INTO CATEGORIES TABLE
**************************************************************************************************/
$domainPurposesQ = "SELECT `id`,`domain_purpose` FROM `$dishDBdomains`";
$domainPurposesR = mysql_query($domainPurposesQ) or die("<p class=\"error\">".mysql_error()."</p>");
while($domainPurposes = mysql_fetch_array($domainPurposesR)) {
	$domainID = $domainPurposes['id'];
	$domainPurpose = $domainPurposes['domain_purpose'];
	$purposeIDQ = "SELECT `category_id` FROM `$dishDBcategories` WHERE `category_name` = '$domainPurpose'";
	$purposeIDR = mysql_query($purposeIDQ)
		or die("<p class=\"error\">".mysql_error()."</p>");
	$purposeID = mysql_result($purposeIDR,0,0);
	$updatePurposeQ = "UPDATE `$dishDBdomains` SET `domain_purpose` = '|$purposeID|' WHERE `id` = '$domainID' LIMIT 1";
	$updatePurposeR = mysql_query($updatePurposeQ)
		or die("<p class=\"error\">".mysql_error()."</p>");
}	
echo "<p class=\"success\">Purposes listed in the domains table were succesfully converted to their new corresponding category IDs!</p>";

/**************************************************************************************************
   INSTALL REGISTRARS TABLE
**************************************************************************************************/
if(mysql_query("SELECT * FROM `$dishDBregistrars`"))
	echo "<p class=\"error\">Table '$dishDBregistrars' already installed!</p>";
else {
	$dishInstallRegistrarsQ = "CREATE TABLE `$dishDBregistrars` (
		`registrar_id` int(6) NOT NULL auto_increment,
		`registrar_name` varchar(255) NOT NULL,
		`registrar_url` varchar(255) NOT NULL,
		PRIMARY KEY  (`registrar_id`));";
	$dishInstallRegistrars = mysql_query($dishInstallRegistrarsQ)
		or die("<p class=\"error\">Couldn't create script table, \"$dishDBregistrars\"!<br />\n".mysql_error()."</p>");
	echo "<p class=\"success\">Registrars table, `$dishDBregistrars` succesfully added!</p>";
}

/**************************************************************************************************
   INSERT REGISTRARS IN REGISTRARS TABLE FROM A DISTINCT SELECTION OF REGISTRARS IN DOMAINS TABLE
**************************************************************************************************/
$registrarsQ = "SELECT DISTINCT `domain_registrar` FROM `$dishDBdomains`";
$registrarsR = mysql_query($registrarsQ) or die("<p class=\"error\">".mysql_error()."</p>");
while($registrars = mysql_fetch_assoc($registrarsR)) {
	$registrar = $registrars['domain_registrar'];
	mysql_query("INSERT INTO `$dishDBregistrars` (`registrar_name`,`registrar_url`) VALUES ('$registrar','')") or die("<p class=\"error\">".mysql_error()."</p>");
}
echo "<p class=\"success\">Registrars were converted and succesfully inserted into `$dishDBregistrars`!</p>";

/**************************************************************************************************
   REPLACE REGISTRARS IN DOMAIN TABLE WITH CORRESPONDING IDs JUST INSERTED INTO REGISTRARS TABLE
**************************************************************************************************/
$domainRegistrarsQ = "SELECT `id`,`domain_registrar` FROM `$dishDBdomains`";
$domainRegistrarsR = mysql_query($domainRegistrarsQ);
while($domainRegistrars = mysql_fetch_array($domainRegistrarsR)) {
	$domainID = $domainRegistrars['id'];
	$domainRegistrar = $domainRegistrars['domain_registrar'];
	$registrarIDQ = "SELECT `registrar_id` FROM `$dishDBregistrars` WHERE `registrar_name` = '$domainRegistrar'";
	$registrarIDR = mysql_query($registrarIDQ)
		or die("<p class=\"error\">".mysql_error()."</p>");
	$registrarID = mysql_result($registrarIDR,0,0);
	$updateRegistrarQ = "UPDATE `$dishDBdomains` SET `domain_registrar` = '$registrarID' WHERE `id` = '$domainID' LIMIT 1";
	$updateRegistrarR = mysql_query($updateRegistrarQ)
		or die("<p class=\"error\">".mysql_error()."</p>");
}
echo "<p class=\"success\">Registrars listed in the domains table were succesfully converted to their new corresponding registrar IDs!</p>";

/**************************************************************************************************
   INSTALL TLDs TABLE
**************************************************************************************************/
if(mysql_query("SELECT * FROM `$dishDBtlds`"))
	echo "<p class=\"error\">Table '$dishDBtlds' already installed!</p>";
else {
	$dishInstallTLDsQ = "CREATE TABLE `$dishDBtlds` (
		`tld_id` int(6) NOT NULL auto_increment,
		`tld_name` varchar(255) NOT NULL,
		PRIMARY KEY  (`tld_id`));";
	$dishInstallTLDs = mysql_query($dishInstallTLDsQ)
		or die("<p class=\"error\">Couldn't create script table, \"$dishDBtlds\"!<br />\n".mysql_error()."</p>");
	echo "<p class=\"success\">TLDs table, `$dishDBtlds` succesfully added!</p>";
}

/**************************************************************************************************
   INSERT TLDs IN TLDs TABLE FROM A DISTINCT SELECTION OF TLDs IN DOMAINS TABLE
**************************************************************************************************/
$tldsQ = "SELECT DISTINCT `domain_tld` FROM `$dishDBdomains`";
$tldsR = mysql_query($tldsQ) or die("<p class=\"error\">".mysql_error()."</p>");
while($tlds = mysql_fetch_assoc($tldsR)) {
	$tld = $tlds['domain_tld'];
	mysql_query("INSERT INTO `$dishDBtlds` (`tld_name`) VALUES ('$tld')") or die("<p class=\"error\">".mysql_error()."</p>");
}
echo "<p class=\"success\">TLDs were converted and succesfully inserted into `$dishDBtlds`!</p>";

/**************************************************************************************************
   REPLACE TLDs IN DOMAIN TABLE WITH CORRESPONDING IDs JUST INSERTED INTO TLDs TABLE
**************************************************************************************************/
$domainTLDsQ = "SELECT `id`,`domain_tld` FROM `$dishDBdomains`";
$domainTLDsR = mysql_query($domainTLDsQ);
while($domainTLDs = mysql_fetch_array($domainTLDsR)) {
	$domainID = $domainTLDs['id'];
	$domainTLD = $domainTLDs['domain_tld'];
	$tldIDQ = "SELECT `tld_id` FROM `$dishDBtlds` WHERE `tld_name` = '$domainTLD'";
	$tldIDR = mysql_query($tldIDQ)
		or die("<p class=\"error\">".mysql_error()."</p>");
	$tldID = mysql_result($tldIDR,0,0);
	$updateTLDQ = "UPDATE `$dishDBdomains` SET `domain_tld` = '$tldID' WHERE `id` = '$domainID' LIMIT 1";
	$updateTLD = mysql_query($updateTLDQ)
		or die("<p class=\"error\">".mysql_error()."</p>");
}
echo "<p class=\"success\">TLDs listed in the domains table were succesfully converted to their new corresponding TLD IDs!</p>";

$updateDishDBdomainsQ = mysql_query("ALTER TABLE `$dishDBdomains` CHANGE `id` `domain_id` int(6) NOT NULL AUTO_INCREMENT")
	or die("<p class=\"error\">".mysql_error()."</p>");
$updateDishDBdomainsQ = mysql_query("ALTER TABLE `$dishDBdomains` CHANGE `domain_tld` `domain_tld` int(6) NOT NULL")
	or die("<p class=\"error\">".mysql_error()."</p>");
$updateDishDBdomainsQ = mysql_query("ALTER TABLE `$dishDBdomains` CHANGE `domain_purpose` `domain_categories` varchar(255) NOT NULL")
	or die("<p class=\"error\">".mysql_error()."</p>");
$updateDishDBdomainsQ = mysql_query("ALTER TABLE `$dishDBdomains` CHANGE `domain_registrar` `domain_registrar` int(6) NOT NULL")
	or die("<p class=\"error\">".mysql_error()."</p>");
$updateDishDBdomainsQ = mysql_query("UPDATE `$dishDBdomains` SET `domain_status` = '0' WHERE `domain_status` = 'notforsale'")
	or die("<p class=\"error\">".mysql_error()."</p>");
$updateDishDBdomainsQ = mysql_query("UPDATE `$dishDBdomains` SET `domain_status` = '1' WHERE `domain_status` = 'forsale'")
	or die("<p class=\"error\">".mysql_error()."</p>");
$updateDishDBdomainsQ = mysql_query("ALTER TABLE `$dishDBdomains` CHANGE `domain_status` `domain_status` int(1) NOT NULL")
	or die("<p class=\"error\">".mysql_error()."</p>");
echo "<p class=\"success\">Domains table, `$dishDBdomains` succesfully updated!</p>";

include('footer.php');
?>