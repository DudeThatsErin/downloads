<?php
/**************************************************************************************************
Domainish 2.0b © 2009 to Hannah W of hannah.nu. All rights reserved. This script is linkware,
meaning that it may be used and modified as long as credit is provided to me. The script may not be
redistributed without permission. I am not responsible for any damage done to your website/server
while running this script. For support, mail girl@hannah.nu or check out @scriptish on Twitter.
**************************************************************************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>Domainish</title>
<link rel="stylesheet" href="style.css" type="text/css" media="screen" title="no title" charset="utf-8" />
</head>
<body>
	<div id="header">
		<h1><a href="index.php">Domainish</a></h1>
	</div>
	<div id="container">