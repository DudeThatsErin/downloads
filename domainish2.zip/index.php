<?php
/**************************************************************************************************
Domainish 2.0b © 2009 to Hannah W of hannah.nu. All rights reserved. This script is linkware,
meaning that it may be used and modified as long as credit is provided to me. The script may not be
redistributed without permission. I am not responsible for any damage done to your website/server
while running this script. For support, mail girl@hannah.nu or check out @scriptish on Twitter.
**************************************************************************************************/
require_once('config.php');
require_once('functions.php');
include('header.php');
?>
<?php
$domainQ = "SELECT * FROM `$dishDBdomains`";
$domainR = mysql_query($domainQ)
	or die("<p class=\"error\">".mysql_error()."</p>");
$domainCount = mysql_num_rows($domainR);

$domainCountForSaleQ = "SELECT * FROM `$dishDBdomains` WHERE `domain_status` = 1";
$domainCountForSaleQ = mysql_query($domainCountForSaleQ)
	or die("<p class=\"error\">".mysql_error()."</p>");
$domainCountForSale = mysql_num_rows($domainCountForSaleQ);
?>
<p>Here I have <?php echo $domainCount ?> domains listed with <a href="index.php?status=1"><?php echo $domainCountForSale ?> for sale</a>. If you are interested in any domains that are for sale, please email me at <strong><?php echo $dishEmail ?></strong>.</p>

<h2>Filter By...</h2>
<ul>
	<li><strong>Status:</strong> <a href="index.php?status=1">For Sale</a> &middot; <a href="index.php?status=0">Not For Sale</a></li>
	<li><strong>Category:</strong> <?php listCategories(); ?></li>
	<li><strong>Registrar:</strong> <?php listRegistrars(); ?></li>
	<li><strong>TLD:</strong> <?php listTLDs(); ?></li>
	<li><a href="index.php">...or just show all?</a></li>
</ul>

<h2>Domain List</h2>
<?php
if (isset($_GET['tld']) && !empty($_GET['tld']) && is_numeric($_GET['tld'])) {
	$qFilter = " WHERE `domain_tld` = '".$_GET['tld']."'";
	$sortURL = "?tld=".$_GET['tld']."&amp;sort=";
} elseif (isset($_GET['registrar']) && !empty($_GET['registrar']) && is_numeric($_GET['registrar'])) {
	$qFilter = " WHERE `domain_registrar` = '".$_GET['registrar']."'";
	$sortURL = "?registrar=".$_GET['registrar']."&amp;sort=";
} elseif (isset($_GET['category']) && !empty($_GET['category']) && is_numeric($_GET['category'])) {
	$qFilter = " WHERE `domain_categories` LIKE '%|".$_GET['category']."|%'";
	$sortURL = "?category=".$_GET['category']."&amp;sort=";
} elseif (isset($_GET['status']) && ($_GET['status'] == 1)) {
	$qFilter = " WHERE `domain_status` = 1";
	$sortURL = "?status=1&amp;sort=";
} elseif(isset($_GET['status']) && ($_GET['status'] == 0)) {
	$qFilter = " WHERE `domain_status` = 0";
	$sortURL = "?status=0&amp;sort=";
} else {
	$qFilter = "";
	$sortURL = "?sort=";
}

if (isset($_GET['sort']) && !empty($_GET['sort']))
	$sort = $_GET['sort'];
else
	$sort = "";

if(isset($sort) && !empty($sort) && isset($_GET['dir']) && !empty($_GET['dir']) && $_GET['dir'] == "desc")
	$queryDir = "DESC";
else
	$queryDir = "ASC";
	
if($sort == "tld")
	$qSort = " ORDER BY `domain_tld` $queryDir, `domain_name` $queryDir";
elseif($sort == "status")
	$qSort = " ORDER BY `domain_status` $queryDir, `domain_name` $queryDir, `domain_tld` $queryDir";
elseif($sort == "registrar")
	$qSort = " ORDER BY `domain_registrar` $queryDir, `domain_name` $queryDir, `domain_tld` $queryDir";
elseif($sort == "expiration")
	$qSort = " ORDER BY `domain_expiration` $queryDir, `domain_name` $queryDir, `domain_tld` $queryDir";
else
	$qSort = " ORDER BY `domain_name` $queryDir, `domain_tld` $queryDir ";

$domainQ = $domainQ.$qFilter.$qSort;
$domainR = mysql_query($domainQ)
	or die("<p class=\"error\">".mysql_error()."</p>");
$domainCountCurrent = mysql_num_rows($domainR);
if($domainCountCurrent > 0) {
?>
<table id="domains" cellpadding="0" cellspacing="0">
	<tr>
		<th>Domain Name <span class="sorting"><a href="index.php<?php echo $sortURL ?>name&amp;dir=asc" title="Sort By Name, Ascending (Default)">^</a> <a href="index.php<?php echo $sortURL ?>name&amp;dir=desc" title="Sort By Name, Descending">v</a></span></th>
		<th>Registrar <span class="sorting"><a href="index.php<?php echo $sortURL ?>registrar&amp;dir=asc" title="Sort By Registrar, Ascending">^</a> <a href="index.php<?php echo $sortURL ?>registrar&amp;dir=desc" title="Sort By Registrar, Descending">v</a></span></th>
		<th>Expires <span class="sorting"><a href="index.php<?php echo $sortURL ?>expiration&amp;dir=asc" title="Sort By Expiration Date, Ascending">^</a> <a href="index.php<?php echo $sortURL ?>expiration&amp;dir=desc" title="Sort By Expiration Date, Descending">v</a></span></th>
		<th>Status <span class="sorting"><a href="index.php<?php echo $sortURL ?>status&amp;dir=asc" title="Sort By Status, Ascending">^</a> <a href="index.php<?php echo $sortURL ?>status&amp;dir=desc" title="Sort By Status, Descending">v</a></span></th>
		<th>Categories</th>
		<th>&nbsp;</th>
		<th>&nbsp;</th>
	</tr>
<?php
	$i = 0;
	while($domain = mysql_fetch_array($domainR)) {
		$i++;
		if($domain['domain_status'] == 1)
			$domainStatus = "<strong>For Sale</strong>: ".$currency.$domain['domain_price'];
		elseif($domain['domain_status'] == 0)
			$domainStatus = "Not For Sale";
		$domainExpiration = strtotime($domain['domain_expiration']);
		$domainExpiration = date($dateFormat, $domainExpiration);
		$domainID = $domain['domain_id'];
		$domainName = $domain['domain_name'];
?>	
	<tr class="row<?php echo ($i & 1); ?>">
		<td><strong><?php echo "$domainName.".getTLD($domain['domain_tld']); ?></strong></td>
		<td><?php echo getRegistrar($domain['domain_registrar']); ?></td>
		<td><?php echo $domainExpiration; ?></td>
		<td><?php echo $domainStatus ?></td>
		<td><?php echo listDomainCategories($domain['domain_categories']); ?></td>
		<td class="icon"><a title="Whois for <?php echo "$domainName.".getTLD($domain['domain_tld']); ?>" href="http://whois.domaintools.com/<?php echo "$domainName.".getTLD($domain['domain_tld']); ?>"><img src="whois.png" alt="" /></a></td>
		<td class="icon"><a title="Visit <?php echo "$domainName.".getTLD($domain['domain_tld']); ?>" href="http://<?php echo "$domainName.".getTLD($domain['domain_tld']); ?>/"><img src="visit.png" alt="" /></a></td>
	</tr>
		<?php
	}
?>
</table>
<p>Showing <?php echo $domainCountCurrent ?> of <?php echo $domainCount ?> domains.</p>
<?php
} else {
?>
<p>No results found.</p>
<?php
}
include('footer.php');
?>