<?php
/**************************************************************************************************
Domainish 2.0b © 2009 to Hannah W of hannah.nu. All rights reserved. This script is linkware,
meaning that it may be used and modified as long as credit is provided to me. The script may not be
redistributed without permission. I am not responsible for any damage done to your website/server
while running this script. For support, mail girl@hannah.nu or check out @scriptish on Twitter.
**************************************************************************************************/

function getScriptVersion() {
	$version = "2.0.1";
	return $version;
}

function countDomains() {
	global $dishDBdomains;
	$numDomainsQ = "SELECT COUNT(`domain_id`) FROM `$dishDBdomains`";
	$numDomainsR = mysql_query($numDomainsQ)
		or die("<p class=\"error\">".mysql_error()."</p>");
	$numDomains = mysql_result($numDomainsR,0,0);
	return $numDomains;
}

function listCategories($filename = "index") {
	global $dishDBcategories;
	$categoriesQ = "SELECT `category_id`,`category_name` FROM `$dishDBcategories` ORDER BY `category_name` ASC";
	$categoriesR = mysql_query($categoriesQ)
		or die("<p class=\"error\">".mysql_error()."</p>");
	if(mysql_num_rows($categoriesR) > 0) {
		while($category = mysql_fetch_array($categoriesR))
			$categories1[] = "<a href=\"$filename.php?category=".$category['category_id']."\">".$category['category_name']."</a>";
		$categories2 = implode(' &middot; ', $categories1);
		echo $categories2;
	} else	
		echo "No categories in the database!";
}

function listRegistrars($filename = "index") {
	global $dishDBregistrars;
	$registrarsQ = "SELECT `registrar_id`,`registrar_name` FROM `$dishDBregistrars` ORDER BY `registrar_name` ASC";
	$registrarsR = mysql_query($registrarsQ)
		or die("<p class=\"error\">".mysql_error()."</p>");
	if(mysql_num_rows($registrarsR) > 0) {
		while($registrar = mysql_fetch_array($registrarsR))
			$registrars1[] = "<a href=\"$filename.php?registrar=".$registrar['registrar_id']."\">".$registrar['registrar_name']."</a>";
		$registrars2 = implode(' &middot; ', $registrars1);
		echo $registrars2;
	} else	
		echo "No registrars in the database!";
}

function listTLDs($filename = "index") {
	global $dishDBtlds;
	$tldsQ = "SELECT `tld_id`,`tld_name` FROM `$dishDBtlds` ORDER BY `tld_name` ASC";
	$tldsR = mysql_query($tldsQ)
		or die("<p class=\"error\">".mysql_error()."</p>");
	if(mysql_num_rows($tldsR) > 0) {
		while($tld = mysql_fetch_array($tldsR))
			$tlds1[] = "<a href=\"$filename.php?tld=".$tld['tld_id']."\">".$tld['tld_name']."</a>";
		$tlds2 = implode(' &middot; ', $tlds1);
		echo $tlds2;
	} else	
		echo "No TLDs in the database!";
}

function getDomainCategories($categoryIDs) {
	global $dishDBcategories;
	$categories = "NULL".$categoryIDs."NULL";
	$categoriesArray = array_unique(explode('|', $categories));
	$catNames = "";
	foreach ($categoriesArray as $category) {
		if(is_numeric($category)) {
			$catNameQ = "SELECT `category_name` FROM `$dishDBcategories` WHERE `category_id` = '$category'";
			$catNameR = mysql_query($catNameQ)
				or die("<p class=\"error\">".mysql_error()."</p>");
			$catNames[$category] = mysql_result($catNameR,0,0);
		}
	}
	return $catNames;
}

function listDomainCategories($categoryIDs) {
	$catNames = getDomainCategories($categoryIDs);
	if(is_array($catNames)) {
		$listDomainCategories = implode(', ',$catNames);
		return $listDomainCategories;
	} else
		return $catName;
}

function getRegistrar($registrarID) {
	global $dishDBregistrars;
	$registrarNameQ = "SELECT `registrar_name`,`registrar_url` FROM `$dishDBregistrars` WHERE `registrar_id` = '$registrarID'";
	$registrarNameR = mysql_query($registrarNameQ)
		or die("<p class=\"error\">".mysql_error()."</p>");
	$registrarArray = mysql_fetch_array($registrarNameR);
	$registrarName = $registrarArray['registrar_name'];
	$registrarURL = $registrarArray['registrar_url'];
	if(!empty($registrarURL))
		$registrar = "<a href=\"".$registrarArray['registrar_url']."\">".$registrarArray['registrar_name']."</a>";
	else
		$registrar = $registrarArray['registrar_name'];
	return $registrar;
}

function getTLD($tldID) {
	global $dishDBtlds;
	$tldQ = "SELECT `tld_name` FROM `$dishDBtlds` WHERE `tld_id` = '$tldID'";
	$tldR = mysql_query($tldQ)
		or die("<p class=\"error\">".mysql_error()."</p>");
	$tld = mysql_result($tldR,0,0);
	return $tld;
}
?>