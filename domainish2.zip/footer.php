<?php
/**************************************************************************************************
Domainish 2.0b © 2009 to Hannah W of hannah.nu. All rights reserved. This script is linkware,
meaning that it may be used and modified as long as credit is provided to me. The script may not be
redistributed without permission. I am not responsible for any damage done to your website/server
while running this script. For support, mail girl@hannah.nu or check out @scriptish on Twitter.
**************************************************************************************************/
?>
	</div>
	<div id="footer">
		<p>Powered by <a href="http://hannah.nu">Domainish <?php echo getScriptVersion(); ?></a> with icons by <a href="http://pinvoke.com">Pinvoke</a>.</p>
	</div>
</body>
</html>