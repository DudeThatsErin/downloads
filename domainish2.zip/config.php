<?php
/**************************************************************************************************
Domainish 2.0b © 2009 to Hannah W of hannah.nu. All rights reserved. This script is linkware,
meaning that it may be used and modified as long as credit is provided to me. The script may not be
redistributed without permission. I am not responsible for any damage done to your website/server
while running this script. For support, mail girl@hannah.nu or check out @scriptish on Twitter.
**************************************************************************************************/
$dishUser = md5("admin");
// username to login to the admin panel
$dishPass = md5("password");
// password for the admin panel
$dishSalt = md5("3048y3w49ht6395ht0384t394yt634605y9eh508eg5y9eg49ge4ge0ge");
// like a password, but you don't have to remember it...
// make it long and random with various letters, numbers and characters

$dishDBhostname = "localhost";
// mysql hostname, usually localhost- if not, contact your host
$dishDBusername = "username_username";
// mysql username that has priviledges to access your database
$dishDBpassword = "password";
// mysql password to get the user access to the database
$dishDBdatabase = "username_database";
// mysql database you want domainish to use

$dishDBdomains = "domainish";
// mysql database table that holds the domains
$dishDBcategories = "domainish_categories";
// mysql database table that holds the domains' categories (previously called purposes)
$dishDBregistrars = "domainish_registrars";
// mysql database table that holds domain registrars and some info on them
$dishDBtlds = "domainish_tlds";
// mysql database table that holds TLDs (example: .com, .net, .org, .nu)

// $tldArray = array('com','net','org','us','me','name','nu');
// all of the TLDs you will be using, in single quotes and separated by commas
// $registrarArray = array('GoDaddy','NameCheap');
// all of the domain registrars you will be using, in single quotes and separated by commas
// $purposeArray = array('blog','collective','portfolio','unused');
// all of the purposes or categories of the domains, in single quotes and separated by commas
$dateFormat = "m/d/Y";
// see php.net/date for formatting
$dishEmail = "you@yourdomain.com";
// email to be used as a contact for "for sale" domains
$currency = "$";
// your currency symbol to use with domain prices

$domainConnect = mysql_connect($dishDBhostname,$dishDBusername,$dishDBpassword)
or die('Unable to connect to the mysql server!<br />\n'.mysql_error());
mysql_select_db($dishDBdatabase, $domainConnect)
or die("Unable to select the database, '$dishDBdatabase'.<br />\n".mysql_error());
?>