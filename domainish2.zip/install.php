<?php
/**************************************************************************************************
Domainish 2.0b © 2009 to Hannah W of hannah.nu. All rights reserved. This script is linkware,
meaning that it may be used and modified as long as credit is provided to me. The script may not be
redistributed without permission. I am not responsible for any damage done to your website/server
while running this script. For support, mail girl@hannah.nu or check out @scriptish on Twitter.
**************************************************************************************************/
require_once('config.php');
require_once('functions.php');
include('header.php');

if (empty($dishDBhostname) || empty($dishDBusername) || empty($dishDBdatabase) || empty($dishDBdomains))
	exit("You must fill out all of the database information in config.php.");

/**************************************************************************************************
   INSTALL DOMAINS TABLE
**************************************************************************************************/
if(mysql_query("SELECT * FROM $dishDBdomains"))
	echo "<p class=\"error\">Table '$dishDBdomains' already installed!</p>";
else {
	$dishInstallQ = "CREATE TABLE `$dishDBdomains` (
		`domain_id` int(6) NOT NULL auto_increment,
		`domain_name` varchar(255) NOT NULL,
		`domain_tld` int(6) NOT NULL,
		`domain_status` int(1) NOT NULL,
		`domain_price` int(20) NOT NULL,
		`domain_categories` varchar(255) NOT NULL,
		`domain_registrar` int(6) NOT NULL,
		`domain_expiration` datetime NOT NULL,
		PRIMARY KEY  (`domain_id`));";
	$dishInstall = mysql_query($dishInstallQ)
		or die("<p class=\"error\">Couldn't create script table, \"$dishDBdomains\"!<br />\n".mysql_error()."</p>");
	echo "<p class=\"success\">Domains table, `$dishDBdomains` succesfully added!</p>";
}

/**************************************************************************************************
   INSTALL CATEGORIES TABLE
**************************************************************************************************/
if(mysql_query("SELECT * FROM `$dishDBcategories`"))
	echo "<p class=\"error\">Table '$dishDBcategories' already installed!</p>";
else {
	$dishInstallCategoriesQ = "CREATE TABLE `$dishDBcategories` (
		`category_id` int(6) NOT NULL auto_increment,
		`category_name` varchar(255) NOT NULL,
		PRIMARY KEY  (`category_id`));";
	$dishInstallCategories = mysql_query($dishInstallCategoriesQ)
		or die("<p class=\"error\">Couldn't create script table, \"$dishDBcategories\"!<br />\n".mysql_error()."</p>");
	echo "<p class=\"success\">Categories table, `$dishDBcategories` succesfully added!</p>";
}

/**************************************************************************************************
   INSTALL REGISTRARS TABLE
**************************************************************************************************/
if(mysql_query("SELECT * FROM `$dishDBregistrars`"))
	echo "<p class=\"error\">Table '$dishDBregistrars' already installed!</p>";
else {
	$dishInstallRegistrarsQ = "CREATE TABLE `$dishDBregistrars` (
		`registrar_id` int(6) NOT NULL auto_increment,
		`registrar_name` varchar(255) NOT NULL,
		`registrar_url` varchar(255) NOT NULL,
		PRIMARY KEY  (`registrar_id`));";
	$dishInstallRegistrars = mysql_query($dishInstallRegistrarsQ)
		or die("<p class=\"error\">Couldn't create script table, \"$dishDBregistrars\"!<br />\n".mysql_error()."</p>");
	echo "<p class=\"success\">Registrars table, `$dishDBregistrars` succesfully added!</p>";
}

/**************************************************************************************************
   INSTALL TLDs TABLE
**************************************************************************************************/
if(mysql_query("SELECT * FROM `$dishDBtlds`"))
	echo "<p class=\"error\">Table '$dishDBtlds' already installed!</p>";
else {
	$dishInstallTLDsQ = "CREATE TABLE `$dishDBtlds` (
		`tld_id` int(6) NOT NULL auto_increment,
		`tld_name` varchar(255) NOT NULL,
		PRIMARY KEY  (`tld_id`));";
	$dishInstallTLDs = mysql_query($dishInstallTLDsQ)
		or die("<p class=\"error\">Couldn't create script table, \"$dishDBtlds\"!<br />\n".mysql_error()."</p>");
	echo "<p class=\"success\">TLDs table, `$dishDBtlds` succesfully added!</p>";
}

include('footer.php');
?>