<?php
/**************************************************************************************************
Domainish 2.0b © 2009 to Hannah W of hannah.nu. All rights reserved. This script is linkware,
meaning that it may be used and modified as long as credit is provided to me. The script may not be
redistributed without permission. I am not responsible for any damage done to your website/server
while running this script. For support, mail girl@hannah.nu or check out @scriptish on Twitter.
**************************************************************************************************/
require_once('config.php');
require_once('functions.php');
if (!isset($_COOKIE[$dishUser])) {
	header('Location: login.php');
	exit;
} else if($_COOKIE[$dishUser] != md5($dishPass.$dishSalt)) {
	header('Location: login.php');
	exit;
} else if ($_COOKIE[$dishUser] == md5($dishPass.$dishSalt)) {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>Domainish</title>
<link rel="stylesheet" href="admin.css" type="text/css" media="screen" title="no title" charset="utf-8" />
<script type="text/javascript" charset="utf-8">
function toggleFormField(evt) {
    evt = (evt) ? evt : event;
    var target = (evt.target) ? evt.target : evt.srcElement;
    var block = document.getElementById("domain_price");
    if (target.id == "forsale") {
        block.style.display = "block";
    } else {
        block.style.display = "none";  
    }
}
</script>
</head>
<body>
	<div id="header">
		<h1><a href="admin.php">Domainish Admin</a></h1>
		<ul id="menu">
			<li><a href="admin.php?manage=categories">Categories</a></li>
			<li><a href="admin.php?manage=registrars">Registrars</a></li>
			<li><a href="admin.php?manage=tlds">TLDs</a></li>
			<li><a href="login.php?action=logout">Logout</a></li>
		</ul>
		<div class="clear"></div>
	</div>
	<div id="container">
		<?php
		$manageArray = array('categories','registrars','tlds','domains');
		if( isset($_GET['manage']) && !empty($_GET['manage']) && in_array($_GET['manage'],$manageArray) )
			$manage = $_GET['manage'];
		else
			$manage = "domains";
			
		switch($manage) {
			case "domains":
			?>
			<h2>Manage Domains (<a href="admin.php?manage=domains&amp;action=add">Add New?</a>)</h2>
			<?php
			$actionArray = array('add','edit','delete');
			if( isset($_GET['action']) && !empty($_GET['action']) && in_array($_GET['action'],$actionArray) )
				$action = $_GET['action'];
			else
				$action = "";
			
			switch($action) {
			default:
			?>
				<h3>Filter By...</h3>
				<ul>
					<li><strong>Status:</strong> <a href="admin.php?status=1">For Sale</a> &middot; <a href="admin.php?status=0">Not For Sale</a></li>
					<li><strong>Category:</strong> <?php listCategories('admin'); ?></li>
					<li><strong>Registrar:</strong> <?php listRegistrars('admin'); ?></li>
					<li><strong>TLD:</strong> <?php listTLDs('admin'); ?></li>
					<li><a href="admin.php">...or just show all?</a></li>
				</ul>
				
				<h3>Domain List</h3>
				<?php
				if (isset($_GET['tld']) && !empty($_GET['tld']) && is_numeric($_GET['tld'])) {
					$qFilter = " WHERE `domain_tld` = '".$_GET['tld']."'";
					$sortURL = "?tld=".$_GET['tld']."&amp;sort=";
				} elseif (isset($_GET['registrar']) && !empty($_GET['registrar']) && is_numeric($_GET['registrar'])) {
					$qFilter = " WHERE `domain_registrar` = '".$_GET['registrar']."'";
					$sortURL = "?registrar=".$_GET['registrar']."&amp;sort=";
				} elseif (isset($_GET['category']) && !empty($_GET['category']) && is_numeric($_GET['category'])) {
					$qFilter = " WHERE `domain_categories` LIKE '%|".$_GET['category']."|%'";
					$sortURL = "?category=".$_GET['category']."&amp;sort=";
				} elseif (isset($_GET['status']) && ($_GET['status'] == 1)) {
					$qFilter = " WHERE `domain_status` = 1";
					$sortURL = "?status=1&amp;sort=";
				} elseif(isset($_GET['status']) && ($_GET['status'] == 0)) {
					$qFilter = " WHERE `domain_status` = 0";
					$sortURL = "?status=0&amp;sort=";
				} else {
					$qFilter = "";
					$sortURL = "?sort=";
				}

				if (isset($_GET['sort']) && !empty($_GET['sort']))
					$sort = $_GET['sort'];
				else
					$sort = "";

				if(isset($sort) && !empty($sort) && isset($_GET['dir']) && !empty($_GET['dir']) && $_GET['dir'] == "desc")
					$queryDir = "DESC";
				else
					$queryDir = "ASC";

				if($sort == "tld")
					$qSort = " ORDER BY `domain_tld` $queryDir, `domain_name` $queryDir";
				elseif($sort == "status")
					$qSort = " ORDER BY `domain_status` $queryDir, `domain_name` $queryDir, `domain_tld` $queryDir";
				elseif($sort == "registrar")
					$qSort = " ORDER BY `domain_registrar` $queryDir, `domain_name` $queryDir, `domain_tld` $queryDir";
				elseif($sort == "expiration")
					$qSort = " ORDER BY `domain_expiration` $queryDir, `domain_name` $queryDir, `domain_tld` $queryDir";
				else
					$qSort = " ORDER BY `domain_name` $queryDir, `domain_tld` $queryDir ";
					
				$domainQ = "SELECT * FROM `$dishDBdomains`";
				$domainR = mysql_query($domainQ)
					or die("<p class=\"error\">".mysql_error()."</p>");
				$domainCount = mysql_num_rows($domainR);
				
				$domainQ = $domainQ.$qFilter.$qSort;
				$domainR = mysql_query($domainQ)
					or die("<p class=\"error\">".mysql_error()."</p>");
				$domainCountCurrent = mysql_num_rows($domainR);
				
				if($domainCountCurrent > 0) {
				?>
				<table id="admindomains" cellpadding="0" cellspacing="0">
					<tr>
						<th>Domain Name <span class="sorting"><a href="admin.php<?php echo $sortURL; ?>name&amp;dir=asc" title="Sort By Name, Ascending (Default)">^</a> <a href="admin.php<?php echo $sortURL; ?>name&amp;dir=desc" title="Sort By Name, Descending">v</a></span></th>
						<th>Registrar <span class="sorting"><a href="admin.php<?php echo $sortURL; ?>registrar&amp;dir=asc" title="Sort By Registrar, Ascending">^</a> <a href="admin.php<?php echo $sortURL; ?>registrar&amp;dir=desc" title="Sort By Registrar, Descending">v</a></span></th>
						<th>Expires <span class="sorting"><a href="admin.php<?php echo $sortURL ?>expiration&amp;dir=asc" title="Sort By Expiration Date, Ascending">^</a> <a href="admin.php<?php echo $sortURL ?>expiration&amp;dir=desc" title="Sort By Expiration Date, Descending">v</a></span></th>
						<th>Status <span class="sorting"><a href="admin.php<?php echo $sortURL ?>status&amp;dir=asc" title="Sort By Status, Ascending">^</a> <a href="admin.php<?php echo $sortURL ?>status&amp;dir=desc" title="Sort By Status, Descending">v</a></span></th>
						<th>Categories</th>
						<th colspan="4">&nbsp;</th>
					</tr>
				<?php
					$i = 0;
					while($domain = mysql_fetch_array($domainR)) {
						$i++;
						if($domain['domain_status'] == 1)
							$domainStatus = "<strong>For Sale</strong>: ".$currency.$domain['domain_price'];
						elseif($domain['domain_status'] == 0)
							$domainStatus = "Not For Sale";
						$domainExpiration = strtotime($domain['domain_expiration']);
						$domainExpiration = date($dateFormat, $domainExpiration);
						$domainID = $domain['domain_id'];
						$domainName = $domain['domain_name'];
				?>	
					<tr class="row<?php echo ($i & 1); ?>">
						<td><strong><?php echo "$domainName.".getTLD($domain['domain_tld']); ?></strong></td>
						<td><?php echo getRegistrar($domain['domain_registrar']); ?></td>
						<td><?php echo $domainExpiration; ?></td>
						<td><?php echo $domainStatus ?></td>
						<td><?php echo listDomainCategories($domain['domain_categories']); ?></td>
						<td class="icon"><a title="Whois for <?php echo "$domainName.".getTLD($domain['domain_tld']); ?>" href="http://whois.domaintools.com/<?php echo "$domainName.".getTLD($domain['domain_tld']); ?>"><img src="whois.png" alt="" /></a></td>
						<td class="icon"><a title="Edit <?php echo "$domainName.".getTLD($domain['domain_tld']); ?>" href="admin.php?manage=domains&amp;action=edit&amp;id=<?php echo $domain['domain_id']; ?>"><img src="edit.png" alt="" /></a></td>
						<td class="icon"><a title="Delete <?php echo "$domainName.".getTLD($domain['domain_tld']); ?>" href="admin.php?manage=domains&amp;action=delete&amp;id=<?php echo $domain['domain_id']; ?>"><img src="delete.png" alt="" /></a></td>
						<td class="icon"><a title="Visit <?php echo "$domainName.".getTLD($domain['domain_tld']); ?>" href="http://<?php echo "$domainName.".getTLD($domain['domain_tld']); ?>/" onclick="return confirm('Are you sure you want to delete this domain?')"><img src="visit.png" alt="" /></a></td>
					</tr>
				<?php
					}
				?>
				</table>
				<p>Showing <?php echo $domainCountCurrent ?> of <?php echo $domainCount ?> domains.</p>
				<?php
				} else {
				?>
				<p>No results found.</p>
				<?php
				}
				
				break;
				case "add":
					$showForm = true;
					if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['submit'])) {
						$domainName = $_POST['domain_name'];
						$domainTLD = (int)$_POST['domain_tld'];
						$domainStatus = (int)$_POST['domain_status'];
						$domainPrice = (int)$_POST['domain_price'];
						$domainRegistrar = (int)$_POST['domain_registrar'];
						if(empty($domainName))
							$errors[] = "You did not fill out the domain name field.";
						if($domainTLD == 0)
							$errors[] = "You did not fill pick a valid TLD.";
						if(empty($domainPrice) && $domainStatus == 1)
							$errors[] = "You did not supply a valid price.";
						if(empty($_POST['domain_categories']) || $_POST['domain_categories'] == "0")
							$errors[] = "You did not pick any categories (you have to have at least one).";
						if(is_array($_POST['domain_categories'])) 
							$domainCategories = "|".implode("|",$_POST['domain_categories'])."|";
						else
							$domainCategories = "|".$_POST['domain_categories']."|";
						if(empty($domainRegistrar) || $domainRegistrar == 0)
							$errors[] = "You did not fill pick a valid registrar.";
						if(!is_numeric($_POST['expirationmonth']) && !is_numeric($_POST['expirationday']) && !is_numeric($_POST['expirationyear']))
							$errors[] = "Invalid expiration date provided.";
						else
							$expirationDate = $_POST['expirationyear']."-".$_POST['expirationmonth']."-".$_POST['expirationday']." 00:00:00";
						if($domainStatus == 0)
							$domainPrice = 0;
						if(isset($errors) && is_array($errors)) {
							foreach($errors as $error)
								echo "<p class=\"error\">$error</p>\n";
						} else {
							$insertDomainQ = "INSERT INTO `$dishDBdomains` (`domain_name`,`domain_tld`,`domain_status`,`domain_price`,`domain_categories`,`domain_registrar`,`domain_expiration`) VALUES ('$domainName','$domainTLD','$domainStatus','$domainPrice','$domainCategories','$domainRegistrar','$expirationDate');";
							$insertDomainR = mysql_query($insertDomainQ)
								or die("<p class=\"error\">".mysql_error()."</p>");
							$displayTLD = getTLD($domainTLD);
							echo "<p class=\"success\">The domain <strong>\"$domainName.$displayTLD\"</strong> was successfully added! <a href=\"admin.php?manage=domains\">Go back?</a></p>";
							$showForm = false;
						}
					}
					if($showForm === true) {
						?>
						<h2>Add a Domain</h2>
						<form manage="admin.php?manage=domains&amp;action=add" method="post">
							<p>
								<label>Domain Name</label>
								<input type="text" name="domain_name" id="domain_name" value="<?php if(isset($domainName)) echo $domainName; ?>" />
							</p>
							<p>
								<label>Domain TLD</label>
								<select name="domain_tld" id="domain_tld">
									<option value="0">Select One</option>
									<?php
									$tldsQ = "SELECT * FROM `$dishDBtlds` ORDER BY `tld_name` ASC";
									$tldsR = mysql_query($tldsQ)
										or die("<p class=\"error\">".mysql_error()."</p>");
									while($tld = mysql_fetch_array($tldsR)) {
									?>
									<option value="<?php echo $tld['tld_id']; ?>"<?php if(isset($domainTLD) && $domainTLD == $tld['tld_id']) echo ' selected="selected"'; ?>><?php echo $tld['tld_name']; ?></option>	
									<?php
									}
									?>
								</select>
							</p>
							<p>
								<label>Domain Status</label>
								<select name="domain_status" id="domain_status">
									<option value="0" id="notforsale" onclick="toggleFormField(event)"<?php if(isset($domainStatus) && $domainStatus == 0) echo' selected="selected"'; ?>>Not For Sale</option>
									<option value="1" id="forsale" onclick="toggleFormField(event)"<?php if(isset($domainStatus) && $domainStatus == 1) echo' selected="selected"'; ?>>For Sale</option>
								</select>
								<div id="domain_price" style="display:<?php if(isset($domainStatus) && $domainStatus == 1) echo 'block'; else echo 'none'; ?>">
									<p>
										<label>Domain Price</label>
										<input type="text" name="domain_price" id="domain_price" value="<?php if(isset($domainPrice)) echo $domainPrice; ?>" />
									</p>
								</div>
							</p>
							<p>
								<label>Domain Categories:</label>
								<select name="domain_categories[]" id="domain_categories" multiple="multiple" class="selectmultiple">
									<option value="0">Select One</option>
									<?php
									$categoriesQ = "SELECT * FROM `$dishDBcategories` ORDER BY `category_name` ASC";
									$categoriesR = mysql_query($categoriesQ)
										or die("<p class=\"error\">".mysql_error()."</p>");
									while($category = mysql_fetch_array($categoriesR)) {
										if(isset($domainCategories))
											$searchCategory = "|".$category['category_id']."|";
									?>
									<option value="<?php echo $category['category_id']; ?>"<?php if(isset($domainCategories) && strstr($domainCategories,$searchCategory)) echo ' selected="selected"'; ?>><?php echo $category['category_name']; ?></option>	
									<?php
									}
									?>
								</select>
							</p>
							<p>
								<label>Domain Registrar</label>
								<select name="domain_registrar" id="domain_registrar">
									<option value="0">Select One</option>
									<?php
									$registrarsQ = "SELECT `registrar_id`,`registrar_name` FROM `$dishDBregistrars` ORDER BY `registrar_name` ASC";
									$registrarsR = mysql_query($registrarsQ)
										or die("<p class=\"error\">".mysql_error()."</p>");
									while($registrar = mysql_fetch_array($registrarsR)) {
									?>
									<option value="<?php echo $registrar['registrar_id']; ?>"<?php if(isset($domainRegistrar) && $domainRegistrar == $registrar['registrar_id']) echo ' selected="selected"'; ?>><?php echo $registrar['registrar_name']; ?></option>	
									<?php
									}
									?>
								</select>
							</p>
							<p>
								<?php
								$time = strtotime($expirationDate);
								$month = date('m', $time);
								$day = date('d', $time);
								$year = date('Y', $time);
								?>
								<label>Expiration Date</label>
								<select name="expirationmonth" id="expirationmonth">
									<option value="01"<?php if($month == "01") echo ' selected="selected"'; ?>>January</option>
									<option value="02"<?php if($month == "02") echo ' selected="selected"'; ?>>February</option>
									<option value="03"<?php if($month == "03") echo ' selected="selected"'; ?>>March</option>
									<option value="04"<?php if($month == "04") echo ' selected="selected"'; ?>>April</option>
									<option value="05"<?php if($month == "05") echo ' selected="selected"'; ?>>May</option>
									<option value="06"<?php if($month == "06") echo ' selected="selected"'; ?>>June</option>
									<option value="07"<?php if($month == "07") echo ' selected="selected"'; ?>>July</option>
									<option value="08"<?php if($month == "08") echo ' selected="selected"'; ?>>August</option>
									<option value="09"<?php if($month == "09") echo ' selected="selected"'; ?>>September</option>
									<option value="10"<?php if($month == "10") echo ' selected="selected"'; ?>>October</option>
									<option value="11"<?php if($month == "11") echo ' selected="selected"'; ?>>November</option>
									<option value="12"<?php if($month == "12") echo ' selected="selected"'; ?>>December</option>
								</select>
								<select name="expirationday" id="expirationday">
									<option value="01"<?php if($day == "01") echo ' selected="selected"'; ?>>01</option>
									<option value="02"<?php if($day == "02") echo ' selected="selected"'; ?>>02</option>
									<option value="03"<?php if($day == "03") echo ' selected="selected"'; ?>>03</option>
									<option value="04"<?php if($day == "04") echo ' selected="selected"'; ?>>04</option>
									<option value="05"<?php if($day == "05") echo ' selected="selected"'; ?>>05</option>
									<option value="06"<?php if($day == "06") echo ' selected="selected"'; ?>>06</option>
									<option value="07"<?php if($day == "07") echo ' selected="selected"'; ?>>07</option>
									<option value="08"<?php if($day == "08") echo ' selected="selected"'; ?>>08</option>
									<option value="09"<?php if($day == "09") echo ' selected="selected"'; ?>>09</option>
									<option value="10"<?php if($day == "10") echo ' selected="selected"'; ?>>10</option>
									<option value="11"<?php if($day == "11") echo ' selected="selected"'; ?>>11</option>
									<option value="12"<?php if($day == "12") echo ' selected="selected"'; ?>>12</option>
									<option value="13"<?php if($day == "13") echo ' selected="selected"'; ?>>13</option>
									<option value="14"<?php if($day == "14") echo ' selected="selected"'; ?>>14</option>
									<option value="15"<?php if($day == "15") echo ' selected="selected"'; ?>>15</option>
									<option value="16"<?php if($day == "16") echo ' selected="selected"'; ?>>16</option>
									<option value="17"<?php if($day == "17") echo ' selected="selected"'; ?>>17</option>
									<option value="18"<?php if($day == "18") echo ' selected="selected"'; ?>>18</option>
									<option value="19"<?php if($day == "19") echo ' selected="selected"'; ?>>19</option>
									<option value="20"<?php if($day == "20") echo ' selected="selected"'; ?>>20</option>
									<option value="21"<?php if($day == "21") echo ' selected="selected"'; ?>>21</option>
									<option value="22"<?php if($day == "22") echo ' selected="selected"'; ?>>22</option>
									<option value="23"<?php if($day == "23") echo ' selected="selected"'; ?>>23</option>
									<option value="24"<?php if($day == "24") echo ' selected="selected"'; ?>>24</option>
									<option value="25"<?php if($day == "25") echo ' selected="selected"'; ?>>25</option>
									<option value="26"<?php if($day == "26") echo ' selected="selected"'; ?>>26</option>
									<option value="27"<?php if($day == "27") echo ' selected="selected"'; ?>>27</option>
									<option value="28"<?php if($day == "28") echo ' selected="selected"'; ?>>28</option>
									<option value="29"<?php if($day == "29") echo ' selected="selected"'; ?>>29</option>
									<option value="30"<?php if($day == "30") echo ' selected="selected"'; ?>>30</option>
									<option value="31"<?php if($day == "31") echo ' selected="selected"'; ?>>31</option>
								</select>
								<select name="expirationyear" id="expirationyear">
									<option value="2009"<?php if($year == "2009") echo ' selected="selected"'; ?>>2009</option>
									<option value="2010"<?php if($year == "2010") echo ' selected="selected"'; ?>>2010</option>
									<option value="2011"<?php if($year == "2011") echo ' selected="selected"'; ?>>2011</option>
									<option value="2012"<?php if($year == "2012") echo ' selected="selected"'; ?>>2012</option>
									<option value="2013"<?php if($year == "2013") echo ' selected="selected"'; ?>>2013</option>
									<option value="2014"<?php if($year == "2014") echo ' selected="selected"'; ?>>2014</option>
									<option value="2015"<?php if($year == "2015") echo ' selected="selected"'; ?>>2015</option>
									<option value="2016"<?php if($year == "2016") echo ' selected="selected"'; ?>>2016</option>
									<option value="2017"<?php if($year == "2017") echo ' selected="selected"'; ?>>2017</option>
									<option value="2018"<?php if($year == "2018") echo ' selected="selected"'; ?>>2018</option>
									<option value="2019"<?php if($year == "2019") echo ' selected="selected"'; ?>>2019</option>
								</select>
							</p>
							<p><input type="submit" name="submit" id="submit" value="Submit &rarr;" /></p>
						</form>
						<?php
					}
				break;
				case "edit":
					if(!isset($_GET['id']) || empty($_GET['id']) || !is_numeric($_GET['id']))
						exit("Invalid ID provided.");
					else
						$id = $_GET['id'];
						
					$domainQ = "SELECT * FROM `$dishDBdomains` WHERE `domain_id` = '$id'";
					$domainR = mysql_query($domainQ)
						or die("<p class=\"error\">".mysql_error()."</p>");
					$domain = mysql_fetch_array($domainR);
					$domainName = $domain['domain_name'];
				 	$domainTLD = $domain['domain_tld'];
					$displayTLD = getTLD($domainTLD);
					$domainStatus = $domain['domain_status'];
					$domainPrice = $domain['domain_price'];
					$domainCategories = $domain['domain_categories'];
					$domainRegistrar = $domain['domain_registrar'];
					$expirationDate = $domain['domain_expiration'];
					?>
					<h2>Editing <?php echo "$domainName.$displayTLD"; ?></h2>
					<?php
					$showForm = true;
					if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['submit'])) {
						$domainName = $_POST['domain_name'];
						$domainTLD = (int)$_POST['domain_tld'];
						$domainStatus = (int)$_POST['domain_status'];
						$domainPrice = (int)$_POST['domain_price'];
						$domainRegistrar = (int)$_POST['domain_registrar'];
						if(empty($domainName))
							$errors[] = "You did not fill out the domain name field.";
						if($domainTLD == 0)
							$errors[] = "You did not fill pick a valid TLD.";
						if(empty($domainPrice) && $domainStatus == 1)
							$errors[] = "You did not supply a valid price.";
						if(!is_array($_POST['domain_categories']) && is_numeric($_POST['domain_categories'])) 
							$domainCategories = "|".$_POST['domain_categories']."|";
						else
							$domainCategories = "|".implode("|",$_POST['domain_categories'])."|";
						if(empty($domainRegistrar) || $domainRegistrar == 0)
							$errors[] = "You did not fill pick a valid registrar.";
						if(!is_numeric($_POST['expirationmonth']) && !is_numeric($_POST['expirationday']) && !is_numeric($_POST['expirationyear']))
							$errors[] = "Invalid expiration date provided.";
						else
							$expirationDate = $_POST['expirationyear']."-".$_POST['expirationmonth']."-".$_POST['expirationday']." 00:00:00";
						if($domainStatus == 0)
							$domainPrice = 0;
						if(isset($errors) && is_array($errors)) {
							foreach($errors as $error)
								echo "<p class=\"error\">$error</p>\n";
						} else {
							$updateDomainQ = "UPDATE `$dishDBdomains` SET `domain_name` = '$domainName',`domain_tld` = '$domainTLD',`domain_status` = '$domainStatus',`domain_price` = '$domainPrice',`domain_categories` = '$domainCategories',`domain_registrar` = '$domainRegistrar',`domain_expiration` = '$expirationDate' WHERE `domain_id` = '$id'";
							$updateDomainR = mysql_query($updateDomainQ)
								or die("<p class=\"error\">".mysql_error()."</p>");
							echo "<p class=\"success\">The domain <strong>\"$domainName.$displayTLD\"</strong> was successfully updated! <a href=\"admin.php?manage=domains\">Go back?</a></p>";
							$showForm = false;
						}
					}
					if($showForm === true) {
					?>
					<form manage="admin.php?manage=domains&amp;action=edit&amp;id=<?php echo $id ?>" method="post">
						<p>
							<label>Domain Name</label>
							<input type="text" name="domain_name" id="domain_name" value="<?php echo $domainName ?>" />
						</p>
						<p>
							<label>Domain TLD</label>
							<select name="domain_tld" id="domain_tld">
								<option value="0">Select One</option>
								<?php
								$tldsQ = "SELECT * FROM `$dishDBtlds` ORDER BY `tld_name` ASC";
								$tldsR = mysql_query($tldsQ)
									or die("<p class=\"error\">".mysql_error()."</p>");
								while($tld = mysql_fetch_array($tldsR)) {
								?>
								<option value="<?php echo $tld['tld_id']; ?>"<?php if($domainTLD == $tld['tld_id']) echo ' selected="selected"'; ?>><?php echo $tld['tld_name']; ?></option>	
								<?php
								}
								?>
							</select>
						</p>
						<p>
							<label>Domain Status</label>
							<select name="domain_status" id="domain_status">
								<option value="0" id="notforsale" onclick="toggleFormField(event)"<?php if($domainStatus == 0) echo' selected="selected"'; ?>>Not For Sale</option>
								<option value="1" id="forsale" onclick="toggleFormField(event)"<?php if($domainStatus == 1) echo' selected="selected"'; ?>>For Sale</option>
							</select>
							<div id="domain_price" style="display:<?php if($domainStatus == 1) echo 'block'; else echo 'none'; ?>">
								<p>
									<label>Domain Price</label>
									<input type="text" name="domain_price" id="domain_price" value="<?php echo $domainPrice ?>" />
								</p>
							</div>
						</p>
						<p>
							<label>Domain Categories:</label>
							<select name="domain_categories[]" id="domain_categories" multiple="multiple" class="selectmultiple">
								<option value="0">Select One</option>
								<?php
								$categoriesQ = "SELECT * FROM `$dishDBcategories` ORDER BY `category_name` ASC";
								$categoriesR = mysql_query($categoriesQ)
									or die("<p class=\"error\">".mysql_error()."</p>");
								while($category = mysql_fetch_array($categoriesR)) {
									$searchCategory = "|".$category['category_id']."|";
								?>
								<option value="<?php echo $category['category_id']; ?>"<?php if(strstr($domainCategories,$searchCategory)) echo ' selected="selected"'; ?>><?php echo $category['category_name']; ?></option>	
								<?php
								}
								?>
							</select>
						</p>
						<p>
							<label>Domain Registrar</label>
							<select name="domain_registrar" id="domain_registrar">
								<option value="0">Select One</option>
								<?php
								$registrarsQ = "SELECT `registrar_id`,`registrar_name` FROM `$dishDBregistrars` ORDER BY `registrar_name` ASC";
								$registrarsR = mysql_query($registrarsQ)
									or die("<p class=\"error\">".mysql_error()."</p>");
								while($registrar = mysql_fetch_array($registrarsR)) {
								?>
								<option value="<?php echo $registrar['registrar_id']; ?>"<?php if($domainRegistrar == $registrar['registrar_id']) echo ' selected="selected"'; ?>><?php echo $registrar['registrar_name']; ?></option>	
								<?php
								}
								?>
							</select>
						</p>
						<p>
							<?php
							$time = strtotime($expirationDate);
							$month = date('m', $time);
							$day = date('d', $time);
							$year = date('Y', $time);
							?>
							<label>Expiration Date</label>
							<select name="expirationmonth" id="expirationmonth">
								<option value="01"<?php if($month == "01") echo ' selected="selected"'; ?>>January</option>
								<option value="02"<?php if($month == "02") echo ' selected="selected"'; ?>>February</option>
								<option value="03"<?php if($month == "03") echo ' selected="selected"'; ?>>March</option>
								<option value="04"<?php if($month == "04") echo ' selected="selected"'; ?>>April</option>
								<option value="05"<?php if($month == "05") echo ' selected="selected"'; ?>>May</option>
								<option value="06"<?php if($month == "06") echo ' selected="selected"'; ?>>June</option>
								<option value="07"<?php if($month == "07") echo ' selected="selected"'; ?>>July</option>
								<option value="08"<?php if($month == "08") echo ' selected="selected"'; ?>>August</option>
								<option value="09"<?php if($month == "09") echo ' selected="selected"'; ?>>September</option>
								<option value="10"<?php if($month == "10") echo ' selected="selected"'; ?>>October</option>
								<option value="11"<?php if($month == "11") echo ' selected="selected"'; ?>>November</option>
								<option value="12"<?php if($month == "12") echo ' selected="selected"'; ?>>December</option>
							</select>
							<select name="expirationday" id="expirationday">
								<option value="01"<?php if($day == "01") echo ' selected="selected"'; ?>>01</option>
								<option value="02"<?php if($day == "02") echo ' selected="selected"'; ?>>02</option>
								<option value="03"<?php if($day == "03") echo ' selected="selected"'; ?>>03</option>
								<option value="04"<?php if($day == "04") echo ' selected="selected"'; ?>>04</option>
								<option value="05"<?php if($day == "05") echo ' selected="selected"'; ?>>05</option>
								<option value="06"<?php if($day == "06") echo ' selected="selected"'; ?>>06</option>
								<option value="07"<?php if($day == "07") echo ' selected="selected"'; ?>>07</option>
								<option value="08"<?php if($day == "08") echo ' selected="selected"'; ?>>08</option>
								<option value="09"<?php if($day == "09") echo ' selected="selected"'; ?>>09</option>
								<option value="10"<?php if($day == "10") echo ' selected="selected"'; ?>>10</option>
								<option value="11"<?php if($day == "11") echo ' selected="selected"'; ?>>11</option>
								<option value="12"<?php if($day == "12") echo ' selected="selected"'; ?>>12</option>
								<option value="13"<?php if($day == "13") echo ' selected="selected"'; ?>>13</option>
								<option value="14"<?php if($day == "14") echo ' selected="selected"'; ?>>14</option>
								<option value="15"<?php if($day == "15") echo ' selected="selected"'; ?>>15</option>
								<option value="16"<?php if($day == "16") echo ' selected="selected"'; ?>>16</option>
								<option value="17"<?php if($day == "17") echo ' selected="selected"'; ?>>17</option>
								<option value="18"<?php if($day == "18") echo ' selected="selected"'; ?>>18</option>
								<option value="19"<?php if($day == "19") echo ' selected="selected"'; ?>>19</option>
								<option value="20"<?php if($day == "20") echo ' selected="selected"'; ?>>20</option>
								<option value="21"<?php if($day == "21") echo ' selected="selected"'; ?>>21</option>
								<option value="22"<?php if($day == "22") echo ' selected="selected"'; ?>>22</option>
								<option value="23"<?php if($day == "23") echo ' selected="selected"'; ?>>23</option>
								<option value="24"<?php if($day == "24") echo ' selected="selected"'; ?>>24</option>
								<option value="25"<?php if($day == "25") echo ' selected="selected"'; ?>>25</option>
								<option value="26"<?php if($day == "26") echo ' selected="selected"'; ?>>26</option>
								<option value="27"<?php if($day == "27") echo ' selected="selected"'; ?>>27</option>
								<option value="28"<?php if($day == "28") echo ' selected="selected"'; ?>>28</option>
								<option value="29"<?php if($day == "29") echo ' selected="selected"'; ?>>29</option>
								<option value="30"<?php if($day == "30") echo ' selected="selected"'; ?>>30</option>
								<option value="31"<?php if($day == "31") echo ' selected="selected"'; ?>>31</option>
							</select>
							<select name="expirationyear" id="expirationyear">
								<option value="2009"<?php if($year == "2009") echo ' selected="selected"'; ?>>2009</option>
								<option value="2010"<?php if($year == "2010") echo ' selected="selected"'; ?>>2010</option>
								<option value="2011"<?php if($year == "2011") echo ' selected="selected"'; ?>>2011</option>
								<option value="2012"<?php if($year == "2012") echo ' selected="selected"'; ?>>2012</option>
								<option value="2013"<?php if($year == "2013") echo ' selected="selected"'; ?>>2013</option>
								<option value="2014"<?php if($year == "2014") echo ' selected="selected"'; ?>>2014</option>
								<option value="2015"<?php if($year == "2015") echo ' selected="selected"'; ?>>2015</option>
								<option value="2016"<?php if($year == "2016") echo ' selected="selected"'; ?>>2016</option>
								<option value="2017"<?php if($year == "2017") echo ' selected="selected"'; ?>>2017</option>
								<option value="2018"<?php if($year == "2018") echo ' selected="selected"'; ?>>2018</option>
								<option value="2019"<?php if($year == "2019") echo ' selected="selected"'; ?>>2019</option>
							</select>
						</p>
						<p><input type="submit" name="submit" id="submit" value="Submit &rarr;" /></p>
					</form>
					<?php
					}
				break;
				case "delete":
					if(!isset($_GET['id']) || empty($_GET['id']) || !is_numeric($_GET['id']))
						exit("Invalid ID provided.");
					else
						$id = $_GET['id'];
					mysql_query("DELETE FROM `$dishDBdomains` WHERE `domain_id`='$id'") or die("<p class=\"error\">".mysql_error()."</p>");
					?>
					<script type="text/javascript">
					<!--
					window.location = "admin.php"
					//-->
					</script>
					<?php
				break;
			}
			break;
			case "categories":
			?>
			<h2>Manage Categories (<a href="admin.php?manage=categories&amp;action=add">Add New?</a>)</h2>
			<?php
			$actionArray = array('add','edit','delete');
			if( isset($_GET['action']) && !empty($_GET['action']) && in_array($_GET['action'],$actionArray) )
				$action = $_GET['action'];
			else
				$action = "";
			
			switch($action) {
			default:
			$categoriesQ = "SELECT * FROM `$dishDBcategories` ORDER BY `category_name` ASC";
			$categoriesR = mysql_query($categoriesQ)
				or die("<p class=\"error\">".mysql_error()."</p>");
			if(mysql_num_rows($categoriesR) > 0) {
			?>
			<table id="admindomains" cellpadding="0" cellspacing="0">
				<tr>
					<th>Category</th>
					<th colspan="2">&nbsp;</th>
				</tr>
				<?php
				$i = 0;
				while($category = mysql_fetch_array($categoriesR)) {
					$i++;
					$category_name = $category['category_name'];
					?>
				<tr class="row<?php echo ($i & 1); ?>">
					<td><?php echo $category_name; ?></td>
					<td class="icon"><a title="Edit <?php echo $category_name; ?>" href="admin.php?manage=categories&amp;action=edit&amp;id=<?php echo $category['category_id']; ?>"><img src="edit.png" alt="" /></a></td>
					<td class="icon"><a title="Delete <?php echo $category_name; ?>" href="admin.php?manage=categories&amp;action=delete&amp;id=<?php echo $category['category_id']; ?>" onclick="return confirm('Are you sure you want to delete this category?')"><img src="delete.png" alt="" /></a></td>
				</tr>
				<?php
				}
				?>
			</table>
			<?php
			} else {
			?>
			<p>No results found.</p>
			<?php
			}
			break;
			case "add":
			?>
			<h3>Adding New Category</h3>
			<?php
			$showForm = true;
			if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['add_category_submit'])) {
				if (get_magic_quotes_gpc())
					$category_name = stripslashes($_POST['category_name']);
				else
					$category_name = $_POST['category_name'];
					
				$errors = "";
				if(empty($category_name))
					$errors[] = "You did not specify a category name!";
				if(!preg_match("/^([a-z\d][a-z\s\d\&\(\)\.\:\-\&\'\/i]*|)$/i", $category))
					$errors[] = "Invalid characters provided. Category names may include letters, numbers, spaces, slashes (/), ampersands (&), parentheses (), colons (:), hyphens/dashes (-), and single quotes/apostrophes.";
				if(isset($errors) && is_array($errors)) {
					foreach($errors as $error)
						echo "<p class=\"error\">$error</p>\n";
				} else {
					$insertCategoryQ = "INSERT INTO `$dishDBcategories` (`category_name`) VALUES ('$category_name')";
					$insertCategoryR = mysql_query($insertCategoryQ) 
						or die("<p class=\"error\">".mysql_error()."</p>");
					echo "<p class=\"success\">The category called \"$category_name\" was successfully added! <a href=\"admin.php?manage=categories\">Go back?</a></p>";
					$showForm = false;
				}
			}
			if($showForm) {
			?>
			<form action="admin.php?manage=categories&amp;action=add" method="post">
				<p>
					<input type="text" name="category_name" id="category_name" value="<?php if(isset($category_name)) echo $category_name ?>" /><br />
					<input type="submit" name="add_category_submit" id="add_category_submit" value="Submit &rarr;">
				</p>
			</form>
			<?php
			}
			break;
			case "edit":
			if(!isset($_GET['id']) || empty($_GET['id']) || !is_numeric($_GET['id']))
				die("<p class=\"error\">Invalid ID provided.</p>");
			else
				$id = $_GET['id'];
			$categoryNameQ = "SELECT `category_name` FROM `$dishDBcategories` WHERE `category_id` = '$id'";
			$categoryNameR = mysql_query($categoryNameQ)
				or die("<p class=\"error\">".mysql_error()."</p>");
			$categoryName = mysql_result($categoryNameR,0,0);
			?>
			<h3>Edit Category: <?php echo $categoryName; ?></h3>
			<?php
			$showForm = true;
			if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['edit_category_submit'])) {
				if (get_magic_quotes_gpc())
					$category_name = stripslashes($_POST['category_name']);
				else
					$category_name = $_POST['category_name'];
					
				$errors = "";
				if(empty($category_name))
					$errors[] = "You did not specify a category name!";
				if(!preg_match("/^([a-z\d][a-z\s\d\&\(\)\.\:\-\&\'\/i]*|)$/i", $category_name))
					$errors[] = "Invalid characters provided. Category names may include letters, numbers, spaces, slashes (/), ampersands (&), parentheses (), colons (:), hyphens/dashes (-), and single quotes/apostrophes.";
				if(isset($errors) && is_array($errors)) {
					foreach($errors as $error)
						echo "<p class=\"error\">$error</p>\n";
				} else {
					$updateCategoryQ = "UPDATE `$dishDBcategories` SET `category_name` = '$category_name' WHERE `category_id` = '$id'";
					$updateCategoryR = mysql_query($updateCategoryQ) 
						or die("<p class=\"error\">".mysql_error()."</p>");
					echo "<p class=\"success\">The category now called \"$category_name\" was successfully edited! <a href=\"admin.php?manage=categories\">Go back?</a></p>";
					$showForm = false;
				}
			}
			if($showForm) {
			?>
			<form action="admin.php?manage=categories&amp;action=edit&amp;id=<?php echo $id; ?>" method="post">
				<p>
					<input type="text" name="category_name" id="category_name" value="<?php if(isset($category_name)) echo $category_name; elseif(isset($categoryName)) echo $categoryName; ?>" /><br />
					<input type="submit" name="edit_category_submit" id="edit_category_submit" value="Submit &rarr;">
				</p>
			</form>
			<?php
			}
			break;
			case "delete":
			if(!isset($_GET['id']) || empty($_GET['id']) || !is_numeric($_GET['id']))
				die("<p class=\"error\">Invalid ID provided.</p>");
			else
				$id = $_GET['id'];
			$categoryNameQ = "SELECT `category_name` FROM `$dishDBcategories` WHERE `category_id` = '$id'";
			$categoryNameR = mysql_query($categoryNameQ)
				or die("<p class=\"error\">".mysql_error()."</p>");
			$categoryName = mysql_result($categoryNameR,0,0);
			?>
			<h3>Deleting Category: <?php echo $categoryName; ?></h3>
			<?php
			$deleteCategoryQ = "DELETE FROM `$dishDBcategories` WHERE `category_id` = '$id'";
			$deleteCategoryR = mysql_query($deleteCategoryQ)
				or die("<p class=\"error\">".mysql_error()."</p>");
			echo "<p class=\"success\">The category was successfully deleted! <a href=\"admin.php?manage=categories\">Go back?</a></p>";
			break;
			}
			
			break;
			case "registrars":
			?>
			<h2>Manage Registrars (<a href="admin.php?manage=registrars&amp;action=add">Add New?</a>)</h2>
			<?php
			$actionArray = array('add','edit','delete');
			if( isset($_GET['action']) && !empty($_GET['action']) && in_array($_GET['action'],$actionArray) )
				$action = $_GET['action'];
			else
				$action = "";
			
			switch($action) {
			default:
			$registrarsQ = "SELECT * FROM `$dishDBregistrars` ORDER BY `registrar_name` ASC";
			$registrarsR = mysql_query($registrarsQ)
				or die("<p class=\"error\">".mysql_error()."</p>");
			if(mysql_num_rows($registrarsR) > 0) {
			?>
			<table id="admindomains" cellpadding="0" cellspacing="0">
				<tr>
					<th>Registrar</th>
					<th colspan="2">&nbsp;</th>
				</tr>
				<?php
				$i = 0;
				while($registrar = mysql_fetch_array($registrarsR)) {
					$i++;
					$registrar_name = $registrar['registrar_name'];
					?>
				<tr class="row<?php echo ($i & 1); ?>">
					<td>
					<?php
					if(!empty($registrar['registrar_url']))
						echo "<a href=\"".$registrar['registrar_url']."\">".$registrar['registrar_name']."</a>";
					else
						echo $registrar['registrar_name'];
					?>
					</td>
					<td class="icon"><a title="Edit <?php echo $registrar_name; ?>" href="admin.php?manage=registrars&amp;action=edit&amp;id=<?php echo $registrar['registrar_id']; ?>"><img src="edit.png" alt="" /></a></td>
					<td class="icon"><a title="Delete <?php echo $registrar_name; ?>" href="admin.php?manage=registrars&amp;action=delete&amp;id=<?php echo $registrar['registrar_id']; ?>" onclick="return confirm('Are you sure you want to delete this registrar?')"><img src="delete.png" alt="" /></a></td>
				</tr>
				<?php
				}
				?>
			</table>
			<?php
			} else {
			?>
			<p>No results found.</p>
			<?php
			}
			break;
			case "add":
			?>
			<h3>Adding New Registrar</h3>
			<?php
			$showForm = true;
			if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['add_registrar_submit'])) {
				if (get_magic_quotes_gpc()) {
					$registrar_name = stripslashes($_POST['registrar_name']);
					$registrar_url = stripslashes($_POST['registrar_url']);
				} else {
					$registrar_name = $_POST['registrar_name'];
					$registrar_url = $_POST['registrar_url'];
				}
				$errors = "";
				if(empty($registrar_name))
					$errors[] = "You did not specify a registrar name!";
				if(!preg_match("/^([a-z\d][a-z\s\d\&\(\)\.\:\-\&\'\/i]*|)$/i", $registrar_name))
					$errors[] = "Invalid characters provided. Registrar names may include letters, numbers, spaces, slashes (/), ampersands (&), parentheses (), colons (:), hyphens/dashes (-), and single quotes/apostrophes.";
				if(!strstr($registrar_url, 'http://'))
					$errors[] = "You specified a registrar URL, but it needs to begin with \"http://\"!";
				if(isset($errors) && is_array($errors)) {
					foreach($errors as $error)
						echo "<p class=\"error\">$error</p>\n";
				} else {
					$insertCategoryQ = "INSERT INTO `$dishDBregistrars` (`registrar_name`,`registrar_url`) VALUES ('$registrar_name','$registrar_url')";
					$insertCategoryR = mysql_query($insertCategoryQ) 
						or die("<p class=\"error\">".mysql_error()."</p>");
					echo "<p class=\"success\">The registrar called \"$registrar_name\" was successfully added! <a href=\"admin.php?manage=registrars\">Go back?</a></p>";
					$showForm = false;
				}
			}
			if($showForm) {
			?>
			<form action="admin.php?manage=registrars&amp;action=add" method="post">
				<p>
					<label>Registrar Name:</label>
					<input type="text" name="registrar_name" id="registrar_name" value="<?php if(isset($registrar_name)) echo $registrar_name ?>" /><br />
					<label>Registrar URL:</label>
					<input type="text" name="registrar_url" id="registrar_url" value="<?php if(isset($registrar_url)) echo $registrar_url ?>" /><br />
					<input type="submit" name="add_registrar_submit" id="add_registrar_submit" value="Submit &rarr;">
				</p>
			</form>
			<?php
			}
			break;
			case "edit":
			if(!isset($_GET['id']) || empty($_GET['id']) || !is_numeric($_GET['id']))
				die("<p class=\"error\">Invalid ID provided.</p>");
			else
				$id = $_GET['id'];
			$registrarDataQ = "SELECT `registrar_name`,`registrar_url` FROM `$dishDBregistrars` WHERE `registrar_id` = '$id'";
			$registrarDataR = mysql_query($registrarDataQ)
				or die("<p class=\"error\">".mysql_error()."</p>");
			$registrarData = mysql_fetch_array($registrarDataR);
			$registrarName = $registrarData['registrar_name'];
			$registrarURL = $registrarData['registrar_url'];
			?>
			<h3>Edit Registrar: <?php echo $registrarName; ?></h3>
			<?php
			$showForm = true;
			if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['edit_registrar_submit'])) {
				if (get_magic_quotes_gpc()) {
					$registrar_name = stripslashes($_POST['registrar_name']);
					$registrar_url = stripslashes($_POST['registrar_url']);
				} else {
					$registrar_name = $_POST['registrar_name'];
					$registrar_url = $_POST['registrar_url'];
				}
				$errors = "";
				if(empty($registrar_name))
					$errors[] = "You did not specify a registrar name!";
				if(!preg_match("/^([a-z\d][a-z\s\d\&\(\)\.\:\-\&\'\/i]*|)$/i", $registrar_name))
					$errors[] = "Invalid characters provided. Registrar names may include letters, numbers, spaces, slashes (/), ampersands (&), parentheses (), colons (:), hyphens/dashes (-), and single quotes/apostrophes.";
				if(!strstr($registrar_url, 'http://'))
					$errors[] = "You specified a registrar URL, but it needs to begin with \"http://\"!";
				if(isset($errors) && is_array($errors)) {
					foreach($errors as $error)
						echo "<p class=\"error\">$error</p>\n";
				} else {
					$updateCategoryQ = "UPDATE `$dishDBregistrars` SET `registrar_name` = '$registrar_name', `registrar_url` = '$registrar_url' WHERE `registrar_id` = '$id'";
					$updateCategoryR = mysql_query($updateCategoryQ) 
						or die("<p class=\"error\">".mysql_error()."</p>");
					echo "<p class=\"success\">The registrar called \"$registrar_name\" was successfully edited! <a href=\"admin.php?manage=registrars\">Go back?</a></p>";
					$showForm = false;
				}
			}
			if($showForm) {
			?>
			<form action="admin.php?manage=registrars&amp;action=edit&amp;id=<?php echo $id; ?>" method="post">
				<p>
					<label>Registrar Name:</label>
					<input type="text" name="registrar_name" id="registrar_name" value="<?php if(isset($registrar_name)) echo $registrar_name; elseif(isset($registrarName)) echo $registrarName; ?>" /><br />
					<label>Registrar URL:</label>
					<input type="text" name="registrar_url" id="registrar_url" value="<?php if(isset($registrar_url)) echo $registrar_url; elseif(isset($registrarURL)) echo $registrarURL; ?>" /><br />
					<input type="submit" name="edit_registrar_submit" id="edit_registrar_submit" value="Submit &rarr;">
				</p>
			</form>
			<?php
			}
			break;
			case "delete":
			if(!isset($_GET['id']) || empty($_GET['id']) || !is_numeric($_GET['id']))
				die("<p class=\"error\">Invalid ID provided.</p>");
			else
				$id = $_GET['id'];
			$registrarNameQ = "SELECT `registrar_name` FROM `$dishDBregistrars` WHERE `registrar_id` = '$id'";
			$registrarNameR = mysql_query($registrarNameQ)
				or die("<p class=\"error\">".mysql_error()."</p>");
			$registrarName = mysql_result($registrarNameR,0,0);
			?>
			<h3>Deleting Registrar: <?php echo $registrarName; ?></h3>
			<?php
			$deleteCategoryQ = "DELETE FROM `$dishDBregistrars` WHERE `registrar_id` = '$id'";
			$deleteCategoryR = mysql_query($deleteCategoryQ)
				or die("<p class=\"error\">".mysql_error()."</p>");
			echo "<p class=\"success\">The registrar was successfully deleted! <a href=\"admin.php?manage=registrars\">Go back?</a></p>";
			break;
			}
			
			break;
			case "tlds":
			?>
			<h2>Manage TLDs (<a href="admin.php?manage=tlds&amp;action=add">Add New?</a>)</h2>
			<?php
			$actionArray = array('add','edit','delete');
			if( isset($_GET['action']) && !empty($_GET['action']) && in_array($_GET['action'],$actionArray) )
				$action = $_GET['action'];
			else
				$action = "";
			
			switch($action) {
			default:
			$tldsQ = "SELECT * FROM `$dishDBtlds` ORDER BY `tld_name` ASC";
			$tldsR = mysql_query($tldsQ)
				or die("<p class=\"error\">".mysql_error()."</p>");
			if(mysql_num_rows($tldsR) > 0) {
			?>
			<table id="admindomains" cellpadding="0" cellspacing="0">
				<tr>
					<th>TLD</th>
					<th colspan="2">&nbsp;</th>
				</tr>
				<?php
				$i = 0;
				while($tld = mysql_fetch_array($tldsR)) {
					$i++;
					$tld_name = $tld['tld_name'];
					?>
				<tr class="row<?php echo ($i & 1); ?>">
					<td><?php echo $tld_name; ?></td>
					<td class="icon"><a title="Edit <?php echo $tld_name; ?>" href="admin.php?manage=tlds&amp;action=edit&amp;id=<?php echo $tld['tld_id']; ?>"><img src="edit.png" alt="" /></a></td>
					<td class="icon"><a title="Delete <?php echo $tld_name; ?>" href="admin.php?manage=tlds&amp;action=delete&amp;id=<?php echo $tld['tld_id']; ?>" onclick="return confirm('Are you sure you want to delete this tld?')"><img src="delete.png" alt="" /></a></td>
				</tr>
				<?php
				}
				?>
			</table>
			<?php
			} else {
			?>
			<p>No results found.</p>
			<?php
			}
			break;
			case "add":
			?>
			<h3>Adding New TLD</h3>
			<?php
			$showForm = true;
			if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['add_tld_submit'])) {
				if (get_magic_quotes_gpc())
					$tld_name = stripslashes($_POST['tld_name']);
				else
					$tld_name = $_POST['tld_name'];
					
				$errors = "";
				if(empty($tld_name))
					$errors[] = "You did not specify a TLD!";
				if(!preg_match("/^([a-z\.]*|)$/i", $tld_name))
					$errors[] = "Invalid characters provided. TLDs may only include letters and periods.";
				if(isset($errors) && is_array($errors)) {
					foreach($errors as $error)
						echo "<p class=\"error\">$error</p>\n";
				} else {
					$insertCategoryQ = "INSERT INTO `$dishDBtlds` (`tld_name`) VALUES ('$tld_name')";
					$insertCategoryR = mysql_query($insertCategoryQ) 
						or die("<p class=\"error\">".mysql_error()."</p>");
					echo "<p class=\"success\">The TLD \"$tld_name\" was successfully added! <a href=\"admin.php?manage=tlds\">Go back?</a></p>";
					$showForm = false;
				}
			}
			if($showForm) {
			?>
			<form action="admin.php?manage=tlds&amp;action=add" method="post">
				<p>
					<input type="text" name="tld_name" id="tld_name" value="<?php if(isset($tld_name)) echo $tld_name ?>" /><br />
					<input type="submit" name="add_tld_submit" id="add_tld_submit" value="Submit &rarr;">
				</p>
			</form>
			<?php
			}
			break;
			case "edit":
			if(!isset($_GET['id']) || empty($_GET['id']) || !is_numeric($_GET['id']))
				die("<p class=\"error\">Invalid ID provided.</p>");
			else
				$id = $_GET['id'];
			$tldNameQ = "SELECT `tld_name` FROM `$dishDBtlds` WHERE `tld_id` = '$id'";
			$tldNameR = mysql_query($tldNameQ)
				or die("<p class=\"error\">".mysql_error()."</p>");
			$tldName = mysql_result($tldNameR,0,0);
			?>
			<h3>Edit TLD: <?php echo $tldName; ?></h3>
			<p><strong>Important:</strong> Domainish is configured to work with TLDs without a preceding period, so don't put a period in front of the TLD.</p>
			<?php
			$showForm = true;
			if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['edit_tld_submit'])) {
				if (get_magic_quotes_gpc())
					$tld_name = stripslashes($_POST['tld_name']);
				else
					$tld_name = $_POST['tld_name'];
					
				$errors = "";
				if(empty($tld_name))
					$errors[] = "You did not specify a TLD!";
				if(!preg_match("/^([a-z\.]*|)$/i", $tld_name))
					$errors[] = "Invalid characters provided. TLDs may only include letters and periods.";
				if(isset($errors) && is_array($errors)) {
					foreach($errors as $error)
						echo "<p class=\"error\">$error</p>\n";
				} else {
					$updateCategoryQ = "UPDATE `$dishDBtlds` SET `tld_name` = '$tld_name' WHERE `tld_id` = '$id'";
					$updateCategoryR = mysql_query($updateCategoryQ) 
						or die("<p class=\"error\">".mysql_error()."</p>");
					echo "<p class=\"success\">The tld now called \"$tld_name\" was successfully edited! <a href=\"admin.php?manage=tlds\">Go back?</a></p>";
					$showForm = false;
				}
			}
			if($showForm) {
			?>
			<form action="admin.php?manage=tlds&amp;action=edit&amp;id=<?php echo $id; ?>" method="post">
				<p>
					<input type="text" name="tld_name" id="tld_name" value="<?php if(isset($tld_name)) echo $tld_name; elseif(isset($tldName)) echo $tldName; ?>" /><br />
					<input type="submit" name="edit_tld_submit" id="edit_tld_submit" value="Submit &rarr;">
				</p>
			</form>
			<?php
			}
			break;
			case "delete":
			if(!isset($_GET['id']) || empty($_GET['id']) || !is_numeric($_GET['id']))
				die("<p class=\"error\">Invalid ID provided.</p>");
			else
				$id = $_GET['id'];
			$tldNameQ = "SELECT `tld_name` FROM `$dishDBtlds` WHERE `tld_id` = '$id'";
			$tldNameR = mysql_query($tldNameQ)
				or die("<p class=\"error\">".mysql_error()."</p>");
			$tldName = mysql_result($tldNameR,0,0);
			?>
			<h3>Deleting TLD: <?php echo $tldName; ?></h3>
			<?php
			$deleteCategoryQ = "DELETE FROM `$dishDBtlds` WHERE `tld_id` = '$id'";
			$deleteCategoryR = mysql_query($deleteCategoryQ)
				or die("<p class=\"error\">".mysql_error()."</p>");
			echo "<p class=\"success\">The TLD was successfully deleted! <a href=\"admin.php?manage=tlds\">Go back?</a></p>";
			break;
			}
			
			break;
		}	
		?>
	</div>
	<div id="footer">
		<p>Powered by <a href="http://hannah.nu">Domainish <?php echo getScriptVersion(); ?></a> with icons by <a href="http://pinvoke.com">Pinvoke</a>.</p>
	</div>
</body>
</html>
<?php
}
?>