<?php
require_once('config.php');
require_once('functions.php');
$showLoginForm = true;
if(isset($_GET['action']) && $_GET['action'] == "logout") {
	setcookie($dishUser, NULL, time() - 3600);
	$error = "<p>You have been successfully logged out.</p>";
}
if ($_SERVER['REQUEST_METHOD'] == "POST") {
	if (md5($_POST['username']) != $dishUser || md5($_POST['password']) != $dishPass)
		$error = "<p>Your username and/or password were incorrect. Try again.</p>";
	else if (md5($_POST['username']) == $dishUser && md5($_POST['password']) == $dishPass) {
		$showLoginForm = false;
		setcookie($dishUser, md5($dishPass.$dishSalt), time()+(31*86400));
		header("Location: admin.php");
	} else
		setcookie($dishUser, NULL, time() - 3600);
}
if(isset($showLoginForm) && $showLoginForm === true) {
include('header.php');
if(isset($error) && !empty($error))
	echo $error;
?>
<form method="post" action="login.php">
   	<p><label for="username">Username:</label><br /><input type="text" name="username" id="username" /></p>
    <p><label for="password">Password:</label><br /><input type="password" name="password" id="password" /></p>
    <p><input type="submit" name="submit" id="submit" value="Login"></p>
</form>
<?php
include('footer.php');
}
?>