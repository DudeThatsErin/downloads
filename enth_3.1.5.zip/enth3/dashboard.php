<?php
/*****************************************************************************
 Enthusiast: Listing Collective Management System
 Copyright (c) by Angela Sabas
 http://scripts.indisguise.org/

 This script is made available for free download, use, and modification as
 long as this note remains intact and a link back to
 http://scripts.indisguise.org/ is given. It is hoped that the script
 will be useful, but does not guarantee that it will solve any problem or is
 free from errors of any kind. Users of this script are forbidden to sell or
 distribute the script in whole or in part without written and explicit
 permission from me, and users agree to hold me blameless from any
 liability directly or indirectly arising from the use of this script.

 For more information please view the readme.txt file.
******************************************************************************/
session_start();
require_once( 'logincheck.inc.php' );
if( !isset( $logged_in ) || !$logged_in ) {
   $_SESSION['message'] = 'You are not logged in. Please log in to continue.';
   $next = '';
   if( isset( $_SERVER['REQUEST_URI'] ) )
      $next = $_SERVER['REQUEST_URI'];
   else if( isset( $_SERVER['PATH_INFO'] ) )
      $next = $_SERVER['PATH_INFO'];
   $_SESSION['next'] = $next;
   header( 'location: index.php' );
   die( 'Redirecting you...' );
}

require_once( 'header.php' );
require( 'config.php' );
require_once( 'mod_categories.php' );
require_once( 'mod_joined.php' );
require_once( 'mod_owned.php' );
require_once( 'mod_affiliates.php' );
require_once( 'mod_settings.php' );
require_once( 'mod_errorlogs.php' );
?>

<h1>You are managing: <?php echo get_setting( 'collective_title' ) ?></h1>

<?php
$today = date( 'F j, Y (l)' );
if( date( 'a' ) == 'am' )
	$greeting = 'Good morning';
else {
	if( date( 'G' ) <= 18 )
		$greeting = 'Good afternoon';
	else
		$greeting = 'Good evening';
}
?>
<p><?php echo $greeting ?>! Today is <?php echo $today ?>.</p>

<h2>Collective statistics:</h2>

<?php
require_once( 'show_collective_stats.php' );
?>
<table class="stats">

<tr><td class="right">
Number of categories:
</td><td>
<?php echo $total_cats ?>
</td></tr>

<tr><td class="right">
Number of joined listings:
</td><td>
<?php echo $joined_approved ?> approved, <?php echo $joined_pending ?> pending
</td></tr>

<tr><td class="right">
Number of owned listings:
</td><td>
<?php echo $owned_current ?> current, <?php echo $owned_upcoming ?> upcoming, <?php echo $owned_pending ?> pending
</td></tr>

<tr><td class="right">
Number of collective affiliates:
</td><td>
<?php echo $affiliates_collective ?> affiliates
</td></tr>

<tr><td class="right">
Newest owned listing
</td><td>
<?php
if( count( $owned_newest ) > 0 ) {
?>
   <a href="<?php echo $owned_newest['url'] ?>"><?php echo $owned_newest['title']
   ?>: the <?php echo $owned_newest['subject'] ?> <?php echo $owned_newest['listingtype']
   ?></a>
<?php
} else echo 'None';
?>
</td></tr>

<tr><td class="right">
Newest joined listing
</td><td>
<?php
if( count( $joined_newest ) > 0 ) {
?>
   <a href="<?php echo $joined_newest['url'] ?>"><?php echo $joined_newest['subject'] ?></a>
<?php
} else echo 'None';
?>
</td></tr>

<tr><td class="right">
Total members in collective:
</td><td>
<?php echo $collective_total_fans_approved ?> (<?php echo $collective_total_fans_pending ?> pending)
</td></tr>

<tr><td class="right">
Collective members growth rate:
</td><td>
<?php echo $collective_fans_growth_rate ?> members/day
</td></tr>

</table>

<?php
$owned = get_owned( 'current' );
$header = true;
foreach( $owned as $id ) {
   $info = get_listing_info( $id );
   $stats = get_listing_stats( $id );

   // now check $lastupdated -- if more than 8 weeks ago, notify!
   $weeks = 0;
   if( $stats['lastupdated'] && date( 'Y' ) != date( 'Y', strtotime( $stats['lastupdated'] ) ) ) {
      $weeks = ( 52 - date( 'W', strtotime( $stats['lastupdated'] ) ) ) + date( 'W' );
   } else if( $stats['lastupdated'] ) {
      $weeks = date( 'W' ) - date( 'W', strtotime( $stats['lastupdated'] ) );
   }

   if( $stats['lastupdated'] == '' || // no last updated date
      $weeks >= 8 ){
      if( $header ) {
?>
         <h2>Neglected Listings Notification</h2>
         <p>The following listings have gone on two months without a 
         newly-approved member or a new/updated affiliate!</p>
         <ul>
<?php
         $header = false;
      }
      // prepare date format
      $readable = @date( get_setting( 'date_format' ),
         strtotime( $stats['lastupdated'] ) );
      echo '<li> ';
      if( $info['title'] )
         echo $info['title'];
      else
         echo $info['subject'];
      echo ", last updated $readable;<br />manage ";
      echo '<a href="members.php?id=' . $info['listingid'] .
         '">members</a>';
      if( $info['affiliates'] == 1 ) // don't show if affiliates aren't enabled
         echo ' or <a href="affiliates.php?listing=' .
            $info['listingid'] . '">affiliates</a>';
      echo '?</li>';
   }
}
echo '</ul>';

echo '<h1>Enthusiast Updates</h1>';

$url = 'http://scripts.indisguise.org/category/enthusiast/feed/';
require_once( 'rss_fetch.inc' );
$rss = fetch_rss( $url );
$atmost = 3;
$i = 0;
foreach( $rss->items as $item ) {
   $title = $item['title'];
   $href = $item['link'];
   $entry = $item['description'];
   $pubdate = $item['pubdate'];

   $dayshort = date( 'D', strtotime( $pubdate ) );
   $daylong = date( 'l', strtotime( $pubdate ) );
   $monshort = date( 'M', strtotime( $pubdate ) );
   $monlong = date( 'F', strtotime( $pubdate ) );
   $yy = date( 'y', strtotime( $pubdate ) );
   $yyyy = date( 'Y', strtotime( $pubdate ) );
   $m = date( 'n', strtotime( $pubdate ) );
   $mm = date( 'm', strtotime( $pubdate ) );
   $d = date( 'j', strtotime( $pubdate ) );
   $dd = date( 'd', strtotime( $pubdate ) );
   $dth = date( 'jS', strtotime( $pubdate ) );
   $ampm = date( 'a', strtotime( $pubdate ) );
   $AMPM = date( 'A', strtotime( $pubdate ) );
   $ap = rtrim( $ampm, 'm' );
   $AP = rtrim( $AMPM, 'm' );
   $min = date( 'i', strtotime( $pubdate ) );
   $_12h = date( 'g', strtotime( $pubdate ) );
   $_12hh = date( 'h', strtotime( $pubdate ) );
   $_24h = date( 'G', strtotime( $pubdate ) );
   $_24hh = date( 'H', strtotime( $pubdate ) );
   $reply = $href . '?mode=reply';
?>
   <h2><?php echo $title ?><br />
   <small><?php echo $daylong ?>, <?php echo $dth ?> <?php echo $monlong ?> <?php echo $yyyy ?> &bull; <a href="<?php echo $href ?>">permalink</a></small></h2>
   <blockquote><?php echo $entry ?></blockquote>
<?php
   $i++;
   if( $i == $atmost )
      break;
}
require_once( 'footer.php' );
?>