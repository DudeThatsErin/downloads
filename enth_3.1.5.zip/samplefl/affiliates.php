<?php
require_once( 'header.php' );
?>

<h1>Fanlisting Affiliates</h1>

<?php
include 'config.php';
include ENTH_PATH . 'show_affiliates.php';

require_once( 'footer.php' );
?>