<?php
require_once( 'header.php' );
?>

<h1>Reset your Password</h1>

<?php
include 'config.php';
include ENTH_PATH . 'show_lostpass.php';

require_once( 'footer.php' );
?>