<?php

require_once('codes-config.php');
require_once('functions.php');

$cs =& CodeSort::GetInstance();

require_once('protect.php');

$cs->AddOptFromDb();

$cs->GetHeader();

?>

<div class="col1">

<p>Welcome to the CodeSort admin area.</p>

<?php if ($cs->GetOpt('do_upload')) { ?>
<p><a href="img-cleanup.php">Cleanup unused images?</a></p>
<?php

}

// ____________________________________________________________ LIST UNAPPROVED CODES

$query = "SELECT code_id, code_image, ".$cs->GetOpt('col_subj')." AS subject, donor_name, donor_url
  FROM ".$cs->GetOpt('codes_table')."
  LEFT JOIN ".$cs->GetOpt('collective_table')." ON code_fl=".$cs->GetOpt('col_id')."
  LEFT JOIN ".$cs->GetOpt('donors_table')." ON code_donor=donor_id
  WHERE code_approved='n'
  ORDER BY code_id ".$cs->GetOpt('sort_order');

$cs->db->Execute($query, 'Failed to select unapproved codes. Check that your collective_script setting is properly configured.');
$num_unapproved = $cs->db->NumRows();

if ($num_unapproved > 0) {

    ?>

    <h2>Codes Awaiting Approval</h2>

    <p>There are currently <strong><?php echo $num_unapproved; ?></strong> unapproved codes. To approve a code, select &#8216;edit&#8217; to choose the right size and category for it. Otherwise select &#8216;delete&#8217; to reject it.</p>

    <form action="add-code.php" method="post">
    <table>

    <thead>
    <tr>
    <th scope="col">Image</th>
    <th scope="col">Fanlisting</th>
    <th scope="col">Donor</th>
    <th scope="col">Edit? / Delete?</th>
    </tr>
    </thead>

    <tbody>
    <?php

    // ____________________________________________________________ LIST CODES

    $i = 0;
    while ($row = $cs->db->ReadRecord()) {

        if (empty($row['subject'])) {
            $row['subject'] = 'Whole Collective';
        }

        $class = (isset($class) && $class == 'odd') ? 'even' : 'odd';

        echo '<tr class="'.$class.'">';
        echo '<td>'.$cs->GetCodeImg($row['code_image']).'</td>';
        echo '<td>'.$row['subject'].'</td>';
        echo '<td>'.$cs->GetDonorName($row['donor_name'], $row['donor_url']).'</td>';
        echo '<td><input type="checkbox" name="id['.$i.']" value="'.$row['code_id'].'" />
<input type="hidden" name="code_oldimg['.$i.']" value="'.$row['code_image'].'" /></td>';
        echo "</tr>\n";
        $i++;
    }

    ?>
    </tbody>

    <tfoot>
    <tr>
    <td colspan="3" class="number"><a href="#" onclick="checkAll(false); return false;">Uncheck All</a> /
    <a href="#" onclick="checkAll(true); return false;">Check All</a></td>
    <td><input type="submit" name="action" value="edit" title="edit checked codes" />
    <input type="submit" name="action" value="delete" title="delete checked codes"
        onclick="return confirm('Are you absolutely sure you want to delete the checked codes?');" /></td>
    </tr>
    </tfoot>

    </table>
    <input type="hidden" name="fl" value="<?php echo $row['fl']; ?>" />
    </form>

    <?php

}

$cs->db->FreeResult();

?>

</div>

<div class="col2 sidebox">

<h2>Stats</h2>

<?php

$query_count = "SELECT COUNT(code_id) FROM ".$cs->GetOpt('codes_table');
$num_code = $cs->db->GetFirstCell($query_count);

?>

<p>You have <strong><?php echo $num_code; ?></strong> codes in total.</p>

</div>

<div class="col2 sidebox">

<h2>Alerts</h2>

<?php

if ($fsock = @fsockopen('prism-perfect.net', 80, $errno, $errstr, 10)) {

    $request = "GET /codesort.txt HTTP/1.1\r\n";
    $request .= "Host: prism-perfect.net\r\n";
    $request .= "User-Agent: CodeSort/".$cs->GetOpt('version')."\r\n";
    $request .= "Connection: close\r\n\r\n";

    @fputs($fsock, $request);

    $get_info = false;
    while (!@feof($fsock)) {
        if ($get_info) {
            $version_info = (float) @fread($fsock, 1024);
        } else {
            if (@fgets($fsock, 1024) == "\r\n") {
                $get_info = true;
            }
        }
    }
    @fclose($fsock);

    if ($cs->GetOpt('version') >= $version_info) {
        echo '<p class="success">This version of CodeSort is up-to-date. Yay!</p>';
    } else {
        echo '<p class="error">Oh dear! This is not the latest version of CodeSort. Please visit <a href="'.$cs->GetOpt('url').'">'.$cs->GetOpt('url').'</a> to download CodeSort version ' . $version_info . '</p>';
    }
} else {
    if ($errstr) {
        echo '<p class="error">Connect socket error.<br />Cannot check for updates.</p>';
    } else {
        echo '<p class="error">Socket functions disabled.<br />Cannot check for updates</p>';
    }
}

?>

</div>

<?php $cs->GetFooter(); ?>