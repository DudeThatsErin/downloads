<?php

if (!isset($listing)) { exit; }

echo '<div id="codes" class="codesort">'."\n";

require_once('codes-config.php');
require_once('functions.php');

$cs =& CodeSort::GetInstance();
$cs->AddOptFromDb();

// ____________________________________________________________ GET SIZE

if (!empty($_GET['size'])) {

    $size = (int)$_GET['size'];

    $query_size = "SELECT size_size
      FROM ".$cs->GetOpt('sizes_table')."
      WHERE size_id=$size LIMIT 1";

    $cs->db->Execute($query_size);

    if ($row_size = $cs->db->GetRecord()) {

        echo '<h2>'.$row_size['size_size']."</h2>\n";

        echo '<p>';

        $query_codes = "SELECT code_image, donor_name, donor_url
          FROM ".$cs->GetOpt('codes_table')."
          LEFT JOIN ".$cs->GetOpt('donors_table')." ON code_donor=donor_id
          WHERE code_fl=$listing AND code_size=$size AND code_approved='y'
          ORDER BY code_id ".$cs->GetOpt('sort_order');

        $cs->db->Execute($query_codes);

        while ($row = $cs->db->ReadRecord()) {

            if (empty($row['donor_name'])) {
                echo $cs->GetCodeImg($row['code_image'])."\n";
            } else {
                $donor_name[] = $row['donor_name'];
                $donor_url[] = $row['donor_url'];
                $code_image[] = $row['code_image'];
            }
        }

        $cs->db->FreeResult();

        echo "</p>\n";

        if (!empty($donor_name)) {

            asort($donor_name);

            $last_donor = '';
            $dtitled = false;
            foreach ($donor_name as $key => $value) {
                if ($last_donor != $value) {
                    if ($dtitled) { echo "</p>\n"; }
                    $dtitled = false;
                }

                if (empty($row['donor_name'])) {
                    if (!$dtitled) {
                        echo '<p>From '.$cs->GetDonorName($value, $donor_url[$key])."<br />\n";
                        $dtitled = true;
                    }
                    echo $cs->GetCodeImg($code_image[$key])."\n";
                }

                $last_donor = $value;
            }
        }

    } else {
        $cs->AddErr('Null size.');
    }

// ____________________________________________________________ GET CATEGORY

} elseif (!empty($_GET['cat']) && $cs->GetOpt('use_cat')) {

    $cat = (int)$_GET['cat'];

    $query_cat = "SELECT cat_name
      FROM ".$cs->GetOpt('cat_table')."
      WHERE cat_id=$cat LIMIT 1";

    $cs->db->Execute($query_cat);

    if ($row_cat = $cs->db->GetRecord()) {

        echo '<h2>'.$row_cat['cat_name']."</h2>\n";

        $query_codes = "SELECT code_image, donor_name, donor_url, size_size
          FROM ".$cs->GetOpt('codes_table')."
          JOIN ".$cs->GetOpt('sizes_table')." ON code_size=size_id
          LEFT JOIN ".$cs->GetOpt('donors_table')." ON code_donor=donor_id
          WHERE code_fl=$listing AND code_cat=$cat AND code_approved='y'
          ORDER BY size_order ASC, code_id ".$cs->GetOpt('sort_order');

        $cs->db->Execute($query_codes);

        $last_size = '';
        $titled = false;
        while ($row = $cs->db->ReadRecord()) {

            if ($last_size != $row['size_size']) {
                if ($titled) { echo "</p>\n"; }

                if (!empty($donor_name)) {

                    asort($donor_name);

                    if (!$titled) { echo '<h3>'.$last_size."</h3>\n"; }

                    $last_donor = '';
                    $dtitled = false;
                    foreach ($donor_name as $key => $value) {
                        if ($last_donor != $value) {
                            if ($dtitled) { echo "</p>\n"; }
                            $dtitled = false;
                        }

                        if (empty($row['donor_name'])) {
                            if (!$dtitled) {
                                echo '<p>From '.$cs->GetDonorName($value, $donor_url[$key])."<br />\n";
                                $dtitled = true;
                            }
                            echo $cs->GetCodeImg($code_image[$key])."\n";
                        }

                        $last_donor = $value;
                    }

                    $donor_name = array();
                    $donor_url = array();
                    $code_image = array();
                }

                $titled = false;
            }

            if (empty($row['donor_name'])) {
                if (!$titled) {
                    echo '<h3>'.$row['size_size']."</h3>\n";
                    echo '<p>';
                    $titled = true;
                }
                echo $cs->GetCodeImg($row['code_image'])."\n";
            } else {
                $donor_name[] = $row['donor_name'];
                $donor_url[] = $row['donor_url'];
                $code_image[] = $row['code_image'];
            }

            $last_size = $row['size_size'];
        }

        $cs->db->FreeResult();

    } else {
        $cs->AddErr('Null category.');
    }

// ____________________________________________________________ GET ALL

} elseif (isset($_GET['show']) && $_GET['show'] == 'all') {

    echo "<h2>All Codes</h2>\n";

    $query_codes = "SELECT code_image, donor_name, donor_url, size_size
      FROM ".$cs->GetOpt('codes_table')."
      JOIN ".$cs->GetOpt('sizes_table')." ON code_size=size_id
      LEFT JOIN ".$cs->GetOpt('donors_table')." ON code_donor=donor_id
      WHERE code_fl=$listing AND code_approved='y'
      ORDER BY size_order ASC, code_id ".$cs->GetOpt('sort_order');

    $cs->db->Execute($query_codes);

    $last_size = '';
    $titled = false;
    while ($row = $cs->db->ReadRecord()) {

        if ($last_size != $row['size_size']) {
            if ($titled) { echo "</p>\n"; }

            if (!empty($donor_name)) {

                asort($donor_name);

                if (!$titled) { echo '<h3>'.$last_size."</h3>\n"; }

                $last_donor = '';
                $dtitled = false;
                foreach ($donor_name as $key => $value) {
                    if ($last_donor != $value) {
                        if ($dtitled) { echo "</p>\n"; }
                        $dtitled = false;
                    }

                    if (empty($row['donor_name'])) {
                        if (!$dtitled) {
                            echo '<p>From '.$cs->GetDonorName($value, $donor_url[$key])."<br />\n";
                            $dtitled = true;
                        }
                        echo $cs->GetCodeImg($code_image[$key])."\n";
                    }

                    $last_donor = $value;
                }

                $donor_name = array();
                $donor_url = array();
                $code_image = array();
            }

            $titled = false;
        }

        if (empty($row['donor_name'])) {
            if (!$titled) {
                echo '<h3>'.$row['size_size']."</h3>\n";
                echo '<p>';
                $titled = true;
            }
            echo $cs->GetCodeImg($row['code_image'])."\n";
        } else {
            $donor_name[] = $row['donor_name'];
            $donor_url[] = $row['donor_url'];
            $code_image[] = $row['code_image'];
        }

         $last_size = $row['size_size'];
    }

    $cs->db->FreeResult();
}

$cs->ReportErrors();

// ____________________________________________________________ LIST SIZES/CATS

$query_size = "SELECT size_id, size_size, COUNT(code_id) AS num_size
  FROM ".$cs->GetOpt('sizes_table')."
  JOIN ".$cs->GetOpt('codes_table')." ON size_id=code_size
  WHERE code_fl=$listing AND code_approved='y'
  GROUP BY size_id
  ORDER BY size_order ASC";

$cs->db->Execute($query_size);

if ($cs->db->NumRows() > 0) {

    echo "<p>Select a size:</p>\n";
    echo "<ul>\n";

    while ($row = $cs->db->ReadRecord()) {

        echo '<li><a href="'.clean_input($_SERVER['PHP_SELF']).'?size='.$row['size_id'].'#codes" title="'.$row['num_size'].' codes">'.$row['size_size']."</a></li>\n";

    }

    echo "</ul>\n";
}

$cs->db->FreeResult();

if ($cs->GetOpt('use_cat')) {

$query_cat = "SELECT cat_id, cat_name, COUNT(code_id) AS num_cat
  FROM ".$cs->GetOpt('cat_table')."
  JOIN ".$cs->GetOpt('codes_table')." ON cat_id=code_cat
  WHERE code_fl=$listing AND code_approved='y'
  GROUP BY cat_id
  ORDER BY cat_name ASC";

$cs->db->Execute($query_cat);

if ($cs->db->NumRows() > 0) {

    echo "<p>Or select a category:</p>\n";
    echo "<ul>\n";

    while ($row = $cs->db->ReadRecord()) {

        echo '<li><a href="'.clean_input($_SERVER['PHP_SELF']).'?cat='.$row['cat_id'].'#codes" title="'.$row['num_cat'].' codes">'.$row['cat_name']."</a></li>\n";

    }

    echo "</ul>\n";
}

$cs->db->FreeResult();

} // end if cat

$query_total = "SELECT COUNT(code_id)
  FROM ".$cs->GetOpt('codes_table')."
  WHERE code_fl=$listing AND code_approved='y'";

$num_total = $cs->db->GetFirstCell($query_total);

echo '<p>Or <a href="'.clean_input($_SERVER['PHP_SELF']).'?show=all#codes" title="'.$num_total.' codes">view all</a>.</p>'."\n";

echo '<div class="credit">
<p>Powered by <a href="'.$cs->GetOpt('url').'">CodeSort '.$cs->GetOpt('version').'</a></p>
</div>'."\n";

echo "</div><!-- END #code .codesort -->\n";

// restore old error handler
restore_error_handler();

?>