</div><!-- END #main -->

<?php if ($showNav) { require_once('admin-nav.php'); } ?>

<div class="credit">
<p>Powered by <a href="<?php echo $this->GetOpt('url'); ?>">CodeSort <?php echo $this->GetOpt('version'); ?></a></p>
</div>

</div>

</body>

</html>