<?php
$CONF['sql'] = 'mysql';
$CONF['sql_host'] = 'localhost';
$CONF['sql_database'] = '';
$CONF['sql_username'] = '';
$CONF['sql_password'] = '';
$CONF['sql_prefix'] = 'ats';
?>
