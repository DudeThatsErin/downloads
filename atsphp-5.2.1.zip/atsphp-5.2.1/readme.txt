//===========================================================================\\
// Aardvark Topsites PHP 5.2                                                 \\
// Copyright (c) 2000-2009 Jeremy Scheff.  All rights reserved.              \\
//---------------------------------------------------------------------------\\
// http://www.aardvarktopsitesphp.com/                http://www.avatic.com/ \\
//---------------------------------------------------------------------------\\
// This program is free software; you can redistribute it and/or modify it   \\
// under the terms of the GNU General Public License as published by the     \\
// Free Software Foundation; either version 2 of the License, or (at your    \\
// option) any later version.                                                \\
//                                                                           \\
// This program is distributed in the hope that it will be useful, but       \\
// WITHOUT ANY WARRANTY; without even the implied warranty of                \\
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General \\
// Public License for more details.                                          \\
//===========================================================================\\

Official Website... http://www.aardvarktopsitesphp.com/
Manual............. http://www.aardvarktopsitesphp.com/manual/
Support Forum...... http://www.aardvarktopsitesphp.com/forums/

The manual contains installation and upgrading instructions.  If you have
trouble, go to the support forum.



--------------------------
QUICK INSTALL INSTRUCTIONS
--------------------------

WARNING:
THESE INSTRUCTIONS ONLY APPLY FOR NEW INSTALLATIONS.  IF YOU ARE UPGRADING FROM
A PREVIOUS VERSION, PLEASE READ THE "UPGRADE" SECTION OF THE MANUAL.

1. Upload all the files to your web server
2. CHMOD 666 settings_sql.php
3. Go to install/index.php in your browser and follow the instructions there
4. Delete the install directory when you are done
5. CHMOD 644 settings_sql.php

After installing, you can log into the admin by going to index.php?a=admin

If these instructions sound confusing, please read the manual for more a more
verbose tutorial.
